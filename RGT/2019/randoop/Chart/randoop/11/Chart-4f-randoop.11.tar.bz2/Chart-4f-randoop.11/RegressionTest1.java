import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot1.getDataset();
        java.util.List list8 = combinedRangeXYPlot1.getAnnotations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (byte) 1, 6, (int) (short) 1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.TOP_OR_RIGHT");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset16 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Number number18 = defaultPieDataset16.getValue(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D19.setTickUnit(numberTickUnit21, true, true);
        java.lang.String str26 = numberTickUnit21.valueToString((double) 2019L);
        try {
            java.lang.String str27 = standardPieSectionLabelGenerator15.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset16, (java.lang.Comparable) numberTickUnit21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: [size=-1]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2,019" + "'", str26.equals("2,019"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        double double2 = categoryAxis3D0.getLowerMargin();
        float float3 = categoryAxis3D0.getTickMarkOutsideLength();
        double double4 = categoryAxis3D0.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.trimHeight(0.0d);
        double double13 = rectangleInsets9.calculateRightInset(1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str15 = categoryAxis3D14.getLabelURL();
        java.awt.Paint paint16 = categoryAxis3D14.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot19.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot19);
        float float22 = jFreeChart21.getBackgroundImageAlpha();
        boolean boolean23 = categoryAxis3D14.hasListener((java.util.EventListener) jFreeChart21);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D29 = chartRenderingInfo28.getChartArea();
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState32 = null;
        categoryAxis3D14.drawTickMarks(graphics2D24, 45.0d, rectangle2D29, rectangleEdge31, axisState32);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets9.createOutsetRectangle(rectangle2D29, true, false);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis38);
        java.awt.Stroke stroke40 = combinedRangeXYPlot39.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot39);
        org.jfree.chart.axis.ValueAxis valueAxis43 = combinedRangeXYPlot39.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean44 = combinedRangeXYPlot39.isNotify();
        org.jfree.chart.StandardChartTheme standardChartTheme46 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle47 = standardChartTheme46.getLabelLinkStyle();
        java.awt.Font font48 = standardChartTheme46.getLargeFont();
        java.awt.Color color49 = java.awt.Color.ORANGE;
        standardChartTheme46.setRangeGridlinePaint((java.awt.Paint) color49);
        combinedRangeXYPlot39.setDomainCrosshairPaint((java.awt.Paint) color49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = combinedRangeXYPlot39.getRangeAxisEdge();
        try {
            double double53 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) (byte) -1, (java.lang.Comparable) 2958465, categoryDataset7, 0.05d, rectangle2D29, rectangleEdge52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle47);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Value", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedRangeXYPlot2.setRenderer(xYItemRenderer3);
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        combinedRangeXYPlot2.setNoDataMessageFont(font6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("{0}", font6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle9.getTextAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor17);
        textTitle9.draw(graphics2D11, rectangle2D15);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D2.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer3D2.getSeriesToolTipGenerator((int) '#');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D10.setFixedDimension((double) 0.5f);
        double double13 = categoryAxis3D10.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.trimHeight(0.0d);
        categoryAxis3D10.setLabelInsets(rectangleInsets14, false);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList20 = new org.jfree.chart.util.ShapeList();
        boolean boolean21 = ringPlot19.equals((java.lang.Object) shapeList20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        java.awt.Stroke stroke27 = combinedRangeXYPlot26.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        float float29 = jFreeChart28.getBackgroundImageAlpha();
        java.awt.Stroke stroke30 = jFreeChart28.getBorderStroke();
        ringPlot19.setSectionOutlineStroke((java.lang.Comparable) year22, stroke30);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator32 = ringPlot19.getToolTipGenerator();
        org.jfree.data.xy.XYDataItem xYDataItem35 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number36 = xYDataItem35.getY();
        double double37 = xYDataItem35.getXValue();
        java.awt.Paint paint38 = ringPlot19.getSectionPaint((java.lang.Comparable) double37);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D43 = chartRenderingInfo42.getChartArea();
        boolean boolean44 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        ringPlot47.clearSectionOutlinePaints(true);
        double double50 = ringPlot47.getInnerSeparatorExtension();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.PiePlotState piePlotState53 = ringPlot19.initialise(graphics2D39, rectangle2D43, (org.jfree.chart.plot.PiePlot) ringPlot47, (java.lang.Integer) 6, plotRenderingInfo52);
        rectangleInsets14.trim(rectangle2D43);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis56);
        java.awt.Stroke stroke58 = combinedRangeXYPlot57.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot57);
        org.jfree.chart.axis.ValueAxis valueAxis61 = combinedRangeXYPlot57.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean62 = combinedRangeXYPlot57.isNotify();
        org.jfree.chart.StandardChartTheme standardChartTheme64 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle65 = standardChartTheme64.getLabelLinkStyle();
        java.awt.Font font66 = standardChartTheme64.getLargeFont();
        java.awt.Color color67 = java.awt.Color.ORANGE;
        standardChartTheme64.setRangeGridlinePaint((java.awt.Paint) color67);
        combinedRangeXYPlot57.setDomainCrosshairPaint((java.awt.Paint) color67);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = combinedRangeXYPlot57.getRangeAxisEdge();
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D2, (int) (short) 10, (int) '#', true, (java.awt.geom.RectangularShape) rectangle2D43, rectangleEdge70, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(pieToolTipGenerator32);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (-1.0d) + "'", number36.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.2d + "'", double50 == 0.2d);
        org.junit.Assert.assertNotNull(piePlotState53);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNull(valueAxis61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle65);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot7.isDomainZoomable();
        int int13 = combinedRangeXYPlot7.getRendererCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setTranslateX(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        piePlot3D0.setDepthFactor(45.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend3 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        java.awt.Paint paint26 = barRenderer3D0.getBaseLegendTextPaint();
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList5 = new org.jfree.chart.util.ShapeList();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) shapeList5);
        java.awt.Paint paint7 = ringPlot4.getLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 100, plotRenderingInfo9);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        java.lang.StringBuffer stringBuffer21 = logFormat15.format((long) 1, stringBuffer19, fieldPosition20);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str27 = logFormat25.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator28 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat25);
        ringPlot4.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis30);
        combinedRangeXYPlot31.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        combinedRangeXYPlot31.setRangeAxisLocation(4, axisLocation36, false);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot31.setBackgroundPaint((java.awt.Paint) color39);
        java.awt.Color color41 = color39.darker();
        ringPlot4.setLabelOutlinePaint((java.awt.Paint) color41);
        ringPlot4.setSeparatorsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "^0.48" + "'", str27.equals("^0.48"));
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint2 = barRenderer3D0.getLegendTextPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.trimHeight(0.0d);
        double double9 = rectangleInsets5.calculateRightInset(1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str11 = categoryAxis3D10.getLabelURL();
        java.awt.Paint paint12 = categoryAxis3D10.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        boolean boolean19 = categoryAxis3D10.hasListener((java.util.EventListener) jFreeChart17);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        boolean boolean26 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState28 = null;
        categoryAxis3D10.drawTickMarks(graphics2D20, 45.0d, rectangle2D25, rectangleEdge27, axisState28);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets5.createOutsetRectangle(rectangle2D25, true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot33.getRenderer();
        java.awt.Stroke stroke35 = categoryPlot33.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str37 = categoryAxis3D36.getLabelURL();
        java.awt.Paint paint38 = categoryAxis3D36.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis40);
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot41);
        float float44 = jFreeChart43.getBackgroundImageAlpha();
        boolean boolean45 = categoryAxis3D36.hasListener((java.util.EventListener) jFreeChart43);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        boolean boolean52 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState54 = null;
        categoryAxis3D36.drawTickMarks(graphics2D46, 45.0d, rectangle2D51, rectangleEdge53, axisState54);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        try {
            barRenderer3D0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D32, categoryPlot33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, categoryDataset58, 2, 8, false, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.5f + "'", float44 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke8 = xYLineAndShapeRenderer4.getItemOutlineStroke((-1), 0, false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        combinedRangeXYPlot11.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedRangeXYPlot11.getRangeAxisIndex(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        combinedRangeXYPlot17.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = combinedRangeXYPlot17.getLegendItems();
        combinedRangeXYPlot11.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot17);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = combinedRangeXYPlot11.getRangeMarkers((int) '#', layer23);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        double double26 = categoryAxis3D25.getCategoryMargin();
        java.awt.Stroke stroke27 = categoryAxis3D25.getAxisLineStroke();
        combinedRangeXYPlot11.setRangeMinorGridlineStroke(stroke27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis30);
        java.awt.Stroke stroke32 = combinedRangeXYPlot31.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int37 = combinedRangeXYPlot31.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer36);
        boolean boolean40 = xYLineAndShapeRenderer36.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer36.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = null;
        java.util.TimeZone timeZone48 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("", timeZone48);
        java.util.TimeZone timeZone51 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("", timeZone51);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection53 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number54 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection53);
        xYLineAndShapeRenderer36.drawItem(graphics2D43, xYItemRendererState44, rectangle2D45, xYPlot46, (org.jfree.chart.axis.ValueAxis) dateAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection53, (int) (short) 0, 4, false, (int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D63 = chartRenderingInfo62.getChartArea();
        boolean boolean64 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D66 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D63, rectangleAnchor65);
        xYLineAndShapeRenderer4.drawDomainGridLine(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) dateAxis52, rectangle2D63, 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D74 = chartRenderingInfo73.getChartArea();
        boolean boolean75 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D74);
        java.awt.geom.Point2D point2D76 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D74);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D78 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D78.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo84 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D85 = chartRenderingInfo84.getChartArea();
        boolean boolean86 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D85);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D88 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D85, rectangleAnchor87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double90 = numberAxis3D78.java2DToValue((double) 0.5f, rectangle2D85, rectangleEdge89);
        org.jfree.chart.axis.AxisSpace axisSpace91 = new org.jfree.chart.axis.AxisSpace();
        axisSpace91.setTop((double) 12);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace94 = categoryAxis0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, rectangle2D74, rectangleEdge89, axisSpace91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(number54);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(point2D66);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(point2D76);
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor87);
        org.junit.Assert.assertNotNull(point2D88);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + Double.POSITIVE_INFINITY + "'", double90 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 24231L);
        java.lang.Comparable comparable2 = xYSeries1.getKey();
        try {
            xYSeries1.updateByIndex((int) 'a', (java.lang.Number) 1900L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 24231L + "'", comparable2.equals(24231L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        java.util.Date date33 = dateAxis23.getMaximumDate();
        dateAxis23.setAxisLineVisible(false);
        try {
            dateAxis23.setRangeWithMargins(90.0d, (double) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (90.0) <= upper (-2.20896E12).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number4 = xYDataItem3.getY();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
        boolean boolean8 = rotation0.equals((java.lang.Object) day6);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str5 = logFormat3.format((java.lang.Object) 3);
        logFormat3.setMaximumFractionDigits(2958465);
        logFormat3.setMaximumIntegerDigits((int) 'a');
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "^0.48" + "'", str5.equals("^0.48"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) 'a');
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot2.getRangeMinorGridlineStroke();
        combinedRangeXYPlot2.setBackgroundImageAlignment(0);
        combinedRangeXYPlot2.setDomainCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = combinedRangeXYPlot15.getDomainAxisIndex(valueAxis16);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = combinedRangeXYPlot15.removeDomainMarker(marker18, layer19);
        boolean boolean21 = combinedRangeXYPlot15.isDomainZoomable();
        combinedRangeXYPlot15.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone25 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("", timeZone25);
        org.jfree.data.Range range27 = combinedRangeXYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.data.Range range28 = combinedRangeXYPlot2.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = combinedRangeXYPlot2.getAxisOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TextBlockAnchor.CENTER_RIGHT", graphics2D1, (float) 12, (float) (-1), (double) 100L, 0.0f, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.zoomRange((double) (short) 0, (double) (byte) 10);
        double double34 = dateAxis23.getUpperBound();
        dateAxis23.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("{0}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key {0}");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        double double10 = blockContainer9.getContentYOffset();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer14.getItemOutlineStroke((-1), 0, false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis20);
        combinedRangeXYPlot21.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        int int25 = combinedRangeXYPlot21.getRangeAxisIndex(valueAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis26);
        combinedRangeXYPlot27.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = combinedRangeXYPlot27.getLegendItems();
        combinedRangeXYPlot21.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot27);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = combinedRangeXYPlot21.getRangeMarkers((int) '#', layer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        double double36 = categoryAxis3D35.getCategoryMargin();
        java.awt.Stroke stroke37 = categoryAxis3D35.getAxisLineStroke();
        combinedRangeXYPlot21.setRangeMinorGridlineStroke(stroke37);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis40);
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot41);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer46 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int47 = combinedRangeXYPlot41.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer46);
        boolean boolean50 = xYLineAndShapeRenderer46.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer46.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = null;
        java.util.TimeZone timeZone58 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("", timeZone58);
        java.util.TimeZone timeZone61 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("", timeZone61);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection63 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number64 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        xYLineAndShapeRenderer46.drawItem(graphics2D53, xYItemRendererState54, rectangle2D55, xYPlot56, (org.jfree.chart.axis.ValueAxis) dateAxis59, (org.jfree.chart.axis.ValueAxis) dateAxis62, (org.jfree.data.xy.XYDataset) timeSeriesCollection63, (int) (short) 0, 4, false, (int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D73 = chartRenderingInfo72.getChartArea();
        boolean boolean74 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D73);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D76 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D73, rectangleAnchor75);
        xYLineAndShapeRenderer14.drawDomainGridLine(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis62, rectangle2D73, 10.0d);
        org.jfree.data.general.SeriesException seriesException80 = new org.jfree.data.general.SeriesException("{0}");
        java.lang.String str81 = seriesException80.toString();
        try {
            java.lang.Object obj82 = blockContainer9.draw(graphics2D11, rectangle2D73, (java.lang.Object) seriesException80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(blockContainer9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.2d + "'", double36 == 0.2d);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(number64);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(point2D76);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "org.jfree.data.general.SeriesException: {0}" + "'", str81.equals("org.jfree.data.general.SeriesException: {0}"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardPieToolTipGenerator0.getPercentFormat();
        java.lang.Object obj2 = standardPieToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int4 = color3.getAlpha();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        standardChartTheme1.setSubtitlePaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYLineAndShapeRenderer15.getLegendItems();
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Stroke stroke21 = legendItem20.getLineStroke();
        java.awt.Stroke stroke22 = legendItem20.getLineStroke();
        legendItem20.setDescription("hi!");
        legendItemCollection18.add(legendItem20);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.ShapeList shapeList8 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean12 = xYSeries10.equals((java.lang.Object) 10.0d);
        boolean boolean13 = shapeList8.equals((java.lang.Object) 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo19.getChartArea();
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D20);
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D20);
        shapeList8.setShape(10, (java.awt.Shape) rectangle2D20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D24.setFixedDimension((double) 0.5f);
        double double27 = categoryAxis3D24.getCategoryMargin();
        java.awt.Paint paint28 = categoryAxis3D24.getAxisLinePaint();
        double double29 = categoryAxis3D24.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.Layer layer32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            barRenderer3D0.drawAnnotations(graphics2D7, rectangle2D20, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis31, layer32, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean5 = xYSeries3.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        xYSeries3.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        double double9 = xYSeries3.getMinY();
        boolean boolean10 = xYSeries3.isEmpty();
        try {
            borderArrangement0.add(block1, (java.lang.Object) boolean10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        double double10 = blockContainer9.getContentXOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(blockContainer9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue((java.lang.Comparable) 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 1.0E-5");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        combinedRangeXYPlot6.setRenderer(xYItemRenderer7);
        java.awt.Paint paint9 = combinedRangeXYPlot6.getDomainMinorGridlinePaint();
        xYAreaRenderer3.setSeriesOutlinePaint((int) (byte) 0, paint9);
        boolean boolean11 = xYAreaRenderer3.getUseFillPaint();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        boolean boolean6 = jFreeChart4.isBorderVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.trimHeight(0.0d);
        periodAxis1.setLabelInsets(rectangleInsets6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = periodAxis1.getFirst();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues11 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 100);
        defaultKeyedValues11.setValue((java.lang.Comparable) year13, (java.lang.Number) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets16.trimHeight(0.0d);
        double double20 = rectangleInsets16.calculateRightInset(1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str22 = categoryAxis3D21.getLabelURL();
        java.awt.Paint paint23 = categoryAxis3D21.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        java.awt.Stroke stroke27 = combinedRangeXYPlot26.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        float float29 = jFreeChart28.getBackgroundImageAlpha();
        boolean boolean30 = categoryAxis3D21.hasListener((java.util.EventListener) jFreeChart28);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo35.getChartArea();
        boolean boolean37 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState39 = null;
        categoryAxis3D21.drawTickMarks(graphics2D31, 45.0d, rectangle2D36, rectangleEdge38, axisState39);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets16.createOutsetRectangle(rectangle2D36, true, false);
        boolean boolean44 = year13.equals((java.lang.Object) rectangle2D36);
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) year13);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList3 = new org.jfree.chart.util.ShapeList();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) shapeList3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        float float12 = jFreeChart11.getBackgroundImageAlpha();
        java.awt.Stroke stroke13 = jFreeChart11.getBorderStroke();
        ringPlot2.setSectionOutlineStroke((java.lang.Comparable) year5, stroke13);
        java.awt.Stroke stroke15 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) year5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(stroke15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedRangeXYPlot1.getRenderer();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        int int5 = combinedRangeXYPlot1.getWeight();
        java.awt.Paint paint7 = combinedRangeXYPlot1.getQuadrantPaint(2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        polarPlot0.setAngleLabelsVisible(false);
        org.junit.Assert.assertNotNull(tickUnit1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis();
        double double9 = logAxis8.getFixedDimension();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        try {
            barRenderer3D0.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D5, categoryPlot6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) logAxis8, categoryDataset10, 0, 255, false, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        intervalXYDelegate8.setAutoWidth(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedRangeXYPlot1.zoomRangeAxes(Double.NaN, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot12.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint15 = defaultDrawingSupplier14.getNextFillPaint();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier14);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str22 = categoryAxis3D21.getLabelURL();
        java.awt.Paint paint23 = categoryAxis3D21.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        java.awt.Stroke stroke27 = combinedRangeXYPlot26.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        float float29 = jFreeChart28.getBackgroundImageAlpha();
        boolean boolean30 = categoryAxis3D21.hasListener((java.util.EventListener) jFreeChart28);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo35.getChartArea();
        boolean boolean37 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState39 = null;
        categoryAxis3D21.drawTickMarks(graphics2D31, 45.0d, rectangle2D36, rectangleEdge38, axisState39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D46 = chartRenderingInfo45.getChartArea();
        boolean boolean47 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D46);
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D46);
        org.jfree.chart.plot.PlotState plotState49 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        try {
            combinedRangeXYPlot1.draw(graphics2D20, rectangle2D36, point2D48, plotState49, plotRenderingInfo50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(point2D48);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint7 = barRenderer3D0.getShadowPaint();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.data.Range range9 = barRenderer3D0.findRangeBounds(categoryDataset8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = null;
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis(6, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            categoryPlot0.handleClick((int) (short) 0, 13, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.isEmpty();
        java.util.List list5 = xYSeries1.getItems();
        org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries1.addOrUpdate((java.lang.Number) 10.0d, (java.lang.Number) 90.0d);
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number12 = xYDataItem11.getY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem11);
        xYDataItem11.setSelected(true);
        xYSeries1.add(xYDataItem11);
        xYDataItem11.setY((double) 1560409200000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(xYDataItem8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        java.awt.Paint paint11 = jFreeChart9.getBackgroundPaint();
        combinedRangeXYPlot1.setDomainCrosshairPaint(paint11);
        java.awt.Paint paint13 = combinedRangeXYPlot1.getOutlinePaint();
        java.awt.Paint paint14 = combinedRangeXYPlot1.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        combinedRangeXYPlot1.setRenderer(0, xYItemRenderer9, true);
        combinedRangeXYPlot1.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = null;
        xYStepAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator1);
        xYStepAreaRenderer0.setShapesFilled(true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        org.jfree.chart.plot.Marker marker4 = null;
        try {
            combinedRangeXYPlot1.addRangeMarker(marker4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList5 = new org.jfree.chart.util.ShapeList();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) shapeList5);
        java.awt.Paint paint7 = ringPlot4.getLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 100, plotRenderingInfo9);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        java.lang.StringBuffer stringBuffer21 = logFormat15.format((long) 1, stringBuffer19, fieldPosition20);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str27 = logFormat25.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator28 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat25);
        ringPlot4.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis30);
        combinedRangeXYPlot31.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        combinedRangeXYPlot31.setRangeAxisLocation(4, axisLocation36, false);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot31.setBackgroundPaint((java.awt.Paint) color39);
        java.awt.Color color41 = color39.darker();
        ringPlot4.setLabelOutlinePaint((java.awt.Paint) color41);
        ringPlot4.setSectionOutlinesVisible(false);
        java.awt.Paint paint45 = null;
        try {
            ringPlot4.setBaseSectionOutlinePaint(paint45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "^0.48" + "'", str27.equals("^0.48"));
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD");
        textTitle1.setURLText("{0}");
        boolean boolean4 = textTitle1.isVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int18 = combinedRangeXYPlot12.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.calculateRightInset((double) 10.0f);
        combinedRangeXYPlot12.setInsets(rectangleInsets19, true);
        combinedRangeXYPlot7.setAxisOffset(rectangleInsets19);
        boolean boolean25 = textTitle1.equals((java.lang.Object) rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int19 = color18.getAlpha();
        java.awt.color.ColorSpace colorSpace20 = color18.getColorSpace();
        xYLineAndShapeRenderer7.setBaseOutlinePaint((java.awt.Paint) color18);
        boolean boolean22 = xYLineAndShapeRenderer7.getAutoPopulateSeriesPaint();
        xYLineAndShapeRenderer7.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = xYLineAndShapeRenderer7.getNegativeItemLabelPosition((int) '4', 2, true);
        double double29 = itemLabelPosition28.getAngle();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        int int1 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 13);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedRangeXYPlot1.getInsets();
        double double5 = rectangleInsets4.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot1.panDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        combinedRangeXYPlot9.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot9.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        combinedRangeXYPlot9.setRangeAxisLocation(4, axisLocation14, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot9.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot20.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextFillPaint();
        categoryPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot20.getDomainAxisLocation(1);
        combinedRangeXYPlot9.setDomainAxisLocation(2019, axisLocation26, true);
        combinedRangeXYPlot1.setDomainAxisLocation(axisLocation26, false);
        java.awt.Paint paint31 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1900);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1884.0d + "'", double2 == 1884.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.zoomRange((double) (short) 0, (double) (byte) 10);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.trimHeight(0.0d);
        double double41 = rectangleInsets37.calculateRightInset(1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str43 = categoryAxis3D42.getLabelURL();
        java.awt.Paint paint44 = categoryAxis3D42.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot47 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis46);
        java.awt.Stroke stroke48 = combinedRangeXYPlot47.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot47);
        float float50 = jFreeChart49.getBackgroundImageAlpha();
        boolean boolean51 = categoryAxis3D42.hasListener((java.util.EventListener) jFreeChart49);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D57 = chartRenderingInfo56.getChartArea();
        boolean boolean58 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D57);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState60 = null;
        categoryAxis3D42.drawTickMarks(graphics2D52, 45.0d, rectangle2D57, rectangleEdge59, axisState60);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets37.createOutsetRectangle(rectangle2D57, true, false);
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot66 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis65);
        combinedRangeXYPlot66.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder69 = combinedRangeXYPlot66.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation71 = null;
        combinedRangeXYPlot66.setRangeAxisLocation(4, axisLocation71, false);
        java.awt.Color color74 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot66.setBackgroundPaint((java.awt.Paint) color74);
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = categoryPlot77.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier79 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint80 = defaultDrawingSupplier79.getNextFillPaint();
        categoryPlot77.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier79);
        org.jfree.chart.axis.AxisLocation axisLocation83 = categoryPlot77.getDomainAxisLocation(1);
        combinedRangeXYPlot66.setDomainAxisLocation(2019, axisLocation83, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation86 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj87 = null;
        boolean boolean88 = plotOrientation86.equals(obj87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation83, plotOrientation86);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo90 = null;
        try {
            org.jfree.chart.axis.AxisState axisState91 = dateAxis23.draw(graphics2D34, (double) 2.0f, rectangle2D36, rectangle2D57, rectangleEdge89, plotRenderingInfo90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.5f + "'", float50 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(seriesRenderingOrder69);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNull(categoryItemRenderer78);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(axisLocation83);
        org.junit.Assert.assertNotNull(plotOrientation86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(rectangleEdge89);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.awt.Font font1 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, 0.0f, textMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        double double10 = size2D9.getHeight();
        double double11 = size2D9.height;
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textFragment1.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Paint paint2 = null;
        legendItem1.setLabelPaint(paint2);
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList();
        boolean boolean5 = legendItem1.equals((java.lang.Object) objectList4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.awt.Paint paint14 = xYLineAndShapeRenderer7.lookupSeriesPaint(1900);
        java.awt.Stroke stroke16 = xYLineAndShapeRenderer7.getSeriesStroke((int) (short) 100);
        xYLineAndShapeRenderer7.setSeriesVisible(2, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(stroke16);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) ' ');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        int int7 = year4.getYear();
        long long8 = year4.getLastMillisecond();
        java.util.Date date9 = year4.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date11 = dateTickUnit3.rollDate(date9, timeZone10);
        java.util.Locale locale12 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("Multiple Pie Plot", timeZone10, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        boolean boolean2 = categoryAxis3D0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 0.2d);
        java.awt.Font font5 = null;
        try {
            categoryAxis3D0.setLabelFont(font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-2208960000000L), 0.0f, 2.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.isEmpty();
        java.util.List list5 = xYSeries1.getItems();
        org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries1.addOrUpdate((java.lang.Number) (short) -1, (java.lang.Number) Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(xYDataItem8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font1, paint2, (float) (byte) 1);
        java.awt.Font font5 = textFragment4.getFont();
        java.awt.Paint paint6 = textFragment4.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.getAutoSort();
        xYSeries1.clear();
        java.lang.Object obj6 = xYSeries1.clone();
        xYSeries1.add(Double.POSITIVE_INFINITY, (java.lang.Number) 10.0d, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = jFreeChart4.getPadding();
        double double8 = rectangleInsets6.calculateTopInset(0.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepAreaRenderer1.getSeriesToolTipGenerator(1900);
        xYStepAreaRenderer1.setShapesVisible(true);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection3 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint7 = barRenderer3D0.getShadowPaint();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.data.Range range9 = barRenderer3D0.findRangeBounds(categoryDataset8);
        barRenderer3D0.setShadowXOffset(10.0d);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int9 = combinedRangeXYPlot3.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer8);
        java.awt.Shape shape11 = xYLineAndShapeRenderer8.getSeriesShape(10);
        boolean boolean13 = xYLineAndShapeRenderer8.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean15 = xYLineAndShapeRenderer8.getSeriesVisibleInLegend((int) (short) 10);
        boolean boolean16 = strokeList0.equals((java.lang.Object) xYLineAndShapeRenderer8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYLineAndShapeRenderer8.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer3D0.getSeriesToolTipGenerator((int) '#');
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes((double) 1900L, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean17 = range14.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(range14);
        numberAxis3D13.setRangeWithMargins((org.jfree.data.Range) dateRange18, false, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis3D13.setMarkerBand(markerAxisBand22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets24.trimHeight(0.0d);
        double double28 = rectangleInsets24.calculateRightInset(1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str30 = categoryAxis3D29.getLabelURL();
        java.awt.Paint paint31 = categoryAxis3D29.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis33);
        java.awt.Stroke stroke35 = combinedRangeXYPlot34.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot34);
        float float37 = jFreeChart36.getBackgroundImageAlpha();
        boolean boolean38 = categoryAxis3D29.hasListener((java.util.EventListener) jFreeChart36);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D44 = chartRenderingInfo43.getChartArea();
        boolean boolean45 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState47 = null;
        categoryAxis3D29.drawTickMarks(graphics2D39, 45.0d, rectangle2D44, rectangleEdge46, axisState47);
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets24.createOutsetRectangle(rectangle2D44, true, false);
        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer55 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer55.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator57 = xYAreaRenderer55.getBaseToolTipGenerator();
        java.awt.Stroke stroke61 = xYAreaRenderer55.getItemStroke(1, 1, false);
        barRenderer3D0.drawRangeLine(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, rectangle2D44, (double) (byte) 10, (java.awt.Paint) color53, stroke61);
        org.jfree.chart.axis.ValueAxis valueAxis64 = categoryPlot6.getRangeAxis(5);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNull(xYToolTipGenerator57);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNull(valueAxis64);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        combinedRangeXYPlot1.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("", timeZone11);
        org.jfree.data.Range range13 = combinedRangeXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.util.Date date14 = dateAxis12.getMaximumDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("rect");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        boolean boolean1 = logAxis0.isVerticalTickLabels();
        logAxis0.setUpperBound(0.0d);
        java.awt.Font font4 = null;
        try {
            logAxis0.setLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Paint paint2 = null;
        legendItem1.setLabelPaint(paint2);
        java.lang.Object obj4 = legendItem1.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYStepAreaRenderer1.getToolTipGenerator((int) 'a', (int) (byte) 100, true);
        java.lang.Boolean boolean8 = xYStepAreaRenderer1.getSeriesVisible((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int17 = combinedRangeXYPlot11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer16);
        java.awt.Shape shape19 = xYLineAndShapeRenderer16.getSeriesShape(10);
        boolean boolean21 = xYLineAndShapeRenderer16.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean23 = xYLineAndShapeRenderer16.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer16.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str27 = categoryAxis3D26.getLabelURL();
        java.awt.Paint paint28 = categoryAxis3D26.getLabelPaint();
        xYLineAndShapeRenderer16.setBaseItemLabelPaint(paint28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYLineAndShapeRenderer16.getSeriesPositiveItemLabelPosition((int) 'a');
        xYStepAreaRenderer1.setBaseNegativeItemLabelPosition(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.isEmpty();
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(100.0d, 0.025d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection4);
        double double7 = xYSeries1.getMinY();
        boolean boolean8 = xYSeries1.isEmpty();
        int int10 = xYSeries1.indexOf((java.lang.Number) 255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedRangeXYPlot2.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int13 = combinedRangeXYPlot7.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) 10.0f);
        combinedRangeXYPlot7.setInsets(rectangleInsets14, true);
        combinedRangeXYPlot2.setAxisOffset(rectangleInsets14);
        combinedRangeXYPlot2.setBackgroundImageAlignment((-1));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getCrosshairX();
        crosshairState0.setCrosshairX((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme1.setErrorIndicatorPaint(paint2);
        java.awt.Paint paint4 = standardChartTheme1.getTickLabelPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme1.setSubtitlePaint(paint5);
        java.awt.Paint paint7 = standardChartTheme1.getRangeGridlinePaint();
        java.awt.Font font8 = standardChartTheme1.getExtraLargeFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("org.jfree.data.general.SeriesException: {0}", paint8);
        java.lang.Comparable comparable10 = legendItem9.getSeriesKey();
        java.lang.Object obj11 = legendItem9.clone();
        boolean boolean12 = legendItem9.isLineVisible();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) 100L, (double) 4, 0);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        boolean boolean10 = jFreeChart9.getAntiAlias();
        boolean boolean11 = defaultPieDataset0.equals((java.lang.Object) jFreeChart9);
        jFreeChart9.setNotify(false);
        java.awt.Image image14 = jFreeChart9.getBackgroundImage();
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(image14);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
//        ringPlot0.clearSectionOutlinePaints(true);
//        double double3 = ringPlot0.getInnerSeparatorExtension();
//        java.awt.Image image4 = null;
//        ringPlot0.setBackgroundImage(image4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        long long8 = day6.getLastMillisecond();
//        java.awt.Paint paint9 = null;
//        ringPlot0.setSectionPaint((java.lang.Comparable) day6, paint9);
//        ringPlot0.setIgnoreZeroValues(false);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getOutlineStroke();
        numberAxis3D1.setTickMarkStroke(stroke6);
        numberAxis3D1.setMinorTickCount((int) '#');
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setRangeDescription("PieLabelLinkStyle.STANDARD");
        java.lang.String str8 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Number number4 = defaultPieDataset2.getValue(0);
        ringPlot1.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset2);
        boolean boolean6 = ringPlot1.getSimpleLabels();
        java.awt.Paint paint7 = ringPlot1.getLabelBackgroundPaint();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer3D5.getBarPainter();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D9.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer3D9.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint16 = barRenderer3D9.getShadowPaint();
        categoryPlot8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D19.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo25.getChartArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor28);
        barRenderer3D5.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, marker22, rectangle2D26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState33 = null;
        boolean boolean34 = categoryPlot0.render(graphics2D4, rectangle2D26, 8, plotRenderingInfo32, categoryCrosshairState33);
        java.lang.Comparable comparable35 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot0.getRangeAxisLocation(32);
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(barPainter6);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(comparable35);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.getAutoPopulateSectionPaint();
        boolean boolean3 = ringPlot1.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.trimHeight(0.0d);
        double double8 = rectangleInsets4.calculateRightInset(1.0d);
        ringPlot1.setLabelPadding(rectangleInsets4);
        int int10 = objectList0.indexOf((java.lang.Object) ringPlot1);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme13.setErrorIndicatorPaint(paint14);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(paint14);
        boolean boolean17 = textAnchor11.equals((java.lang.Object) paint14);
        int int18 = objectList0.indexOf((java.lang.Object) paint14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint3 = standardChartTheme1.getLegendBackgroundPaint();
        java.awt.Paint paint4 = standardChartTheme1.getTitlePaint();
        java.awt.Paint paint5 = null;
        try {
            standardChartTheme1.setGridBandPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        java.awt.Stroke stroke6 = xYAreaRenderer1.getItemStroke((-1), (int) (short) 10, false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepAreaRenderer1.getSeriesToolTipGenerator(1900);
        boolean boolean4 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.lang.Number number4 = null;
        defaultPieDataset0.insertValue(0, (java.lang.Comparable) "DomainOrder.NONE", number4);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator31 = xYLineAndShapeRenderer7.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(xYToolTipGenerator31);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.getLegendShape((int) '#');
        boolean boolean3 = xYAreaRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("^0.48");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "^0.48" + "'", str2.equals("^0.48"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(sortOrder1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        ringPlot0.setLabelShadowPaint(paint4);
        int int6 = ringPlot0.getPieIndex();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        try {
            java.awt.Paint paint13 = combinedRangeXYPlot7.getQuadrantPaint(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (8) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setCrosshairDatasetIndex(2958465, false);
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        jFreeChart4.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo12.getChartArea();
        try {
            java.awt.image.BufferedImage bufferedImage14 = jFreeChart4.createBufferedImage((int) (short) -1, (int) (short) 0, (double) '#', (double) 24231L, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        combinedRangeXYPlot5.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedRangeXYPlot5.panDomainAxes((double) 0, plotRenderingInfo9, point2D10);
        float float12 = combinedRangeXYPlot5.getForegroundAlpha();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedRangeXYPlot5.getRenderer();
        boolean boolean14 = standardXYToolTipGenerator1.equals((java.lang.Object) xYItemRenderer13);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        xYLineAndShapeRenderer7.setBaseLinesVisible(true);
        xYLineAndShapeRenderer7.setAutoPopulateSeriesStroke(true);
        xYLineAndShapeRenderer7.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(blockContainer9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis(6, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.lightGray;
        categoryPlot6.setDomainCrosshairPaint((java.awt.Paint) color7);
        categoryPlot6.setAnchorValue((double) 1L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor18);
        categoryPlot6.zoomDomainAxes((double) 100, plotRenderingInfo12, point2D19);
        categoryPlot0.zoomRangeAxes(0.05d, plotRenderingInfo5, point2D19, false);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            boolean boolean26 = categoryPlot0.removeRangeMarker((int) ' ', marker24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            timeSeriesCollection2.removeSeries(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 2958465, "VerticalAlignment.CENTER", textAnchor3, textAnchor4, (double) 60000L);
        java.lang.Number number7 = numberTick6.getNumber();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 2958465.0d + "'", number7.equals(2958465.0d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("SeriesRenderingOrder.REVERSE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat5.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        java.lang.StringBuffer stringBuffer11 = logFormat5.format((long) 1, stringBuffer9, fieldPosition10);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat15);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset17 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset17);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset19 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Number number21 = defaultPieDataset19.getValue(0);
        ringPlot18.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset19);
        java.text.AttributedString attributedString24 = standardPieSectionLabelGenerator16.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset19, (java.lang.Comparable) 1577865599999L);
        piePlot3D0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(stringBuffer11);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNull(attributedString24);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) ' ');
        boolean boolean4 = defaultPieDataset0.equals((java.lang.Object) dateTickUnit3);
        int int5 = dateTickUnit3.getRollMultiple();
        java.lang.String str7 = dateTickUnit3.valueToString((double) 1L);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12/31/69" + "'", str7.equals("12/31/69"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
        centerArrangement0.clear();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer3D5.getBarPainter();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D9.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer3D9.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint16 = barRenderer3D9.getShadowPaint();
        categoryPlot8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D19.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo25.getChartArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor28);
        barRenderer3D5.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, marker22, rectangle2D26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState33 = null;
        boolean boolean34 = categoryPlot0.render(graphics2D4, rectangle2D26, 8, plotRenderingInfo32, categoryCrosshairState33);
        categoryPlot0.setCrosshairDatasetIndex(40, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            categoryPlot0.handleClick(0, 2958465, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(barPainter6);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYLineAndShapeRenderer15.getLegendItems();
        xYLineAndShapeRenderer15.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendItemCollection18);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer7.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str18 = categoryAxis3D17.getLabelURL();
        java.awt.Paint paint19 = categoryAxis3D17.getLabelPaint();
        xYLineAndShapeRenderer7.setBaseItemLabelPaint(paint19);
        boolean boolean21 = xYLineAndShapeRenderer7.getUseOutlinePaint();
        boolean boolean22 = xYLineAndShapeRenderer7.getUseFillPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomDomainAxes((double) 1900L, plotRenderingInfo2, point2D3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        boolean boolean8 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D10.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer3D10.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint17 = barRenderer3D10.getShadowPaint();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = barRenderer3D10.getBaseItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Stroke stroke22 = legendItem21.getLineStroke();
        java.awt.Stroke stroke23 = legendItem21.getLineStroke();
        boolean boolean24 = barRenderer3D10.equals((java.lang.Object) legendItem21);
        java.awt.Paint paint28 = barRenderer3D10.getItemLabelPaint(2019, 2, false);
        categoryPlot0.setRangeGridlinePaint(paint28);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("AxisLocation.TOP_OR_RIGHT", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int19 = color18.getAlpha();
        java.awt.color.ColorSpace colorSpace20 = color18.getColorSpace();
        xYLineAndShapeRenderer7.setBaseOutlinePaint((java.awt.Paint) color18);
        boolean boolean22 = xYLineAndShapeRenderer7.getAutoPopulateSeriesPaint();
        java.awt.Shape shape24 = xYLineAndShapeRenderer7.getSeriesShape(0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(shape24);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 100);
        defaultKeyedValues0.setValue((java.lang.Comparable) year2, (java.lang.Number) (-1.0f));
        try {
            java.lang.Number number6 = defaultKeyedValues0.getValue(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        boolean boolean5 = combinedRangeXYPlot1.equals((java.lang.Object) ' ');
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot1.getDataset((int) (short) 1);
        combinedRangeXYPlot1.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(xYDataset7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        double double8 = combinedRangeXYPlot1.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace9 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setDomainCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = null;
        try {
            combinedRangeXYPlot1.setOrientation(plotOrientation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(3, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) regularTimePeriod9, true);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Stroke stroke7 = xYAreaRenderer1.getItemStroke(1, 1, false);
        xYAreaRenderer1.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = xYAreaRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint15 = xYAreaRenderer1.getItemFillPaint(13, 8, false);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        boolean boolean9 = jFreeChart8.getAntiAlias();
        jFreeChart8.setTitle("hi!");
        java.awt.Paint paint12 = jFreeChart8.getBackgroundPaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint12);
        java.lang.Object obj14 = categoryPlot0.clone();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(0.025d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.StandardChartTheme standardChartTheme9 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = standardChartTheme9.getLabelLinkStyle();
        java.awt.Font font11 = standardChartTheme9.getLargeFont();
        java.awt.Color color12 = java.awt.Color.ORANGE;
        standardChartTheme9.setRangeGridlinePaint((java.awt.Paint) color12);
        combinedRangeXYPlot2.setDomainCrosshairPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.AxisSpace axisSpace15 = combinedRangeXYPlot2.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        combinedRangeXYPlot1.clearRangeAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number6 = xYDataItem5.getY();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem5);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(3, year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate(regularTimePeriod12, (double) 60000L);
        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale16 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("PieLabelLinkStyle.STANDARD", regularTimePeriod2, regularTimePeriod12, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis(6, 0);
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        xYAreaRenderer1.setBaseItemLabelsVisible(false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        boolean boolean9 = jFreeChart8.getAntiAlias();
        jFreeChart8.setTitle("hi!");
        java.awt.Paint paint12 = jFreeChart8.getBackgroundPaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot16.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        combinedRangeXYPlot16.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        combinedRangeXYPlot16.zoomRangeAxes((double) (short) 1, plotRenderingInfo22, point2D23, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot16.setRangeAxes(valueAxisArray26);
        categoryPlot0.setRangeAxes(valueAxisArray26);
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(valueAxisArray26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.util.List list2 = defaultPieDataset0.getKeys();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset3 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) defaultPieDataset0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Font font1 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, 0.0f, textMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        org.jfree.chart.text.TextLine textLine10 = textBlock7.getLastLine();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock7.calculateDimensions(graphics2D11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNull(textLine10);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot0.setRangeAxis(valueAxis10);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 24231L, false);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers(layer15);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Paint paint2 = null;
        legendItem1.setLabelPaint(paint2);
        boolean boolean4 = legendItem1.isShapeFilled();
        java.awt.Paint paint5 = legendItem1.getLinePaint();
        java.lang.String str6 = legendItem1.getDescription();
        legendItem1.setSeriesIndex((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        int int2 = timeSeriesCollection0.getSeriesCount();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            timeSeriesCollection0.removeSeries(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset6 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, (int) ' ');
        boolean boolean10 = defaultPieDataset6.equals((java.lang.Object) dateTickUnit9);
        int int11 = dateTickUnit9.getRollMultiple();
        tickUnits4.add((org.jfree.chart.axis.TickUnit) dateTickUnit9);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        segmentedTimeline3.setAdjustForDaylightSaving(true);
        java.lang.Object obj8 = segmentedTimeline3.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(3, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate(regularTimePeriod9, (double) 60000L);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection13);
        java.util.List list15 = timeSeriesCollection13.getSeries();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis(6, 0);
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) itemLabelAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder4.getInsets();
        categoryPlot0.setAxisOffset(rectangleInsets7);
        double double10 = rectangleInsets7.trimHeight(1.0d);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomDomainAxes((double) 1900L, plotRenderingInfo2, point2D3, false);
        java.lang.Comparable comparable6 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot0.addDomainMarker(6, categoryMarker8, layer9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        double double8 = combinedRangeXYPlot1.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace9 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        boolean boolean10 = combinedRangeXYPlot1.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        java.awt.Paint paint3 = ringPlot0.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = ringPlot0.getSimpleLabelOffset();
        double double5 = ringPlot0.getStartAngle();
        java.awt.Stroke stroke6 = ringPlot0.getLabelOutlineStroke();
        java.lang.Comparable comparable7 = null;
        try {
            ringPlot0.setExplodePercent(comparable7, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        int int10 = barRenderer3D1.getRowCount();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot12.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        combinedRangeXYPlot15.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedRangeXYPlot15.getInsets();
        org.jfree.chart.util.ShapeList shapeList19 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean23 = xYSeries21.equals((java.lang.Object) 10.0d);
        boolean boolean24 = shapeList19.equals((java.lang.Object) 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D31 = chartRenderingInfo30.getChartArea();
        boolean boolean32 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D31);
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D31);
        shapeList19.setShape(10, (java.awt.Shape) rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets18.createOutsetRectangle(rectangle2D31);
        try {
            barRenderer3D1.drawOutline(graphics2D11, categoryPlot12, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean11 = xYLineAndShapeRenderer7.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator13 = xYLineAndShapeRenderer7.getSeriesItemLabelGenerator(15);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(xYItemLabelGenerator13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        java.awt.Shape shape4 = multiplePiePlot1.getLegendItemShape();
        java.lang.String str5 = multiplePiePlot1.getPlotType();
        java.lang.String str6 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Multiple Pie Plot" + "'", str5.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        boolean boolean9 = jFreeChart8.getAntiAlias();
        standardChartTheme1.apply(jFreeChart8);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        strokeMap0.clear();
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.clearSectionOutlineStrokes(true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year1);
        int int4 = month3.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        standardChartTheme1.setSubtitlePaint((java.awt.Paint) color6);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset8 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset8);
        java.awt.Paint paint10 = ringPlot9.getBaseSectionPaint();
        standardChartTheme1.setLegendBackgroundPaint(paint10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = xYItemRendererState1.getSelectionState();
        org.junit.Assert.assertNull(xYDatasetSelectionState2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot1.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        combinedRangeXYPlot9.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot9.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        combinedRangeXYPlot9.setRangeAxisLocation(4, axisLocation14, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot9.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot20.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextFillPaint();
        categoryPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot20.getDomainAxisLocation(1);
        combinedRangeXYPlot9.setDomainAxisLocation(2019, axisLocation26, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj30 = null;
        boolean boolean31 = plotOrientation29.equals(obj30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation26, plotOrientation29);
        combinedRangeXYPlot1.setOrientation(plotOrientation29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection4);
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeriesCollection4.getSeries((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList5 = new org.jfree.chart.util.ShapeList();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) shapeList5);
        java.awt.Paint paint7 = ringPlot4.getLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 100, plotRenderingInfo9);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        java.lang.StringBuffer stringBuffer21 = logFormat15.format((long) 1, stringBuffer19, fieldPosition20);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str27 = logFormat25.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator28 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat25);
        ringPlot4.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis30);
        combinedRangeXYPlot31.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        combinedRangeXYPlot31.setRangeAxisLocation(4, axisLocation36, false);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot31.setBackgroundPaint((java.awt.Paint) color39);
        java.awt.Color color41 = color39.darker();
        ringPlot4.setLabelOutlinePaint((java.awt.Paint) color41);
        ringPlot4.setSectionOutlinesVisible(false);
        java.lang.Object obj45 = ringPlot4.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "^0.48" + "'", str27.equals("^0.48"));
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int9 = combinedRangeXYPlot3.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot3.getRangeMinorGridlineStroke();
        combinedRangeXYPlot3.setBackgroundImageAlignment(0);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        categoryPlot0.setAnchorValue((double) 1L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo9.getChartArea();
        boolean boolean11 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor12);
        categoryPlot0.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D13);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot0.addRangeMarker(6, marker16, layer17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(point2D13);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSimpleLabels(true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries(comparable0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getSerialIndex();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        java.util.Date date5 = year0.getEnd();
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str16 = logFormat14.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        java.lang.String str18 = standardPieToolTipGenerator17.getLabelFormat();
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "^0.48" + "'", str16.equals("^0.48"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Combined Range XYPlot" + "'", str18.equals("Combined Range XYPlot"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeries4.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        timeSeries4.setDomainDescription("ClassContext");
        java.lang.String str14 = timeSeries4.getRangeDescription();
        java.lang.Object obj15 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        long long1 = dateRange0.getLowerMillis();
        double double2 = dateRange0.getLowerBound();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(range0);
        java.lang.String str5 = dateRange4.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        java.lang.String str5 = seriesRenderingOrder4.toString();
        java.lang.String str6 = seriesRenderingOrder4.toString();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, (int) ' ');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        long long12 = year10.getSerialIndex();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        java.util.Date date15 = year10.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date17 = dateTickUnit9.rollDate(date15, timeZone16);
        boolean boolean18 = seriesRenderingOrder4.equals((java.lang.Object) date15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str5.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str6.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesLinesVisible((int) (short) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer7.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = xYLineAndShapeRenderer7.getToolTipGenerator((int) (byte) -1, (int) (short) 1, true);
        org.jfree.data.UnknownKeyException unknownKeyException22 = new org.jfree.data.UnknownKeyException("");
        java.lang.String str23 = unknownKeyException22.toString();
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("{0}");
        unknownKeyException22.addSuppressed((java.lang.Throwable) seriesException25);
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYToolTipGenerator20, (java.lang.Object) seriesException25);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertNull(xYToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.UnknownKeyException: " + "'", str23.equals("org.jfree.data.UnknownKeyException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        java.util.Date date33 = dateAxis23.getMaximumDate();
        double double34 = dateAxis23.getFixedDimension();
        dateAxis23.setTickMarkOutsideLength(0.5f);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType37 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType37, (int) ' ');
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
        long long42 = year40.getSerialIndex();
        int int43 = year40.getYear();
        long long44 = year40.getLastMillisecond();
        java.util.Date date45 = year40.getEnd();
        java.util.TimeZone timeZone46 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date47 = dateTickUnit39.rollDate(date45, timeZone46);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        boolean boolean52 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D51);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis53);
        combinedRangeXYPlot54.setRangeCrosshairValue((double) (short) 100);
        float float57 = combinedRangeXYPlot54.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = combinedRangeXYPlot54.getRangeAxisEdge(3);
        double double60 = dateAxis23.dateToJava2D(date45, rectangle2D51, rectangleEdge59);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnitType37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 1.0f + "'", float57 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        combinedRangeXYPlot1.setDomainCrosshairVisible(true);
        combinedRangeXYPlot1.configureDomainAxes();
        int int8 = combinedRangeXYPlot1.getWeight();
        java.awt.Paint paint9 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot1.getRangeMarkers((int) (byte) -1, layer11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.lang.Boolean boolean19 = xYLineAndShapeRenderer7.getSeriesLinesVisible(8);
        boolean boolean20 = xYLineAndShapeRenderer7.getBaseShapesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        double double2 = categoryAxis3D0.getFixedDimension();
        int int3 = categoryAxis3D0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        int int4 = defaultPieDataset0.getIndex((java.lang.Comparable) "Combined Range XYPlot");
        try {
            defaultPieDataset0.remove((java.lang.Comparable) 0.5f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (0.5) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.lang.Boolean boolean19 = xYLineAndShapeRenderer7.getSeriesLinesVisible(8);
        boolean boolean20 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = combinedRangeXYPlot9.getDomainAxisIndex(valueAxis10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = combinedRangeXYPlot9.removeDomainMarker(marker12, layer13);
        boolean boolean15 = combinedRangeXYPlot9.isDomainZoomable();
        combinedRangeXYPlot9.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        org.jfree.data.Range range21 = combinedRangeXYPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.Range range22 = combinedRangeXYPlot2.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double24 = range23.getUpperBound();
        dateAxis20.setRangeWithMargins(range23, true, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            double double6 = timeSeriesCollection0.getStartXValue((int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer7.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str18 = categoryAxis3D17.getLabelURL();
        java.awt.Paint paint19 = categoryAxis3D17.getLabelPaint();
        xYLineAndShapeRenderer7.setBaseItemLabelPaint(paint19);
        boolean boolean21 = xYLineAndShapeRenderer7.getBaseShapesFilled();
        boolean boolean22 = xYLineAndShapeRenderer7.getDrawOutlines();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer7.getSeriesURLGenerator(3);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis(6, 0);
        java.awt.Paint paint4 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, (-1), 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        org.jfree.chart.StandardChartTheme standardChartTheme4 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = standardChartTheme4.getLabelLinkStyle();
        java.awt.Font font6 = standardChartTheme4.getLargeFont();
        java.awt.Paint paint7 = standardChartTheme4.getDomainGridlinePaint();
        java.awt.Paint paint8 = standardChartTheme4.getLabelLinkPaint();
        barRenderer3D0.setSeriesOutlinePaint(0, paint8);
        java.awt.Paint paint13 = barRenderer3D0.getItemLabelPaint(0, 2, true);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("rect");
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(8, xYToolTipGenerator1, xYURLGenerator2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        java.lang.String str2 = numberTickUnit1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=-1]" + "'", str2.equals("[size=-1]"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = standardChartTheme1.getGridBandAlternatePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset16 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset16);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset18 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Number number20 = defaultPieDataset18.getValue(0);
        ringPlot17.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset18);
        java.text.AttributedString attributedString23 = standardPieSectionLabelGenerator15.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset18, (java.lang.Comparable) 1577865599999L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D24.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = barRenderer3D24.getSeriesToolTipGenerator((int) '#');
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot30.zoomDomainAxes((double) 1900L, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean41 = range38.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange(range38);
        numberAxis3D37.setRangeWithMargins((org.jfree.data.Range) dateRange42, false, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis3D37.setMarkerBand(markerAxisBand46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double50 = rectangleInsets48.trimHeight(0.0d);
        double double52 = rectangleInsets48.calculateRightInset(1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str54 = categoryAxis3D53.getLabelURL();
        java.awt.Paint paint55 = categoryAxis3D53.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot58 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis57);
        java.awt.Stroke stroke59 = combinedRangeXYPlot58.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart60 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot58);
        float float61 = jFreeChart60.getBackgroundImageAlpha();
        boolean boolean62 = categoryAxis3D53.hasListener((java.util.EventListener) jFreeChart60);
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D68 = chartRenderingInfo67.getChartArea();
        boolean boolean69 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState71 = null;
        categoryAxis3D53.drawTickMarks(graphics2D63, 45.0d, rectangle2D68, rectangleEdge70, axisState71);
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets48.createOutsetRectangle(rectangle2D68, true, false);
        java.awt.Color color77 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer79 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer79.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator81 = xYAreaRenderer79.getBaseToolTipGenerator();
        java.awt.Stroke stroke85 = xYAreaRenderer79.getItemStroke(1, 1, false);
        barRenderer3D24.drawRangeLine(graphics2D29, categoryPlot30, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, rectangle2D68, (double) (byte) 10, (java.awt.Paint) color77, stroke85);
        boolean boolean87 = standardPieSectionLabelGenerator15.equals((java.lang.Object) stroke85);
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNull(attributedString23);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.5f + "'", float61 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNull(xYToolTipGenerator81);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(3, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate(regularTimePeriod9, (double) 60000L);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection13);
        timeSeries4.clear();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 24231L);
        try {
            java.lang.Number number3 = xYSeries1.getY(32);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        java.awt.Stroke stroke11 = jFreeChart9.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) year3, stroke11);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator13 = ringPlot0.getToolTipGenerator();
        boolean boolean14 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(pieToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        boolean boolean5 = combinedRangeXYPlot1.equals((java.lang.Object) ' ');
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = combinedRangeXYPlot1.removeDomainMarker(5, marker7, layer8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainMinorGridlinePaint();
        int int5 = combinedRangeXYPlot1.getWeight();
        java.lang.String str6 = combinedRangeXYPlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Combined Range XYPlot" + "'", str6.equals("Combined Range XYPlot"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart8);
        jFreeChart8.setBackgroundImageAlignment(2958465);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        double double10 = blockContainer9.getContentYOffset();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D13.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo19.getChartArea();
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D23 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double25 = numberAxis3D13.java2DToValue((double) 0.5f, rectangle2D20, rectangleEdge24);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        java.awt.Stroke stroke29 = combinedRangeXYPlot28.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot28);
        boolean boolean31 = jFreeChart30.getAntiAlias();
        jFreeChart30.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity35 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape) rectangle2D20, jFreeChart30, "ClassContext");
        org.jfree.chart.util.LogFormat logFormat40 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat40.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer44 = null;
        java.text.FieldPosition fieldPosition45 = null;
        java.lang.StringBuffer stringBuffer46 = logFormat40.format((long) 1, stringBuffer44, fieldPosition45);
        org.jfree.chart.util.LogFormat logFormat50 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str52 = logFormat50.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator53 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat40, (java.text.NumberFormat) logFormat50);
        java.lang.String str55 = logFormat40.format((double) 0.5f);
        try {
            java.lang.Object obj56 = blockContainer9.draw(graphics2D11, rectangle2D20, (java.lang.Object) logFormat40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(blockContainer9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stringBuffer46);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "^0.48" + "'", str52.equals("^0.48"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "^-0.3" + "'", str55.equals("^-0.3"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D9.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double21 = numberAxis3D9.java2DToValue((double) 0.5f, rectangle2D16, rectangleEdge20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        double double23 = categoryAxis3D22.getCategoryMargin();
        double double24 = categoryAxis3D22.getLowerMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D25.setTickUnit(numberTickUnit27, true, true);
        java.awt.Shape shape31 = numberAxis3D25.getDownArrow();
        org.jfree.chart.util.Layer layer32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            barRenderer3D0.drawAnnotations(graphics2D7, rectangle2D16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, layer32, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        ringPlot0.setLabelShadowPaint(paint4);
        ringPlot0.setSectionDepth(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.isEmpty();
        java.util.List list5 = xYSeries1.getItems();
        org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries1.addOrUpdate((java.lang.Number) 10.0d, (java.lang.Number) 90.0d);
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number12 = xYDataItem11.getY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem11);
        xYDataItem11.setSelected(true);
        xYSeries1.add(xYDataItem11);
        java.lang.Object obj17 = xYDataItem11.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(xYDataItem8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = null;
        try {
            combinedRangeXYPlot1.setDatasetRenderingOrder(datasetRenderingOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer2.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYAreaRenderer2.getBaseToolTipGenerator();
        java.awt.Stroke stroke8 = xYAreaRenderer2.getItemStroke(1, 1, false);
        boolean boolean9 = lengthAdjustmentType0.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(xYToolTipGenerator4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int11 = combinedRangeXYPlot5.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer10);
        boolean boolean14 = xYLineAndShapeRenderer10.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer10.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        java.util.TimeZone timeZone25 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("", timeZone25);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        xYLineAndShapeRenderer10.drawItem(graphics2D17, xYItemRendererState18, rectangle2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.data.xy.XYDataset) timeSeriesCollection27, (int) (short) 0, 4, false, (int) '4');
        dateAxis26.setTickLabelsVisible(false);
        java.util.TimeZone timeZone36 = dateAxis26.getTimeZone();
        categoryPlot0.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(timeZone36);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        long long4 = year2.getSerialIndex();
        java.awt.Paint paint5 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) year2);
        long long6 = year2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem8 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number9 = xYDataItem8.getY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem8);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.addAndOrUpdate(timeSeries10);
        org.jfree.data.xy.XYDataItem xYDataItem14 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number15 = xYDataItem14.getY();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem14);
        long long17 = timeSeries16.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem20 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number21 = xYDataItem20.getY();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem20);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries16.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.addAndOrUpdate(timeSeries22);
        boolean boolean25 = timeSeries22.isEmpty();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1.0d) + "'", number15.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int13 = combinedRangeXYPlot7.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        boolean boolean16 = xYLineAndShapeRenderer12.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        double double19 = categoryAxis3D18.getCategoryMargin();
        java.awt.Stroke stroke20 = categoryAxis3D18.getAxisLineStroke();
        xYLineAndShapeRenderer12.setSeriesStroke(1900, stroke20);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator22 = xYLineAndShapeRenderer12.getLegendItemLabelGenerator();
        xYLineAndShapeRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator22);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator22);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem8 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number9 = xYDataItem8.getY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem8);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(1, year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.xy.XYSeries xYSeries19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) year13, true, false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone1;
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone1);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((-1), 0, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        combinedRangeXYPlot9.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        int int13 = combinedRangeXYPlot9.getRangeAxisIndex(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        combinedRangeXYPlot15.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = combinedRangeXYPlot15.getLegendItems();
        combinedRangeXYPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot9.getRangeMarkers((int) '#', layer21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        double double24 = categoryAxis3D23.getCategoryMargin();
        java.awt.Stroke stroke25 = categoryAxis3D23.getAxisLineStroke();
        combinedRangeXYPlot9.setRangeMinorGridlineStroke(stroke25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        java.awt.Stroke stroke30 = combinedRangeXYPlot29.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot29);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int35 = combinedRangeXYPlot29.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer34);
        boolean boolean38 = xYLineAndShapeRenderer34.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer34.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        java.util.TimeZone timeZone46 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("", timeZone46);
        java.util.TimeZone timeZone49 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("", timeZone49);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection51 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection51);
        xYLineAndShapeRenderer34.drawItem(graphics2D41, xYItemRendererState42, rectangle2D43, xYPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.data.xy.XYDataset) timeSeriesCollection51, (int) (short) 0, 4, false, (int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D61 = chartRenderingInfo60.getChartArea();
        boolean boolean62 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor63);
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D61, 10.0d);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.data.Range range68 = combinedRangeXYPlot9.getDataRange(valueAxis67);
        combinedRangeXYPlot9.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNull(range68);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 12);
        java.lang.Object obj3 = axisSpace0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range8.intersects((double) 100.0f, (double) 2019L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 1900L, range1, lengthConstraintType6, (double) (byte) 100, range8, lengthConstraintType12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint13.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        combinedRangeXYPlot1.setDomainCrosshairVisible(true);
        combinedRangeXYPlot1.configureDomainAxes();
        int int8 = combinedRangeXYPlot1.getWeight();
        java.awt.Paint paint9 = combinedRangeXYPlot1.getBackgroundPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme11.setErrorIndicatorPaint(paint12);
        java.awt.Paint paint14 = standardChartTheme11.getTickLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme11.setSubtitlePaint(paint15);
        java.awt.Paint paint17 = standardChartTheme11.getDomainGridlinePaint();
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint9, paint17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor(0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot1.panDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedRangeXYPlot1.removeDomainMarker(marker8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Font font3 = standardChartTheme1.getLargeFont();
        java.awt.Color color4 = java.awt.Color.ORANGE;
        standardChartTheme1.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = standardChartTheme7.getLabelLinkStyle();
        java.awt.Font font9 = standardChartTheme7.getLargeFont();
        java.awt.Color color10 = java.awt.Color.ORANGE;
        standardChartTheme7.setRangeGridlinePaint((java.awt.Paint) color10);
        standardChartTheme1.setItemLabelPaint((java.awt.Paint) color10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font14, paint15, (float) (byte) 1);
        java.awt.Font font18 = textFragment17.getFont();
        standardChartTheme1.setLargeFont(font18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMinimumBarLength();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        barRenderer3D0.setWallPaint((java.awt.Paint) color2);
        java.lang.String str4 = color2.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=0,g=192,b=192]" + "'", str4.equals("java.awt.Color[r=0,g=192,b=192]"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoRangeIncludesZero(true);
        numberAxis3D1.setInverted(true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        double double2 = categoryAxis3D0.getLowerMargin();
        float float3 = categoryAxis3D0.getTickMarkOutsideLength();
        float float4 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("org.jfree.data.general.SeriesException: {0}", paint8);
        java.lang.Comparable comparable10 = legendItem9.getSeriesKey();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList12 = new org.jfree.chart.util.ShapeList();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) shapeList12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        float float21 = jFreeChart20.getBackgroundImageAlpha();
        java.awt.Stroke stroke22 = jFreeChart20.getBorderStroke();
        ringPlot11.setSectionOutlineStroke((java.lang.Comparable) year14, stroke22);
        legendItem9.setOutlineStroke(stroke22);
        java.lang.String str25 = legendItem9.getURLText();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        xYSeries1.add((double) 10, (double) 1L, true);
        java.util.List list6 = xYSeries1.getItems();
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        xYLineAndShapeRenderer7.setBaseLinesVisible(true);
        xYLineAndShapeRenderer7.setSeriesVisibleInLegend((int) 'a', (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.mapDatasetToDomainAxis(6, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = java.awt.Color.lightGray;
        categoryPlot14.setDomainCrosshairPaint((java.awt.Paint) color15);
        categoryPlot14.setAnchorValue((double) 1L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo23.getChartArea();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor26);
        categoryPlot14.zoomDomainAxes((double) 100, plotRenderingInfo20, point2D27);
        categoryPlot8.zoomRangeAxes(0.05d, plotRenderingInfo13, point2D27, false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot31 = combinedRangeXYPlot1.findSubplot(plotRenderingInfo7, point2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = jFreeChart4.getPadding();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart4.addProgressListener(chartProgressListener7);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = waferMapPlot2.getDataset();
        org.junit.Assert.assertNull(waferMapDataset5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeries4.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        java.util.Collection collection12 = timeSeries4.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timeSeries4.getItemCount();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4144960) + "'", int1 == (-4144960));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        java.awt.Stroke stroke11 = jFreeChart9.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) year3, stroke11);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator13 = ringPlot0.getToolTipGenerator();
        org.jfree.data.xy.XYDataItem xYDataItem16 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number17 = xYDataItem16.getY();
        double double18 = xYDataItem16.getXValue();
        java.awt.Paint paint19 = ringPlot0.getSectionPaint((java.lang.Comparable) double18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo23.getChartArea();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor26);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        ringPlot28.clearSectionOutlinePaints(true);
        double double31 = ringPlot28.getInnerSeparatorExtension();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = ringPlot0.initialise(graphics2D20, rectangle2D24, (org.jfree.chart.plot.PiePlot) ringPlot28, (java.lang.Integer) 6, plotRenderingInfo33);
        java.awt.Paint paint36 = null;
        ringPlot28.setSectionPaint((java.lang.Comparable) "12/31/69", paint36);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(pieToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-1.0d) + "'", number17.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNotNull(piePlotState34);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        double double4 = xYDataItem2.getXValue();
        java.lang.String str5 = xYDataItem2.toString();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) xYDataItem2);
        try {
            xYSeries6.delete(192, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 101");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[10.0, -1.0]" + "'", str5.equals("[10.0, -1.0]"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer7.setDrawSeriesLineAsPath(true);
        xYLineAndShapeRenderer7.setSeriesShapesFilled(1, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator20 = xYLineAndShapeRenderer7.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(xYItemLabelGenerator20);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint2 = barRenderer3D0.getLegendTextPaint((int) (short) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer3D0.removeAnnotation(categoryAnnotation3);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint7 = standardChartTheme6.getThermometerPaint();
        ringPlot3.setLabelShadowPaint(paint7);
        labelBlock2.setPaint(paint7);
        java.lang.String str10 = labelBlock2.getToolTipText();
        java.lang.String str11 = labelBlock2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[size=-1]", dateFormat1, dateFormat2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        java.awt.Paint paint3 = ringPlot0.getLabelPaint();
        double double4 = ringPlot0.getInteriorGap();
        ringPlot0.setIgnoreNullValues(false);
        java.awt.Paint paint7 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 0.5f, (double) 32, 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        boolean boolean4 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D3);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D3, "");
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "^0.48", "JFreeChartEntity: tooltip = ClassContext", "^-0.3");
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font1, paint2, (float) (byte) 1);
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        combinedRangeXYPlot1.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("", timeZone11);
        org.jfree.data.Range range13 = combinedRangeXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        dateAxis12.resizeRange2((double) 2.0f, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Font font3 = standardChartTheme1.getLargeFont();
        java.awt.Paint paint4 = standardChartTheme1.getDomainGridlinePaint();
        java.awt.Paint paint5 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint6 = standardChartTheme1.getLegendBackgroundPaint();
        java.awt.Paint paint7 = standardChartTheme1.getPlotBackgroundPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem6 = legendItemCollection4.get(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart4.getLegend(40);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(legendTitle9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = chartRenderingInfo0.getChartArea();
        chartRenderingInfo0.clear();
        org.junit.Assert.assertNotNull(rectangle2D1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int9 = combinedRangeXYPlot3.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer8);
        java.awt.Shape shape11 = xYLineAndShapeRenderer8.getSeriesShape(10);
        boolean boolean13 = xYLineAndShapeRenderer8.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean15 = xYLineAndShapeRenderer8.getSeriesVisibleInLegend((int) (short) 10);
        boolean boolean16 = strokeList0.equals((java.lang.Object) xYLineAndShapeRenderer8);
        java.awt.Shape shape18 = xYLineAndShapeRenderer8.getLegendShape(6);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        combinedRangeXYPlot20.setRenderer(xYItemRenderer21);
        java.awt.Font font24 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font24);
        combinedRangeXYPlot20.setNoDataMessageFont(font24);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        combinedRangeXYPlot20.setRangeAxis(12, valueAxis28, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean35 = xYLineAndShapeRenderer34.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot20.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer34);
        java.awt.Paint paint37 = combinedRangeXYPlot20.getDomainZeroBaselinePaint();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        int int41 = timeSeriesCollection39.getSeriesCount();
        combinedRangeXYPlot20.setDataset((int) 'a', (org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        xYLineAndShapeRenderer8.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 100);
        defaultKeyedValues0.setValue((java.lang.Comparable) year2, (java.lang.Number) (-1.0f));
        org.jfree.data.general.DefaultPieDataset defaultPieDataset5 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean7 = defaultPieDataset5.equals((java.lang.Object) xYStepAreaRenderer6);
        xYStepAreaRenderer6.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false);
        boolean boolean11 = defaultKeyedValues0.equals((java.lang.Object) (byte) 1);
        java.lang.Comparable comparable13 = defaultKeyedValues0.getKey(0);
        try {
            defaultKeyedValues0.removeValue((java.lang.Comparable) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (2019) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(comparable13);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double1 = logAxis0.getFixedDimension();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot5.setRangeAxis(1, valueAxis9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = combinedRangeXYPlot5.getRangeAxisEdge(12);
        java.awt.Font font15 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("", font15);
        java.lang.Object obj17 = labelBlock16.clone();
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock16.getBounds();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str20 = categoryAxis3D19.getLabelURL();
        java.awt.Paint paint21 = categoryAxis3D19.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot24.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot24);
        float float27 = jFreeChart26.getBackgroundImageAlpha();
        boolean boolean28 = categoryAxis3D19.hasListener((java.util.EventListener) jFreeChart26);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo33.getChartArea();
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState37 = null;
        categoryAxis3D19.drawTickMarks(graphics2D29, 45.0d, rectangle2D34, rectangleEdge36, axisState37);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis40);
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot41);
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection45 = new org.jfree.data.time.TimeSeriesCollection(timeZone44);
        combinedRangeXYPlot41.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection45);
        boolean boolean47 = combinedRangeXYPlot41.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace48 = new org.jfree.chart.axis.AxisSpace();
        axisSpace48.setTop((double) 12);
        combinedRangeXYPlot41.setFixedRangeAxisSpace(axisSpace48, false);
        axisSpace48.setTop(0.5d);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace55 = logAxis0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5, rectangle2D18, rectangleEdge36, axisSpace48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
//        ringPlot0.clearSectionOutlinePaints(true);
//        double double3 = ringPlot0.getInnerSeparatorExtension();
//        java.awt.Image image4 = null;
//        ringPlot0.setBackgroundImage(image4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        long long8 = day6.getLastMillisecond();
//        java.awt.Paint paint9 = null;
//        ringPlot0.setSectionPaint((java.lang.Comparable) day6, paint9);
//        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        ringPlot0.setLabelPaint((java.awt.Paint) color11);
//        java.awt.Paint paint13 = ringPlot0.getSeparatorPaint();
//        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!");
//        java.awt.Paint paint16 = null;
//        legendItem15.setLabelPaint(paint16);
//        boolean boolean18 = legendItem15.isShapeFilled();
//        java.awt.Paint paint19 = legendItem15.getLinePaint();
//        boolean boolean20 = ringPlot0.equals((java.lang.Object) paint19);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double13 = numberAxis3D1.java2DToValue((double) 0.5f, rectangle2D8, rectangleEdge12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot16.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        boolean boolean19 = jFreeChart18.getAntiAlias();
        jFreeChart18.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity23 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape) rectangle2D8, jFreeChart18, "ClassContext");
        java.lang.String str24 = jFreeChartEntity23.toString();
        java.lang.String str25 = jFreeChartEntity23.getShapeType();
        java.lang.String str26 = jFreeChartEntity23.getURLText();
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JFreeChartEntity: tooltip = ClassContext" + "'", str24.equals("JFreeChartEntity: tooltip = ClassContext"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "rect" + "'", str25.equals("rect"));
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year1);
        long long4 = month3.getSerialIndex();
        int int5 = month3.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month3.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24231L + "'", long4 == 24231L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint3 = standardChartTheme1.getLegendBackgroundPaint();
        java.awt.Paint paint4 = standardChartTheme1.getTitlePaint();
        java.awt.Paint paint5 = null;
        try {
            standardChartTheme1.setBaselinePaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int19 = color18.getAlpha();
        java.awt.color.ColorSpace colorSpace20 = color18.getColorSpace();
        xYLineAndShapeRenderer7.setBaseOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator23 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        boolean boolean25 = standardXYToolTipGenerator23.equals((java.lang.Object) 255);
        java.lang.Object obj26 = standardXYToolTipGenerator23.clone();
        xYLineAndShapeRenderer7.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator23, false);
        try {
            xYLineAndShapeRenderer7.setSeriesVisibleInLegend((-4144960), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "org.jfree.data.general.SeriesException: {0}", textAnchor3, textAnchor4, 90.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = numberTick6.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double13 = numberAxis3D1.java2DToValue((double) 0.5f, rectangle2D8, rectangleEdge12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot16.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        boolean boolean19 = jFreeChart18.getAntiAlias();
        jFreeChart18.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity23 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape) rectangle2D8, jFreeChart18, "ClassContext");
        java.lang.String str24 = jFreeChartEntity23.getURLText();
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int12 = combinedRangeXYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        boolean boolean15 = xYLineAndShapeRenderer11.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        double double18 = categoryAxis3D17.getCategoryMargin();
        java.awt.Stroke stroke19 = categoryAxis3D17.getAxisLineStroke();
        xYLineAndShapeRenderer11.setSeriesStroke(1900, stroke19);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = xYLineAndShapeRenderer11.getLegendItemLabelGenerator();
        xYLineAndShapeRenderer2.setLegendItemURLGenerator(xYSeriesLabelGenerator21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator21);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        int int2 = timeSeriesCollection0.getSeriesCount();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            double double6 = timeSeriesCollection0.getXValue(0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range8.intersects((double) 100.0f, (double) 2019L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 1900L, range1, lengthConstraintType6, (double) (byte) 100, range8, lengthConstraintType12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean18 = range15.intersects((double) 100.0f, (double) 2019L);
        double double20 = range15.constrain((double) 2147483647);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint14.toRangeHeight(range15);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setFixedDimension((double) 0.5f);
        double double3 = categoryAxis3D0.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.trimHeight(0.0d);
        categoryAxis3D0.setLabelInsets(rectangleInsets4, false);
        boolean boolean9 = categoryAxis3D0.isMinorTickMarksVisible();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.ShapeList shapeList13 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean17 = xYSeries15.equals((java.lang.Object) 10.0d);
        boolean boolean18 = shapeList13.equals((java.lang.Object) 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        boolean boolean26 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D25);
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D25);
        shapeList13.setShape(10, (java.awt.Shape) rectangle2D25);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis30);
        java.awt.Stroke stroke32 = combinedRangeXYPlot31.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        combinedRangeXYPlot31.setRangeAxis(1, valueAxis35, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedRangeXYPlot31.getRangeAxisEdge(12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            org.jfree.chart.axis.AxisState axisState41 = categoryAxis3D0.draw(graphics2D10, (double) 0.5f, rectangle2D12, rectangle2D25, rectangleEdge39, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        axisState0.cursorUp(1.0E-5d);
        double double4 = axisState0.getMax();
        axisState0.setCursor((double) 60000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD");
        textTitle1.setURLText("{0}");
        boolean boolean4 = textTitle1.isVisible();
        java.lang.Object obj5 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) ' ');
        boolean boolean4 = defaultPieDataset0.equals((java.lang.Object) dateTickUnit3);
        try {
            defaultPieDataset0.insertValue((int) '4', (java.lang.Comparable) 1L, (java.lang.Number) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        jFreeChart4.setTitle("{0}");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset10 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset10);
        java.util.List list12 = defaultPieDataset10.getKeys();
        jFreeChart4.setSubtitles(list12);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        categoryPlot0.setWeight((-1));
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean16 = categoryPlot0.removeDomainMarker((-1), marker13, layer14, true);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("JFreeChartEntity: tooltip = ClassContext", "rect", "DomainOrder.NONE", "VerticalAlignment.CENTER");
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        int int1 = strokeList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        boolean boolean2 = strokeList0.equals((java.lang.Object) (-4144960));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER_RIGHT");
        java.text.AttributedString attributedString2 = legendItem1.getAttributedLabel();
        org.junit.Assert.assertNull(attributedString2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D5.setTickUnit(numberTickUnit7, true, true);
        java.awt.Shape shape11 = numberAxis3D5.getDownArrow();
        int int12 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D5);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean19 = categoryPlot0.removeDomainMarker(2958465, marker16, layer17, true);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Font font1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int10 = combinedRangeXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape12 = xYLineAndShapeRenderer9.getSeriesShape(10);
        boolean boolean14 = xYLineAndShapeRenderer9.isSeriesVisibleInLegend(1);
        java.awt.Paint paint16 = xYLineAndShapeRenderer9.lookupSeriesPaint(1900);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer19 = new org.jfree.chart.text.G2TextMeasurer(graphics2D18);
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint16, (float) '#', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer19);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean25 = range22.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange(range22);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean32 = range29.intersects((double) 100.0f, (double) 2019L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) 1900L, range22, lengthConstraintType27, (double) (byte) 100, range29, lengthConstraintType33);
        boolean boolean35 = textBlock20.equals((java.lang.Object) lengthConstraintType27);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.updateCrosshairY((double) 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("org.jfree.data.UnknownKeyException: ");
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((-1), 0, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        combinedRangeXYPlot9.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        int int13 = combinedRangeXYPlot9.getRangeAxisIndex(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        combinedRangeXYPlot15.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = combinedRangeXYPlot15.getLegendItems();
        combinedRangeXYPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot9.getRangeMarkers((int) '#', layer21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        double double24 = categoryAxis3D23.getCategoryMargin();
        java.awt.Stroke stroke25 = categoryAxis3D23.getAxisLineStroke();
        combinedRangeXYPlot9.setRangeMinorGridlineStroke(stroke25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        java.awt.Stroke stroke30 = combinedRangeXYPlot29.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot29);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int35 = combinedRangeXYPlot29.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer34);
        boolean boolean38 = xYLineAndShapeRenderer34.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer34.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        java.util.TimeZone timeZone46 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("", timeZone46);
        java.util.TimeZone timeZone49 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("", timeZone49);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection51 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection51);
        xYLineAndShapeRenderer34.drawItem(graphics2D41, xYItemRendererState42, rectangle2D43, xYPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.data.xy.XYDataset) timeSeriesCollection51, (int) (short) 0, 4, false, (int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D61 = chartRenderingInfo60.getChartArea();
        boolean boolean62 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor63);
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D61, 10.0d);
        dateAxis50.zoomRange((double) (-1), 0.0d);
        java.awt.Shape shape70 = dateAxis50.getDownArrow();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(shape70);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot1.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextFillPaint();
        categoryPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        java.lang.Object obj6 = defaultDrawingSupplier3.clone();
        boolean boolean7 = timePeriodAnchor0.equals(obj6);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D9.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer3D9.getSeriesToolTipGenerator((int) '#');
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot15.zoomDomainAxes((double) 1900L, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean26 = range23.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(range23);
        numberAxis3D22.setRangeWithMargins((org.jfree.data.Range) dateRange27, false, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis3D22.setMarkerBand(markerAxisBand31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.trimHeight(0.0d);
        double double37 = rectangleInsets33.calculateRightInset(1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str39 = categoryAxis3D38.getLabelURL();
        java.awt.Paint paint40 = categoryAxis3D38.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis42);
        java.awt.Stroke stroke44 = combinedRangeXYPlot43.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot43);
        float float46 = jFreeChart45.getBackgroundImageAlpha();
        boolean boolean47 = categoryAxis3D38.hasListener((java.util.EventListener) jFreeChart45);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo52.getChartArea();
        boolean boolean54 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState56 = null;
        categoryAxis3D38.drawTickMarks(graphics2D48, 45.0d, rectangle2D53, rectangleEdge55, axisState56);
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets33.createOutsetRectangle(rectangle2D53, true, false);
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer64 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer64.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator66 = xYAreaRenderer64.getBaseToolTipGenerator();
        java.awt.Stroke stroke70 = xYAreaRenderer64.getItemStroke(1, 1, false);
        barRenderer3D9.drawRangeLine(graphics2D14, categoryPlot15, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, rectangle2D53, (double) (byte) 10, (java.awt.Paint) color62, stroke70);
        org.jfree.chart.RenderingSource renderingSource72 = null;
        combinedRangeXYPlot1.select(generalPath8, rectangle2D53, renderingSource72);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.5f + "'", float46 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNull(xYToolTipGenerator66);
        org.junit.Assert.assertNotNull(stroke70);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.awt.Color color2 = java.awt.Color.getColor("JFreeChartEntity: tooltip = ClassContext", 3);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        java.lang.Object obj2 = tickUnits0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER_RIGHT", paint1);
        java.awt.Paint paint3 = legendItem2.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.awt.Font font1 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, 0.0f, textMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        double double10 = size2D9.getWidth();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot8.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextFillPaint();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getDomainAxisLocation(1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer17.getItemOutlineStroke((-1), 0, false);
        boolean boolean22 = axisLocation14.equals((java.lang.Object) false);
        combinedRangeXYPlot2.setDomainAxisLocation(axisLocation14, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint7 = xYLineAndShapeRenderer5.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYLineAndShapeRenderer5.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Stroke stroke11 = legendItem10.getLineStroke();
        java.awt.Stroke stroke12 = legendItem10.getLineStroke();
        xYLineAndShapeRenderer5.setBaseStroke(stroke12);
        categoryAxis3D0.setAxisLineStroke(stroke12);
        java.lang.Object obj15 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset1, (java.lang.Comparable) 100L, (double) 4, 0);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        boolean boolean11 = jFreeChart10.getAntiAlias();
        boolean boolean12 = defaultPieDataset1.equals((java.lang.Object) jFreeChart10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart10.getPadding();
        int int14 = objectList0.indexOf((java.lang.Object) jFreeChart10);
        java.awt.Image image15 = null;
        jFreeChart10.setBackgroundImage(image15);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str16 = logFormat14.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean20 = blockBorder18.equals((java.lang.Object) itemLabelAnchor19);
        try {
            java.lang.String str21 = logFormat4.format((java.lang.Object) blockBorder18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "^0.48" + "'", str16.equals("^0.48"));
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        java.awt.Stroke stroke8 = combinedRangeXYPlot1.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Paint paint2 = null;
        legendItem1.setLabelPaint(paint2);
        legendItem1.setDatasetIndex(32);
        boolean boolean6 = legendItem1.isShapeFilled();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.trimHeight(0.0d);
        periodAxis1.setLabelInsets(rectangleInsets6);
        org.jfree.data.xy.XYDataItem xYDataItem12 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number13 = xYDataItem12.getY();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem12);
        long long15 = timeSeries14.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem18 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number19 = xYDataItem18.getY();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem18);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries14.addAndOrUpdate(timeSeries20);
        org.jfree.data.xy.XYDataItem xYDataItem24 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number25 = xYDataItem24.getY();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem24);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(3, year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries26.addOrUpdate(regularTimePeriod31, (double) 60000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries14.addOrUpdate(regularTimePeriod31, 0.4d);
        periodAxis1.setFirst(regularTimePeriod31);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1.0d) + "'", number19.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0d) + "'", number25.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("org.jfree.data.general.SeriesException: {0}", paint8);
        java.lang.Comparable comparable10 = legendItem9.getSeriesKey();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem9.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 100);
        defaultKeyedValues0.setValue((java.lang.Comparable) year2, (java.lang.Number) (-1.0f));
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray7 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis6.setLabelInfo(periodAxisLabelInfoArray7);
        org.jfree.chart.axis.TickUnits tickUnits9 = new org.jfree.chart.axis.TickUnits();
        periodAxis6.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.trimHeight(0.0d);
        periodAxis6.setLabelInsets(rectangleInsets11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis6.getFirst();
        try {
            defaultKeyedValues0.removeValue((java.lang.Comparable) regularTimePeriod15);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (13-June-2019) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot2);
        categoryPlot2.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        combinedRangeXYPlot3.setRenderer(xYItemRenderer4);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        combinedRangeXYPlot3.setNoDataMessageFont(font7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("{0}", font7);
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme12.setErrorIndicatorPaint(paint13);
        java.awt.Paint paint15 = standardChartTheme12.getTickLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme12.setSubtitlePaint(paint16);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("SeriesRenderingOrder.REVERSE", font7, paint16);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesLinesVisible((int) (short) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer7.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.LegendItem legendItem19 = xYLineAndShapeRenderer7.getLegendItem(4, 0);
        int int20 = xYLineAndShapeRenderer7.getPassCount();
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer7.lookupSeriesStroke((int) (byte) 10);
        org.jfree.chart.LegendItem legendItem25 = xYLineAndShapeRenderer7.getLegendItem(8, 100);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(legendItem25);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType2, (int) ' ');
        boolean boolean5 = defaultPieDataset1.equals((java.lang.Object) dateTickUnit4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = combinedRangeXYPlot7.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = combinedRangeXYPlot7.removeDomainMarker(marker10, layer11);
        boolean boolean13 = combinedRangeXYPlot7.isDomainZoomable();
        combinedRangeXYPlot7.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("", timeZone17);
        org.jfree.data.Range range19 = combinedRangeXYPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.util.Date date20 = dateAxis18.getMaximumDate();
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Date date22 = dateTickUnit4.addToDate(date20, timeZone21);
        try {
            org.jfree.chart.axis.TickUnit tickUnit23 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int13 = combinedRangeXYPlot7.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) 10.0f);
        combinedRangeXYPlot7.setInsets(rectangleInsets14, true);
        combinedRangeXYPlot2.setAxisOffset(rectangleInsets14);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis22);
        java.awt.Stroke stroke24 = combinedRangeXYPlot23.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot23);
        float float26 = jFreeChart25.getBackgroundImageAlpha();
        java.util.List list27 = jFreeChart25.getSubtitles();
        try {
            combinedRangeXYPlot2.mapDatasetToDomainAxes((int) (short) 0, list27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Indices must be Integer instances.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        combinedRangeXYPlot2.setRangeAxis(1, valueAxis6, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedRangeXYPlot2.getRangeAxisEdge(12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str13 = verticalAlignment12.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) 1.0f, 0.0d);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        flowArrangement16.add((org.jfree.chart.block.Block) textTitle18, (java.lang.Object) range20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment22, verticalAlignment23, (double) '4', 10.0d);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot2, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) columnArrangement26);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "VerticalAlignment.CENTER" + "'", str13.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        java.lang.Object obj2 = ringPlot0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setRangeAxes(valueAxisArray12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedRangeXYPlot2.getDomainAxisIndex(valueAxis14);
        java.lang.Object obj16 = null;
        boolean boolean17 = combinedRangeXYPlot2.equals(obj16);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = standardChartTheme3.getLabelLinkStyle();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = standardChartTheme3.getDrawingSupplier();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font7, paint8, (float) (byte) 1);
        java.awt.Font font11 = textFragment10.getFont();
        standardChartTheme3.setLargeFont(font11);
        barRenderer3D0.setSeriesItemLabelFont((int) (byte) 10, font11, false);
        barRenderer3D0.setDrawBarOutline(true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumFractionDigits((int) (byte) -1);
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, dateFormat7);
        int int9 = logFormat4.getMaximumIntegerDigits();
        java.text.ParsePosition parsePosition11 = null;
        java.lang.Object obj12 = logFormat4.parseObject("{0}", parsePosition11);
        int int13 = logFormat4.getMinimumIntegerDigits();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        boolean boolean6 = jFreeChart4.getAntiAlias();
        boolean boolean7 = jFreeChart4.getAntiAlias();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart4.getPadding();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        timeSeriesCollection0.removeAllSeries();
        double double4 = timeSeriesCollection0.getDomainLowerBound(false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str1 = categoryAxis3D0.getLabelURL();
        java.awt.Paint paint2 = categoryAxis3D0.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        float float8 = jFreeChart7.getBackgroundImageAlpha();
        boolean boolean9 = categoryAxis3D0.hasListener((java.util.EventListener) jFreeChart7);
        java.awt.Paint paint10 = jFreeChart7.getBackgroundPaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        combinedRangeXYPlot12.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = combinedRangeXYPlot12.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        combinedRangeXYPlot12.setRangeAxisLocation(4, axisLocation17, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot12.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Color color22 = color20.darker();
        jFreeChart7.setBorderPaint((java.awt.Paint) color20);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        intervalXYDelegate8.setIntervalPositionFactor(1.0d);
        org.jfree.data.Range range13 = intervalXYDelegate8.getDomainBounds(false);
        double double14 = intervalXYDelegate8.getFixedIntervalWidth();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        boolean boolean16 = xYLineAndShapeRenderer7.getItemShapeVisible((int) (byte) 100, (int) ' ');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) "org.jfree.data.general.SeriesException: {0}");
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        double double10 = intervalXYDelegate8.getIntervalWidth();
        org.jfree.data.Range range12 = intervalXYDelegate8.getDomainBounds(false);
        try {
            java.lang.Number number15 = intervalXYDelegate8.getStartX((int) 'a', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock6.getBounds();
        java.awt.Stroke stroke9 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint12 = standardChartTheme11.getThermometerPaint();
        java.awt.Paint paint13 = standardChartTheme11.getLegendBackgroundPaint();
        java.awt.Paint paint14 = standardChartTheme11.getTitlePaint();
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "TextBlockAnchor.CENTER_RIGHT", "VerticalAlignment.CENTER", (java.awt.Shape) rectangle2D8, stroke9, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeriesCollection4.getSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(timeSeries8);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        combinedRangeXYPlot2.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        combinedRangeXYPlot2.setRangeAxisLocation(4, axisLocation7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot2.setBackgroundPaint((java.awt.Paint) color10);
        int int12 = color10.getGreen();
        java.awt.Color color13 = java.awt.Color.yellow;
        float[] floatArray19 = new float[] { 2958465, 0.5f, 1900L, 10L, 0.0f };
        float[] floatArray20 = color13.getColorComponents(floatArray19);
        float[] floatArray21 = color10.getRGBColorComponents(floatArray19);
        java.awt.Color color22 = java.awt.Color.getColor("Last", color10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 192 + "'", int12 == 192);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        int int4 = defaultPieDataset0.getIndex((java.lang.Comparable) "Combined Range XYPlot");
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) 1900, (double) 'a', 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setFixedDimension((double) 0.5f);
        double double5 = categoryAxis3D2.getCategoryMargin();
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font2);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getFirstTextFragment();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getRangeMinorGridlinePaint();
        combinedRangeXYPlot7.setDomainCrosshairVisible(true);
        combinedRangeXYPlot7.configureDomainAxes();
        boolean boolean14 = textLine4.equals((java.lang.Object) combinedRangeXYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis15 = combinedRangeXYPlot7.getDomainAxis();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.renderer.category.BarPainter barPainter3 = standardChartTheme1.getBarPainter();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(barPainter3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        combinedRangeXYPlot2.clearRangeMarkers((int) (short) 10);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int10 = color9.getGreen();
        combinedRangeXYPlot2.setRangeGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot2.setFixedDomainAxisSpace(axisSpace12, false);
        combinedRangeXYPlot2.setRangeMinorGridlinesVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        int int9 = combinedRangeXYPlot2.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        try {
            int int14 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection7, (int) (byte) 10, (double) 100, (double) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        java.lang.String str4 = standardChartTheme1.getName();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        combinedRangeXYPlot6.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot6.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        combinedRangeXYPlot6.setRangeAxisLocation(4, axisLocation11, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot6.setBackgroundPaint((java.awt.Paint) color14);
        java.awt.Color color16 = color14.darker();
        standardChartTheme1.setAxisLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D18.setFixedDimension((double) 0.5f);
        double double21 = categoryAxis3D18.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.trimHeight(0.0d);
        categoryAxis3D18.setLabelInsets(rectangleInsets22, false);
        standardChartTheme1.setAxisOffset(rectangleInsets22);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        combinedRangeXYPlot29.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = combinedRangeXYPlot29.getInsets();
        org.jfree.chart.util.ShapeList shapeList33 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries35 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean37 = xYSeries35.equals((java.lang.Object) 10.0d);
        boolean boolean38 = shapeList33.equals((java.lang.Object) 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D45 = chartRenderingInfo44.getChartArea();
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D45);
        boolean boolean47 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D45);
        shapeList33.setShape(10, (java.awt.Shape) rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets32.createOutsetRectangle(rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets22.createInsetRectangle(rectangle2D49);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean5 = range2.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range2);
        numberAxis3D1.setRangeWithMargins((org.jfree.data.Range) dateRange6, false, false);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (byte) 0, (double) 2.0f);
        double double13 = dateRange12.getLowerBound();
        boolean boolean15 = dateRange12.contains((double) 19000L);
        boolean boolean16 = dateRange6.intersects((org.jfree.data.Range) dateRange12);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        long long8 = segmentedTimeline3.getExceptionSegmentCount((long) 12, (long) 100);
        java.lang.Object obj9 = segmentedTimeline3.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        intervalXYDelegate8.setIntervalPositionFactor(1.0d);
        org.jfree.data.Range range13 = intervalXYDelegate8.getDomainBounds(false);
        try {
            intervalXYDelegate8.setIntervalPositionFactor((double) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.updateCrosshairY(0.0d, 3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection4);
        java.lang.Object obj7 = timeSeriesCollection4.clone();
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection4.getDomainOrder();
        java.lang.String str9 = domainOrder8.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DomainOrder.ASCENDING" + "'", str9.equals("DomainOrder.ASCENDING"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        java.lang.Object obj2 = defaultKeyedValues0.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.awt.Font font1 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, 0.0f, textMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        double double10 = size2D9.width;
        size2D9.height = 0.0d;
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        double double4 = xYDataItem2.getXValue();
        java.lang.String str5 = xYDataItem2.toString();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) xYDataItem2);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        xYSeries6.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[10.0, -1.0]" + "'", str5.equals("[10.0, -1.0]"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        java.awt.Paint paint3 = ringPlot0.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = ringPlot0.getSimpleLabelOffset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int15 = combinedRangeXYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer14);
        java.awt.Shape shape17 = xYLineAndShapeRenderer14.getSeriesShape(10);
        boolean boolean19 = xYLineAndShapeRenderer14.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean21 = xYLineAndShapeRenderer14.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer14.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str25 = categoryAxis3D24.getLabelURL();
        java.awt.Paint paint26 = categoryAxis3D24.getLabelPaint();
        xYLineAndShapeRenderer14.setBaseItemLabelPaint(paint26);
        ringPlot0.setLabelOutlinePaint(paint26);
        ringPlot0.setInteriorGap(0.05d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Font font1 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, 0.0f, textMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        double double10 = size2D9.getHeight();
        size2D9.setWidth((double) (-1));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        xYLineAndShapeRenderer2.setSeriesCreateEntities(40, (java.lang.Boolean) false, true);
        java.lang.Boolean boolean9 = xYLineAndShapeRenderer2.getSeriesLinesVisible(13);
        boolean boolean13 = xYLineAndShapeRenderer2.isItemLabelVisible(0, 0, false);
        java.util.Collection collection14 = xYLineAndShapeRenderer2.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = combinedRangeXYPlot1.getDataRange(valueAxis18);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.awt.Paint paint14 = xYLineAndShapeRenderer7.lookupSeriesPaint(1900);
        java.awt.Stroke stroke16 = xYLineAndShapeRenderer7.getSeriesStroke((int) (short) 100);
        try {
            xYLineAndShapeRenderer7.setSeriesItemLabelsVisible(2147483647, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(stroke16);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        java.lang.Boolean boolean12 = xYLineAndShapeRenderer7.getSeriesShapesVisible((int) (short) 100);
        xYLineAndShapeRenderer7.setAutoPopulateSeriesShape(false);
        xYLineAndShapeRenderer7.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        xYLineAndShapeRenderer7.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot3.getRangeMarkers((int) (byte) 1, layer27);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean11 = xYLineAndShapeRenderer7.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer7.setBaseShapesVisible(false);
        java.awt.Shape shape15 = xYLineAndShapeRenderer7.getLegendShape((-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYLineAndShapeRenderer7.getSeriesPositiveItemLabelPosition((-1));
        xYLineAndShapeRenderer7.setBaseShapesFilled(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(shape15);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double1 = logAxis0.getFixedDimension();
        logAxis0.setLabelURL("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedRangeXYPlot1.zoomRangeAxes(Double.NaN, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot12.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint15 = defaultDrawingSupplier14.getNextFillPaint();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier14);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation18);
        combinedRangeXYPlot1.setDomainCrosshairValue((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        float float6 = jFreeChart5.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = jFreeChart5.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 1, jFreeChart5, 1, (int) (byte) 1);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart5.addChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setLabelAngle(0.0d);
        java.awt.Shape shape33 = dateAxis23.getUpArrow();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer3D0.getSeriesToolTipGenerator((int) '#');
        barRenderer3D0.setIncludeBaseInRange(true);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.setCrosshairY((double) 6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        java.util.List list9 = timeSeriesCollection6.getSeries();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range8.intersects((double) 100.0f, (double) 2019L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 1900L, range1, lengthConstraintType6, (double) (byte) 100, range8, lengthConstraintType12);
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Paint paint2 = null;
        legendItem1.setLabelPaint(paint2);
        java.awt.Shape shape4 = legendItem1.getLine();
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Font font3 = standardChartTheme1.getLargeFont();
        java.awt.Paint paint4 = standardChartTheme1.getDomainGridlinePaint();
        java.awt.Font font5 = standardChartTheme1.getRegularFont();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.Marker marker7 = null;
        try {
            combinedRangeXYPlot2.addRangeMarker(marker7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeries4.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        java.util.Collection collection12 = timeSeries4.getTimePeriods();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(1, year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.String str18 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset(2);
        double double12 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        java.awt.Paint paint18 = combinedRangeXYPlot1.getDomainZeroBaselinePaint();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        int int22 = timeSeriesCollection20.getSeriesCount();
        combinedRangeXYPlot1.setDataset((int) 'a', (org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = combinedRangeXYPlot1.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            combinedRangeXYPlot1.handleClick(10, 5, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = standardChartTheme2.getLabelLinkStyle();
        java.awt.Font font4 = standardChartTheme2.getLargeFont();
        java.awt.Paint paint5 = standardChartTheme2.getDomainGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        combinedRangeXYPlot7.setRenderer(xYItemRenderer8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font11);
        combinedRangeXYPlot7.setNoDataMessageFont(font11);
        standardChartTheme2.setRegularFont(font11);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter15 = standardChartTheme2.getXYBarPainter();
        boolean boolean16 = strokeList0.equals((java.lang.Object) xYBarPainter15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(xYBarPainter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        long long6 = segmentedTimeline3.getSegmentSize();
        segmentedTimeline3.addException((long) 1900);
        long long10 = segmentedTimeline3.getTimeFromLong((long) 1);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        java.util.List list15 = timeSeriesCollection11.getSeries();
        segmentedTimeline3.addExceptions(list15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1900L + "'", long6 == 1900L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedRangeXYPlot1.getInsets();
        java.awt.Paint paint5 = combinedRangeXYPlot1.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(axisSpace2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        barRenderer3D0.setItemMargin((double) 9223372036854775807L);
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit30 = polarPlot29.getAngleTickUnit();
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        polarPlot29.setAngleLabelPaint(paint31);
        barRenderer3D0.setSeriesOutlinePaint(8, paint31, true);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(tickUnit30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        intervalXYDelegate8.setAutoWidth(true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        intervalXYDelegate8.datasetChanged(datasetChangeEvent12);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        paintMap0.clear();
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("DomainOrder.NONE", "Value", "SeriesRenderingOrder.REVERSE", "");
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextFillPaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier2);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation(1);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Object obj1 = defaultPieDataset0.clone();
        java.lang.Comparable comparable2 = null;
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, comparable2, 2.0d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        java.lang.String str33 = dateAxis23.getLabelToolTip();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.clearSectionOutlineStrokes(false);
        java.lang.String str3 = piePlot3D0.getPlotType();
        java.lang.String str4 = piePlot3D0.getPlotType();
        double double5 = piePlot3D0.getDepthFactor();
        double double7 = piePlot3D0.getExplodePercent((java.lang.Comparable) "{0}");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12d + "'", double5 == 0.12d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("AxisLocation.TOP_OR_RIGHT");
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Polar Plot", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range8.intersects((double) 100.0f, (double) 2019L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 1900L, range1, lengthConstraintType6, (double) (byte) 100, range8, lengthConstraintType12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toFixedHeight(0.4d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        double double10 = legendTitle8.getContentYOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(blockContainer9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = combinedRangeXYPlot9.getDomainAxisIndex(valueAxis10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = combinedRangeXYPlot9.removeDomainMarker(marker12, layer13);
        boolean boolean15 = combinedRangeXYPlot9.isDomainZoomable();
        combinedRangeXYPlot9.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        org.jfree.data.Range range21 = combinedRangeXYPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.Range range22 = combinedRangeXYPlot2.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.lang.String str23 = combinedRangeXYPlot2.getPlotType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Combined Range XYPlot" + "'", str23.equals("Combined Range XYPlot"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator2 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1900, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        combinedRangeXYPlot6.setRangeCrosshairValue((double) (short) 100);
        float float9 = combinedRangeXYPlot6.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = combinedRangeXYPlot6.getRangeAxisEdge(3);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        combinedRangeXYPlot13.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = combinedRangeXYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        combinedRangeXYPlot13.setRangeAxisLocation(4, axisLocation18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot13.setBackgroundPaint((java.awt.Paint) color21);
        combinedRangeXYPlot6.setOutlinePaint((java.awt.Paint) color21);
        boolean boolean24 = standardXYToolTipGenerator2.equals((java.lang.Object) color21);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator25 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator2, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator25);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Paint paint2 = null;
        legendItem1.setLabelPaint(paint2);
        boolean boolean4 = legendItem1.isShapeFilled();
        boolean boolean5 = legendItem1.isShapeVisible();
        int int6 = legendItem1.getSeriesIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme3.setErrorIndicatorPaint(paint4);
        legendItem1.setLabelPaint(paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        axisState0.cursorUp(1.0E-5d);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        float float9 = jFreeChart8.getBackgroundImageAlpha();
        java.util.List list10 = jFreeChart8.getSubtitles();
        axisState0.setTicks(list10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font2);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment6 = textLine4.getLastTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(textFragment6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer3D0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D15);
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D15);
        try {
            barRenderer3D0.drawBackground(graphics2D8, categoryPlot9, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList6 = new org.jfree.chart.util.ShapeList();
        boolean boolean7 = ringPlot5.equals((java.lang.Object) shapeList6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        java.awt.Stroke stroke16 = jFreeChart14.getBorderStroke();
        ringPlot5.setSectionOutlineStroke((java.lang.Comparable) year8, stroke16);
        ringPlot5.setNotify(true);
        boolean boolean20 = year1.equals((java.lang.Object) ringPlot5);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font2);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D6.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = barRenderer3D6.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint13 = barRenderer3D6.getShadowPaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.Range range15 = barRenderer3D6.findRangeBounds(categoryDataset14);
        boolean boolean16 = textLine4.equals((java.lang.Object) range15);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot1.getRenderer();
        java.awt.Stroke stroke3 = categoryPlot1.getRangeCrosshairStroke();
        xYStepAreaRenderer0.setBaseOutlineStroke(stroke3, false);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.trimHeight(0.0d);
        periodAxis1.setLabelInsets(rectangleInsets6);
        boolean boolean10 = periodAxis1.isMinorTickMarksVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        combinedRangeXYPlot12.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getRangeMinorGridlinePaint();
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot12);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(13, (int) (short) 1, 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.data.xy.XYDataItem xYDataItem10 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number11 = xYDataItem10.getY();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem10);
        long long13 = timeSeries12.getMaximumItemAge();
        timeSeries12.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        timeSeries12.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection17);
        combinedRangeXYPlot2.setDataset(255, (org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.data.general.DatasetGroup datasetGroup22 = new org.jfree.data.general.DatasetGroup("^0.48");
        timeSeriesCollection17.setGroup(datasetGroup22);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.awt.Font font1 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, 0.0f, textMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        double double10 = size2D9.getHeight();
        java.lang.Object obj11 = size2D9.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("org.jfree.data.general.SeriesException: {0}", paint8);
        java.lang.Comparable comparable10 = legendItem9.getSeriesKey();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList12 = new org.jfree.chart.util.ShapeList();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) shapeList12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        float float21 = jFreeChart20.getBackgroundImageAlpha();
        java.awt.Stroke stroke22 = jFreeChart20.getBorderStroke();
        ringPlot11.setSectionOutlineStroke((java.lang.Comparable) year14, stroke22);
        legendItem9.setOutlineStroke(stroke22);
        java.awt.Shape shape25 = legendItem9.getLine();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        boolean boolean9 = legendTitle8.visible;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        combinedRangeXYPlot11.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = combinedRangeXYPlot11.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        combinedRangeXYPlot11.setRangeAxisLocation(4, axisLocation16, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot11.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot22.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextFillPaint();
        categoryPlot22.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot22.getDomainAxisLocation(1);
        combinedRangeXYPlot11.setDomainAxisLocation(2019, axisLocation28, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj32 = null;
        boolean boolean33 = plotOrientation31.equals(obj32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation28, plotOrientation31);
        legendTitle8.setLegendItemGraphicEdge(rectangleEdge34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.plot.CrosshairState crosshairState39 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean40 = legendTitle8.equals((java.lang.Object) crosshairState39);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("12/31/69", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.getAutoSort();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        combinedRangeXYPlot8.setNotify(false);
        boolean boolean13 = tickUnits4.equals((java.lang.Object) combinedRangeXYPlot8);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis();
        boolean boolean15 = logAxis14.isVerticalTickLabels();
        logAxis14.pan((double) 1900);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = logAxis14.getTickUnit();
        tickUnits4.add((org.jfree.chart.axis.TickUnit) numberTickUnit18);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(numberTickUnit18);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.awt.Shape shape0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            org.jfree.chart.entity.XYItemEntity xYItemEntity9 = new org.jfree.chart.entity.XYItemEntity(shape0, (org.jfree.data.xy.XYDataset) timeSeriesCollection1, 32, 0, "AxisLocation.TOP_OR_RIGHT", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        legendTitle8.setID("[size=-1]");
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(blockContainer9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        float float6 = jFreeChart5.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = jFreeChart5.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 1, jFreeChart5, 1, (int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart5.getPadding();
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis();
        double double13 = logAxis12.getFixedDimension();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        chartRenderingInfo14.setEntityCollection(entityCollection15);
        chartRenderingInfo14.clear();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        combinedRangeXYPlot19.setRangeCrosshairValue((double) (short) 100);
        float float22 = combinedRangeXYPlot19.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.ShapeList shapeList24 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries26 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean28 = xYSeries26.equals((java.lang.Object) 10.0d);
        boolean boolean29 = shapeList24.equals((java.lang.Object) 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo35.getChartArea();
        boolean boolean37 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D36);
        boolean boolean38 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D36);
        shapeList24.setShape(10, (java.awt.Shape) rectangle2D36);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis41);
        java.awt.Stroke stroke43 = combinedRangeXYPlot42.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot42);
        combinedRangeXYPlot42.setNotify(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection47 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number48 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection47);
        int int49 = combinedRangeXYPlot42.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection47);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues50 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list51 = defaultKeyedValues50.getKeys();
        org.jfree.data.Range range53 = timeSeriesCollection47.getDomainBounds(list51, true);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues54 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list55 = defaultKeyedValues54.getKeys();
        org.jfree.data.Range range56 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean59 = range56.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange60 = new org.jfree.data.time.DateRange(range56);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection47, list55, range56, true);
        combinedRangeXYPlot19.drawRangeTickBands(graphics2D23, rectangle2D36, list55);
        chartRenderingInfo14.setChartArea(rectangle2D36);
        logAxis12.setUpArrow((java.awt.Shape) rectangle2D36);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets11.createOutsetRectangle(rectangle2D36, false, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertNotNull(rectangle2D68);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D1.setFixedDimension((double) 0.5f);
        double double4 = categoryAxis3D1.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.trimHeight(0.0d);
        categoryAxis3D1.setLabelInsets(rectangleInsets5, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D12.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer3D12.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint19 = barRenderer3D12.getShadowPaint();
        categoryPlot11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = barRenderer3D12.getBaseItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Stroke stroke24 = legendItem23.getLineStroke();
        java.awt.Stroke stroke25 = legendItem23.getLineStroke();
        boolean boolean26 = barRenderer3D12.equals((java.lang.Object) legendItem23);
        java.awt.Paint paint30 = barRenderer3D12.getItemLabelPaint(2019, 2, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D1, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getIntervalPositionFactor();
        try {
            double double12 = intervalXYDelegate8.getStartXValue(5, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        combinedRangeXYPlot7.setRangeAxisLocation(4, axisLocation12, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot7.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot18.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextFillPaint();
        categoryPlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot18.getDomainAxisLocation(1);
        combinedRangeXYPlot7.setDomainAxisLocation(2019, axisLocation24, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj28 = null;
        boolean boolean29 = plotOrientation27.equals(obj28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation24, plotOrientation27);
        try {
            double double31 = periodAxis1.java2DToValue((double) 0.5f, rectangle2D5, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setRangeDescription("PieLabelLinkStyle.STANDARD");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            timeSeries4.add(timeSeriesDataItem8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(4.0d, (double) 19000L, (double) 1L, 0.5d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        java.awt.Paint paint8 = barRenderer3D0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer3D0.getToolTipGenerator(1900, (int) (byte) 0, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection14.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot16);
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot16.getDomainMarkers(8, layer21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot23.setFixedDomainAxisSpace(axisSpace25, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D28.setTickUnit(numberTickUnit30, true, true);
        java.awt.Shape shape34 = numberAxis3D28.getDownArrow();
        int int35 = categoryPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo40.getChartArea();
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D41);
        java.awt.Color color45 = java.awt.Color.WHITE;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis47);
        java.awt.Stroke stroke49 = combinedRangeXYPlot48.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot48);
        org.jfree.chart.axis.ValueAxis valueAxis52 = combinedRangeXYPlot48.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke53 = combinedRangeXYPlot48.getDomainGridlineStroke();
        barRenderer3D0.drawRangeLine(graphics2D13, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, rectangle2D41, (double) 19000L, (java.awt.Paint) color45, stroke53);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D61 = chartRenderingInfo60.getChartArea();
        boolean boolean62 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D61, rectangleAnchor65, 0.05d, (double) (short) 0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D72 = chartRenderingInfo71.getChartArea();
        boolean boolean73 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D72);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D75 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D72, rectangleAnchor74);
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot78 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis77);
        java.awt.Stroke stroke79 = combinedRangeXYPlot78.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart80 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot78);
        org.jfree.chart.axis.ValueAxis valueAxis82 = combinedRangeXYPlot78.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean83 = combinedRangeXYPlot78.isNotify();
        org.jfree.chart.StandardChartTheme standardChartTheme85 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle86 = standardChartTheme85.getLabelLinkStyle();
        java.awt.Font font87 = standardChartTheme85.getLargeFont();
        java.awt.Color color88 = java.awt.Color.ORANGE;
        standardChartTheme85.setRangeGridlinePaint((java.awt.Paint) color88);
        combinedRangeXYPlot78.setDomainCrosshairPaint((java.awt.Paint) color88);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = combinedRangeXYPlot78.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = null;
        try {
            org.jfree.chart.axis.AxisState axisState93 = numberAxis3D28.draw(graphics2D56, 0.0d, rectangle2D61, rectangle2D72, rectangleEdge91, plotRenderingInfo92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNotNull(point2D75);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNull(valueAxis82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle86);
        org.junit.Assert.assertNotNull(font87);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertNotNull(rectangleEdge91);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone1);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Paint paint2 = null;
        legendItem1.setLabelPaint(paint2);
        boolean boolean4 = legendItem1.isShapeFilled();
        boolean boolean5 = legendItem1.isShapeVisible();
        legendItem1.setToolTipText("TextBlockAnchor.CENTER_RIGHT");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D7.setFixedDimension((double) 0.5f);
        java.util.List list10 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D7);
        java.awt.Stroke stroke11 = categoryPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot1.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot1.getDataset();
        java.lang.String str6 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        boolean boolean4 = standardXYSeriesLabelGenerator1.equals((java.lang.Object) regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD");
        textTitle1.setURLText("{0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getPadding();
        double double6 = rectangleInsets4.trimWidth((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.0d) + "'", double6 == (-2.0d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        xYAreaRenderer1.setSeriesOutlinePaint(0, (java.awt.Paint) color3);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer5 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        combinedRangeXYPlot8.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        java.awt.Stroke stroke15 = combinedRangeXYPlot14.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot14);
        float float17 = jFreeChart16.getBackgroundImageAlpha();
        java.awt.Paint paint18 = jFreeChart16.getBackgroundPaint();
        combinedRangeXYPlot8.setDomainCrosshairPaint(paint18);
        xYAreaRenderer1.setPlot((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1);
        xYStepAreaRenderer1.setShapesVisible(false);
        xYStepAreaRenderer1.setShapesFilled(true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat5.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        java.lang.StringBuffer stringBuffer11 = logFormat5.format((long) 1, stringBuffer9, fieldPosition10);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str17 = logFormat15.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat15);
        java.text.NumberFormat numberFormat19 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat15, numberFormat19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'percentFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stringBuffer11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "^0.48" + "'", str17.equals("^0.48"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        combinedRangeXYPlot2.setDomainCrosshairLockedOnData(false);
        java.lang.String str14 = combinedRangeXYPlot2.getPlotType();
        boolean boolean15 = combinedRangeXYPlot2.isRangeZoomable();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        xYStepAreaRenderer1.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYStepAreaRenderer1.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer1.getBaseNegativeItemLabelPosition();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList9 = new org.jfree.chart.util.ShapeList();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) shapeList9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        java.awt.Stroke stroke19 = jFreeChart17.getBorderStroke();
        ringPlot8.setSectionOutlineStroke((java.lang.Comparable) year11, stroke19);
        java.awt.Paint paint21 = ringPlot8.getBaseSectionOutlinePaint();
        xYStepAreaRenderer1.setBaseLegendTextPaint(paint21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1);
        xYStepAreaRenderer1.setShapesFilled(true);
        xYStepAreaRenderer1.clearSeriesStrokes(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int15 = combinedRangeXYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer14);
        java.awt.Shape shape17 = xYLineAndShapeRenderer14.getSeriesShape(10);
        boolean boolean19 = xYLineAndShapeRenderer14.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean21 = xYLineAndShapeRenderer14.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer14.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str25 = categoryAxis3D24.getLabelURL();
        java.awt.Paint paint26 = categoryAxis3D24.getLabelPaint();
        xYLineAndShapeRenderer14.setBaseItemLabelPaint(paint26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYLineAndShapeRenderer14.getSeriesPositiveItemLabelPosition((int) 'a');
        xYStepAreaRenderer1.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition29);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator31 = null;
        xYStepAreaRenderer1.setBaseURLGenerator(xYURLGenerator31);
        xYStepAreaRenderer1.setOutline(true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }
}

