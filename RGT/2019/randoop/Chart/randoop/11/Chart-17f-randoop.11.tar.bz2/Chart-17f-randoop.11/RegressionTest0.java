import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        try {
            timeSeries1.delete((int) ' ', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        try {
            timeSeries1.delete((int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.isEmpty();
        try {
            timeSeries1.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (short) 10);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.lang.Object obj6 = timeSeries1.clone();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (short) 10);
        try {
            timeSeries1.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (short) 10);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (byte) 1);
        int int12 = timeSeriesDataItem10.compareTo((java.lang.Object) "hi!");
        try {
            timeSeries1.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1, 2, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean10 = month8.equals((java.lang.Object) (short) 100);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 11, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getEndOfCurrentMonth(serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate1.getFollowingDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("28-February-1900");
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        try {
            timeSeries1.add(timeSeriesDataItem12, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        java.lang.String str6 = month2.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 100" + "'", str6.equals("January 100"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setDomainDescription("hi!");
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        java.lang.String str9 = timeSeries5.getDescription();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getEndOfCurrentMonth(serialDate3);
        java.lang.String str5 = serialDate4.toString();
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate4.getFollowingDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "28-February-1900" + "'", str5.equals("28-February-1900"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year7 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59011603200000L) + "'", long6 == (-59011603200000L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        int int15 = year12.getYear();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year12.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getEndOfCurrentMonth(serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 10);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (byte) 10 + "'", obj2.equals((byte) 10));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year12.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean14 = month12.equals((java.lang.Object) (short) 100);
        long long15 = month12.getLastMillisecond();
        long long16 = month12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (double) 1);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 1900, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-59008924800001L) + "'", long15 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-59010264000001L) + "'", long16 == (-59010264000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setDomainDescription("hi!");
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        try {
            timeSeries1.update(1969, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        try {
            org.jfree.data.time.Year year12 = month6.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate7.getNearestDayOfWeek(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate5);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (short) 10);
        int int24 = month16.compareTo((java.lang.Object) timeSeriesDataItem23);
        java.lang.Number number25 = null;
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month16, number25);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(uRL11);
        org.junit.Assert.assertNull(inputStream12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem19.getPeriod();
        boolean boolean22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) str14, (java.lang.Object) regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass9);
        try {
            timeSeries13.delete(2, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(uRL11);
        org.junit.Assert.assertNull(inputStream12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year12.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        try {
            timeSeries1.update((int) (short) 10, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 'a' + "'", comparable6.equals('a'));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        long long12 = month6.getLastMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month6.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-59008924800001L) + "'", long12 == (-59008924800001L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        java.util.Calendar calendar28 = null;
        try {
            year23.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (short) 10);
        int int10 = month2.compareTo((java.lang.Object) timeSeriesDataItem9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getMiddleMillisecond();
        long long7 = month2.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59010264000001L) + "'", long6 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59008924800001L) + "'", long7 == (-59008924800001L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        long long12 = month6.getLastMillisecond();
        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths(false);
        boolean boolean15 = month6.equals((java.lang.Object) strArray14);
        try {
            org.jfree.data.time.Year year16 = month6.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-59008924800001L) + "'", long12 == (-59008924800001L));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("January 100");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getNearestDayOfWeek((int) (short) 1);
        try {
            int int38 = spreadsheetDate13.compareTo((java.lang.Object) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year12.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries8.setDomainDescription("hi!");
        boolean boolean12 = timeSeries8.equals((java.lang.Object) 0L);
        java.util.List list13 = timeSeries8.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9999);
        java.util.Date date18 = fixedMillisecond15.getEnd();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 'a' + "'", comparable6.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year12.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean15 = timeSeriesDataItem10.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem10.getPeriod();
        try {
            timeSeries1.update(regularTimePeriod16, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 1);
        int int16 = month13.getMonth();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        try {
            java.lang.Number number5 = timeSeries1.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setDomainDescription("hi!");
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
        java.lang.Object obj15 = timeSeriesDataItem13.clone();
        try {
            timeSeries5.add(timeSeriesDataItem13, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj15);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate9.toSerial();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        try {
            int int19 = spreadsheetDate9.compareTo((java.lang.Object) timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeriesDataItem cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries1.setRangeDescription("1969");
        java.lang.Class class22 = timeSeries1.getTimePeriodClass();
        boolean boolean23 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        long long15 = year12.getFirstMillisecond();
        int int16 = year12.getYear();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year12.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        int int3 = day1.getYear();
        java.lang.Class<?> wildcardClass4 = day1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Time", class5);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(inputStream6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate44 = serialDate41.getEndOfCurrentMonth(serialDate43);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(0, serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate49 = serialDate46.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate51 = day50.getSerialDate();
        boolean boolean52 = spreadsheetDate48.isOn(serialDate51);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate57 = serialDate54.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate63 = serialDate60.getEndOfCurrentMonth(serialDate62);
        java.lang.String str64 = serialDate63.toString();
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths(0, serialDate63);
        boolean boolean67 = spreadsheetDate48.isInRange(serialDate57, serialDate63, 0);
        boolean boolean68 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean69 = spreadsheetDate36.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate71 = spreadsheetDate48.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate78 = serialDate75.getEndOfCurrentMonth(serialDate77);
        java.lang.String str79 = serialDate78.toString();
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addMonths(0, serialDate78);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, serialDate78);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate86 = serialDate83.getEndOfCurrentMonth(serialDate85);
        boolean boolean87 = spreadsheetDate48.isInRange(serialDate78, serialDate85);
        int int88 = spreadsheetDate1.compareTo((java.lang.Object) serialDate85);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "28-February-1900" + "'", str45.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "28-February-1900" + "'", str64.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "28-February-1900" + "'", str79.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-17) + "'", int88 == (-17));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        java.lang.Class<?> wildcardClass7 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass7);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("1969", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(uRL9);
        org.junit.Assert.assertNull(inputStream10);
        org.junit.Assert.assertNull(uRL11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        boolean boolean33 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        int int7 = day5.getYear();
        int int8 = day5.getMonth();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.lang.String str33 = timeSeries25.getDescription();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries35.setDomainDescription("hi!");
        boolean boolean39 = timeSeries35.equals((java.lang.Object) 0L);
        java.util.List list40 = timeSeries35.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 9999);
        java.util.Date date45 = fixedMillisecond42.getEnd();
        long long46 = fixedMillisecond42.getFirstMillisecond();
        long long47 = fixedMillisecond42.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond42.next();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.lang.String str33 = timeSeries25.getDescription();
        boolean boolean34 = timeSeries25.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        java.lang.Class<?> wildcardClass7 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass7);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) uRL9);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(uRL9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem4.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem4.getPeriod();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        int int9 = day7.getYear();
        java.lang.Class<?> wildcardClass10 = day7.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        boolean boolean12 = timeSeriesDataItem4.equals((java.lang.Object) wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.setDescription("");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.isEmpty();
        boolean boolean3 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        timeSeries25.setDescription("28-February-1900");
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries36.setDomainDescription("hi!");
        boolean boolean40 = timeSeries36.equals((java.lang.Object) 0L);
        java.util.List list41 = timeSeries36.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 9999);
        java.util.Date date46 = fixedMillisecond43.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year47, (double) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year47.next();
        java.lang.String str51 = year47.toString();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month54, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        int int58 = timeSeriesDataItem56.compareTo((java.lang.Object) day57);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection61 = timeSeries60.getTimePeriods();
        int int62 = timeSeriesDataItem56.compareTo((java.lang.Object) timeSeries60);
        int int63 = year47.compareTo((java.lang.Object) timeSeriesDataItem56);
        try {
            timeSeries25.add(timeSeriesDataItem56);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1969" + "'", str51.equals("1969"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(collection61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate9.toSerial();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.util.List list18 = timeSeries13.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries24.setDomainDescription("hi!");
        boolean boolean28 = timeSeries24.equals((java.lang.Object) 0L);
        java.util.List list29 = timeSeries24.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 9999);
        java.util.Date date34 = fixedMillisecond31.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, (double) 5);
        boolean boolean40 = spreadsheetDate9.equals((java.lang.Object) timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(3, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year12.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, (int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        timeSeries1.setDescription("ClassContext");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(11, 1969);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-31507200000L));
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        long long28 = year23.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-31507200000L) + "'", long28 == (-31507200000L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean8 = month6.equals((java.lang.Object) (short) 100);
        long long9 = month6.getLastMillisecond();
        long long10 = month6.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries14.setDomainDescription("hi!");
        boolean boolean18 = timeSeries14.equals((java.lang.Object) 0L);
        java.util.List list19 = timeSeries14.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 9999);
        java.util.Date date24 = fixedMillisecond21.getEnd();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        long long26 = fixedMillisecond21.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond21.next();
        try {
            timeSeries1.add(regularTimePeriod27, (double) 10.0f, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-59008924800001L) + "'", long9 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-59010264000001L) + "'", long10 == (-59010264000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, 6, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("January 100");
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries10.setDomainDescription("hi!");
        boolean boolean14 = timeSeries10.equals((java.lang.Object) 0L);
        java.util.List list15 = timeSeries10.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond17.previous();
        try {
            timeSeries1.add(regularTimePeriod20, (double) 8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        java.util.Date date12 = month6.getEnd();
        long long13 = month6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59008924800001L) + "'", long13 == (-59008924800001L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        boolean boolean6 = timeSeries2.equals((java.lang.Object) 0L);
        java.util.List list7 = timeSeries2.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.util.List list18 = timeSeries13.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 9999);
        java.util.Date date23 = fixedMillisecond20.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 5);
        int int29 = year24.getYear();
        try {
            org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) -1, year24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        long long11 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond8.next();
        java.util.Date date13 = fixedMillisecond8.getTime();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem4.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem4.getPeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        timeSeries1.removeAgedItems(true);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem39.getPeriod();
        java.lang.Number number41 = timeSeriesDataItem39.getValue();
        try {
            timeSeries1.add(timeSeriesDataItem39);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (short) 10 + "'", number41.equals((short) 10));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem4.getPeriod();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean11 = timeSeriesDataItem4.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean10 = month8.equals((java.lang.Object) (short) 100);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59008924800001L) + "'", long11 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9, 1900, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        java.util.Calendar calendar15 = null;
        try {
            year12.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        java.lang.String str11 = serialDate10.toString();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(0, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        boolean boolean18 = spreadsheetDate14.isOn(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        java.lang.String str30 = serialDate29.toString();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(0, serialDate29);
        boolean boolean33 = spreadsheetDate14.isInRange(serialDate23, serialDate29, 0);
        boolean boolean34 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean35 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int36 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28-February-1900" + "'", str11.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "28-February-1900" + "'", str30.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.String str3 = timeSeries1.getDescription();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        timeSeries1.setMaximumItemCount(2958465);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.previous();
        java.lang.String str16 = year12.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        int int8 = month2.getMonth();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getLastMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (double) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setNotify(false);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean12 = month10.equals((java.lang.Object) (short) 100);
        long long13 = month10.getLastMillisecond();
        long long14 = month10.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59008924800001L) + "'", long13 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-59010264000001L) + "'", long14 == (-59010264000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond8.getMiddleMillisecond(calendar14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        boolean boolean13 = spreadsheetDate9.isOn(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getEndOfCurrentMonth(serialDate23);
        java.lang.String str25 = serialDate24.toString();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(0, serialDate24);
        boolean boolean28 = spreadsheetDate9.isInRange(serialDate18, serialDate24, 0);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate35 = serialDate32.getEndOfCurrentMonth(serialDate34);
        java.lang.String str36 = serialDate35.toString();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate40 = serialDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate37);
        boolean boolean42 = spreadsheetDate9.isOnOrBefore(serialDate41);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "28-February-1900" + "'", str25.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "28-February-1900" + "'", str36.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        timeSeries1.setMaximumItemCount(1969);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100 + "'", obj2.equals(100));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean10 = month8.equals((java.lang.Object) (short) 100);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        long long13 = month8.getLastMillisecond();
        int int15 = month8.compareTo((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59008924800001L) + "'", long11 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59008924800001L) + "'", long13 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        java.lang.String str11 = serialDate10.toString();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(0, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        boolean boolean18 = spreadsheetDate14.isOn(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        java.lang.String str30 = serialDate29.toString();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(0, serialDate29);
        boolean boolean33 = spreadsheetDate14.isInRange(serialDate23, serialDate29, 0);
        boolean boolean34 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean35 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int36 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28-February-1900" + "'", str11.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "28-February-1900" + "'", str30.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        int int5 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, 0.0d);
        java.util.Date date14 = month9.getStart();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries20.setDomainDescription("hi!");
        java.util.Collection collection23 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        int int24 = month9.compareTo((java.lang.Object) timeSeries16);
        int int25 = month9.getYearValue();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean30 = month28.equals((java.lang.Object) (short) 100);
        long long31 = month28.getLastMillisecond();
        long long32 = month28.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
        java.lang.String str43 = serialDate42.toString();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(0, serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        boolean boolean50 = spreadsheetDate46.isOn(serialDate49);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate55 = serialDate52.getEndOfCurrentMonth(serialDate54);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate61 = serialDate58.getEndOfCurrentMonth(serialDate60);
        java.lang.String str62 = serialDate61.toString();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths(0, serialDate61);
        boolean boolean65 = spreadsheetDate46.isInRange(serialDate55, serialDate61, 0);
        boolean boolean66 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean67 = spreadsheetDate34.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate46.getNearestDayOfWeek((int) (short) 1);
        int int70 = month28.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.Object obj72 = timeSeries1.clone();
        try {
            java.lang.Number number74 = timeSeries1.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-59008924800001L) + "'", long31 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-59010264000001L) + "'", long32 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28-February-1900" + "'", str43.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "28-February-1900" + "'", str62.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(obj72);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries1.setRangeDescription("1969");
        java.lang.Class class22 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries1.removeChangeListener(seriesChangeListener23);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class22);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
        long long9 = day8.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 60L + "'", long9 == 60L);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
//        java.util.List list6 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
//        timeSeries1.clear();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 0);
//        int int16 = day12.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        java.lang.String str11 = serialDate10.toString();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(0, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        boolean boolean18 = spreadsheetDate14.isOn(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        java.lang.String str30 = serialDate29.toString();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(0, serialDate29);
        boolean boolean33 = spreadsheetDate14.isInRange(serialDate23, serialDate29, 0);
        boolean boolean34 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean35 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        try {
            org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28-February-1900" + "'", str11.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "28-February-1900" + "'", str30.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getFirstMillisecond();
        java.lang.String str7 = month2.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59011603200000L) + "'", long6 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 100" + "'", str7.equals("January 100"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        java.lang.String str38 = spreadsheetDate13.getDescription();
        java.util.Date date39 = spreadsheetDate13.toDate();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39, timeZone40);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        java.lang.String str22 = serialDate21.toString();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(0, serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
        boolean boolean29 = spreadsheetDate25.isOn(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate40 = serialDate37.getEndOfCurrentMonth(serialDate39);
        java.lang.String str41 = serialDate40.toString();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(0, serialDate40);
        boolean boolean44 = spreadsheetDate25.isInRange(serialDate34, serialDate40, 0);
        boolean boolean45 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean46 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate25.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate54 = serialDate51.getEndOfCurrentMonth(serialDate53);
        java.lang.String str55 = serialDate54.toString();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addMonths(0, serialDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate59 = serialDate56.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate61 = day60.getSerialDate();
        boolean boolean62 = spreadsheetDate58.isOn(serialDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate70 = serialDate67.getEndOfCurrentMonth(serialDate69);
        java.lang.String str71 = serialDate70.toString();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addMonths(0, serialDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate75 = serialDate72.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate77 = day76.getSerialDate();
        boolean boolean78 = spreadsheetDate74.isOn(serialDate77);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate83 = serialDate80.getEndOfCurrentMonth(serialDate82);
        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate89 = serialDate86.getEndOfCurrentMonth(serialDate88);
        java.lang.String str90 = serialDate89.toString();
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addMonths(0, serialDate89);
        boolean boolean93 = spreadsheetDate74.isInRange(serialDate83, serialDate89, 0);
        boolean boolean94 = spreadsheetDate64.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean95 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate64);
        boolean boolean96 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "28-February-1900" + "'", str22.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "28-February-1900" + "'", str41.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "28-February-1900" + "'", str55.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "28-February-1900" + "'", str71.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "28-February-1900" + "'", str90.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, 0.0d);
        timeSeries2.setKey((java.lang.Comparable) month7);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries14.setDomainDescription("hi!");
        boolean boolean18 = timeSeries14.equals((java.lang.Object) 0L);
        java.lang.Object obj19 = timeSeries14.clone();
        java.util.Collection collection20 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries2.setRangeDescription("1969");
        java.lang.Class class23 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.util.List list30 = timeSeries25.getItems();
        timeSeries25.setDescription("ClassContext");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries39.setDomainDescription("hi!");
        boolean boolean42 = timeSeriesDataItem37.equals((java.lang.Object) "hi!");
        boolean boolean43 = timeSeries25.equals((java.lang.Object) timeSeriesDataItem37);
        java.util.Collection collection44 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        boolean boolean45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0f, (java.lang.Object) collection44);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        long long11 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond8.next();
        int int14 = fixedMillisecond8.compareTo((java.lang.Object) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond8.next();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond8.getLastMillisecond(calendar16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (short) 10);
        int int10 = month2.compareTo((java.lang.Object) timeSeriesDataItem9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        long long22 = fixedMillisecond19.getLastMillisecond();
        int int23 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems((long) 1, true);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        try {
            org.jfree.data.time.Year year7 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January 100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        int int3 = day1.getYear();
        java.lang.Class<?> wildcardClass4 = day1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass4);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, 0.0d);
        java.util.Date date14 = month9.getStart();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries18.setDomainDescription("hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, 0.0d);
        timeSeries18.setKey((java.lang.Comparable) month23);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries30.setDomainDescription("hi!");
        boolean boolean34 = timeSeries30.equals((java.lang.Object) 0L);
        java.lang.Object obj35 = timeSeries30.clone();
        java.util.Collection collection36 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        timeSeries18.setRangeDescription("1969");
        java.lang.Class class39 = timeSeries18.getTimePeriodClass();
        java.lang.ClassLoader classLoader40 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class39);
        boolean boolean41 = timeSeries16.equals((java.lang.Object) class39);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries43.setDomainDescription("hi!");
        boolean boolean47 = timeSeries43.equals((java.lang.Object) 0L);
        java.util.List list48 = timeSeries43.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) 9999);
        java.util.Date date53 = fixedMillisecond50.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date53, timeZone54);
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date53, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone56);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(uRL6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(classLoader40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod58);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.next();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate37 = null;
        try {
            int int38 = spreadsheetDate13.compare(serialDate37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        java.lang.String str22 = serialDate21.toString();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(0, serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
        boolean boolean29 = spreadsheetDate25.isOn(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate40 = serialDate37.getEndOfCurrentMonth(serialDate39);
        java.lang.String str41 = serialDate40.toString();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(0, serialDate40);
        boolean boolean44 = spreadsheetDate25.isInRange(serialDate34, serialDate40, 0);
        boolean boolean45 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean46 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate25.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate55 = serialDate52.getEndOfCurrentMonth(serialDate54);
        java.lang.String str56 = serialDate55.toString();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(0, serialDate55);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, serialDate55);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate63 = serialDate60.getEndOfCurrentMonth(serialDate62);
        boolean boolean64 = spreadsheetDate25.isInRange(serialDate55, serialDate62);
        boolean boolean65 = timeSeries1.equals((java.lang.Object) serialDate62);
        org.jfree.data.time.SerialDate serialDate67 = serialDate62.getNearestDayOfWeek(1);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "28-February-1900" + "'", str22.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "28-February-1900" + "'", str41.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "28-February-1900" + "'", str56.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(serialDate67);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        java.lang.Object obj13 = timeSeries1.clone();
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries1.setRangeDescription("1969");
        java.lang.Class class22 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries24.setDomainDescription("hi!");
        boolean boolean28 = timeSeries24.equals((java.lang.Object) 0L);
        java.util.List list29 = timeSeries24.getItems();
        timeSeries24.setDescription("ClassContext");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries38.setDomainDescription("hi!");
        boolean boolean41 = timeSeriesDataItem36.equals((java.lang.Object) "hi!");
        boolean boolean42 = timeSeries24.equals((java.lang.Object) timeSeriesDataItem36);
        java.util.Collection collection43 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        try {
            java.lang.Number number45 = timeSeries24.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(collection43);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        long long11 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond8.next();
        long long13 = fixedMillisecond8.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1969);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-459));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("28-February-1900");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 28-February-1900" + "'", str2.equals("org.jfree.data.general.SeriesException: 28-February-1900"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, 0.0d);
        java.util.Date date14 = month9.getStart();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries20.setDomainDescription("hi!");
        java.util.Collection collection23 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        int int24 = month9.compareTo((java.lang.Object) timeSeries16);
        int int25 = month9.getYearValue();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean30 = month28.equals((java.lang.Object) (short) 100);
        long long31 = month28.getLastMillisecond();
        long long32 = month28.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
        java.lang.String str43 = serialDate42.toString();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(0, serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        boolean boolean50 = spreadsheetDate46.isOn(serialDate49);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate55 = serialDate52.getEndOfCurrentMonth(serialDate54);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate61 = serialDate58.getEndOfCurrentMonth(serialDate60);
        java.lang.String str62 = serialDate61.toString();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths(0, serialDate61);
        boolean boolean65 = spreadsheetDate46.isInRange(serialDate55, serialDate61, 0);
        boolean boolean66 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean67 = spreadsheetDate34.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate46.getNearestDayOfWeek((int) (short) 1);
        int int70 = month28.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month9.previous();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-59008924800001L) + "'", long31 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-59010264000001L) + "'", long32 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28-February-1900" + "'", str43.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "28-February-1900" + "'", str62.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate(regularTimePeriod4, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', (-17));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getNearestDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable throwable8 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Time");
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 0L);
        long long16 = fixedMillisecond8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        boolean boolean6 = timeSeries2.equals((java.lang.Object) 0L);
        java.util.List list7 = timeSeries2.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 9999);
        java.util.Date date12 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        long long14 = year13.getFirstMillisecond();
        java.lang.String str15 = year13.toString();
        long long16 = year13.getFirstMillisecond();
        int int17 = year13.getYear();
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(2958465, year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31507200000L) + "'", long14 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
//        timeSeries1.setKey((java.lang.Comparable) month6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries13.setDomainDescription("hi!");
//        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
//        java.lang.Object obj18 = timeSeries13.clone();
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        timeSeries1.setRangeDescription("1969");
//        java.lang.Comparable comparable22 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries24.setDomainDescription("hi!");
//        boolean boolean28 = timeSeries24.equals((java.lang.Object) 0L);
//        java.util.List list29 = timeSeries24.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 9999);
//        timeSeries24.clear();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 35);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(comparable22);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(list29);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560452399999L + "'", long36 == 1560452399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        java.lang.String str38 = spreadsheetDate13.getDescription();
        java.util.Date date39 = spreadsheetDate13.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        timeSeries1.setDescription("ClassContext");
        timeSeries1.setDomainDescription("Sunday");
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        long long7 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries10.setDomainDescription("hi!");
        boolean boolean14 = timeSeries10.equals((java.lang.Object) 0L);
        java.util.List list15 = timeSeries10.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond17.previous();
        long long21 = fixedMillisecond17.getMiddleMillisecond();
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries1.createCopy(regularTimePeriod8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        boolean boolean6 = timeSeries2.equals((java.lang.Object) 0L);
        java.util.List list7 = timeSeries2.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 9999);
        java.util.Date date12 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        java.lang.String str14 = year13.toString();
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) '#', year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems((long) 35, false);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        try {
            java.lang.Number number21 = timeSeries1.getValue((-17));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "September" + "'", str2.equals("September"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        try {
            timeSeries1.update((int) (byte) 100, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries1.setRangeDescription("1969");
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, 0.0d);
        java.util.Date date29 = month24.getStart();
        java.lang.Number number30 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month24, number30);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries11.setNotify(false);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries1.setRangeDescription("1969");
        java.lang.Class class22 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries24.setDomainDescription("hi!");
        boolean boolean28 = timeSeries24.equals((java.lang.Object) 0L);
        java.util.List list29 = timeSeries24.getItems();
        timeSeries24.setDescription("ClassContext");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries38.setDomainDescription("hi!");
        boolean boolean41 = timeSeriesDataItem36.equals((java.lang.Object) "hi!");
        boolean boolean42 = timeSeries24.equals((java.lang.Object) timeSeriesDataItem36);
        java.util.Collection collection43 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener44);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(collection43);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ThreadContext" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: ThreadContext"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        int int28 = year23.getYear();
        long long29 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year23.next();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31507200000L) + "'", long29 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(7, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jul" + "'", str2.equals("Jul"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = serialDate43.getEndOfCurrentMonth(serialDate45);
        java.lang.String str47 = serialDate46.toString();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(0, serialDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate51 = serialDate48.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate53 = day52.getSerialDate();
        boolean boolean54 = spreadsheetDate50.isOn(serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = serialDate56.getEndOfCurrentMonth(serialDate58);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = serialDate62.getEndOfCurrentMonth(serialDate64);
        java.lang.String str66 = serialDate65.toString();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addMonths(0, serialDate65);
        boolean boolean69 = spreadsheetDate50.isInRange(serialDate59, serialDate65, 0);
        boolean boolean70 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean71 = spreadsheetDate38.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate50.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate80 = serialDate77.getEndOfCurrentMonth(serialDate79);
        java.lang.String str81 = serialDate80.toString();
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addMonths(0, serialDate80);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, serialDate80);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate88 = serialDate85.getEndOfCurrentMonth(serialDate87);
        boolean boolean89 = spreadsheetDate50.isInRange(serialDate80, serialDate87);
        boolean boolean90 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "28-February-1900" + "'", str47.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "28-February-1900" + "'", str66.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "28-February-1900" + "'", str81.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        timeSeries1.removeAgedItems(true);
        try {
            timeSeries1.delete(0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        int int5 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        java.lang.Class<?> wildcardClass6 = timeSeries4.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass6);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Sunday", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNull(uRL9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem4.getPeriod();
        java.lang.Number number6 = timeSeriesDataItem4.getValue();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        java.lang.Class<?> wildcardClass11 = timeSeries9.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass11);
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        int int14 = timeSeriesDataItem4.compareTo((java.lang.Object) classLoader13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem4.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.lang.Object obj6 = timeSeries1.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        long long7 = timeSeries1.getMaximumItemAge();
        timeSeries1.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str8 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ThreadContext" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: ThreadContext"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, 11, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass9);
        try {
            java.lang.Number number15 = timeSeries13.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(uRL11);
        org.junit.Assert.assertNull(inputStream12);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
//        java.util.List list6 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries12.setDomainDescription("hi!");
//        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
//        java.util.List list17 = timeSeries12.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
//        java.util.Date date22 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries1.getTimePeriod(0);
//        java.util.List list30 = timeSeries1.getItems();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = timeSeriesDataItem35.compareTo((java.lang.Object) day36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day36.next();
//        long long39 = day36.getFirstMillisecond();
//        long long40 = day36.getFirstMillisecond();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day36, (double) 6, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 13-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560409200000L + "'", long39 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        int int3 = day1.getYear();
        java.lang.Class<?> wildcardClass4 = day1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("September", class5);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(uRL6);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean10 = month8.equals((java.lang.Object) (short) 100);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        long long13 = month8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59008924800001L) + "'", long11 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59011603200000L) + "'", long13 == (-59011603200000L));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jul", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 100");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: January 100" + "'", str2.equals("org.jfree.data.general.SeriesException: January 100"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries4.setDomainDescription("hi!");
        boolean boolean8 = timeSeries4.equals((java.lang.Object) 0L);
        java.util.List list9 = timeSeries4.getItems();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, 0.0d);
        java.util.Date date17 = month12.getStart();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries19.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries23.setDomainDescription("hi!");
        java.util.Collection collection26 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        int int27 = month12.compareTo((java.lang.Object) timeSeries19);
        int int28 = month12.getYearValue();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean33 = month31.equals((java.lang.Object) (short) 100);
        long long34 = month31.getLastMillisecond();
        long long35 = month31.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate45 = serialDate42.getEndOfCurrentMonth(serialDate44);
        java.lang.String str46 = serialDate45.toString();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(0, serialDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate50 = serialDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate52 = day51.getSerialDate();
        boolean boolean53 = spreadsheetDate49.isOn(serialDate52);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate64 = serialDate61.getEndOfCurrentMonth(serialDate63);
        java.lang.String str65 = serialDate64.toString();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(0, serialDate64);
        boolean boolean68 = spreadsheetDate49.isInRange(serialDate58, serialDate64, 0);
        boolean boolean69 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean70 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate72 = spreadsheetDate49.getNearestDayOfWeek((int) (short) 1);
        int int73 = month31.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month31);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month31, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-59008924800001L) + "'", long34 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-59010264000001L) + "'", long35 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "28-February-1900" + "'", str46.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "28-February-1900" + "'", str65.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(timeSeries74);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        java.lang.String str16 = year12.toString();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) day22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection26 = timeSeries25.getTimePeriods();
        int int27 = timeSeriesDataItem21.compareTo((java.lang.Object) timeSeries25);
        int int28 = year12.compareTo((java.lang.Object) timeSeriesDataItem21);
        int int29 = year12.getYear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        java.util.Collection collection16 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        int int17 = month2.compareTo((java.lang.Object) timeSeries9);
        int int18 = month2.getYearValue();
        try {
            org.jfree.data.time.Year year19 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("13-June-2019");
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        java.util.Date date2 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Sunday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
//        int int7 = day5.getYear();
//        long long8 = day5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond8.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond8.peg(calendar15);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond8.getMiddleMillisecond(calendar17);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems((long) 1, true);
        timeSeries1.setRangeDescription("Sunday");
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        int int9 = day5.getMonth();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        java.lang.Object obj13 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection33 = org.jfree.chart.util.ObjectUtilities.deepClone(collection32);
        java.util.Collection collection34 = org.jfree.chart.util.ObjectUtilities.deepClone(collection33);
        java.util.Collection collection35 = org.jfree.chart.util.ObjectUtilities.deepClone(collection33);
        java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) collection35);
        java.util.Collection collection37 = org.jfree.chart.util.ObjectUtilities.deepClone(collection35);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        java.util.Collection collection16 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        int int17 = month2.compareTo((java.lang.Object) timeSeries9);
        int int18 = month2.getYearValue();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month2.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
//        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
//        java.lang.String str29 = serialDate28.toString();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
//        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
//        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        int int35 = spreadsheetDate13.toSerial();
//        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
//        java.lang.String str38 = spreadsheetDate13.getDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month41, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = timeSeriesDataItem43.compareTo((java.lang.Object) day44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day44.next();
//        long long47 = day44.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day44.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day44.next();
//        boolean boolean50 = spreadsheetDate13.equals((java.lang.Object) day44);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560409200000L + "'", long47 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("September");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(1);
        boolean boolean6 = spreadsheetDate1.isAfter(serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = null;
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
        java.lang.String str14 = serialDate13.toString();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(0, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        boolean boolean21 = spreadsheetDate17.isOn(serialDate20);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate32 = serialDate29.getEndOfCurrentMonth(serialDate31);
        java.lang.String str33 = serialDate32.toString();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(0, serialDate32);
        boolean boolean36 = spreadsheetDate17.isInRange(serialDate26, serialDate32, 0);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate44 = serialDate41.getEndOfCurrentMonth(serialDate43);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(0, serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate49 = serialDate46.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate46);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears(1, serialDate46);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getEndOfCurrentMonth(serialDate55);
        serialDate56.setDescription("ClassContext");
        boolean boolean59 = spreadsheetDate17.isInRange(serialDate46, serialDate56);
        try {
            boolean boolean61 = spreadsheetDate1.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate17, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "28-February-1900" + "'", str14.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "28-February-1900" + "'", str33.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "28-February-1900" + "'", str45.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("13-June-2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        timeSeries25.removeAgedItems((long) 11, true);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries40.setDomainDescription("hi!");
        boolean boolean44 = timeSeries40.equals((java.lang.Object) 0L);
        java.util.List list45 = timeSeries40.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 9999);
        java.util.Date date50 = fixedMillisecond47.getEnd();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year51, (double) (short) 0);
        boolean boolean55 = timeSeriesDataItem53.equals((java.lang.Object) (short) 0);
        boolean boolean56 = month38.equals((java.lang.Object) (short) 0);
        int int57 = month38.getMonth();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) month38);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-17));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.lang.Comparable comparable33 = timeSeries25.getKey();
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (byte) 1 + "'", comparable33.equals((byte) 1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        long long11 = fixedMillisecond8.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2958465);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        long long28 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getFirstMillisecond();
        long long7 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59011603200000L) + "'", long6 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1201L + "'", long7 == 1201L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        try {
            org.jfree.data.time.Year year5 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Jul");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        boolean boolean6 = timeSeries2.equals((java.lang.Object) 0L);
        java.util.List list7 = timeSeries2.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.util.List list18 = timeSeries13.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 9999);
        java.util.Date date23 = fixedMillisecond20.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 5);
        int int29 = year24.getYear();
        long long30 = year24.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year24.next();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries33.setDomainDescription("hi!");
        boolean boolean37 = timeSeries33.equals((java.lang.Object) 0L);
        java.util.Collection collection38 = timeSeries33.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries40.setDomainDescription("hi!");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, 0.0d);
        timeSeries40.setKey((java.lang.Comparable) month45);
        long long51 = month45.getLastMillisecond();
        int int52 = month45.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) month45);
        boolean boolean54 = year24.equals((java.lang.Object) timeSeries33);
        try {
            org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((-457), year24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-59008924800001L) + "'", long51 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
//        java.util.List list6 = timeSeries1.getItems();
//        timeSeries1.setDescription("ClassContext");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries15.setDomainDescription("hi!");
//        boolean boolean18 = timeSeriesDataItem13.equals((java.lang.Object) "hi!");
//        boolean boolean19 = timeSeries1.equals((java.lang.Object) timeSeriesDataItem13);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = timeSeriesDataItem24.compareTo((java.lang.Object) day25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
//        long long28 = day25.getFirstMillisecond();
//        long long29 = day25.getFirstMillisecond();
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 2019);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy((int) (short) 10, (int) 'a');
        boolean boolean17 = timeSeries16.isEmpty();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(uRL11);
        org.junit.Assert.assertNull(inputStream12);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        java.lang.String str11 = serialDate10.toString();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(0, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        boolean boolean18 = spreadsheetDate14.isOn(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        java.lang.String str30 = serialDate29.toString();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(0, serialDate29);
        boolean boolean33 = spreadsheetDate14.isInRange(serialDate23, serialDate29, 0);
        boolean boolean34 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean35 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int36 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate14.getNearestDayOfWeek(4);
        java.lang.String str39 = spreadsheetDate14.getDescription();
        java.util.Date date40 = spreadsheetDate14.toDate();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date40, timeZone41);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28-February-1900" + "'", str11.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "28-February-1900" + "'", str30.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        boolean boolean6 = timeSeries2.equals((java.lang.Object) 0L);
        java.util.List list7 = timeSeries2.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 9999);
        java.util.Date date12 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        long long14 = year13.getFirstMillisecond();
        java.lang.String str15 = year13.toString();
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) 'a', year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31507200000L) + "'", long14 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries1.getNotify();
        timeSeries1.setDomainDescription("ERROR : Relative To String");
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        timeSeries1.setDescription("ClassContext");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean12 = month10.equals((java.lang.Object) (short) 100);
        long long13 = month10.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries15.setDomainDescription("hi!");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, 0.0d);
        timeSeries15.setKey((java.lang.Comparable) month20);
        long long26 = month20.getLastMillisecond();
        java.lang.String[] strArray28 = org.jfree.data.time.SerialDate.getMonths(false);
        boolean boolean29 = month20.equals((java.lang.Object) strArray28);
        int int30 = month10.compareTo((java.lang.Object) month20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59008924800001L) + "'", long13 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-59008924800001L) + "'", long26 == (-59008924800001L));
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        int int7 = day5.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        int int5 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries7.setDomainDescription("hi!");
        timeSeries7.removeAgedItems((long) (byte) 1, false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        java.lang.String str23 = serialDate22.toString();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(0, serialDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate27 = serialDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        boolean boolean30 = spreadsheetDate26.isOn(serialDate29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate35 = serialDate32.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getEndOfCurrentMonth(serialDate40);
        java.lang.String str42 = serialDate41.toString();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, serialDate41);
        boolean boolean45 = spreadsheetDate26.isInRange(serialDate35, serialDate41, 0);
        boolean boolean46 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean47 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int48 = spreadsheetDate26.toSerial();
        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate26.getNearestDayOfWeek(4);
        java.lang.String str51 = spreadsheetDate26.getDescription();
        java.util.Date date52 = spreadsheetDate26.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 13);
        long long58 = day55.getMiddleMillisecond();
        int int59 = month2.compareTo((java.lang.Object) day55);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "28-February-1900" + "'", str23.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "28-February-1900" + "'", str42.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 35 + "'", int48 == 35);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2206065600001L) + "'", long58 == (-2206065600001L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
//        timeSeries1.setKey((java.lang.Comparable) month6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries13.setDomainDescription("hi!");
//        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
//        java.lang.Object obj18 = timeSeries13.clone();
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        timeSeries1.setRangeDescription("1969");
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
//        int int24 = day22.getDayOfMonth();
//        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.SerialDate serialDate26 = day22.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries3.setDomainDescription("hi!");
        boolean boolean7 = timeSeries3.equals((java.lang.Object) 0L);
        java.util.List list8 = timeSeries3.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries14.setDomainDescription("hi!");
        boolean boolean18 = timeSeries14.equals((java.lang.Object) 0L);
        java.util.List list19 = timeSeries14.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 9999);
        java.util.Date date24 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (double) 5);
        int int30 = year25.getYear();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(10, year25);
        try {
            org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) 'a', year25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.removeAgedItems((long) (byte) 1, false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate16 = serialDate13.getEndOfCurrentMonth(serialDate15);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        boolean boolean24 = spreadsheetDate20.isOn(serialDate23);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate35 = serialDate32.getEndOfCurrentMonth(serialDate34);
        java.lang.String str36 = serialDate35.toString();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
        boolean boolean39 = spreadsheetDate20.isInRange(serialDate29, serialDate35, 0);
        boolean boolean40 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean41 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int42 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate20.getNearestDayOfWeek(4);
        java.lang.String str45 = spreadsheetDate20.getDescription();
        java.util.Date date46 = spreadsheetDate20.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 13);
        java.util.Calendar calendar52 = null;
        try {
            long long53 = day49.getLastMillisecond(calendar52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "28-February-1900" + "'", str17.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "28-February-1900" + "'", str36.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 35 + "'", int42 == 35);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(11);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        java.lang.Class<?> wildcardClass12 = timeSeries10.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass12);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass12);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection20 = timeSeries19.getTimePeriods();
        java.lang.Class<?> wildcardClass21 = timeSeries19.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass21);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", (java.lang.Class) wildcardClass21);
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("13-June-2019", (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(uRL14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertNull(inputStream26);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        java.util.Collection collection2 = timeSeries1.getTimePeriods();
//        java.lang.String str3 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = timeSeriesDataItem8.compareTo((java.lang.Object) day9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        long long12 = day9.getFirstMillisecond();
//        long long13 = day9.getFirstMillisecond();
//        long long14 = day9.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
//        java.lang.String str24 = serialDate23.toString();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(0, serialDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        boolean boolean31 = spreadsheetDate27.isOn(serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate36 = serialDate33.getEndOfCurrentMonth(serialDate35);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
//        java.lang.String str43 = serialDate42.toString();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(0, serialDate42);
//        boolean boolean46 = spreadsheetDate27.isInRange(serialDate36, serialDate42, 0);
//        boolean boolean47 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addYears((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        int int49 = day9.compareTo((java.lang.Object) spreadsheetDate27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) 2);
//        org.junit.Assert.assertNotNull(collection2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "28-February-1900" + "'", str24.equals("28-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28-February-1900" + "'", str43.equals("28-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 0L);
        timeSeriesDataItem15.setValue((java.lang.Number) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("28-February-1900");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("Time");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        java.lang.Class<?> wildcardClass4 = timeSeries2.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader6);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.time.TimePeriodFormatException: ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        java.util.Collection collection16 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        int int17 = month2.compareTo((java.lang.Object) timeSeries9);
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries9.createCopy(0, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        try {
            java.lang.Number number23 = timeSeries21.getValue(regularTimePeriod22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        java.lang.String str38 = spreadsheetDate13.getDescription();
        java.util.Date date39 = spreadsheetDate13.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        long long11 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond8.next();
        int int14 = fixedMillisecond8.compareTo((java.lang.Object) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond8.next();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        long long7 = timeSeries1.getMaximumItemAge();
        timeSeries1.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        try {
            timeSeries1.update(3, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 10);
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (short) 10 + "'", obj6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) 10 + "'", obj7.equals((short) 10));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries8.setDomainDescription("hi!");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        timeSeries8.setKey((java.lang.Comparable) month13);
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        int int22 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-59008924800001L) + "'", long19 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        spreadsheetDate13.setDescription("January 100");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getEndOfCurrentMonth(serialDate24);
        java.lang.String str26 = serialDate25.toString();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(0, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate30 = serialDate27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        boolean boolean33 = spreadsheetDate29.isOn(serialDate32);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate38 = serialDate35.getEndOfCurrentMonth(serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate44 = serialDate41.getEndOfCurrentMonth(serialDate43);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(0, serialDate44);
        boolean boolean48 = spreadsheetDate29.isInRange(serialDate38, serialDate44, 0);
        boolean boolean49 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean50 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int51 = spreadsheetDate29.toSerial();
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate29.getNearestDayOfWeek(4);
        java.lang.String str54 = spreadsheetDate29.getDescription();
        boolean boolean55 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean56 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate62 = serialDate59.getEndOfCurrentMonth(serialDate61);
        java.lang.String str63 = serialDate62.toString();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addMonths(0, serialDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate67 = serialDate64.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean68 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "28-February-1900" + "'", str26.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "28-February-1900" + "'", str45.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 35 + "'", int51 == 35);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "28-February-1900" + "'", str63.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        java.util.Date date12 = month6.getEnd();
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        timeSeries1.clear();
        int int12 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        java.lang.Object obj13 = timeSeries1.clone();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean20 = month18.equals((java.lang.Object) (short) 100);
        long long21 = month18.getLastMillisecond();
        long long22 = month18.getMiddleMillisecond();
        long long23 = month18.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 1L);
        try {
            timeSeries1.add(timeSeriesDataItem25, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-59008924800001L) + "'", long21 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-59010264000001L) + "'", long22 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-59008924800001L) + "'", long23 == (-59008924800001L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        boolean boolean16 = timeSeriesDataItem14.equals((java.lang.Object) (short) 0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem14);
        java.lang.Object obj18 = seriesChangeEvent17.getSource();
        java.lang.Object obj19 = seriesChangeEvent17.getSource();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        java.lang.String str21 = serialDate20.toString();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(0, serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        boolean boolean28 = spreadsheetDate24.isOn(serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getEndOfCurrentMonth(serialDate38);
        java.lang.String str40 = serialDate39.toString();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(0, serialDate39);
        boolean boolean43 = spreadsheetDate24.isInRange(serialDate33, serialDate39, 0);
        boolean boolean44 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean45 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int46 = spreadsheetDate24.toSerial();
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate24.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate24.getNearestDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate51 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int52 = spreadsheetDate24.getMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "28-February-1900" + "'", str21.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "28-February-1900" + "'", str40.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 35 + "'", int46 == 35);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries6.setDomainDescription("hi!");
        boolean boolean10 = timeSeries6.equals((java.lang.Object) 0L);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        java.util.Date date19 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        java.util.Collection collection28 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        int int29 = month14.compareTo((java.lang.Object) timeSeries21);
        int int30 = month14.getYearValue();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean35 = month33.equals((java.lang.Object) (short) 100);
        long long36 = month33.getLastMillisecond();
        long long37 = month33.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        java.lang.String str48 = serialDate47.toString();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
        boolean boolean55 = spreadsheetDate51.isOn(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
        java.lang.String str67 = serialDate66.toString();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(0, serialDate66);
        boolean boolean70 = spreadsheetDate51.isInRange(serialDate60, serialDate66, 0);
        boolean boolean71 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean72 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate51.getNearestDayOfWeek((int) (short) 1);
        int int75 = month33.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries79.setDomainDescription("hi!");
        boolean boolean83 = timeSeries79.equals((java.lang.Object) 0L);
        java.util.List list84 = timeSeries79.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries79.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86, (java.lang.Number) 9999);
        java.util.Collection collection89 = timeSeries79.getTimePeriods();
        java.util.Collection collection90 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries79);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener91 = null;
        timeSeries1.removeChangeListener(seriesChangeListener91);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59008924800001L) + "'", long36 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-59010264000001L) + "'", long37 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "28-February-1900" + "'", str48.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "28-February-1900" + "'", str67.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(timeSeries76);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(list84);
        org.junit.Assert.assertNull(timeSeriesDataItem88);
        org.junit.Assert.assertNotNull(collection89);
        org.junit.Assert.assertNotNull(collection90);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59011603200000L) + "'", long6 == (-59011603200000L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        java.lang.Class<?> wildcardClass4 = timeSeries2.getClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(inputStream5);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries7.setDomainDescription("hi!");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) month12);
        long long18 = month12.getLastMillisecond();
        java.lang.Number number19 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month12);
        java.lang.String str20 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-59008924800001L) + "'", long18 == (-59008924800001L));
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.previous();
        java.util.Calendar calendar16 = null;
        try {
            year12.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        java.lang.Class<?> wildcardClass4 = timeSeries2.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertNull(inputStream6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 0L);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond8.getLastMillisecond(calendar16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getEndOfCurrentMonth(serialDate42);
        java.lang.String str44 = serialDate43.toString();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(0, serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate48 = serialDate45.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate50 = day49.getSerialDate();
        boolean boolean51 = spreadsheetDate47.isOn(serialDate50);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getEndOfCurrentMonth(serialDate55);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate62 = serialDate59.getEndOfCurrentMonth(serialDate61);
        java.lang.String str63 = serialDate62.toString();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addMonths(0, serialDate62);
        boolean boolean66 = spreadsheetDate47.isInRange(serialDate56, serialDate62, 0);
        org.jfree.data.time.SerialDate serialDate67 = serialDate37.getEndOfCurrentMonth(serialDate56);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "28-February-1900" + "'", str44.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "28-February-1900" + "'", str63.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate67);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.removeAgedItems((long) 10, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            java.lang.Number number8 = timeSeries1.getValue(regularTimePeriod7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        java.lang.String str16 = year12.toString();
        long long17 = year12.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28799999L + "'", long17 == 28799999L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, 0.0d);
        timeSeries2.setKey((java.lang.Comparable) month7);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries14.setDomainDescription("hi!");
        boolean boolean18 = timeSeries14.equals((java.lang.Object) 0L);
        java.lang.Object obj19 = timeSeries14.clone();
        java.util.Collection collection20 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries2.setRangeDescription("1969");
        java.lang.Class class23 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("September", class23);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNull(uRL24);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        java.lang.String str38 = spreadsheetDate13.getDescription();
        java.util.Date date39 = spreadsheetDate13.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        java.util.Calendar calendar41 = null;
        fixedMillisecond40.peg(calendar41);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        java.lang.String str38 = spreadsheetDate13.getDescription();
        int int39 = spreadsheetDate13.getMonth();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.lang.Object obj6 = timeSeries1.clone();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean11 = month9.equals((java.lang.Object) (short) 100);
        long long12 = month9.getLastMillisecond();
        long long13 = month9.getMiddleMillisecond();
        long long14 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month9, (double) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1560495599999L);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries20.setDomainDescription("hi!");
        boolean boolean24 = timeSeries20.equals((java.lang.Object) 0L);
        java.util.List list25 = timeSeries20.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries31.setDomainDescription("hi!");
        boolean boolean35 = timeSeries31.equals((java.lang.Object) 0L);
        java.util.List list36 = timeSeries31.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 9999);
        java.util.Date date41 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year42, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeries20.getTimePeriod(0);
        java.lang.Class class49 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean54 = month52.equals((java.lang.Object) (short) 100);
        long long55 = month52.getLastMillisecond();
        long long56 = month52.getMiddleMillisecond();
        long long57 = month52.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month52, (java.lang.Number) (-1));
        int int60 = timeSeriesDataItem18.compareTo((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-59008924800001L) + "'", long12 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59010264000001L) + "'", long13 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-59011603200000L) + "'", long14 == (-59011603200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-59008924800001L) + "'", long55 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-59010264000001L) + "'", long56 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-59008924800001L) + "'", long57 == (-59008924800001L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        java.lang.Class<?> wildcardClass6 = timeSeries4.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass6, class12);
        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        java.util.Date date23 = month18.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23, timeZone24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, 0.0d);
        java.util.Date date33 = month28.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone34);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries38.setDomainDescription("hi!");
        boolean boolean42 = timeSeries38.equals((java.lang.Object) 0L);
        java.util.List list43 = timeSeries38.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (java.lang.Number) 9999);
        java.util.Date date48 = fixedMillisecond45.getEnd();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
        long long50 = year49.getFirstMillisecond();
        java.lang.String str51 = year49.toString();
        int int52 = year49.getYear();
        long long53 = year49.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year49.previous();
        java.util.Date date55 = regularTimePeriod54.getEnd();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries60.setDomainDescription("hi!");
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month65, 0.0d);
        timeSeries60.setKey((java.lang.Comparable) month65);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries72.setDomainDescription("hi!");
        boolean boolean76 = timeSeries72.equals((java.lang.Object) 0L);
        java.lang.Object obj77 = timeSeries72.clone();
        java.util.Collection collection78 = timeSeries60.getTimePeriodsUniqueToOtherSeries(timeSeries72);
        timeSeries60.setRangeDescription("1969");
        java.lang.Class class81 = timeSeries60.getTimePeriodClass();
        java.lang.ClassLoader classLoader82 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class81);
        boolean boolean83 = timeSeries58.equals((java.lang.Object) class81);
        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries85.setDomainDescription("hi!");
        boolean boolean89 = timeSeries85.equals((java.lang.Object) 0L);
        java.util.List list90 = timeSeries85.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond92 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem94 = timeSeries85.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond92, (java.lang.Number) 9999);
        java.util.Date date95 = fixedMillisecond92.getEnd();
        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date95, timeZone96);
        org.jfree.data.time.Day day98 = new org.jfree.data.time.Day(date55, timeZone96);
        org.jfree.data.time.Month month99 = new org.jfree.data.time.Month(date23, timeZone96);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(uRL8);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(classLoader14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-31507200000L) + "'", long50 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1969" + "'", str51.equals("1969"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1969 + "'", int52 == 1969);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-31507200000L) + "'", long53 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(obj77);
        org.junit.Assert.assertNotNull(collection78);
        org.junit.Assert.assertNotNull(class81);
        org.junit.Assert.assertNotNull(classLoader82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(list90);
        org.junit.Assert.assertNull(timeSeriesDataItem94);
        org.junit.Assert.assertNotNull(date95);
        org.junit.Assert.assertNotNull(timeZone96);
        org.junit.Assert.assertNotNull(regularTimePeriod97);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        boolean boolean15 = spreadsheetDate11.isOn(serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        java.lang.String str27 = serialDate26.toString();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(0, serialDate26);
        boolean boolean30 = spreadsheetDate11.isInRange(serialDate20, serialDate26, 0);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        try {
            org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', serialDate31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "28-February-1900" + "'", str8.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "28-February-1900" + "'", str27.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        int int3 = day1.getYear();
        java.lang.Class<?> wildcardClass4 = day1.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 31, (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException11.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod16, (double) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        timeSeries1.setDescription("ClassContext");
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        timeSeries1.setMaximumItemCount(1969);
        try {
            timeSeries1.setMaximumItemAge((-59011603200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
//        java.util.List list6 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
//        timeSeries1.clear();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 0);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day12.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.lang.Object obj17 = timeSeries12.clone();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean22 = month20.equals((java.lang.Object) (short) 100);
        long long23 = month20.getLastMillisecond();
        long long24 = month20.getMiddleMillisecond();
        long long25 = month20.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) 10L);
        timeSeries8.setKey((java.lang.Comparable) month20);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = month20.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-59008924800001L) + "'", long23 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-59010264000001L) + "'", long24 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-59011603200000L) + "'", long25 == (-59011603200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries6.setDomainDescription("hi!");
        boolean boolean10 = timeSeries6.equals((java.lang.Object) 0L);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        java.util.Date date19 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        java.util.Collection collection28 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        int int29 = month14.compareTo((java.lang.Object) timeSeries21);
        int int30 = month14.getYearValue();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean35 = month33.equals((java.lang.Object) (short) 100);
        long long36 = month33.getLastMillisecond();
        long long37 = month33.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        java.lang.String str48 = serialDate47.toString();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
        boolean boolean55 = spreadsheetDate51.isOn(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
        java.lang.String str67 = serialDate66.toString();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(0, serialDate66);
        boolean boolean70 = spreadsheetDate51.isInRange(serialDate60, serialDate66, 0);
        boolean boolean71 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean72 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate51.getNearestDayOfWeek((int) (short) 1);
        int int75 = month33.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries79.setDomainDescription("hi!");
        boolean boolean83 = timeSeries79.equals((java.lang.Object) 0L);
        java.util.List list84 = timeSeries79.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries79.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86, (java.lang.Number) 9999);
        java.util.Collection collection89 = timeSeries79.getTimePeriods();
        java.util.Collection collection90 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries79);
        int int91 = timeSeries1.getItemCount();
        int int92 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59008924800001L) + "'", long36 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-59010264000001L) + "'", long37 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "28-February-1900" + "'", str48.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "28-February-1900" + "'", str67.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(timeSeries76);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(list84);
        org.junit.Assert.assertNull(timeSeriesDataItem88);
        org.junit.Assert.assertNotNull(collection89);
        org.junit.Assert.assertNotNull(collection90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2147483647 + "'", int92 == 2147483647);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getMiddleMillisecond();
        long long13 = fixedMillisecond8.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries10.setDomainDescription("hi!");
        boolean boolean14 = timeSeries10.equals((java.lang.Object) 0L);
        java.util.List list15 = timeSeries10.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
        java.util.Date date20 = fixedMillisecond17.getEnd();
        long long21 = fixedMillisecond17.getFirstMillisecond();
        long long22 = fixedMillisecond17.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 2019, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        java.lang.String str7 = serialDate6.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        boolean boolean14 = spreadsheetDate10.isOn(serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getEndOfCurrentMonth(serialDate18);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getEndOfCurrentMonth(serialDate24);
        java.lang.String str26 = serialDate25.toString();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(0, serialDate25);
        boolean boolean29 = spreadsheetDate10.isInRange(serialDate19, serialDate25, 0);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) (short) 1, (int) (byte) 10, 9999);
        boolean boolean35 = spreadsheetDate10.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "28-February-1900" + "'", str7.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "28-February-1900" + "'", str26.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        try {
            timeSeries1.delete((int) (short) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean32 = month30.equals((java.lang.Object) (short) 100);
        long long33 = month30.getLastMillisecond();
        long long34 = month30.getMiddleMillisecond();
        int int35 = timeSeriesDataItem27.compareTo((java.lang.Object) month30);
        java.util.Calendar calendar36 = null;
        try {
            month30.peg(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-59008924800001L) + "'", long33 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-59010264000001L) + "'", long34 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setDomainDescription("hi!");
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        java.lang.Comparable comparable9 = timeSeries5.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries5.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate6);
        int int9 = spreadsheetDate1.compare(serialDate6);
        serialDate6.setDescription("hi!");
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-43) + "'", int9 == (-43));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        timeSeries1.removeAgedItems((long) (byte) 1, false);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = timeSeriesDataItem11.compareTo((java.lang.Object) day12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day12.next();
//        try {
//            timeSeries1.update(regularTimePeriod16, (java.lang.Number) (-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        java.util.Date date12 = month6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month6.next();
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        java.lang.Class<?> wildcardClass12 = timeSeries10.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass12);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass12);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection20 = timeSeries19.getTimePeriods();
        java.lang.Class<?> wildcardClass21 = timeSeries19.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass21);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", (java.lang.Class) wildcardClass21);
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("28-February-1900", (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(uRL14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertNull(inputStream26);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        long long11 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond8.next();
        int int14 = fixedMillisecond8.compareTo((java.lang.Object) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond8.next();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("28-February-1900");
        try {
            int int37 = spreadsheetDate1.compareTo((java.lang.Object) "28-February-1900");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem4.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        java.lang.Class<?> wildcardClass14 = timeSeries12.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        java.lang.Class class20 = timeSeries18.getTimePeriodClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass14, class20);
        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass14);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem4, "org.jfree.data.general.SeriesException: 28-February-1900", "", class24);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(uRL16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(classLoader22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries13.setRangeDescription("13-June-2019");
        long long22 = timeSeries13.getMaximumItemAge();
        java.lang.String str23 = timeSeries13.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems(1560495599999L, true);
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries1.getTimePeriod(0);
        java.lang.Class class30 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean35 = month33.equals((java.lang.Object) (short) 100);
        long long36 = month33.getLastMillisecond();
        long long37 = month33.getMiddleMillisecond();
        long long38 = month33.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (-1));
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries1.getTimePeriod(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59008924800001L) + "'", long36 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-59010264000001L) + "'", long37 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-59008924800001L) + "'", long38 == (-59008924800001L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
        java.lang.String str43 = serialDate42.toString();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(0, serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        boolean boolean50 = spreadsheetDate46.isOn(serialDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth(serialDate57);
        java.lang.String str59 = serialDate58.toString();
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addMonths(0, serialDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate63 = serialDate60.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate65 = day64.getSerialDate();
        boolean boolean66 = spreadsheetDate62.isOn(serialDate65);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate71 = serialDate68.getEndOfCurrentMonth(serialDate70);
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate77 = serialDate74.getEndOfCurrentMonth(serialDate76);
        java.lang.String str78 = serialDate77.toString();
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addMonths(0, serialDate77);
        boolean boolean81 = spreadsheetDate62.isInRange(serialDate71, serialDate77, 0);
        boolean boolean82 = spreadsheetDate52.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        boolean boolean83 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int84 = spreadsheetDate46.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28-February-1900" + "'", str43.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "28-February-1900" + "'", str59.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "28-February-1900" + "'", str78.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 3 + "'", int84 == 3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries6.setDomainDescription("hi!");
        boolean boolean10 = timeSeries6.equals((java.lang.Object) 0L);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        java.util.Date date19 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        java.util.Collection collection28 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        int int29 = month14.compareTo((java.lang.Object) timeSeries21);
        int int30 = month14.getYearValue();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean35 = month33.equals((java.lang.Object) (short) 100);
        long long36 = month33.getLastMillisecond();
        long long37 = month33.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        java.lang.String str48 = serialDate47.toString();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
        boolean boolean55 = spreadsheetDate51.isOn(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
        java.lang.String str67 = serialDate66.toString();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(0, serialDate66);
        boolean boolean70 = spreadsheetDate51.isInRange(serialDate60, serialDate66, 0);
        boolean boolean71 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean72 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate51.getNearestDayOfWeek((int) (short) 1);
        int int75 = month33.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.lang.Class<?> wildcardClass78 = timeSeries1.getClass();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59008924800001L) + "'", long36 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-59010264000001L) + "'", long37 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "28-February-1900" + "'", str48.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "28-February-1900" + "'", str67.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(timeSeries76);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertNotNull(wildcardClass78);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection21 = timeSeries20.getTimePeriods();
        java.lang.Class<?> wildcardClass22 = timeSeries20.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass22);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass22);
        int int27 = fixedMillisecond8.compareTo((java.lang.Object) 5);
        java.util.Date date28 = fixedMillisecond8.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        long long30 = fixedMillisecond29.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(uRL24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 520764324 + "'", int1 == 520764324);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        int int15 = year12.getYear();
        long long16 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.previous();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection23 = timeSeries22.getTimePeriods();
        java.lang.Class class24 = timeSeries22.getTimePeriodClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize(class24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date18, "", "1969", class24);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(class25);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
//        java.util.List list6 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
//        timeSeries1.clear();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        int int14 = day12.getDayOfMonth();
//        int int15 = day12.getMonth();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.String str17 = timeSeries1.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        java.lang.String str11 = serialDate10.toString();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(0, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        boolean boolean18 = spreadsheetDate14.isOn(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        java.lang.String str30 = serialDate29.toString();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(0, serialDate29);
        boolean boolean33 = spreadsheetDate14.isInRange(serialDate23, serialDate29, 0);
        boolean boolean34 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean35 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate14.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays((-1), (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28-February-1900" + "'", str11.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "28-February-1900" + "'", str30.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries17.setDomainDescription("hi!");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, 0.0d);
        timeSeries17.setKey((java.lang.Comparable) month22);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries29.setDomainDescription("hi!");
        boolean boolean33 = timeSeries29.equals((java.lang.Object) 0L);
        java.lang.Object obj34 = timeSeries29.clone();
        java.util.Collection collection35 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries17.setRangeDescription("1969");
        java.lang.Class class38 = timeSeries17.getTimePeriodClass();
        boolean boolean39 = timeSeriesDataItem15.equals((java.lang.Object) timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setDomainDescription("hi!");
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getEndOfCurrentMonth(serialDate40);
        java.lang.String str42 = serialDate41.toString();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate46 = serialDate43.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate48 = day47.getSerialDate();
        boolean boolean49 = spreadsheetDate45.isOn(serialDate48);
        int int50 = spreadsheetDate45.getYYYY();
        boolean boolean51 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate45.getNearestDayOfWeek(1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "28-February-1900" + "'", str42.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(serialDate53);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries6.setDomainDescription("hi!");
        boolean boolean10 = timeSeries6.equals((java.lang.Object) 0L);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        java.util.Date date19 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        java.util.Collection collection28 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        int int29 = month14.compareTo((java.lang.Object) timeSeries21);
        int int30 = month14.getYearValue();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean35 = month33.equals((java.lang.Object) (short) 100);
        long long36 = month33.getLastMillisecond();
        long long37 = month33.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        java.lang.String str48 = serialDate47.toString();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
        boolean boolean55 = spreadsheetDate51.isOn(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
        java.lang.String str67 = serialDate66.toString();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(0, serialDate66);
        boolean boolean70 = spreadsheetDate51.isInRange(serialDate60, serialDate66, 0);
        boolean boolean71 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean72 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate51.getNearestDayOfWeek((int) (short) 1);
        int int75 = month33.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries79.setDomainDescription("hi!");
        boolean boolean83 = timeSeries79.equals((java.lang.Object) 0L);
        java.util.List list84 = timeSeries79.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries79.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86, (java.lang.Number) 9999);
        java.util.Collection collection89 = timeSeries79.getTimePeriods();
        java.util.Collection collection90 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries79);
        int int91 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete(28, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59008924800001L) + "'", long36 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-59010264000001L) + "'", long37 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "28-February-1900" + "'", str48.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "28-February-1900" + "'", str67.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(timeSeries76);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(list84);
        org.junit.Assert.assertNull(timeSeriesDataItem88);
        org.junit.Assert.assertNotNull(collection89);
        org.junit.Assert.assertNotNull(collection90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries23.setDomainDescription("hi!");
        boolean boolean27 = timeSeries23.equals((java.lang.Object) 0L);
        java.util.List list28 = timeSeries23.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 9999);
        java.util.Date date33 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (double) 5);
        int int39 = year34.getYear();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(10, year34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 1560495599999L);
        long long44 = year34.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1969L + "'", long44 == 1969L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries14.setDomainDescription("hi!");
        boolean boolean18 = timeSeries14.equals((java.lang.Object) 0L);
        java.util.List list19 = timeSeries14.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 9999);
        java.util.Date date24 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        long long26 = year25.getFirstMillisecond();
        java.lang.String str27 = year25.toString();
        int int28 = year25.getYear();
        long long29 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year25.previous();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = fixedMillisecond8.compareTo((java.lang.Object) day32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31507200000L) + "'", long26 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1969" + "'", str27.equals("1969"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31507200000L) + "'", long29 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection21 = timeSeries20.getTimePeriods();
        java.lang.Class<?> wildcardClass22 = timeSeries20.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass22);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass22);
        int int27 = fixedMillisecond8.compareTo((java.lang.Object) 5);
        java.util.Date date28 = fixedMillisecond8.getStart();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, 0.0d);
        java.util.Date date36 = month31.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date28, timeZone37);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = year39.getFirstMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(uRL24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        int int15 = year12.getYear();
        long long16 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.previous();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, 0.0d);
        timeSeries23.setKey((java.lang.Comparable) month28);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries35.setDomainDescription("hi!");
        boolean boolean39 = timeSeries35.equals((java.lang.Object) 0L);
        java.lang.Object obj40 = timeSeries35.clone();
        java.util.Collection collection41 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        timeSeries23.setRangeDescription("1969");
        java.lang.Class class44 = timeSeries23.getTimePeriodClass();
        java.lang.ClassLoader classLoader45 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class44);
        boolean boolean46 = timeSeries21.equals((java.lang.Object) class44);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries48.setDomainDescription("hi!");
        boolean boolean52 = timeSeries48.equals((java.lang.Object) 0L);
        java.util.List list53 = timeSeries48.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 9999);
        java.util.Date date58 = fixedMillisecond55.getEnd();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date58, timeZone59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date18, timeZone59);
        org.jfree.data.time.SerialDate serialDate62 = day61.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(classLoader45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(serialDate62);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getFollowingDayOfWeek(1);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries6.setDomainDescription("hi!");
        boolean boolean10 = timeSeries6.equals((java.lang.Object) 0L);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        java.util.Date date19 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        java.util.Collection collection28 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        int int29 = month14.compareTo((java.lang.Object) timeSeries21);
        int int30 = month14.getYearValue();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean35 = month33.equals((java.lang.Object) (short) 100);
        long long36 = month33.getLastMillisecond();
        long long37 = month33.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        java.lang.String str48 = serialDate47.toString();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
        boolean boolean55 = spreadsheetDate51.isOn(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
        java.lang.String str67 = serialDate66.toString();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(0, serialDate66);
        boolean boolean70 = spreadsheetDate51.isInRange(serialDate60, serialDate66, 0);
        boolean boolean71 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean72 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate51.getNearestDayOfWeek((int) (short) 1);
        int int75 = month33.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries1.addAndOrUpdate(timeSeries6);
        boolean boolean78 = timeSeries1.isEmpty();
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59008924800001L) + "'", long36 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-59010264000001L) + "'", long37 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "28-February-1900" + "'", str48.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "28-February-1900" + "'", str67.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(timeSeries76);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, 0.0d);
        java.util.Date date14 = month9.getStart();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries20.setDomainDescription("hi!");
        java.util.Collection collection23 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        int int24 = month9.compareTo((java.lang.Object) timeSeries16);
        int int25 = month9.getYearValue();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean30 = month28.equals((java.lang.Object) (short) 100);
        long long31 = month28.getLastMillisecond();
        long long32 = month28.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
        java.lang.String str43 = serialDate42.toString();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(0, serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        boolean boolean50 = spreadsheetDate46.isOn(serialDate49);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate55 = serialDate52.getEndOfCurrentMonth(serialDate54);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate61 = serialDate58.getEndOfCurrentMonth(serialDate60);
        java.lang.String str62 = serialDate61.toString();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths(0, serialDate61);
        boolean boolean65 = spreadsheetDate46.isInRange(serialDate55, serialDate61, 0);
        boolean boolean66 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean67 = spreadsheetDate34.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate46.getNearestDayOfWeek((int) (short) 1);
        int int70 = month28.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month28);
        try {
            timeSeries71.update(28, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 28, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-59008924800001L) + "'", long31 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-59010264000001L) + "'", long32 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28-February-1900" + "'", str43.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "28-February-1900" + "'", str62.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(timeSeries71);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getYear();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        int int36 = spreadsheetDate13.getMonth();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getEndOfCurrentMonth(serialDate40);
        java.lang.String str42 = serialDate40.getDescription();
        boolean boolean43 = spreadsheetDate13.isBefore(serialDate40);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        long long13 = year12.getFirstMillisecond();
        java.lang.String str14 = year12.toString();
        int int15 = year12.getYear();
        java.lang.String str16 = year12.toString();
        long long17 = year12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1969L + "'", long17 == 1969L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
//        long long9 = day5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries11.setNotify(false);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy(3, 10);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int26 = timeSeriesDataItem24.compareTo((java.lang.Object) day25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day25.previous();
        int int29 = day25.getMonth();
        timeSeries1.setKey((java.lang.Comparable) int29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str14 = timePeriodFormatException11.toString();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        java.lang.Number number5 = timeSeriesDataItem4.getValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        try {
            java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) propertyChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
//        timeSeries1.setKey((java.lang.Comparable) month6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries13.setDomainDescription("hi!");
//        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
//        java.lang.Object obj18 = timeSeries13.clone();
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        timeSeries1.setRangeDescription("1969");
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
//        int int24 = day22.getDayOfMonth();
//        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
//        java.lang.String str26 = timeSeries1.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries10.setDomainDescription("hi!");
        boolean boolean14 = timeSeries10.equals((java.lang.Object) 0L);
        java.util.List list15 = timeSeries10.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setDomainDescription("hi!");
        boolean boolean25 = timeSeries21.equals((java.lang.Object) 0L);
        java.util.List list26 = timeSeries21.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 9999);
        java.util.Date date31 = fixedMillisecond28.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeries10.getTimePeriod(0);
        java.util.List list39 = timeSeries10.getItems();
        boolean boolean40 = year8.equals((java.lang.Object) list39);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 10);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries11.setNotify(false);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy(3, 10);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setDomainDescription("hi!");
        boolean boolean25 = timeSeries21.equals((java.lang.Object) 0L);
        java.util.List list26 = timeSeries21.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries32.setDomainDescription("hi!");
        boolean boolean36 = timeSeries32.equals((java.lang.Object) 0L);
        java.util.List list37 = timeSeries32.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 9999);
        java.util.Date date42 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year43, (double) 5);
        int int48 = year43.getYear();
        long long49 = year43.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year43.next();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries52.setDomainDescription("hi!");
        boolean boolean56 = timeSeries52.equals((java.lang.Object) 0L);
        java.util.Collection collection57 = timeSeries52.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries59.setDomainDescription("hi!");
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, 0.0d);
        timeSeries59.setKey((java.lang.Comparable) month64);
        long long70 = month64.getLastMillisecond();
        int int71 = month64.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries52.getDataItem((org.jfree.data.time.RegularTimePeriod) month64);
        boolean boolean73 = year43.equals((java.lang.Object) timeSeries52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year43.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries1.addOrUpdate(regularTimePeriod74, (double) 1969L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1969 + "'", int48 == 1969);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-31507200000L) + "'", long49 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-59008924800001L) + "'", long70 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNull(timeSeriesDataItem76);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        timeSeries3.setKey((java.lang.Comparable) month8);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries15.setDomainDescription("hi!");
        boolean boolean19 = timeSeries15.equals((java.lang.Object) 0L);
        java.lang.Object obj20 = timeSeries15.clone();
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries3.setRangeDescription("1969");
        java.lang.Class class24 = timeSeries3.getTimePeriodClass();
        java.lang.ClassLoader classLoader25 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class24);
        boolean boolean26 = timeSeries1.equals((java.lang.Object) class24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries28.setDomainDescription("hi!");
        boolean boolean32 = timeSeries28.equals((java.lang.Object) 0L);
        java.util.List list33 = timeSeries28.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 9999);
        java.util.Date date38 = fixedMillisecond35.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date38, timeZone39);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class24);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(classLoader25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate13.getNearestDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek((int) (short) 1);
        java.lang.String str42 = serialDate41.getDescription();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setDomainDescription("hi!");
        boolean boolean9 = timeSeries5.equals((java.lang.Object) 0L);
        java.util.List list10 = timeSeries5.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 9999);
        java.util.Date date15 = fixedMillisecond12.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        int int17 = fixedMillisecond1.compareTo((java.lang.Object) date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        timeSeries1.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries11.setDomainDescription("hi!");
        boolean boolean15 = timeSeries11.equals((java.lang.Object) 0L);
        java.util.List list16 = timeSeries11.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 9999);
        java.util.Date date21 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        long long23 = year22.getFirstMillisecond();
        java.lang.String str24 = year22.toString();
        int int25 = year22.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) (short) 100);
        long long28 = year22.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31507200000L) + "'", long23 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28799999L + "'", long28 == 28799999L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        int int3 = day1.getYear();
        java.lang.Class<?> wildcardClass4 = day1.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", (java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate16 = serialDate13.getEndOfCurrentMonth(serialDate15);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        boolean boolean24 = spreadsheetDate20.isOn(serialDate23);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate35 = serialDate32.getEndOfCurrentMonth(serialDate34);
        java.lang.String str36 = serialDate35.toString();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
        boolean boolean39 = spreadsheetDate20.isInRange(serialDate29, serialDate35, 0);
        boolean boolean40 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean41 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int42 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate20.getNearestDayOfWeek(4);
        java.lang.String str45 = spreadsheetDate20.getDescription();
        java.util.Date date46 = spreadsheetDate20.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date46, timeZone48);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNotNull(classLoader6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "28-February-1900" + "'", str17.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "28-February-1900" + "'", str36.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 35 + "'", int42 == 35);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod49);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        java.lang.String str7 = serialDate6.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        boolean boolean14 = spreadsheetDate10.isOn(serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getEndOfCurrentMonth(serialDate18);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getEndOfCurrentMonth(serialDate24);
        java.lang.String str26 = serialDate25.toString();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(0, serialDate25);
        boolean boolean29 = spreadsheetDate10.isInRange(serialDate19, serialDate25, 0);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate31 = null;
        try {
            boolean boolean32 = spreadsheetDate10.isAfter(serialDate31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "28-February-1900" + "'", str7.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "28-February-1900" + "'", str26.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: January 100");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries5.setDomainDescription("hi!");
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        java.util.List list9 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        java.lang.Class<?> wildcardClass14 = timeSeries12.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem4, "", "September", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries19.setDomainDescription("hi!");
        boolean boolean23 = timeSeries19.equals((java.lang.Object) 0L);
        java.util.List list24 = timeSeries19.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 9999);
        java.util.Date date29 = fixedMillisecond26.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        long long31 = year30.getFirstMillisecond();
        java.lang.String str32 = year30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year30.previous();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) year30);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(uRL16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1969" + "'", str32.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.lang.Object obj17 = timeSeries12.clone();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean22 = month20.equals((java.lang.Object) (short) 100);
        long long23 = month20.getLastMillisecond();
        long long24 = month20.getMiddleMillisecond();
        long long25 = month20.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) 10L);
        timeSeries8.setKey((java.lang.Comparable) month20);
        java.lang.Comparable comparable29 = timeSeries8.getKey();
        boolean boolean30 = timeSeries8.getNotify();
        java.util.Collection collection31 = timeSeries8.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-59008924800001L) + "'", long23 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-59010264000001L) + "'", long24 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-59011603200000L) + "'", long25 == (-59011603200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(comparable29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection31);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("28-February-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate13.getNearestDayOfWeek((int) (byte) 1);
        try {
            org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate13.getFollowingDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        java.lang.Class<?> wildcardClass6 = timeSeries4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        java.lang.Class<?> wildcardClass12 = timeSeries10.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass12);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass12);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass12);
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass6);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection20 = timeSeries19.getTimePeriods();
        java.util.Collection collection21 = timeSeries19.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries23.setDomainDescription("hi!");
        boolean boolean27 = timeSeries23.equals((java.lang.Object) 0L);
        java.util.List list28 = timeSeries23.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 9999);
        java.util.Date date33 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        long long35 = year34.getFirstMillisecond();
        java.lang.String str36 = year34.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries19.addOrUpdate(regularTimePeriod37, (double) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries43.setDomainDescription("hi!");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, 0.0d);
        timeSeries43.setKey((java.lang.Comparable) month48);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries55.setDomainDescription("hi!");
        boolean boolean59 = timeSeries55.equals((java.lang.Object) 0L);
        java.lang.Object obj60 = timeSeries55.clone();
        java.util.Collection collection61 = timeSeries43.getTimePeriodsUniqueToOtherSeries(timeSeries55);
        timeSeries43.setRangeDescription("1969");
        java.lang.Class class64 = timeSeries43.getTimePeriodClass();
        java.lang.ClassLoader classLoader65 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class64);
        boolean boolean66 = timeSeries41.equals((java.lang.Object) class64);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries68.setDomainDescription("hi!");
        boolean boolean72 = timeSeries68.equals((java.lang.Object) 0L);
        java.util.List list73 = timeSeries68.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 9999);
        java.util.Date date78 = fixedMillisecond75.getEnd();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date78, timeZone79);
        boolean boolean81 = timeSeries19.equals((java.lang.Object) class64);
        java.lang.Object obj82 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass6, class64);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(uRL14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(classLoader16);
        org.junit.Assert.assertNull(uRL17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31507200000L) + "'", long35 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1969" + "'", str36.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(collection61);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNotNull(classLoader65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(list73);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(obj82);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries6.setDomainDescription("hi!");
        boolean boolean10 = timeSeries6.equals((java.lang.Object) 0L);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        java.util.Date date19 = month14.getStart();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries21.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        java.util.Collection collection28 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        int int29 = month14.compareTo((java.lang.Object) timeSeries21);
        int int30 = month14.getYearValue();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean35 = month33.equals((java.lang.Object) (short) 100);
        long long36 = month33.getLastMillisecond();
        long long37 = month33.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        java.lang.String str48 = serialDate47.toString();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
        boolean boolean55 = spreadsheetDate51.isOn(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
        java.lang.String str67 = serialDate66.toString();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(0, serialDate66);
        boolean boolean70 = spreadsheetDate51.isInRange(serialDate60, serialDate66, 0);
        boolean boolean71 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean72 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate51.getNearestDayOfWeek((int) (short) 1);
        int int75 = month33.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries6.setNotify(true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59008924800001L) + "'", long36 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-59010264000001L) + "'", long37 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "28-February-1900" + "'", str48.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "28-February-1900" + "'", str67.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(timeSeries76);
        org.junit.Assert.assertNotNull(timeSeries77);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection21 = timeSeries20.getTimePeriods();
        java.lang.Class<?> wildcardClass22 = timeSeries20.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass22);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass22);
        int int27 = fixedMillisecond8.compareTo((java.lang.Object) 5);
        java.util.Date date28 = fixedMillisecond8.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date28);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(uRL24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        java.lang.Class<?> wildcardClass10 = timeSeries8.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass10);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        java.lang.Class<?> wildcardClass19 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass19);
        java.lang.ClassLoader classLoader21 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass19);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass19);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(uRL12);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(classLoader21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(class23);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth(serialDate3);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        java.lang.String str9 = serialDate8.toString();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(0, serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        boolean boolean16 = spreadsheetDate12.isOn(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = serialDate24.getEndOfCurrentMonth(serialDate26);
        java.lang.String str28 = serialDate27.toString();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(0, serialDate27);
        boolean boolean31 = spreadsheetDate12.isInRange(serialDate21, serialDate27, 0);
        boolean boolean32 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int33 = spreadsheetDate12.toSerial();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(8, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "28-February-1900" + "'", str9.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "28-February-1900" + "'", str28.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 35 + "'", int33 == 35);
        org.junit.Assert.assertNotNull(serialDate34);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
//        java.util.List list6 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries12.setDomainDescription("hi!");
//        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
//        java.util.List list17 = timeSeries12.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
//        java.util.Date date22 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        boolean boolean32 = month30.equals((java.lang.Object) (short) 100);
//        long long33 = month30.getLastMillisecond();
//        long long34 = month30.getMiddleMillisecond();
//        int int35 = timeSeriesDataItem27.compareTo((java.lang.Object) month30);
//        java.lang.Object obj36 = timeSeriesDataItem27.clone();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        int int43 = timeSeriesDataItem41.compareTo((java.lang.Object) day42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
//        long long45 = day42.getLastMillisecond();
//        int int46 = timeSeriesDataItem27.compareTo((java.lang.Object) day42);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-59008924800001L) + "'", long33 == (-59008924800001L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-59010264000001L) + "'", long34 == (-59010264000001L));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560495599999L + "'", long45 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        long long13 = fixedMillisecond8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond8.next();
        long long15 = fixedMillisecond8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, 0.0d);
        timeSeries4.setKey((java.lang.Comparable) month9);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries16.setDomainDescription("hi!");
        boolean boolean20 = timeSeries16.equals((java.lang.Object) 0L);
        java.lang.Object obj21 = timeSeries16.clone();
        java.util.Collection collection22 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries4.setRangeDescription("1969");
        java.lang.Class class25 = timeSeries4.getTimePeriodClass();
        java.lang.ClassLoader classLoader26 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class25);
        boolean boolean27 = timeSeries2.equals((java.lang.Object) class25);
        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class25);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(classLoader26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(inputStream28);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getNearestDayOfWeek((int) (short) 1);
        serialDate36.setDescription("1969");
        java.lang.String str39 = serialDate36.toString();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "4-February-1900" + "'", str39.equals("4-February-1900"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        java.lang.Class class6 = timeSeries4.getTimePeriodClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1201L, class12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=100]", class7, class12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', class7);
        java.lang.String str16 = timeSeries15.getRangeDescription();
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        java.lang.Class<?> wildcardClass3 = day0.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        timeSeries1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean10 = month8.equals((java.lang.Object) (short) 100);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        long long13 = month8.getLastMillisecond();
        int int14 = month8.getMonth();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59008924800001L) + "'", long11 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59008924800001L) + "'", long13 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "December" + "'", str1.equals("December"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        java.lang.String str22 = serialDate21.toString();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(0, serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
        boolean boolean29 = spreadsheetDate25.isOn(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate40 = serialDate37.getEndOfCurrentMonth(serialDate39);
        java.lang.String str41 = serialDate40.toString();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(0, serialDate40);
        boolean boolean44 = spreadsheetDate25.isInRange(serialDate34, serialDate40, 0);
        boolean boolean45 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean46 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int47 = spreadsheetDate25.toSerial();
        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate25.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate49);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate57 = serialDate54.getEndOfCurrentMonth(serialDate56);
        java.lang.String str58 = serialDate57.toString();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(0, serialDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate62 = serialDate59.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths((int) ' ', serialDate62);
        org.jfree.data.time.SerialDate serialDate64 = serialDate50.getEndOfCurrentMonth(serialDate63);
        boolean boolean65 = spreadsheetDate9.isOnOrAfter(serialDate50);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "28-February-1900" + "'", str22.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "28-February-1900" + "'", str41.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 35 + "'", int47 == 35);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "28-February-1900" + "'", str58.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) day7);
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate10 = null;
        try {
            boolean boolean12 = spreadsheetDate1.isInRange(serialDate9, serialDate10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries1.setDomainDescription("hi!");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
//        timeSeries1.setKey((java.lang.Comparable) month6);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries13.setDomainDescription("hi!");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
//        timeSeries13.setKey((java.lang.Comparable) month18);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        timeSeries25.setDomainDescription("hi!");
//        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
//        java.lang.Object obj30 = timeSeries25.clone();
//        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(1, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        int int39 = timeSeriesDataItem37.compareTo((java.lang.Object) day38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day38.next();
//        long long41 = day38.getFirstMillisecond();
//        long long42 = day38.getFirstMillisecond();
//        long long43 = day38.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth(serialDate51);
//        java.lang.String str53 = serialDate52.toString();
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(0, serialDate52);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate57 = serialDate54.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate59 = day58.getSerialDate();
//        boolean boolean60 = spreadsheetDate56.isOn(serialDate59);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate65 = serialDate62.getEndOfCurrentMonth(serialDate64);
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance((int) '4');
//        org.jfree.data.time.SerialDate serialDate71 = serialDate68.getEndOfCurrentMonth(serialDate70);
//        java.lang.String str72 = serialDate71.toString();
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addMonths(0, serialDate71);
//        boolean boolean75 = spreadsheetDate56.isInRange(serialDate65, serialDate71, 0);
//        boolean boolean76 = spreadsheetDate46.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addYears((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int78 = day38.compareTo((java.lang.Object) spreadsheetDate56);
//        int int79 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) day38);
//        timeSeries25.setMaximumItemAge((long) 520764324);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560409200000L + "'", long42 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560495599999L + "'", long43 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "28-February-1900" + "'", str53.equals("28-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "28-February-1900" + "'", str72.equals("28-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries1.setRangeDescription("1969");
        java.lang.Class class22 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries24.setDomainDescription("hi!");
        boolean boolean28 = timeSeries24.equals((java.lang.Object) 0L);
        java.util.List list29 = timeSeries24.getItems();
        timeSeries24.setDescription("ClassContext");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries38.setDomainDescription("hi!");
        boolean boolean41 = timeSeriesDataItem36.equals((java.lang.Object) "hi!");
        boolean boolean42 = timeSeries24.equals((java.lang.Object) timeSeriesDataItem36);
        java.util.Collection collection43 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries45.setDomainDescription("hi!");
        boolean boolean49 = timeSeries45.equals((java.lang.Object) 0L);
        java.util.List list50 = timeSeries45.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 9999);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries45.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries58.setDomainDescription("hi!");
        boolean boolean62 = timeSeries58.equals((java.lang.Object) 0L);
        java.util.List list63 = timeSeries58.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) 9999);
        java.util.Date date68 = fixedMillisecond65.getEnd();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date68);
        long long70 = year69.getFirstMillisecond();
        java.lang.String str71 = year69.toString();
        int int72 = year69.getYear();
        long long73 = year69.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year69.previous();
        int int75 = timeSeries45.getIndex(regularTimePeriod74);
        java.lang.Number number76 = timeSeries24.getValue(regularTimePeriod74);
        java.lang.Comparable comparable77 = timeSeries24.getKey();
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(collection43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-31507200000L) + "'", long70 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "1969" + "'", str71.equals("1969"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-31507200000L) + "'", long73 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNull(number76);
        org.junit.Assert.assertTrue("'" + comparable77 + "' != '" + (byte) 1 + "'", comparable77.equals((byte) 1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.lang.Object obj18 = timeSeries13.clone();
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, 0.0d);
        timeSeries23.setKey((java.lang.Comparable) month28);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries35.setDomainDescription("hi!");
        boolean boolean39 = timeSeries35.equals((java.lang.Object) 0L);
        java.lang.Object obj40 = timeSeries35.clone();
        java.util.Collection collection41 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        timeSeries23.setRangeDescription("1969");
        java.lang.Class class44 = timeSeries23.getTimePeriodClass();
        java.lang.ClassLoader classLoader45 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class44);
        boolean boolean46 = timeSeries21.equals((java.lang.Object) class44);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries48.setDomainDescription("hi!");
        boolean boolean52 = timeSeries48.equals((java.lang.Object) 0L);
        java.util.List list53 = timeSeries48.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 9999);
        java.util.Date date58 = fixedMillisecond55.getEnd();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date58, timeZone59);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date58, timeZone61);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate68 = serialDate65.getEndOfCurrentMonth(serialDate67);
        java.lang.String str69 = serialDate68.toString();
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(0, serialDate68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(serialDate68);
        int int72 = year62.compareTo((java.lang.Object) serialDate68);
        java.lang.Number number73 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) year62);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(classLoader45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "28-February-1900" + "'", str69.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNull(number73);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond8.getMiddleMillisecond(calendar13);
        java.lang.Object obj15 = null;
        boolean boolean16 = fixedMillisecond8.equals(obj15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries8.setDomainDescription("hi!");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        timeSeries8.setKey((java.lang.Comparable) month13);
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries23.setDomainDescription("hi!");
        boolean boolean27 = timeSeries23.equals((java.lang.Object) 0L);
        java.lang.Object obj28 = timeSeries23.clone();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean33 = month31.equals((java.lang.Object) (short) 100);
        long long34 = month31.getLastMillisecond();
        long long35 = month31.getMiddleMillisecond();
        long long36 = month31.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (double) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (double) 1560495599999L);
        try {
            timeSeries1.add(timeSeriesDataItem40, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-59008924800001L) + "'", long19 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-59008924800001L) + "'", long34 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-59010264000001L) + "'", long35 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59011603200000L) + "'", long36 == (-59011603200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(9999, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate16 = serialDate13.getEndOfCurrentMonth(serialDate15);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        boolean boolean24 = spreadsheetDate20.isOn(serialDate23);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate35 = serialDate32.getEndOfCurrentMonth(serialDate34);
        java.lang.String str36 = serialDate35.toString();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
        boolean boolean39 = spreadsheetDate20.isInRange(serialDate29, serialDate35, 0);
        boolean boolean40 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean41 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate20.getNearestDayOfWeek((int) (short) 1);
        int int44 = month2.compareTo((java.lang.Object) (short) 1);
        try {
            org.jfree.data.time.Year year45 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59010264000001L) + "'", long6 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "28-February-1900" + "'", str17.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "28-February-1900" + "'", str36.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "28-February-1900" + "'", str8.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        long long11 = fixedMillisecond8.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5, "Time", "28-February-1900", (java.lang.Class) wildcardClass9);
        java.lang.String str14 = timeSeries13.getDescription();
        timeSeries13.setRangeDescription("January 100");
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(uRL11);
        org.junit.Assert.assertNull(inputStream12);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate9);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(1, serialDate9);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries16.setDomainDescription("hi!");
        boolean boolean20 = timeSeries16.equals((java.lang.Object) 0L);
        java.lang.Object obj21 = timeSeries16.clone();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean26 = month24.equals((java.lang.Object) (short) 100);
        long long27 = month24.getLastMillisecond();
        long long28 = month24.getMiddleMillisecond();
        long long29 = month24.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (double) 10L);
        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate9, (java.lang.Object) month24);
        java.util.Calendar calendar33 = null;
        try {
            month24.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "28-February-1900" + "'", str8.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-59008924800001L) + "'", long27 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-59010264000001L) + "'", long28 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-59011603200000L) + "'", long29 == (-59011603200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries14.setDomainDescription("hi!");
        boolean boolean18 = timeSeries14.equals((java.lang.Object) 0L);
        java.util.List list19 = timeSeries14.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 9999);
        java.util.Date date24 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        long long26 = year25.getFirstMillisecond();
        java.lang.String str27 = year25.toString();
        int int28 = year25.getYear();
        long long29 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year25.previous();
        int int31 = timeSeries1.getIndex(regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries33.setDomainDescription("hi!");
        boolean boolean37 = timeSeries33.equals((java.lang.Object) 0L);
        java.util.List list38 = timeSeries33.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries44.setDomainDescription("hi!");
        boolean boolean48 = timeSeries44.equals((java.lang.Object) 0L);
        java.util.List list49 = timeSeries44.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 9999);
        java.util.Date date54 = fixedMillisecond51.getEnd();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (double) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries62.setDomainDescription("hi!");
        boolean boolean66 = timeSeries62.equals((java.lang.Object) 0L);
        java.util.List list67 = timeSeries62.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (java.lang.Number) 9999);
        java.util.Date date72 = fixedMillisecond69.getEnd();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
        long long74 = year73.getFirstMillisecond();
        java.lang.String str75 = year73.toString();
        int int76 = year73.getYear();
        int int77 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year73);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31507200000L) + "'", long26 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1969" + "'", str27.equals("1969"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31507200000L) + "'", long29 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertNull(timeSeriesDataItem71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-31507200000L) + "'", long74 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1969" + "'", str75.equals("1969"));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1969 + "'", int76 == 1969);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        java.lang.Object obj5 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries8.setDomainDescription("hi!");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        timeSeries8.setKey((java.lang.Comparable) month13);
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        java.util.Date date22 = month13.getEnd();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-59008924800001L) + "'", long19 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        java.lang.String str11 = serialDate10.toString();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(0, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        boolean boolean18 = spreadsheetDate14.isOn(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        java.lang.String str30 = serialDate29.toString();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(0, serialDate29);
        boolean boolean33 = spreadsheetDate14.isInRange(serialDate23, serialDate29, 0);
        boolean boolean34 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean35 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int36 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(30, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        spreadsheetDate39.setDescription("January 100");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate51 = serialDate48.getEndOfCurrentMonth(serialDate50);
        java.lang.String str52 = serialDate51.toString();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths(0, serialDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate58 = day57.getSerialDate();
        boolean boolean59 = spreadsheetDate55.isOn(serialDate58);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate64 = serialDate61.getEndOfCurrentMonth(serialDate63);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate70 = serialDate67.getEndOfCurrentMonth(serialDate69);
        java.lang.String str71 = serialDate70.toString();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addMonths(0, serialDate70);
        boolean boolean74 = spreadsheetDate55.isInRange(serialDate64, serialDate70, 0);
        boolean boolean75 = spreadsheetDate45.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean76 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        int int77 = spreadsheetDate55.toSerial();
        org.jfree.data.time.SerialDate serialDate79 = spreadsheetDate55.getNearestDayOfWeek(4);
        java.lang.String str80 = spreadsheetDate55.getDescription();
        boolean boolean81 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean82 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28-February-1900" + "'", str11.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "28-February-1900" + "'", str30.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "28-February-1900" + "'", str52.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "28-February-1900" + "'", str71.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 35 + "'", int77 == 35);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        boolean boolean39 = spreadsheetDate13.isOnOrAfter(serialDate38);
        int int40 = spreadsheetDate13.toSerial();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 35 + "'", int40 == 35);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        int int8 = day5.getMonth();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        java.lang.String str7 = serialDate6.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        boolean boolean14 = spreadsheetDate10.isOn(serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getEndOfCurrentMonth(serialDate18);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getEndOfCurrentMonth(serialDate24);
        java.lang.String str26 = serialDate25.toString();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(0, serialDate25);
        boolean boolean29 = spreadsheetDate10.isInRange(serialDate19, serialDate25, 0);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "28-February-1900" + "'", str7.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "28-February-1900" + "'", str26.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries3.setDomainDescription("hi!");
        boolean boolean7 = timeSeries3.equals((java.lang.Object) 0L);
        java.util.List list8 = timeSeries3.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 9999);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        long long15 = year14.getFirstMillisecond();
        java.lang.String str16 = year14.toString();
        int int17 = year14.getYear();
        long long18 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        boolean boolean20 = year0.equals((java.lang.Object) regularTimePeriod19);
        long long21 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) day5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries15.setDomainDescription("hi!");
        boolean boolean19 = timeSeries15.equals((java.lang.Object) 0L);
        java.util.List list20 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 9999);
        java.util.Date date25 = fixedMillisecond22.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (short) 0);
        boolean boolean30 = timeSeriesDataItem28.equals((java.lang.Object) (short) 0);
        boolean boolean31 = month13.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
        int int34 = day32.getYear();
        boolean boolean35 = month13.equals((java.lang.Object) day32);
        int int36 = timeSeriesDataItem4.compareTo((java.lang.Object) month13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        java.util.Date date18 = month13.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean24 = month22.equals((java.lang.Object) (short) 100);
        long long25 = month22.getLastMillisecond();
        long long26 = month22.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) month22);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-59008924800001L) + "'", long25 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1201L + "'", long26 == 1201L);
        org.junit.Assert.assertNotNull(timeSeries27);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 9999);
        java.util.Date date22 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries1.getTimePeriod(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries1.removeChangeListener(seriesChangeListener30);
        try {
            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy((-43), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate13.getNearestDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        java.lang.String str48 = serialDate47.toString();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate49);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears(1, serialDate49);
        boolean boolean55 = spreadsheetDate13.isOnOrAfter(serialDate54);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "28-February-1900" + "'", str48.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries2.setDomainDescription("hi!");
        boolean boolean6 = timeSeries2.equals((java.lang.Object) 0L);
        java.util.List list7 = timeSeries2.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        boolean boolean17 = timeSeries13.equals((java.lang.Object) 0L);
        java.util.List list18 = timeSeries13.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 9999);
        java.util.Date date23 = fixedMillisecond20.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 5);
        int int29 = year24.getYear();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(10, year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year24.next();
        java.lang.Class<?> wildcardClass33 = year24.getClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, 0.0d);
        timeSeries1.setKey((java.lang.Comparable) month6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries13.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, 0.0d);
        timeSeries13.setKey((java.lang.Comparable) month18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries25.setDomainDescription("hi!");
        boolean boolean29 = timeSeries25.equals((java.lang.Object) 0L);
        java.lang.Object obj30 = timeSeries25.clone();
        java.util.Collection collection31 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        int int39 = timeSeriesDataItem37.compareTo((java.lang.Object) day38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection42 = timeSeries41.getTimePeriods();
        int int43 = timeSeriesDataItem37.compareTo((java.lang.Object) timeSeries41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem37.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries1.addOrUpdate(regularTimePeriod44, (double) 28);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate48 = day47.getSerialDate();
        int int49 = day47.getYear();
        java.lang.Class<?> wildcardClass50 = day47.getClass();
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        boolean boolean52 = timeSeries1.equals((java.lang.Object) wildcardClass50);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = spreadsheetDate13.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate28);
        boolean boolean32 = spreadsheetDate13.isInRange(serialDate22, serialDate28, 0);
        boolean boolean33 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int35 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate13.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate13.getNearestDayOfWeek((int) (byte) 1);
        java.lang.String str40 = spreadsheetDate13.getDescription();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28-February-1900" + "'", str10.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "28-February-1900" + "'", str29.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        timeSeries3.setKey((java.lang.Comparable) month8);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries15.setDomainDescription("hi!");
        boolean boolean19 = timeSeries15.equals((java.lang.Object) 0L);
        java.lang.Object obj20 = timeSeries15.clone();
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries3.setRangeDescription("1969");
        java.lang.Class class24 = timeSeries3.getTimePeriodClass();
        java.lang.ClassLoader classLoader25 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class24);
        boolean boolean26 = timeSeries1.equals((java.lang.Object) class24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries28.setDomainDescription("hi!");
        boolean boolean32 = timeSeries28.equals((java.lang.Object) 0L);
        java.util.List list33 = timeSeries28.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 9999);
        java.util.Date date38 = fixedMillisecond35.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date38, timeZone39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38, timeZone41);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException49);
        boolean boolean51 = year42.equals((java.lang.Object) timePeriodFormatException49);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(classLoader25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        timeSeries1.setMaximumItemCount((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        boolean boolean13 = spreadsheetDate9.isOn(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getEndOfCurrentMonth(serialDate23);
        java.lang.String str25 = serialDate24.toString();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(0, serialDate24);
        boolean boolean28 = spreadsheetDate9.isInRange(serialDate18, serialDate24, 0);
        int int29 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries31.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries35.setDomainDescription("hi!");
        java.util.Collection collection38 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        boolean boolean39 = spreadsheetDate9.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28-February-1900" + "'", str6.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "28-February-1900" + "'", str25.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Date date7 = month2.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
    }
}

