import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test1");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries8.setDomainDescription("hi!");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        timeSeries8.setKey((java.lang.Comparable) month13);
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        try {
            timeSeries1.setMaximumItemAge((long) (-43));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-59008924800001L) + "'", long19 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test2");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        int int5 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test3");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        java.lang.String str7 = serialDate6.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate8);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "28-February-1900" + "'", str7.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test4");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        long long14 = fixedMillisecond8.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        java.lang.Class<?> wildcardClass18 = timeSeries16.getClass();
        timeSeries16.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean25 = month23.equals((java.lang.Object) (short) 100);
        long long26 = month23.getLastMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int28 = fixedMillisecond8.compareTo((java.lang.Object) month23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100);
        java.lang.Object obj31 = seriesChangeEvent30.getSource();
        int int32 = fixedMillisecond8.compareTo((java.lang.Object) seriesChangeEvent30);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-59008924800001L) + "'", long26 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + obj31 + "' != '" + 100 + "'", obj31.equals(100));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test5() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test5");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean4 = month2.equals((java.lang.Object) (short) 100);
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getMiddleMillisecond();
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1L);
        java.util.Calendar calendar10 = null;
        try {
            month2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59008924800001L) + "'", long5 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59010264000001L) + "'", long6 == (-59010264000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59008924800001L) + "'", long7 == (-59008924800001L));
    }

    @Test
    public void test6() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test6");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: January 100");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test7() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test7");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setDomainDescription("hi!");
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 0L);
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 9999);
        java.util.Date date11 = fixedMillisecond8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries15.setDomainDescription("hi!");
        boolean boolean19 = timeSeries15.equals((java.lang.Object) 0L);
        java.util.List list20 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries26.setDomainDescription("hi!");
        boolean boolean30 = timeSeries26.equals((java.lang.Object) 0L);
        java.util.List list31 = timeSeries26.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 9999);
        java.util.Date date36 = fixedMillisecond33.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (double) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year37, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries15.getTimePeriod(0);
        java.lang.Class class44 = timeSeries15.getTimePeriodClass();
        boolean boolean45 = month13.equals((java.lang.Object) class44);
        java.util.Calendar calendar46 = null;
        try {
            long long47 = month13.getFirstMillisecond(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test8() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test8");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        boolean boolean15 = spreadsheetDate11.isOn(serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        java.lang.String str27 = serialDate26.toString();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(0, serialDate26);
        boolean boolean30 = spreadsheetDate11.isInRange(serialDate20, serialDate26, 0);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getEndOfCurrentMonth(serialDate40);
        java.lang.String str42 = serialDate41.toString();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate46 = serialDate43.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate48 = day47.getSerialDate();
        boolean boolean49 = spreadsheetDate45.isOn(serialDate48);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate54 = serialDate51.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
        java.lang.String str61 = serialDate60.toString();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths(0, serialDate60);
        boolean boolean64 = spreadsheetDate45.isInRange(serialDate54, serialDate60, 0);
        boolean boolean65 = spreadsheetDate35.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addYears((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate68 = day67.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate68);
        boolean boolean70 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, serialDate68);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "28-February-1900" + "'", str8.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "28-February-1900" + "'", str27.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "28-February-1900" + "'", str42.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "28-February-1900" + "'", str61.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test9() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test9");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        java.lang.Class<?> wildcardClass4 = timeSeries2.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, (java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries7.setDomainDescription("hi!");
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries12.setDomainDescription("hi!");
        boolean boolean16 = timeSeries12.equals((java.lang.Object) 0L);
        java.util.List list17 = timeSeries12.getItems();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, 0.0d);
        java.util.Date date25 = month20.getStart();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries27.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries31.setDomainDescription("hi!");
        java.util.Collection collection34 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        int int35 = month20.compareTo((java.lang.Object) timeSeries27);
        int int36 = month20.getYearValue();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(1, (int) (byte) 100);
        boolean boolean41 = month39.equals((java.lang.Object) (short) 100);
        long long42 = month39.getLastMillisecond();
        long long43 = month39.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate53 = serialDate50.getEndOfCurrentMonth(serialDate52);
        java.lang.String str54 = serialDate53.toString();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addMonths(0, serialDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate60 = day59.getSerialDate();
        boolean boolean61 = spreadsheetDate57.isOn(serialDate60);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate72 = serialDate69.getEndOfCurrentMonth(serialDate71);
        java.lang.String str73 = serialDate72.toString();
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addMonths(0, serialDate72);
        boolean boolean76 = spreadsheetDate57.isInRange(serialDate66, serialDate72, 0);
        boolean boolean77 = spreadsheetDate47.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean78 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate57.getNearestDayOfWeek((int) (short) 1);
        int int81 = month39.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) month20, (org.jfree.data.time.RegularTimePeriod) month39);
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries7.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries85.setDomainDescription("hi!");
        boolean boolean89 = timeSeries85.equals((java.lang.Object) 0L);
        java.util.List list90 = timeSeries85.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond92 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem94 = timeSeries85.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond92, (java.lang.Number) 9999);
        java.util.Collection collection95 = timeSeries85.getTimePeriods();
        java.util.Collection collection96 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries85);
        boolean boolean97 = timeSeries5.equals((java.lang.Object) timeSeries85);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener98 = null;
        timeSeries5.removeChangeListener(seriesChangeListener98);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-59008924800001L) + "'", long42 == (-59008924800001L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-59010264000001L) + "'", long43 == (-59010264000001L));
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "28-February-1900" + "'", str54.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "28-February-1900" + "'", str73.equals("28-February-1900"));
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(list90);
        org.junit.Assert.assertNull(timeSeriesDataItem94);
        org.junit.Assert.assertNotNull(collection95);
        org.junit.Assert.assertNotNull(collection96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }
}

