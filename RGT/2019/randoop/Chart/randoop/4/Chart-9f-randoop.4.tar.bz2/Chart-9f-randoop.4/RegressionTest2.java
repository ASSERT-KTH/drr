import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond15.previous();
        long long23 = fixedMillisecond15.getSerialIndex();
        long long24 = fixedMillisecond15.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        long long18 = timeSeries13.getMaximumItemAge();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        boolean boolean25 = timeSeries13.getNotify();
        java.util.Collection collection26 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener27);
        timeSeries4.setRangeDescription("First");
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        java.util.Date date5 = day4.getStart();
        long long6 = day4.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 25568L + "'", long6 == 25568L);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Date date45 = fixedMillisecond41.getTime();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date23, timeZone46);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.Year year50 = month49.getYear();
        org.jfree.data.time.Year year51 = month49.getYear();
        int int52 = month49.getMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 12 + "'", int52 == 12);
    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test05");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getSerialIndex();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 2);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 2);
//        int int24 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond21.getLastMillisecond(calendar25);
//        long long27 = fixedMillisecond21.getFirstMillisecond();
//        java.util.Date date28 = fixedMillisecond21.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        boolean boolean32 = spreadsheetDate5.equals((java.lang.Object) day30);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean35 = spreadsheetDate5.isBefore(serialDate34);
//        int int36 = spreadsheetDate5.getDayOfWeek();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 2);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 2);
//        int int56 = timeSeries42.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond53.getLastMillisecond(calendar57);
//        long long59 = fixedMillisecond53.getFirstMillisecond();
//        java.util.Date date60 = fixedMillisecond53.getEnd();
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class65);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 2);
//        java.lang.Class class74 = null;
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class74);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) 2);
//        int int80 = timeSeries66.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77);
//        java.util.Calendar calendar81 = null;
//        long long82 = fixedMillisecond77.getLastMillisecond(calendar81);
//        long long83 = fixedMillisecond77.getFirstMillisecond();
//        java.util.Date date84 = fixedMillisecond77.getEnd();
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(date84);
//        org.jfree.data.time.SerialDate serialDate86 = serialDate61.getEndOfCurrentMonth(serialDate85);
//        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.addMonths(9, serialDate86);
//        org.jfree.data.time.SerialDate serialDate88 = spreadsheetDate5.getEndOfCurrentMonth(serialDate87);
//        int int89 = spreadsheetDate5.getDayOfWeek();
//        boolean boolean90 = day2.equals((java.lang.Object) spreadsheetDate5);
//        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.createInstance(3);
//        boolean boolean93 = spreadsheetDate5.isOnOrAfter(serialDate92);
//        boolean boolean94 = spreadsheetDate1.isAfter(serialDate92);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 100L + "'", long59 == 100L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertNull(timeSeriesDataItem79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 100L + "'", long82 == 100L);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 100L + "'", long83 == 100L);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertNotNull(serialDate88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 5 + "'", int89 == 5);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertNotNull(serialDate92);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1905);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.util.List list9 = timeSeries4.getItems();
        boolean boolean10 = timeSeries4.getNotify();
        java.lang.String str11 = timeSeries4.getDescription();
        boolean boolean12 = timeSeries4.isEmpty();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        timeSeries2.setDomainDescription("hi!");
        timeSeries2.setNotify(true);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.lang.String str4 = fixedMillisecond1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str4.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond18.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        int int45 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond42.getLastMillisecond(calendar46);
        long long48 = fixedMillisecond42.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.SerialDate serialDate51 = serialDate26.getEndOfCurrentMonth(serialDate50);
        java.lang.String str52 = serialDate50.toString();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate50);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(5, serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getPreviousDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate53);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-1969" + "'", str52.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        boolean boolean26 = day24.equals((java.lang.Object) 10L);
        java.lang.String str27 = day24.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-1969" + "'", str27.equals("31-December-1969"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int9 = year7.compareTo((java.lang.Object) "January");
        int int10 = year7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.previous();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.next();
        int int15 = year7.getYear();
        int int16 = year7.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (double) 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) false);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        java.util.Collection collection17 = timeSeries4.getTimePeriods();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class19);
        boolean boolean21 = timeSeries4.equals((java.lang.Object) timeSeries20);
        boolean boolean22 = timeSeries20.getNotify();
        timeSeries20.fireSeriesChanged();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: First");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond18.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        int int45 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond42.getLastMillisecond(calendar46);
        long long48 = fixedMillisecond42.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.SerialDate serialDate51 = serialDate26.getEndOfCurrentMonth(serialDate50);
        java.lang.String str52 = serialDate50.toString();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate50);
        boolean boolean54 = spreadsheetDate1.isOnOrBefore(serialDate53);
        int int55 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (java.lang.Number) 2);
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (java.lang.Number) 2);
        int int76 = timeSeries62.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.util.Calendar calendar77 = null;
        long long78 = fixedMillisecond73.getLastMillisecond(calendar77);
        long long79 = fixedMillisecond73.getFirstMillisecond();
        java.util.Date date80 = fixedMillisecond73.getEnd();
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date80, timeZone81);
        org.jfree.data.time.SerialDate serialDate83 = day82.getSerialDate();
        boolean boolean84 = spreadsheetDate57.equals((java.lang.Object) day82);
        int int85 = spreadsheetDate57.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate(12);
        int int88 = spreadsheetDate87.getYYYY();
        boolean boolean90 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate87, (-1));
        int int91 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-1969" + "'", str52.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 100L + "'", long78 == 100L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 12 + "'", int85 == 12);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1900 + "'", int88 == 1900);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 12 + "'", int91 == 12);
    }
}

