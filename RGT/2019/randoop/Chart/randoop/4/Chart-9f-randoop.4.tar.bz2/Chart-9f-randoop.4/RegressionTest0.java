import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries4.add(timeSeriesDataItem5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries4.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.createCopy((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Fourth" + "'", str1.equals("Fourth"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "April" + "'", str1.equals("April"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("April");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        try {
            timeSeries4.removeAgedItems((long) ' ', false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 2);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 2);
        int int37 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond34.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) (-1));
        java.lang.Object obj42 = timeSeriesDataItem41.clone();
        try {
            timeSeries4.add(timeSeriesDataItem41, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100, (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, (int) (short) 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        try {
            timeSeries4.setMaximumItemCount((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries2.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) "January");
        int int12 = year9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        try {
            timeSeries4.add(regularTimePeriod13, (java.lang.Number) (-447), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Sunday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        org.jfree.data.time.SerialDate serialDate49 = serialDate24.getEndOfCurrentMonth(serialDate48);
        try {
            org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, serialDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(4, (int) (byte) 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-447), (-447), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries4.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, (-447));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 2);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 2);
        int int24 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond21.getLastMillisecond(calendar25);
        long long27 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond21.next();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 2);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        int int26 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond23.getLastMillisecond(calendar27);
        long long29 = fixedMillisecond23.getFirstMillisecond();
        java.util.Date date30 = fixedMillisecond23.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year31, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(13, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month6.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.lang.String str7 = month6.toString();
        long long8 = month6.getSerialIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) "January");
        int int12 = year9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        boolean boolean14 = month6.equals((java.lang.Object) regularTimePeriod13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month6.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24238L + "'", long8 == 24238L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate(regularTimePeriod20, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.lang.String str7 = month6.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        int int45 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond42.getLastMillisecond(calendar46);
        long long48 = fixedMillisecond42.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond42.getEnd();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date24, timeZone50);
        try {
            org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date0, timeZone50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod52);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond22.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1));
        boolean boolean31 = timeSeriesDataItem29.equals((java.lang.Object) ' ');
        try {
            timeSeries4.add(timeSeriesDataItem29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(1900, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.String str5 = timeSeries2.getRangeDescription();
        boolean boolean6 = timeSeries2.isEmpty();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond22.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1));
        java.lang.Object obj30 = timeSeriesDataItem29.clone();
        try {
            timeSeries2.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        try {
            java.lang.Number number28 = timeSeries26.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "January");
        int int26 = year23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year23.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, year23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year23.previous();
        try {
            timeSeries4.add(regularTimePeriod29, (java.lang.Number) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "February" + "'", str2.equals("February"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond15.getFirstMillisecond(calendar23);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month6.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24238L + "'", long7 == 24238L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        boolean boolean10 = timeSeries4.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 2);
        int int29 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getLastMillisecond(calendar30);
        long long32 = fixedMillisecond26.getFirstMillisecond();
        java.util.Date date33 = fixedMillisecond26.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        java.lang.Number number36 = null;
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day35, number36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 0, serialDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("First");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        int int50 = day49.getDayOfMonth();
        java.util.Calendar calendar51 = null;
        try {
            long long52 = day49.getFirstMillisecond(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 100, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = serialDate25.getEndOfCurrentMonth(serialDate49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate25);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate25);
        try {
            org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Fourth");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int30 = year28.compareTo((java.lang.Object) "January");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year28.next();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int35 = year33.compareTo((java.lang.Object) "January");
        int int36 = year33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, year33);
        long long39 = month38.getSerialIndex();
        try {
            org.jfree.data.time.TimeSeries timeSeries40 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) month38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 24238L + "'", long39 == 24238L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        boolean boolean20 = timeSeries4.getNotify();
        timeSeries4.setMaximumItemCount(1900);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 2);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 2);
        int int41 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond38.getLastMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond38.getTime();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 1900, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        serialDate23.setDescription("hi!");
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        try {
            timeSeries2.update((int) (byte) 0, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sunday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        timeSeries4.clear();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("February");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        long long16 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        try {
            java.lang.Number number10 = timeSeries4.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        int int9 = month6.getYearValue();
        java.util.Calendar calendar10 = null;
        try {
            month6.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        int int35 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond32.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1));
        java.lang.Object obj40 = timeSeriesDataItem39.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem39.getPeriod();
        try {
            timeSeries4.add(timeSeriesDataItem39, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.lang.String str7 = month6.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getFirstMillisecond(calendar11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        int int5 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        int int27 = timeSeries11.getItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        int int22 = fixedMillisecond15.compareTo((java.lang.Object) true);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond15.getMiddleMillisecond(calendar23);
        long long25 = fixedMillisecond15.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1900, 9999, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3, (int) (short) -1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        int int9 = month6.getYearValue();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.String str5 = timeSeries2.getRangeDescription();
        boolean boolean6 = timeSeries2.isEmpty();
        try {
            timeSeries2.delete((int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        try {
            java.lang.Number number17 = timeSeries4.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond24.getTime();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 2);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 2);
        int int50 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeries36.getNextTimePeriod();
        java.util.Date date52 = regularTimePeriod51.getStart();
        try {
            timeSeries4.add(regularTimePeriod51, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries12.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            java.lang.Number number18 = timeSeries12.getValue(regularTimePeriod17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = serialDate25.getEndOfCurrentMonth(serialDate49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(2, serialDate50);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate50);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("October");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        timeSeries4.setMaximumItemAge((long) 31);
        timeSeries4.clear();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        org.jfree.data.time.SerialDate serialDate49 = serialDate24.getEndOfCurrentMonth(serialDate48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate24);
        java.lang.String str52 = serialDate24.getDescription();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int25 = day24.getMonth();
        java.lang.String str26 = day24.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-1969" + "'", str26.equals("31-December-1969"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries5.getNextTimePeriod();
        java.util.Date date21 = regularTimePeriod20.getStart();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        try {
            org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) -1, serialDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 2);
        int int28 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1));
        java.lang.Object obj33 = timeSeriesDataItem32.clone();
        int int35 = timeSeriesDataItem32.compareTo((java.lang.Object) (short) 1);
        try {
            timeSeries4.add(timeSeriesDataItem32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = fixedMillisecond6.getFirstMillisecond();
        long long10 = fixedMillisecond6.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
        java.util.Calendar calendar51 = null;
        try {
            long long52 = regularTimePeriod50.getMiddleMillisecond(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Sunday");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Sunday" + "'", str2.equals("org.jfree.data.general.SeriesException: Sunday"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        int int50 = day49.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day49.next();
        long long52 = day49.getLastMillisecond();
        int int53 = day49.getMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 28799999L + "'", long52 == 28799999L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        java.lang.String str50 = serialDate48.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-1969" + "'", str50.equals("31-December-1969"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond15.getMiddleMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond15.next();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        int int24 = year23.getYear();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year23.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        try {
            timeSeries5.delete((int) 'a', 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        org.jfree.data.time.SerialDate serialDate49 = serialDate24.getEndOfCurrentMonth(serialDate48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(9, serialDate49);
        try {
            org.jfree.data.time.SerialDate serialDate52 = serialDate50.getPreviousDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("February");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day58.previous();
        java.util.Calendar calendar63 = null;
        try {
            long long64 = day58.getLastMillisecond(calendar63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (short) 0);
        java.lang.String str7 = regularTimePeriod4.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2018" + "'", str7.equals("2018"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(31, serialDate26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        java.lang.String str28 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date31 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) year32);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int7 = year5.compareTo((java.lang.Object) "January");
        int int8 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        long long10 = year5.getFirstMillisecond();
        long long11 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        java.util.Calendar calendar13 = null;
        try {
            year5.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        timeSeries2.removeAgedItems(false);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond22.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1));
        java.lang.Number number30 = timeSeriesDataItem29.getValue();
        java.lang.Object obj31 = timeSeriesDataItem29.clone();
        try {
            timeSeries2.add(timeSeriesDataItem29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1) + "'", number30.equals((-1)));
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond22.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1));
        java.lang.Object obj30 = timeSeriesDataItem29.clone();
        int int32 = timeSeriesDataItem29.compareTo((java.lang.Object) (short) 1);
        timeSeriesDataItem29.setValue((java.lang.Number) (byte) -1);
        try {
            timeSeries4.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries12.addChangeListener(seriesChangeListener16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries12.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 2);
        long long14 = fixedMillisecond11.getFirstMillisecond();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 2);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        int int33 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond30.getLastMillisecond(calendar34);
        long long36 = fixedMillisecond30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond30.next();
        int int38 = fixedMillisecond11.compareTo((java.lang.Object) regularTimePeriod37);
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        java.lang.Class class11 = timeSeries5.getTimePeriodClass();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        long long21 = fixedMillisecond18.getFirstMillisecond();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 2);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 2);
        int int40 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond37.getLastMillisecond(calendar41);
        long long43 = fixedMillisecond37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond37.next();
        int int45 = fixedMillisecond18.compareTo((java.lang.Object) regularTimePeriod44);
        boolean boolean46 = timeSeries5.equals((java.lang.Object) int45);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = serialDate25.getEndOfCurrentMonth(serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate49);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate49);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-1969" + "'", str51.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1969, (-460), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        java.lang.Comparable comparable3 = timeSeries2.getKey();
        timeSeries2.setNotify(false);
        timeSeries2.fireSeriesChanged();
        try {
            timeSeries2.update(5, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        int int64 = year62.compareTo((java.lang.Object) "January");
        int int65 = year62.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year62.previous();
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(10, year62);
        long long68 = month67.getLastMillisecond();
        int int69 = month67.getMonth();
        java.lang.Number number70 = null;
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month67, number70, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1572591599999L + "'", long68 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond15.next();
        long long23 = fixedMillisecond15.getSerialIndex();
        java.util.Date date24 = fixedMillisecond15.getStart();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1572591599999L);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) (-1));
        java.lang.Object obj26 = timeSeriesDataItem25.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem25.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem25, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day58);
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 2);
        java.lang.Class class74 = null;
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class74);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) 2);
        int int80 = timeSeries66.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77);
        java.util.Calendar calendar81 = null;
        long long82 = fixedMillisecond77.getLastMillisecond(calendar81);
        long long83 = fixedMillisecond77.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = fixedMillisecond77.previous();
        long long85 = fixedMillisecond77.getFirstMillisecond();
        boolean boolean86 = day58.equals((java.lang.Object) fixedMillisecond77);
        java.util.Calendar calendar87 = null;
        try {
            day58.peg(calendar87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 100L + "'", long82 == 100L);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 100L + "'", long83 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 100L + "'", long85 == 100L);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1969);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.util.List list9 = timeSeries4.getItems();
        timeSeries4.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy(0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = serialDate25.getEndOfCurrentMonth(serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(9, serialDate50);
        try {
            org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2019, serialDate51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int25 = day24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        java.util.Date date27 = day24.getStart();
        java.util.Calendar calendar28 = null;
        try {
            day24.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int25 = day24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.next();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = regularTimePeriod27.getMiddleMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, 13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source= ]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        long long18 = timeSeries13.getMaximumItemAge();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        boolean boolean25 = timeSeries13.getNotify();
        java.util.Collection collection26 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.util.List list27 = timeSeries4.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
        try {
            int int29 = timeSeries4.getIndex(regularTimePeriod28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        try {
            timeSeries4.delete((int) (byte) 10, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1969, 5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        timeSeries2.removeAgedItems(false);
        try {
            timeSeries2.removeAgedItems((long) 13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        int int50 = day49.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day49.next();
        long long52 = day49.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-57600000L) + "'", long52 == (-57600000L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        boolean boolean20 = timeSeries4.getNotify();
        java.lang.Comparable comparable21 = timeSeries4.getKey();
        java.util.Collection collection22 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 1.0d + "'", comparable21.equals(1.0d));
        org.junit.Assert.assertNotNull(collection22);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Sunday");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.lang.Class class24 = null;
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date47, timeZone48);
        java.lang.Class class53 = null;
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (java.lang.Number) 2);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) 2);
        int int68 = timeSeries54.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
        java.util.Calendar calendar69 = null;
        long long70 = fixedMillisecond65.getLastMillisecond(calendar69);
        long long71 = fixedMillisecond65.getFirstMillisecond();
        java.util.Date date72 = fixedMillisecond65.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date47, timeZone73);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date22, timeZone73);
        int int77 = day76.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day76.next();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 100L + "'", long71 == 100L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1969 + "'", int77 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        java.lang.String str28 = timeSeries2.getDomainDescription();
        java.lang.Object obj29 = timeSeries2.clone();
        try {
            org.jfree.data.time.TimeSeries timeSeries32 = timeSeries2.createCopy((-457), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        int int3 = timeSeries2.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.addOrUpdate(regularTimePeriod4, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "ERROR : Relative To String", "April", class3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries4.delete(regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        int int10 = month6.getMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond15.previous();
        long long23 = fixedMillisecond15.getFirstMillisecond();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond41.getTime();
        java.lang.Class<?> wildcardClass48 = date47.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond15, "org.jfree.data.general.SeriesChangeEvent[source=10]", "31-December-1969", (java.lang.Class) wildcardClass48);
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(class51);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.lang.Class class24 = null;
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date47, timeZone48);
        java.lang.Class class53 = null;
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (java.lang.Number) 2);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) 2);
        int int68 = timeSeries54.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
        java.util.Calendar calendar69 = null;
        long long70 = fixedMillisecond65.getLastMillisecond(calendar69);
        long long71 = fixedMillisecond65.getFirstMillisecond();
        java.util.Date date72 = fixedMillisecond65.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date47, timeZone73);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date22, timeZone73);
        int int77 = day76.getYear();
        java.util.Calendar calendar78 = null;
        try {
            day76.peg(calendar78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 100L + "'", long71 == 100L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1969 + "'", int77 == 1969);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560190154122L + "'", long1 == 1560190154122L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        java.lang.Class class11 = timeSeries5.getTimePeriodClass();
        java.lang.String str12 = timeSeries5.getDomainDescription();
        timeSeries5.setKey((java.lang.Comparable) false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int4 = year2.compareTo((java.lang.Object) "January");
        int int5 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.previous();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year2);
        java.lang.String str8 = month7.toString();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 2);
        int int28 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        long long31 = fixedMillisecond25.getFirstMillisecond();
        java.util.Date date32 = fixedMillisecond25.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (java.lang.Number) 2);
        int int52 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond49.getLastMillisecond(calendar53);
        long long55 = fixedMillisecond49.getFirstMillisecond();
        java.util.Date date56 = fixedMillisecond49.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate58 = serialDate33.getEndOfCurrentMonth(serialDate57);
        java.lang.String str59 = serialDate57.toString();
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate57);
        int int61 = month7.compareTo((java.lang.Object) serialDate60);
        try {
            org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2019, serialDate60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "31-December-1969" + "'", str59.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.addAndOrUpdate(timeSeries10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2147483647) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        int int50 = day49.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day49.next();
        java.lang.String str52 = regularTimePeriod51.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1-January-1970" + "'", str52.equals("1-January-1970"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) day26);
        try {
            org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate1.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.lang.Object obj23 = timeSeriesDataItem22.clone();
        int int25 = timeSeriesDataItem22.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
        seriesException27.addSuppressed((java.lang.Throwable) seriesException29);
        boolean boolean31 = timeSeriesDataItem22.equals((java.lang.Object) seriesException29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem22.getPeriod();
        java.lang.Object obj33 = timeSeriesDataItem22.clone();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone22 = null;
        try {
            org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long21);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.lang.String str7 = month6.toString();
        long long8 = month6.getSerialIndex();
        int int9 = month6.getMonth();
        long long10 = month6.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24238L + "'", long8 == 24238L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24238L + "'", long10 == 24238L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date12 = fixedMillisecond11.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.removeChangeListener(seriesChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener18);
        boolean boolean20 = fixedMillisecond11.equals((java.lang.Object) timeSeries15);
        timeSeries15.removeAgedItems(true);
        boolean boolean23 = month6.equals((java.lang.Object) timeSeries15);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries15.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
        long long51 = day49.getFirstMillisecond();
        long long52 = day49.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-57600000L) + "'", long51 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-57600000L) + "'", long52 == (-57600000L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        org.jfree.data.time.SerialDate serialDate49 = serialDate24.getEndOfCurrentMonth(serialDate48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate24);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        int int55 = year53.compareTo((java.lang.Object) "January");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year53.next();
        java.lang.String str57 = year53.toString();
        boolean boolean58 = day52.equals((java.lang.Object) str57);
        java.util.Calendar calendar59 = null;
        try {
            day52.peg(calendar59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2019" + "'", str57.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond18.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        int int45 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond42.getLastMillisecond(calendar46);
        long long48 = fixedMillisecond42.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.SerialDate serialDate51 = serialDate26.getEndOfCurrentMonth(serialDate50);
        java.lang.String str52 = serialDate50.toString();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate50);
        boolean boolean54 = spreadsheetDate1.isOnOrBefore(serialDate53);
        org.jfree.data.time.SerialDate serialDate55 = null;
        try {
            boolean boolean56 = spreadsheetDate1.isOnOrAfter(serialDate55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-1969" + "'", str52.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "ERROR : Relative To String", "April", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 2);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 2);
        int int23 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond20.getLastMillisecond(calendar24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1));
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        int int30 = timeSeriesDataItem27.compareTo((java.lang.Object) (short) 1);
        try {
            timeSeries4.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond17.previous();
        long long25 = fixedMillisecond17.getFirstMillisecond();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 2);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 2);
        int int46 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond43.getLastMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond43.getTime();
        java.lang.Class<?> wildcardClass50 = date49.getClass();
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, "org.jfree.data.general.SeriesChangeEvent[source=10]", "31-December-1969", (java.lang.Class) wildcardClass50);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) 2);
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 2);
        int int71 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond68.getLastMillisecond(calendar72);
        long long74 = fixedMillisecond68.getFirstMillisecond();
        java.util.Date date75 = fixedMillisecond68.getEnd();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date75);
        int int77 = fixedMillisecond17.compareTo((java.lang.Object) year76);
        int int78 = fixedMillisecond1.compareTo((java.lang.Object) year76);
        int int79 = year76.getYear();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 100L + "'", long73 == 100L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 100L + "'", long74 == 100L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1969 + "'", int79 == 1969);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1969);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        java.lang.String str61 = day58.toString();
        org.jfree.data.time.SerialDate serialDate62 = day58.getSerialDate();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "31-December-1969" + "'", str61.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate62);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        int int9 = month6.getYearValue();
        long long10 = month6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1572591599999L + "'", long10 == 1572591599999L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        timeSeries4.clear();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries7.getNextTimePeriod();
        boolean boolean23 = timeSeries7.getNotify();
        timeSeries7.setMaximumItemCount(1900);
        java.lang.Class<?> wildcardClass26 = timeSeries7.getClass();
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "2019", "2019", class27);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.lang.Object obj23 = timeSeriesDataItem22.clone();
        java.lang.Object obj24 = timeSeriesDataItem22.clone();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24238L + "'", long8 == 24238L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries4.getTimePeriod(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) ' ');
        java.lang.String str13 = seriesChangeEvent12.toString();
        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) seriesChangeEvent12);
        java.lang.Object obj15 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source= ]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source= ]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + ' ' + "'", obj15.equals(' '));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 11);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1572591599999L + "'", long8 == 1572591599999L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries4.removeChangeListener(seriesChangeListener21);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) day26);
        java.util.Calendar calendar29 = null;
        try {
            day26.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        try {
            timeSeries2.delete((int) 'a', 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        int int19 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond16.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond16.getFirstMillisecond();
        java.util.Date date23 = fixedMillisecond16.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date23, timeZone49);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month52, (double) 1969L);
        java.lang.Number number55 = timeSeriesDataItem54.getValue();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 1969.0d + "'", number55.equals(1969.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-455) + "'", int1 == (-455));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(17, 12, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = serialDate25.getEndOfCurrentMonth(serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate49);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths(5, serialDate52);
        try {
            org.jfree.data.time.SerialDate serialDate55 = serialDate53.getNearestDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-1969" + "'", str51.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond18.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        int int45 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond42.getLastMillisecond(calendar46);
        long long48 = fixedMillisecond42.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.SerialDate serialDate51 = serialDate26.getEndOfCurrentMonth(serialDate50);
        java.lang.String str52 = serialDate50.toString();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate50);
        boolean boolean54 = spreadsheetDate1.isOnOrBefore(serialDate53);
        java.lang.Object obj55 = null;
        try {
            int int56 = spreadsheetDate1.compareTo(obj55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-1969" + "'", str52.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24238L + "'", long7 == 24238L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-455));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("First");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("First");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 2);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 2);
        int int40 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond37.getLastMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond37.getTime();
        java.lang.Class<?> wildcardClass44 = date43.getClass();
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        java.util.Date date46 = null;
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 2);
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) 2);
        int int65 = timeSeries51.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        java.util.Calendar calendar66 = null;
        long long67 = fixedMillisecond62.getLastMillisecond(calendar66);
        long long68 = fixedMillisecond62.getFirstMillisecond();
        java.util.Date date69 = fixedMillisecond62.getEnd();
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(date69);
        java.lang.Class class74 = null;
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class74);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) 2);
        java.lang.Class class83 = null;
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class83);
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries84.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86, (java.lang.Number) 2);
        int int89 = timeSeries75.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86);
        java.util.Calendar calendar90 = null;
        long long91 = fixedMillisecond86.getLastMillisecond(calendar90);
        long long92 = fixedMillisecond86.getFirstMillisecond();
        java.util.Date date93 = fixedMillisecond86.getEnd();
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date93, timeZone94);
        org.jfree.data.time.Month month96 = new org.jfree.data.time.Month(date69, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone94);
        org.jfree.data.time.Month month98 = new org.jfree.data.time.Month(date21, timeZone94);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 100L + "'", long67 == 100L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 100L + "'", long68 == 100L);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertNull(timeSeriesDataItem88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 100L + "'", long91 == 100L);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 100L + "'", long92 == 100L);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(timeZone94);
        org.junit.Assert.assertNull(regularTimePeriod97);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 2);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        long long19 = timeSeries14.getMaximumItemAge();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.removeChangeListener(seriesChangeListener23);
        java.util.Collection collection25 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        boolean boolean26 = timeSeries14.getNotify();
        java.util.Collection collection27 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int30 = year28.compareTo((java.lang.Object) "January");
        int int31 = year28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year28.previous();
        boolean boolean33 = timeSeries14.equals((java.lang.Object) year28);
        try {
            org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) -1, year28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond22.getLastMillisecond(calendar26);
        long long28 = fixedMillisecond22.getFirstMillisecond();
        java.util.Date date29 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 2);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 2);
        int int49 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond46.getLastMillisecond(calendar50);
        long long52 = fixedMillisecond46.getFirstMillisecond();
        java.util.Date date53 = fixedMillisecond46.getEnd();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        org.jfree.data.time.SerialDate serialDate55 = serialDate30.getEndOfCurrentMonth(serialDate54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate55);
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day56);
        long long58 = day56.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 100L + "'", long52 == 100L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28799999L + "'", long58 == 28799999L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        fixedMillisecond15.peg(calendar19);
        java.util.Calendar calendar21 = null;
        fixedMillisecond15.peg(calendar21);
        java.lang.Object obj23 = null;
        boolean boolean24 = fixedMillisecond15.equals(obj23);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date12 = fixedMillisecond11.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.removeChangeListener(seriesChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener18);
        boolean boolean20 = fixedMillisecond11.equals((java.lang.Object) timeSeries15);
        timeSeries15.removeAgedItems(true);
        boolean boolean23 = month6.equals((java.lang.Object) timeSeries15);
        try {
            timeSeries15.update((int) (short) 1, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        int int50 = day49.getDayOfMonth();
        java.util.Calendar calendar51 = null;
        try {
            day49.peg(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        timeSeries2.setNotify(false);
        int int5 = timeSeries2.getMaximumItemCount();
        timeSeries2.setNotify(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) ' ');
        java.lang.String str13 = seriesChangeEvent12.toString();
        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) seriesChangeEvent12);
        int int16 = fixedMillisecond1.compareTo((java.lang.Object) "Sunday");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source= ]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source= ]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        java.lang.Object obj8 = timeSeries7.clone();
        timeSeries7.setNotify(true);
        timeSeries7.fireSeriesChanged();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) 2);
        int int30 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond27.getLastMillisecond(calendar31);
        long long33 = fixedMillisecond27.getFirstMillisecond();
        java.util.Date date34 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 2);
        int int54 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond51.getLastMillisecond(calendar55);
        long long57 = fixedMillisecond51.getFirstMillisecond();
        java.util.Date date58 = fixedMillisecond51.getEnd();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date58);
        org.jfree.data.time.SerialDate serialDate60 = serialDate35.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day61, (double) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = day61.previous();
        java.lang.Class<?> wildcardClass65 = day61.getClass();
        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "First", "First", "Fourth", (java.lang.Class) wildcardClass65);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(class66);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries7.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries7.removeChangeListener(seriesChangeListener23);
        timeSeries7.setMaximumItemAge((long) 31);
        java.util.List list27 = timeSeries7.getItems();
        try {
            int int28 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int7 = year5.compareTo((java.lang.Object) "January");
        int int8 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        long long10 = year5.getFirstMillisecond();
        long long11 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year5.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        java.lang.String str28 = timeSeries2.getDomainDescription();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 2);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 2);
        int int47 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeries33.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries33.removeChangeListener(seriesChangeListener49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        int int53 = year51.compareTo((java.lang.Object) "January");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year51.next();
        java.lang.String str55 = year51.toString();
        int int56 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) year51);
        java.util.Collection collection57 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        try {
            timeSeries2.update(6, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(collection57);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        java.util.Date date6 = year0.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        int int6 = year0.getYear();
        long long7 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("2018");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2018 + "'", int1 == 2018);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("");
        timeSeries4.setDomainDescription("October");
        timeSeries4.clear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year28, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.lang.Number number23 = timeSeriesDataItem22.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem22.getPeriod();
        java.lang.Number number25 = timeSeriesDataItem22.getValue();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int29 = year27.compareTo((java.lang.Object) "January");
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.previous();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(10, year27);
        long long33 = month32.getLastMillisecond();
        java.lang.String str34 = month32.toString();
        org.jfree.data.time.Year year35 = month32.getYear();
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year35, class36);
        java.util.Collection collection38 = timeSeries37.getTimePeriods();
        java.lang.String str39 = timeSeries37.getDomainDescription();
        boolean boolean40 = timeSeriesDataItem22.equals((java.lang.Object) str39);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1) + "'", number23.equals((-1)));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1) + "'", number25.equals((-1)));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1572591599999L + "'", long33 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 2019" + "'", str34.equals("October 2019"));
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        int int62 = day58.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        int int65 = year63.compareTo((java.lang.Object) "January");
        int int66 = year63.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year63.previous();
        long long68 = year63.getLastMillisecond();
        int int69 = day58.compareTo((java.lang.Object) year63);
        java.util.Calendar calendar70 = null;
        try {
            long long71 = year63.getFirstMillisecond(calendar70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1577865599999L + "'", long68 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(17, 6, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("1-January-1970");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "January");
        int int28 = year25.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year25, (double) (-57600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.lang.String str7 = month6.toString();
        long long8 = month6.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24238L + "'", long8 == 24238L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100, 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries12.isEmpty();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries19.addAndOrUpdate(timeSeries28);
        timeSeries19.fireSeriesChanged();
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 2);
        long long54 = timeSeries49.getMaximumItemAge();
        java.util.Collection collection55 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries49);
        java.util.Collection collection56 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.util.List list57 = timeSeries12.getItems();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 9223372036854775807L + "'", long54 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection55);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertNotNull(list57);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 11);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        int int61 = day58.getDayOfMonth();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        long long26 = day24.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28799999L + "'", long26 == 28799999L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        try {
            timeSeries5.delete(2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        java.lang.Class class11 = timeSeries5.getTimePeriodClass();
        java.lang.String str12 = timeSeries5.getDomainDescription();
        java.lang.Object obj13 = timeSeries5.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("");
        timeSeries4.setRangeDescription("2019");
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        java.lang.Object obj32 = timeSeries31.clone();
        timeSeries31.setNotify(true);
        timeSeries31.fireSeriesChanged();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 2);
        int int54 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond51.getLastMillisecond(calendar55);
        long long57 = fixedMillisecond51.getFirstMillisecond();
        java.util.Date date58 = fixedMillisecond51.getEnd();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date58);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 2);
        java.lang.Class class72 = null;
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 2);
        int int78 = timeSeries64.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
        java.util.Calendar calendar79 = null;
        long long80 = fixedMillisecond75.getLastMillisecond(calendar79);
        long long81 = fixedMillisecond75.getFirstMillisecond();
        java.util.Date date82 = fixedMillisecond75.getEnd();
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date82);
        org.jfree.data.time.SerialDate serialDate84 = serialDate59.getEndOfCurrentMonth(serialDate83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate84);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day85, (double) 2019);
        int int89 = day85.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = day85.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day85);
        long long92 = day85.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 100L + "'", long81 == 100L);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNull(timeSeriesDataItem87);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeSeriesDataItem91);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 28799999L + "'", long92 == 28799999L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int19 = year17.compareTo((java.lang.Object) "January");
        int int20 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, year17);
        long long23 = month22.getLastMillisecond();
        int int24 = month22.getMonth();
        org.jfree.data.time.Year year25 = month22.getYear();
        try {
            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year25, (double) 13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1572591599999L + "'", long23 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertNotNull(year25);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.Year year9 = month6.getYear();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener15);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        int int35 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries12.addAndOrUpdate(timeSeries21);
        timeSeries12.fireSeriesChanged();
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 2);
        long long47 = timeSeries42.getMaximumItemAge();
        java.util.Collection collection48 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries42);
        int int49 = month6.compareTo((java.lang.Object) collection48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month6.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent51 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getLastMillisecond();
        long long6 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 2);
        int int38 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
        java.util.Date date41 = fixedMillisecond35.getTime();
        long long42 = fixedMillisecond35.getMiddleMillisecond();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.lang.Number number23 = timeSeriesDataItem22.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem22.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem22);
        try {
            timeSeries25.setMaximumItemAge((long) (-447));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1) + "'", number23.equals((-1)));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day58.previous();
        int int62 = day58.getMonth();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 12 + "'", int62 == 12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        timeSeries4.setDomainDescription("January");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries4.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        int int8 = month6.getMonth();
        org.jfree.data.time.Year year9 = month6.getYear();
        long long10 = month6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1569913200000L + "'", long10 == 1569913200000L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
        java.util.Calendar calendar51 = null;
        try {
            day49.peg(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        int int9 = month6.getYearValue();
        long long10 = month6.getSerialIndex();
        java.lang.String str11 = month6.toString();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month6.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24238L + "'", long10 == 24238L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "October 2019" + "'", str11.equals("October 2019"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.lang.Class class24 = null;
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date47, timeZone48);
        java.lang.Class class53 = null;
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (java.lang.Number) 2);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) 2);
        int int68 = timeSeries54.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
        java.util.Calendar calendar69 = null;
        long long70 = fixedMillisecond65.getLastMillisecond(calendar69);
        long long71 = fixedMillisecond65.getFirstMillisecond();
        java.util.Date date72 = fixedMillisecond65.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date47, timeZone73);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date22, timeZone73);
        int int77 = day76.getMonth();
        java.util.Calendar calendar78 = null;
        try {
            long long79 = day76.getFirstMillisecond(calendar78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 100L + "'", long71 == 100L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 12 + "'", int77 == 12);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond15.previous();
        long long23 = fixedMillisecond15.getFirstMillisecond();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond41.getTime();
        java.lang.Class<?> wildcardClass48 = date47.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond15, "org.jfree.data.general.SeriesChangeEvent[source=10]", "31-December-1969", (java.lang.Class) wildcardClass48);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener51);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeries50.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        long long18 = timeSeries13.getMaximumItemAge();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        boolean boolean25 = timeSeries13.getNotify();
        java.util.Collection collection26 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.util.List list27 = timeSeries4.getItems();
        try {
            timeSeries4.delete((int) (short) 1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond18.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        int int45 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond42.getLastMillisecond(calendar46);
        long long48 = fixedMillisecond42.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.SerialDate serialDate51 = serialDate26.getEndOfCurrentMonth(serialDate50);
        java.lang.String str52 = serialDate50.toString();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate50);
        boolean boolean54 = spreadsheetDate1.isOnOrBefore(serialDate53);
        int int55 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (java.lang.Number) 2);
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (java.lang.Number) 2);
        int int76 = timeSeries62.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.util.Calendar calendar77 = null;
        long long78 = fixedMillisecond73.getLastMillisecond(calendar77);
        long long79 = fixedMillisecond73.getFirstMillisecond();
        java.util.Date date80 = fixedMillisecond73.getEnd();
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date80, timeZone81);
        org.jfree.data.time.SerialDate serialDate83 = day82.getSerialDate();
        boolean boolean84 = spreadsheetDate57.equals((java.lang.Object) day82);
        int int85 = spreadsheetDate57.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate(12);
        int int88 = spreadsheetDate87.getYYYY();
        boolean boolean90 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate87, (-1));
        try {
            org.jfree.data.time.SerialDate serialDate92 = spreadsheetDate1.getPreviousDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-1969" + "'", str52.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 100L + "'", long78 == 100L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 12 + "'", int85 == 12);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1900 + "'", int88 == 1900);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day58.previous();
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 2);
        java.lang.Class class74 = null;
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class74);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) 2);
        int int80 = timeSeries66.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77);
        java.util.Calendar calendar81 = null;
        long long82 = fixedMillisecond77.getLastMillisecond(calendar81);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) (-1));
        java.lang.Number number85 = timeSeriesDataItem84.getValue();
        java.lang.Object obj86 = timeSeriesDataItem84.clone();
        boolean boolean87 = day58.equals(obj86);
        java.util.Calendar calendar88 = null;
        try {
            day58.peg(calendar88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 100L + "'", long82 == 100L);
        org.junit.Assert.assertTrue("'" + number85 + "' != '" + (-1) + "'", number85.equals((-1)));
        org.junit.Assert.assertNotNull(obj86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 10);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 10 + "'", obj3.equals((short) 10));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 10 + "'", obj4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        long long9 = month6.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1569913200000L + "'", long9 == 1569913200000L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        java.lang.String str26 = timeSeries21.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar29 = null;
        fixedMillisecond28.peg(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        timeSeries21.setKey((java.lang.Comparable) fixedMillisecond28);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        int int24 = year23.getYear();
        long long25 = year23.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1969L + "'", long25 == 1969L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        boolean boolean10 = timeSeries4.getNotify();
        try {
            timeSeries4.delete(7, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        timeSeries4.clear();
        try {
            timeSeries4.delete(100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 2);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 2);
        int int28 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        long long31 = fixedMillisecond25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond25.next();
        int int33 = fixedMillisecond6.compareTo((java.lang.Object) regularTimePeriod32);
        long long34 = fixedMillisecond6.getMiddleMillisecond();
        long long35 = fixedMillisecond6.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        int int35 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond32.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1));
        java.lang.Number number40 = timeSeriesDataItem39.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem39.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem39);
        timeSeries4.setKey((java.lang.Comparable) timeSeriesDataItem39);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) 2);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) 2);
        int int62 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond59.getLastMillisecond(calendar63);
        long long65 = fixedMillisecond59.getFirstMillisecond();
        java.util.Date date66 = fixedMillisecond59.getEnd();
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(1, 0);
        try {
            org.jfree.data.time.TimeSeries timeSeries70 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (org.jfree.data.time.RegularTimePeriod) month69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (-1) + "'", number40.equals((-1)));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 100L + "'", long64 == 100L);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 100L + "'", long65 == 100L);
        org.junit.Assert.assertNotNull(date66);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Class<?> wildcardClass22 = date21.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "January");
        int int26 = year23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year23.previous();
        long long28 = year23.getFirstMillisecond();
        java.util.Date date29 = year23.getStart();
        java.lang.Class class30 = null;
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 2);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 2);
        int int49 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond46.getLastMillisecond(calendar50);
        long long52 = fixedMillisecond46.getFirstMillisecond();
        java.util.Date date53 = fixedMillisecond46.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date53, timeZone54);
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) 2);
        java.lang.Class class68 = null;
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class68);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (java.lang.Number) 2);
        int int74 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71);
        java.util.Calendar calendar75 = null;
        long long76 = fixedMillisecond71.getLastMillisecond(calendar75);
        long long77 = fixedMillisecond71.getFirstMillisecond();
        java.util.Date date78 = fixedMillisecond71.getEnd();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date53, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date29, timeZone79);
        java.util.TimeZone timeZone83 = null;
        try {
            org.jfree.data.time.Month month84 = new org.jfree.data.time.Month(date29, timeZone83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 100L + "'", long52 == 100L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertNull(timeSeriesDataItem73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 100L + "'", long76 == 100L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 100L + "'", long77 == 100L);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getSerialIndex();
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond15.getMiddleMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond15.next();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond15.getEnd();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond15.getMiddleMillisecond(calendar24);
        long long26 = fixedMillisecond15.getMiddleMillisecond();
        long long27 = fixedMillisecond15.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        int int62 = day58.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        int int65 = year63.compareTo((java.lang.Object) "January");
        int int66 = year63.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year63.previous();
        long long68 = year63.getLastMillisecond();
        int int69 = day58.compareTo((java.lang.Object) year63);
        java.util.Calendar calendar70 = null;
        try {
            long long71 = day58.getLastMillisecond(calendar70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1577865599999L + "'", long68 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        int int3 = timeSeries2.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            java.lang.Number number9 = timeSeries4.getValue(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.Year year9 = month6.getYear();
        int int11 = year9.compareTo((java.lang.Object) 1.0f);
        java.lang.String str12 = year9.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        java.lang.String str6 = year0.toString();
        java.lang.Object obj7 = null;
        int int8 = year0.compareTo(obj7);
        long long9 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        boolean boolean20 = timeSeries4.getNotify();
        timeSeries4.setMaximumItemCount(1900);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries4.addChangeListener(seriesChangeListener23);
        timeSeries4.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = null;
        try {
            timeSeries4.update(regularTimePeriod29, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        int int24 = year23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
        long long26 = year23.getSerialIndex();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year23.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-447));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("");
        timeSeries4.setRangeDescription("2019");
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        java.lang.Object obj32 = timeSeries31.clone();
        timeSeries31.setNotify(true);
        timeSeries31.fireSeriesChanged();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 2);
        int int54 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond51.getLastMillisecond(calendar55);
        long long57 = fixedMillisecond51.getFirstMillisecond();
        java.util.Date date58 = fixedMillisecond51.getEnd();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date58);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 2);
        java.lang.Class class72 = null;
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 2);
        int int78 = timeSeries64.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
        java.util.Calendar calendar79 = null;
        long long80 = fixedMillisecond75.getLastMillisecond(calendar79);
        long long81 = fixedMillisecond75.getFirstMillisecond();
        java.util.Date date82 = fixedMillisecond75.getEnd();
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date82);
        org.jfree.data.time.SerialDate serialDate84 = serialDate59.getEndOfCurrentMonth(serialDate83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate84);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day85, (double) 2019);
        int int89 = day85.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = day85.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day85);
        java.util.Calendar calendar92 = null;
        try {
            long long93 = day85.getLastMillisecond(calendar92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 100L + "'", long81 == 100L);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNull(timeSeriesDataItem87);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeSeriesDataItem91);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.lang.Object obj23 = timeSeriesDataItem22.clone();
        int int25 = timeSeriesDataItem22.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int29 = year27.compareTo((java.lang.Object) "January");
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.previous();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(10, year27);
        long long33 = month32.getLastMillisecond();
        java.lang.String str34 = month32.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month32.next();
        long long36 = month32.getSerialIndex();
        boolean boolean37 = timeSeriesDataItem22.equals((java.lang.Object) long36);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1572591599999L + "'", long33 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 2019" + "'", str34.equals("October 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24238L + "'", long36 == 24238L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source= ]");
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.String str34 = timeSeries29.getDomainDescription();
        timeSeries29.setRangeDescription("Sunday");
        try {
            org.jfree.data.time.TimeSeries timeSeries37 = timeSeries4.addAndOrUpdate(timeSeries29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond15.getEnd();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond15.getMiddleMillisecond(calendar24);
        long long26 = fixedMillisecond15.getMiddleMillisecond();
        long long27 = fixedMillisecond15.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries4.removeChangeListener(seriesChangeListener23);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int4 = year2.compareTo((java.lang.Object) "January");
        int int5 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.previous();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year2);
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.Year year9 = month7.getYear();
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(0, year9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        int int8 = month6.getMonth();
        org.jfree.data.time.Year year9 = month6.getYear();
        long long10 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        int int43 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
        long long46 = fixedMillisecond40.getFirstMillisecond();
        java.util.Date date47 = fixedMillisecond40.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date47, timeZone48);
        org.jfree.data.time.SerialDate serialDate50 = day49.getSerialDate();
        boolean boolean51 = spreadsheetDate24.equals((java.lang.Object) day49);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean54 = spreadsheetDate24.isBefore(serialDate53);
        int int55 = spreadsheetDate24.getDayOfWeek();
        java.util.Date date56 = spreadsheetDate24.toDate();
        java.lang.Class class60 = null;
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (java.lang.Number) 2);
        java.lang.Class class69 = null;
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class69);
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries70.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (java.lang.Number) 2);
        int int75 = timeSeries61.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
        java.util.Date date76 = fixedMillisecond72.getTime();
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date76, timeZone77);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date56, timeZone77);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date22, timeZone77);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 5 + "'", int55 == 5);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone77);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "November" + "'", str1.equals("November"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond17.previous();
        long long25 = fixedMillisecond17.getFirstMillisecond();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 2);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 2);
        int int46 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond43.getLastMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond43.getTime();
        java.lang.Class<?> wildcardClass50 = date49.getClass();
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, "org.jfree.data.general.SeriesChangeEvent[source=10]", "31-December-1969", (java.lang.Class) wildcardClass50);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) 2);
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 2);
        int int71 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond68.getLastMillisecond(calendar72);
        long long74 = fixedMillisecond68.getFirstMillisecond();
        java.util.Date date75 = fixedMillisecond68.getEnd();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date75);
        int int77 = fixedMillisecond17.compareTo((java.lang.Object) year76);
        int int78 = fixedMillisecond1.compareTo((java.lang.Object) year76);
        long long79 = year76.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 100L + "'", long73 == 100L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 100L + "'", long74 == 100L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-31507200000L) + "'", long79 == (-31507200000L));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        timeSeries2.setNotify(false);
        timeSeries2.removeAgedItems(false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        java.lang.Object obj27 = timeSeries26.clone();
        timeSeries26.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries26.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("First");
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        int int6 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        int int8 = year1.getYear();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("First");
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        seriesException10.addSuppressed((java.lang.Throwable) seriesException12);
        boolean boolean14 = year1.equals((java.lang.Object) seriesException12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond18.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        int int45 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond42.getLastMillisecond(calendar46);
        long long48 = fixedMillisecond42.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.SerialDate serialDate51 = serialDate26.getEndOfCurrentMonth(serialDate50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate26);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate26);
        boolean boolean54 = spreadsheetDate1.isOnOrAfter(serialDate53);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getSerialIndex();
        long long23 = fixedMillisecond15.getSerialIndex();
        java.util.Date date24 = fixedMillisecond15.getEnd();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("First");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getSerialIndex();
        long long23 = fixedMillisecond15.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) day26);
        int int29 = spreadsheetDate1.toSerial();
        java.util.Date date30 = spreadsheetDate1.toDate();
        int int31 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int25 = day24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.next();
        int int28 = day24.getDayOfMonth();
        long long29 = day24.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 31 + "'", int28 == 31);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28799999L + "'", long29 == 28799999L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getMiddleMillisecond();
        int int24 = fixedMillisecond15.compareTo((java.lang.Object) 4);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond15.getMiddleMillisecond(calendar25);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("");
        timeSeries4.setRangeDescription("2019");
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class30);
        java.lang.Object obj32 = timeSeries31.clone();
        timeSeries31.setNotify(true);
        timeSeries31.fireSeriesChanged();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 2);
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 2);
        int int54 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond51.getLastMillisecond(calendar55);
        long long57 = fixedMillisecond51.getFirstMillisecond();
        java.util.Date date58 = fixedMillisecond51.getEnd();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date58);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 2);
        java.lang.Class class72 = null;
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 2);
        int int78 = timeSeries64.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
        java.util.Calendar calendar79 = null;
        long long80 = fixedMillisecond75.getLastMillisecond(calendar79);
        long long81 = fixedMillisecond75.getFirstMillisecond();
        java.util.Date date82 = fixedMillisecond75.getEnd();
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date82);
        org.jfree.data.time.SerialDate serialDate84 = serialDate59.getEndOfCurrentMonth(serialDate83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate84);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day85, (double) 2019);
        int int89 = day85.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = day85.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day85);
        java.lang.Number number93 = timeSeries4.getValue(0);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 100L + "'", long81 == 100L);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNull(timeSeriesDataItem87);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeSeriesDataItem91);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 2 + "'", number93.equals(2));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        int int9 = timeSeries4.getMaximumItemCount();
        timeSeries4.setMaximumItemAge(0L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day58.previous();
        java.lang.Class<?> wildcardClass62 = day58.getClass();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1572591599999L);
        long long65 = timeSeries64.getMaximumItemAge();
        boolean boolean66 = day58.equals((java.lang.Object) long65);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 9223372036854775807L + "'", long65 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Class<?> wildcardClass22 = date21.getClass();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
        serialDate23.setDescription("");
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        java.util.List list6 = timeSeries4.getItems();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.lang.Number number23 = timeSeriesDataItem22.getValue();
        java.lang.Object obj24 = timeSeriesDataItem22.clone();
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeriesDataItem22.equals(obj25);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1) + "'", number23.equals((-1)));
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: Sunday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-57600000L));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        int int62 = day58.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day58.next();
        java.util.Calendar calendar64 = null;
        try {
            day58.peg(calendar64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        int int50 = day49.getDayOfMonth();
        long long51 = day49.getFirstMillisecond();
        int int52 = day49.getDayOfMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-57600000L) + "'", long51 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        long long45 = fixedMillisecond39.getFirstMillisecond();
        java.util.Date date46 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate23.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        java.lang.String str50 = day49.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-1969" + "'", str50.equals("31-December-1969"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "January");
        int int26 = year23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year23.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, year23);
        long long29 = month28.getLastMillisecond();
        java.lang.String str30 = month28.toString();
        org.jfree.data.time.Year year31 = month28.getYear();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries34.removeChangeListener(seriesChangeListener35);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener37);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (java.lang.Number) 2);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (java.lang.Number) 2);
        int int57 = timeSeries43.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries34.addAndOrUpdate(timeSeries43);
        timeSeries34.fireSeriesChanged();
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 2);
        long long69 = timeSeries64.getMaximumItemAge();
        java.util.Collection collection70 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries64);
        int int71 = month28.compareTo((java.lang.Object) collection70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (-1.0d));
        java.util.Calendar calendar75 = null;
        try {
            month28.peg(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1572591599999L + "'", long29 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "October 2019" + "'", str30.equals("October 2019"));
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 9223372036854775807L + "'", long69 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries5);
        long long11 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str12 = fixedMillisecond1.toString();
        long long13 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str12.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("First");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 13);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        try {
            timeSeries4.delete((-447), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -447");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.String str5 = timeSeries2.getRangeDescription();
        java.util.List list6 = timeSeries2.getItems();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) "January");
        int int12 = year9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, year9);
        long long15 = month14.getLastMillisecond();
        java.lang.String str16 = month14.toString();
        org.jfree.data.time.Year year17 = month14.getYear();
        int int19 = year17.compareTo((java.lang.Object) 1.0f);
        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year17);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year17.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1572591599999L + "'", long15 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "October 2019" + "'", str16.equals("October 2019"));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int19 = year17.compareTo((java.lang.Object) "January");
        int int20 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        long long22 = year17.getFirstMillisecond();
        java.lang.String str23 = year17.toString();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        long long27 = year17.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        java.lang.Object obj6 = timeSeries5.clone();
        try {
            timeSeries5.update((-455), (java.lang.Number) 25568L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        java.lang.String str22 = timeSeries4.getDescription();
        try {
            timeSeries4.delete((int) (short) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        timeSeries2.setDescription("First");
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        long long16 = timeSeries11.getMaximumItemAge();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.lang.Comparable comparable23 = timeSeries11.getKey();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        int int42 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getLastMillisecond(calendar43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) (-1));
        java.lang.Number number47 = timeSeriesDataItem46.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeriesDataItem46.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem46);
        timeSeries11.setKey((java.lang.Comparable) timeSeriesDataItem46);
        try {
            timeSeries2.add(timeSeriesDataItem46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 1.0d + "'", comparable23.equals(1.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (-1) + "'", number47.equals((-1)));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("");
        java.util.Collection collection25 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 2);
        long long37 = timeSeries32.getMaximumItemAge();
        java.util.Collection collection38 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries32.removePropertyChangeListener(propertyChangeListener39);
        long long41 = timeSeries32.getMaximumItemAge();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond15.getMiddleMillisecond(calendar23);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        java.util.Date date6 = year0.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        java.lang.Object obj12 = timeSeries11.clone();
        timeSeries11.setNotify(true);
        timeSeries11.fireSeriesChanged();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        int int34 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond31.getLastMillisecond(calendar35);
        long long37 = fixedMillisecond31.getFirstMillisecond();
        java.util.Date date38 = fixedMillisecond31.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 2);
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 2);
        int int58 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond55.getLastMillisecond(calendar59);
        long long61 = fixedMillisecond55.getFirstMillisecond();
        java.util.Date date62 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        org.jfree.data.time.SerialDate serialDate64 = serialDate39.getEndOfCurrentMonth(serialDate63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(serialDate64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day65, (double) 2019);
        java.lang.String str68 = day65.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day65.next();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day65, (double) 24238L, false);
        long long73 = timeSeries5.getMaximumItemAge();
        try {
            timeSeries5.update((int) (byte) -1, (java.lang.Number) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(comparable6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 100L + "'", long61 == 100L);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "31-December-1969" + "'", str68.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 9223372036854775807L + "'", long73 == 9223372036854775807L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.lang.String str7 = month6.toString();
        long long8 = month6.getSerialIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) "January");
        int int12 = year9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        boolean boolean14 = month6.equals((java.lang.Object) regularTimePeriod13);
        long long15 = month6.getSerialIndex();
        int int16 = month6.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24238L + "'", long8 == 24238L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24238L + "'", long15 == 24238L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getLastMillisecond();
        long long5 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        long long18 = timeSeries13.getMaximumItemAge();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        boolean boolean25 = timeSeries13.getNotify();
        java.util.Collection collection26 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries4.clear();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        java.lang.String str28 = timeSeries2.getDomainDescription();
        java.lang.Object obj29 = timeSeries2.clone();
        try {
            timeSeries2.setMaximumItemAge((long) (-455));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-455));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-455) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        java.lang.String str6 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        java.lang.String str8 = year0.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("");
        timeSeries4.setDomainDescription("October");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        int int31 = year29.compareTo((java.lang.Object) "January");
        int int32 = year29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.previous();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(10, year29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year29.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries36 = timeSeries4.createCopy(regularTimePeriod27, (org.jfree.data.time.RegularTimePeriod) year29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        long long18 = timeSeries13.getMaximumItemAge();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        boolean boolean25 = timeSeries13.getNotify();
        java.util.Collection collection26 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener27);
        long long29 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        java.lang.Object obj12 = timeSeries11.clone();
        timeSeries11.setNotify(true);
        timeSeries11.fireSeriesChanged();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 2);
        int int34 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond31.getLastMillisecond(calendar35);
        long long37 = fixedMillisecond31.getFirstMillisecond();
        java.util.Date date38 = fixedMillisecond31.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 2);
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 2);
        int int58 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond55.getLastMillisecond(calendar59);
        long long61 = fixedMillisecond55.getFirstMillisecond();
        java.util.Date date62 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        org.jfree.data.time.SerialDate serialDate64 = serialDate39.getEndOfCurrentMonth(serialDate63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(serialDate64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day65, (double) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day65.previous();
        java.lang.Class class72 = null;
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 2);
        java.lang.Class class81 = null;
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class81);
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries82.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84, (java.lang.Number) 2);
        int int87 = timeSeries73.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84);
        java.util.Calendar calendar88 = null;
        long long89 = fixedMillisecond84.getLastMillisecond(calendar88);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84, (java.lang.Number) (-1));
        java.lang.Number number92 = timeSeriesDataItem91.getValue();
        java.lang.Object obj93 = timeSeriesDataItem91.clone();
        boolean boolean94 = day65.equals(obj93);
        int int95 = day65.getYear();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day65);
        int int97 = day65.getDayOfMonth();
        java.lang.String str98 = day65.toString();
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 100L + "'", long61 == 100L);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNull(timeSeriesDataItem86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 100L + "'", long89 == 100L);
        org.junit.Assert.assertTrue("'" + number92 + "' != '" + (-1) + "'", number92.equals((-1)));
        org.junit.Assert.assertNotNull(obj93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1969 + "'", int95 == 1969);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 31 + "'", int97 == 31);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "31-December-1969" + "'", str98.equals("31-December-1969"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        int int20 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener21);
        timeSeries4.setDomainDescription("1-January-1970");
        java.lang.String str25 = timeSeries4.getDescription();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 2);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 2);
        int int24 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond21.getLastMillisecond(calendar25);
        long long27 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond21.previous();
        boolean boolean30 = year0.equals((java.lang.Object) fixedMillisecond21);
        long long31 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond15.previous();
        long long23 = fixedMillisecond15.getFirstMillisecond();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond41.getTime();
        java.lang.Class<?> wildcardClass48 = date47.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond15, "org.jfree.data.general.SeriesChangeEvent[source=10]", "31-December-1969", (java.lang.Class) wildcardClass48);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries50.removeChangeListener(seriesChangeListener51);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1310400001L) + "'", long4 == (-1310400001L));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        long long7 = month6.getLastMillisecond();
        int int8 = month6.getMonth();
        org.jfree.data.time.Year year9 = month6.getYear();
        java.util.Date date10 = year9.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        timeSeries2.setNotify(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9999);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        java.lang.Comparable comparable61 = timeSeries4.getKey();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + comparable61 + "' != '" + 1.0d + "'", comparable61.equals(1.0d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source= ]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        java.lang.String str28 = timeSeries2.getDomainDescription();
        java.lang.Object obj29 = timeSeries2.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = null;
        try {
            timeSeries2.add(timeSeriesDataItem30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int4 = year2.compareTo((java.lang.Object) "January");
        int int5 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.previous();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year2.previous();
        long long9 = year2.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(17, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        int int35 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond32.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1));
        java.lang.Number number40 = timeSeriesDataItem39.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem39.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem39);
        timeSeries4.setKey((java.lang.Comparable) timeSeriesDataItem39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem39.getPeriod();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (-1) + "'", number40.equals((-1)));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("First");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.String str11 = seriesException8.toString();
        java.lang.String str12 = seriesException8.toString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str11.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str12.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        java.lang.String str6 = year0.toString();
        java.lang.String str7 = year0.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) day26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean31 = spreadsheetDate1.isBefore(serialDate30);
        int int32 = spreadsheetDate1.getDayOfWeek();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (java.lang.Number) 2);
        int int52 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond49.getLastMillisecond(calendar53);
        long long55 = fixedMillisecond49.getFirstMillisecond();
        java.util.Date date56 = fixedMillisecond49.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (java.lang.Number) 2);
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (java.lang.Number) 2);
        int int76 = timeSeries62.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.util.Calendar calendar77 = null;
        long long78 = fixedMillisecond73.getLastMillisecond(calendar77);
        long long79 = fixedMillisecond73.getFirstMillisecond();
        java.util.Date date80 = fixedMillisecond73.getEnd();
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(date80);
        org.jfree.data.time.SerialDate serialDate82 = serialDate57.getEndOfCurrentMonth(serialDate81);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addMonths(9, serialDate82);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate1.getEndOfCurrentMonth(serialDate83);
        try {
            org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate1.getNearestDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 100L + "'", long78 == 100L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 2);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2);
        int int22 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond19.getLastMillisecond(calendar23);
        long long25 = fixedMillisecond19.getFirstMillisecond();
        java.util.Date date26 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 2);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 2);
        int int46 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond43.getLastMillisecond(calendar47);
        long long49 = fixedMillisecond43.getFirstMillisecond();
        java.util.Date date50 = fixedMillisecond43.getEnd();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
        org.jfree.data.time.SerialDate serialDate52 = serialDate27.getEndOfCurrentMonth(serialDate51);
        java.lang.String str53 = serialDate51.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate51);
        boolean boolean55 = spreadsheetDate2.isOnOrBefore(serialDate54);
        int int56 = spreadsheetDate2.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-1969" + "'", str53.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        timeSeries4.setDomainDescription("January");
        java.lang.String str12 = timeSeries4.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((-447));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January" + "'", str12.equals("January"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int30 = year28.compareTo((java.lang.Object) "January");
        int int31 = year28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year28.previous();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(10, year28);
        long long34 = month33.getLastMillisecond();
        java.lang.String str35 = month33.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date39 = fixedMillisecond38.getEnd();
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class41);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries42.removeChangeListener(seriesChangeListener43);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener45);
        boolean boolean47 = fixedMillisecond38.equals((java.lang.Object) timeSeries42);
        timeSeries42.removeAgedItems(true);
        boolean boolean50 = month33.equals((java.lang.Object) timeSeries42);
        java.util.Collection collection51 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries42);
        int int52 = timeSeries42.getMaximumItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1572591599999L + "'", long34 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "October 2019" + "'", str35.equals("October 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(collection51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2147483647 + "'", int52 == 2147483647);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        int int62 = day58.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day58.next();
        long long64 = day58.getSerialIndex();
        int int65 = day58.getMonth();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 25568L + "'", long64 == 25568L);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 12 + "'", int65 == 12);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        java.lang.Comparable comparable3 = timeSeries2.getKey();
        timeSeries2.setNotify(false);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int10 = year8.compareTo((java.lang.Object) "January");
        int int11 = year8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.previous();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, year8);
        long long14 = month13.getLastMillisecond();
        java.lang.String str15 = month13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month13, (double) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1572591599999L + "'", long14 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 2019" + "'", str15.equals("October 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.String str9 = timeSeries4.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar12 = null;
        fixedMillisecond11.peg(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        timeSeries4.setKey((java.lang.Comparable) fixedMillisecond11);
        try {
            timeSeries4.update((-25556), (java.lang.Number) (-25556));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = serialDate25.getEndOfCurrentMonth(serialDate49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(2, serialDate50);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addDays(0, serialDate52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate53);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) "January");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.next();
        java.lang.String str26 = year22.toString();
        int int27 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        timeSeries4.setRangeDescription("1-January-1970");
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        java.lang.Object obj4 = null;
        int int5 = year0.compareTo(obj4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (-1310400001L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        long long5 = year1.getSerialIndex();
        long long6 = year1.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        timeSeries5.setDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-447), 0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day58);
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 2);
        java.lang.Class class74 = null;
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class74);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) 2);
        int int80 = timeSeries66.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77);
        java.util.Calendar calendar81 = null;
        long long82 = fixedMillisecond77.getLastMillisecond(calendar81);
        long long83 = fixedMillisecond77.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = fixedMillisecond77.previous();
        long long85 = fixedMillisecond77.getFirstMillisecond();
        boolean boolean86 = day58.equals((java.lang.Object) fixedMillisecond77);
        long long87 = day58.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 100L + "'", long82 == 100L);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 100L + "'", long83 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 100L + "'", long85 == 100L);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 28799999L + "'", long87 == 28799999L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (short) -1);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1));
        boolean boolean24 = timeSeriesDataItem22.equals((java.lang.Object) ' ');
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int28 = year26.compareTo((java.lang.Object) "January");
        int int29 = year26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year26.previous();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(10, year26);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getSerialIndex();
        int int34 = month31.getMonth();
        boolean boolean35 = timeSeriesDataItem22.equals((java.lang.Object) int34);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "October 2019" + "'", str32.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24238L + "'", long33 == 24238L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(17, (-455), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries2.getNotify();
        timeSeries2.setDescription("First");
        boolean boolean8 = timeSeries2.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries2.removeChangeListener(seriesChangeListener9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        long long28 = timeSeries2.getMaximumItemAge();
        timeSeries2.setNotify(false);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        long long28 = timeSeries2.getMaximumItemAge();
        java.lang.Comparable comparable29 = timeSeries2.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 2);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 2);
        int int50 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond47.getLastMillisecond(calendar51);
        long long53 = fixedMillisecond47.getFirstMillisecond();
        java.util.Date date54 = fixedMillisecond47.getEnd();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date54, timeZone55);
        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
        boolean boolean58 = spreadsheetDate31.equals((java.lang.Object) day56);
        int int59 = day56.getMonth();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day56, (double) 1572591599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + false + "'", comparable29.equals(false));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 100L + "'", long52 == 100L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 12 + "'", int59 == 12);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int25 = day24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        java.util.Date date27 = day24.getStart();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        timeSeries4.setDomainDescription("January");
        int int12 = timeSeries4.getItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries7.getNextTimePeriod();
        java.util.Date date23 = regularTimePeriod22.getStart();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        boolean boolean25 = spreadsheetDate1.isOnOrAfter(serialDate24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        int int44 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        long long47 = fixedMillisecond41.getFirstMillisecond();
        java.util.Date date48 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        java.lang.Class class53 = null;
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (java.lang.Number) 2);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) 2);
        int int68 = timeSeries54.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
        java.util.Calendar calendar69 = null;
        long long70 = fixedMillisecond65.getLastMillisecond(calendar69);
        long long71 = fixedMillisecond65.getFirstMillisecond();
        java.util.Date date72 = fixedMillisecond65.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72, timeZone73);
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date48, timeZone73);
        try {
            int int76 = spreadsheetDate1.compareTo((java.lang.Object) timeZone73);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: sun.util.calendar.ZoneInfo cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 100L + "'", long71 == 100L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 2);
        int int35 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond32.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1));
        java.lang.Number number40 = timeSeriesDataItem39.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem39.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem39);
        timeSeries4.setKey((java.lang.Comparable) timeSeriesDataItem39);
        java.lang.Class class44 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (-1) + "'", number40.equals((-1)));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(class44);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 2);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 2);
        int int24 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond21.getLastMillisecond(calendar25);
        long long27 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond21.previous();
        boolean boolean30 = year0.equals((java.lang.Object) fixedMillisecond21);
        long long31 = fixedMillisecond21.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) day26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean31 = spreadsheetDate1.isBefore(serialDate30);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 2);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (java.lang.Number) 2);
        int int52 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond49.getLastMillisecond(calendar53);
        long long55 = fixedMillisecond49.getFirstMillisecond();
        java.util.Date date56 = fixedMillisecond49.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (java.lang.Number) 2);
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (java.lang.Number) 2);
        int int76 = timeSeries62.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.util.Calendar calendar77 = null;
        long long78 = fixedMillisecond73.getLastMillisecond(calendar77);
        long long79 = fixedMillisecond73.getFirstMillisecond();
        java.util.Date date80 = fixedMillisecond73.getEnd();
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(date80);
        org.jfree.data.time.SerialDate serialDate82 = serialDate57.getEndOfCurrentMonth(serialDate81);
        java.lang.String str83 = serialDate81.toString();
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate81);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate84);
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate88 = serialDate85.getEndOfCurrentMonth(serialDate87);
        int int89 = spreadsheetDate1.compare(serialDate88);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 100L + "'", long78 == 100L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "31-December-1969" + "'", str83.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-20) + "'", int89 == (-20));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 2);
        int int20 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond17.getLastMillisecond(calendar21);
        long long23 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date24 = fixedMillisecond17.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) day26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean31 = spreadsheetDate1.isBefore(serialDate30);
        int int32 = spreadsheetDate1.getDayOfWeek();
        java.util.Date date33 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate34 = null;
        try {
            boolean boolean35 = spreadsheetDate1.isBefore(serialDate34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond24.getTime();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.lang.String str32 = fixedMillisecond24.toString();
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 2);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) 2);
        int int53 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond50.getLastMillisecond(calendar54);
        java.util.Date date56 = fixedMillisecond50.getTime();
        java.lang.Class<?> wildcardClass57 = date56.getClass();
        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond24, "October 2019", "ERROR : Relative To String", (java.lang.Class) wildcardClass57);
        timeSeries59.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str32.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(class58);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "January");
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year1);
        java.lang.String str7 = month6.toString();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        java.lang.String str58 = serialDate56.toString();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate56);
        int int60 = month6.compareTo((java.lang.Object) serialDate59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month6.next();
        java.util.Date date62 = month6.getEnd();
        org.jfree.data.time.Year year63 = month6.getYear();
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (java.lang.Number) 2);
        java.lang.Class class76 = null;
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class76);
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries77.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79, (java.lang.Number) 2);
        int int82 = timeSeries68.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79);
        int int83 = year63.compareTo((java.lang.Object) fixedMillisecond79);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31-December-1969" + "'", str58.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(year63);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 2);
        int int27 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond24.getFirstMillisecond();
        java.util.Date date31 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getLastMillisecond(calendar52);
        long long54 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date55 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.SerialDate serialDate57 = serialDate32.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day58, (double) 2019);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day58.previous();
        long long63 = day58.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 28799999L + "'", long63 == 28799999L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 2);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 2);
        int int23 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond20.getLastMillisecond(calendar24);
        long long26 = fixedMillisecond20.getFirstMillisecond();
        java.util.Date date27 = fixedMillisecond20.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
        boolean boolean31 = spreadsheetDate4.equals((java.lang.Object) day29);
        boolean boolean32 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 2);
        int int51 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Calendar calendar52 = null;
        fixedMillisecond48.peg(calendar52);
        boolean boolean54 = spreadsheetDate4.equals((java.lang.Object) calendar52);
        try {
            org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (short) 0);
        java.util.Date date7 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        long long18 = timeSeries13.getMaximumItemAge();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        boolean boolean25 = timeSeries21.isEmpty();
        int int26 = year8.compareTo((java.lang.Object) boolean25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        boolean boolean20 = timeSeries4.getNotify();
        java.lang.Comparable comparable21 = timeSeries4.getKey();
        timeSeries4.removeAgedItems(false);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 1.0d + "'", comparable21.equals(1.0d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond15.getEnd();
        long long24 = fixedMillisecond15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 17);
        java.lang.Number number27 = timeSeriesDataItem26.getValue();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 17 + "'", number27.equals(17));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        timeSeries4.setNotify(true);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 2);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 2);
        int int26 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond23.getLastMillisecond(calendar27);
        long long29 = fixedMillisecond23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries4.addOrUpdate(regularTimePeriod30, (java.lang.Number) 9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries4.getNextTimePeriod();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 2);
        int int21 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond18.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond18.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
        boolean boolean29 = spreadsheetDate2.equals((java.lang.Object) day27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean32 = spreadsheetDate2.isBefore(serialDate31);
        int int33 = spreadsheetDate2.getDayOfWeek();
        java.util.Date date34 = spreadsheetDate2.toDate();
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 2);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 2);
        int int55 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        java.util.Calendar calendar56 = null;
        long long57 = fixedMillisecond52.getLastMillisecond(calendar56);
        long long58 = fixedMillisecond52.getFirstMillisecond();
        java.util.Date date59 = fixedMillisecond52.getEnd();
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(date59);
        java.lang.Class class64 = null;
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class64);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries65.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, (java.lang.Number) 2);
        java.lang.Class class73 = null;
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class73);
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, (java.lang.Number) 2);
        int int79 = timeSeries65.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76);
        java.util.Calendar calendar80 = null;
        long long81 = fixedMillisecond76.getLastMillisecond(calendar80);
        long long82 = fixedMillisecond76.getFirstMillisecond();
        java.util.Date date83 = fixedMillisecond76.getEnd();
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.createInstance(date83);
        org.jfree.data.time.SerialDate serialDate85 = serialDate60.getEndOfCurrentMonth(serialDate84);
        java.lang.String str86 = serialDate84.toString();
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate84);
        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate87);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(serialDate88);
        boolean boolean90 = spreadsheetDate2.isOnOrBefore(serialDate88);
        org.jfree.data.time.SerialDate serialDate92 = spreadsheetDate2.getNearestDayOfWeek(6);
        try {
            org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-459), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 100L + "'", long81 == 100L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 100L + "'", long82 == 100L);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "31-December-1969" + "'", str86.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(serialDate92);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond15.getTime();
        long long22 = fixedMillisecond15.getMiddleMillisecond();
        int int24 = fixedMillisecond15.compareTo((java.lang.Object) 4);
        long long25 = fixedMillisecond15.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 2);
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getLastMillisecond(calendar19);
        long long21 = fixedMillisecond15.getFirstMillisecond();
        java.util.Date date22 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int25 = day24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.next();
        int int28 = day24.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (-455));
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day24.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 31 + "'", int28 == 31);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "January");
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        int int6 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class13);
        java.lang.Object obj15 = timeSeries14.clone();
        timeSeries14.setNotify(true);
        timeSeries14.fireSeriesChanged();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 2);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 2);
        int int37 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond34.getLastMillisecond(calendar38);
        long long40 = fixedMillisecond34.getFirstMillisecond();
        java.util.Date date41 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (java.lang.Number) 2);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (java.lang.Number) 2);
        int int61 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58);
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond58.getLastMillisecond(calendar62);
        long long64 = fixedMillisecond58.getFirstMillisecond();
        java.util.Date date65 = fixedMillisecond58.getEnd();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date65);
        org.jfree.data.time.SerialDate serialDate67 = serialDate42.getEndOfCurrentMonth(serialDate66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(serialDate67);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day68, (double) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day68.previous();
        java.lang.Class<?> wildcardClass72 = day68.getClass();
        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass72);
        java.lang.Class class74 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass72);
        java.lang.Class class75 = org.jfree.data.time.RegularTimePeriod.downsize(class74);
        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "November", "Fourth", class74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 100L + "'", long63 == 100L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 100L + "'", long64 == 100L);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(class73);
        org.junit.Assert.assertNotNull(class74);
        org.junit.Assert.assertNotNull(class75);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 2);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2);
        int int25 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries2.addAndOrUpdate(timeSeries11);
        timeSeries2.fireSeriesChanged();
        java.lang.String str28 = timeSeries2.getDomainDescription();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 2);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 2);
        int int47 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeries33.getNextTimePeriod();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries33.removeChangeListener(seriesChangeListener49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        int int53 = year51.compareTo((java.lang.Object) "January");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year51.next();
        java.lang.String str55 = year51.toString();
        int int56 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) year51);
        java.util.Collection collection57 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        int int60 = year58.compareTo((java.lang.Object) "January");
        int int61 = year58.getYear();
        long long62 = year58.getSerialIndex();
        long long63 = year58.getFirstMillisecond();
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (java.lang.Number) 2);
        java.lang.Class class76 = null;
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class76);
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries77.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79, (java.lang.Number) 2);
        int int82 = timeSeries68.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79);
        java.util.Calendar calendar83 = null;
        long long84 = fixedMillisecond79.getLastMillisecond(calendar83);
        long long85 = fixedMillisecond79.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = fixedMillisecond79.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = fixedMillisecond79.previous();
        boolean boolean88 = year58.equals((java.lang.Object) fixedMillisecond79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = year58.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries2.addOrUpdate(regularTimePeriod89, (double) 1569913200000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2019L + "'", long62 == 2019L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1546329600000L + "'", long63 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 100L + "'", long84 == 100L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 100L + "'", long85 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem91);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 2);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2);
        int int22 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond19.getLastMillisecond(calendar23);
        long long25 = fixedMillisecond19.getFirstMillisecond();
        java.util.Date date26 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 2);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "First", class40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 2);
        int int46 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond43.getLastMillisecond(calendar47);
        long long49 = fixedMillisecond43.getFirstMillisecond();
        java.util.Date date50 = fixedMillisecond43.getEnd();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
        org.jfree.data.time.SerialDate serialDate52 = serialDate27.getEndOfCurrentMonth(serialDate51);
        java.lang.String str53 = serialDate51.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate51);
        boolean boolean55 = spreadsheetDate2.isOnOrBefore(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean58 = spreadsheetDate2.isOnOrBefore(serialDate57);
        java.lang.String str59 = serialDate57.getDescription();
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate57);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-1969" + "'", str53.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(serialDate60);
    }
}

