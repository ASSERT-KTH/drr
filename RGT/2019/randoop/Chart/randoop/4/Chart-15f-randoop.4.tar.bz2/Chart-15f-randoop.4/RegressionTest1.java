import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Paint paint5 = valueMarker4.getOutlinePaint();
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker4.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge(3);
        categoryPlot0.mapDatasetToDomainAxis((int) '4', 128);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot0.zoomRangeAxes((double) 128, plotRenderingInfo32, point2D33);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        java.awt.Shape shape5 = dateAxis1.getRightArrow();
        dateAxis1.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        java.awt.Shape shape15 = dateAxis11.getRightArrow();
        dateAxis11.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date19 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double22 = rectangleInsets20.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment24, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement27);
        boolean boolean29 = blockContainer28.isEmpty();
        java.util.List list30 = blockContainer28.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D31 = blockContainer28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets20.createOutsetRectangle(rectangle2D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double34 = dateAxis1.dateToJava2D(date19, rectangle2D31, rectangleEdge33);
        dateAxis1.setLabel("");
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 94.0d + "'", double22 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        xYPlot50.setDataset(xYDataset73);
        int int75 = xYPlot50.getDatasetCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        polarPlot0.handleClick((int) '4', 100, plotRenderingInfo4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot0.setRadiusGridlineStroke(stroke6);
        int int8 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        org.jfree.chart.JFreeChart jFreeChart25 = chartProgressEvent24.getChart();
        int int26 = jFreeChart25.getBackgroundImageAlignment();
        jFreeChart25.fireChartChanged();
        java.lang.Object obj28 = jFreeChart25.clone();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, (double) (-1L), plotRenderingInfo11, point2D12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = java.awt.Color.BLACK;
        int int11 = color10.getRGB();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color10);
        int int13 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot9.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = java.awt.Color.BLACK;
        int int17 = color16.getRGB();
        categoryPlot15.setRangeCrosshairPaint((java.awt.Paint) color16);
        int int19 = categoryPlot15.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot15.getDomainAxisLocation();
        categoryPlot9.setRangeAxisLocation(axisLocation20);
        categoryPlot0.setRangeAxisLocation(axisLocation20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot0.zoomDomainAxes((double) 0, plotRenderingInfo25, point2D26);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16777216) + "'", int11 == (-16777216));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16777216) + "'", int17 == (-16777216));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis4.setInverted(true);
        java.awt.Stroke stroke7 = dateAxis4.getTickMarkStroke();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = java.awt.Color.BLACK;
        int int11 = color10.getRGB();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color10);
        int int13 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot9.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot9.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis20.setInverted(true);
        categoryPlot9.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray30, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray46, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray52);
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset53, true);
        org.jfree.data.Range range56 = org.jfree.data.Range.combine(range39, range55);
        dateAxis20.setRange(range39);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis59.setInverted(true);
        java.awt.Stroke stroke62 = dateAxis59.getTickMarkStroke();
        java.awt.Shape shape63 = dateAxis59.getRightArrow();
        dateAxis59.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date67 = dateAxis59.calculateLowestVisibleTickValue(dateTickUnit66);
        java.util.Date date68 = dateAxis20.calculateLowestVisibleTickValue(dateTickUnit66);
        dateAxis4.setTickUnit(dateTickUnit66, false, false);
        boolean boolean73 = dateAxis4.isHiddenValue((long) (byte) 1);
        java.lang.String str74 = dateAxis4.getLabelURL();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16777216) + "'", int11 == (-16777216));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(dateTickUnit66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(str74);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint6 = polarPlot5.getBackgroundPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 1, paint6, stroke7);
        java.awt.Paint paint9 = valueMarker8.getOutlinePaint();
        float float10 = valueMarker8.getAlpha();
        org.jfree.chart.util.Layer layer11 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer11);
        float float13 = valueMarker8.getAlpha();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 4, 0.05d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
        java.awt.Paint paint5 = polarPlot0.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot0.zoomDomainAxes((double) (short) -1, (double) 10L, plotRenderingInfo8, point2D9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Font font16 = multiplePiePlot14.getNoDataMessageFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean18 = multiplePiePlot14.equals((java.lang.Object) dateTickUnit17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color20 = java.awt.Color.BLACK;
        int int21 = color20.getRGB();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color20);
        int int23 = categoryPlot19.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot19.getOrientation();
        categoryPlot19.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot19.zoomRangeAxes((double) (-1L), (double) (short) -1, plotRenderingInfo29, point2D30);
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray44);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot46 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset45);
        categoryPlot19.setDataset(categoryDataset45);
        multiplePiePlot14.setDataset(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-16777216) + "'", int21 == (-16777216));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.Range range0 = null;
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset30, true);
        org.jfree.data.Range range33 = org.jfree.data.Range.combine(range16, range32);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint(range0, range33);
        org.jfree.data.time.DateRange dateRange35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toRangeHeight((org.jfree.data.Range) dateRange35);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(dateRange35);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        java.awt.Paint paint2 = categoryAxis0.getAxisLinePaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setUpperMargin((double) 1);
        categoryAxis5.clearCategoryLabelToolTips();
        categoryAxis5.setTickLabelsVisible(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis5.setLabelPaint((java.awt.Paint) color11);
        boolean boolean13 = categoryAxis5.isTickLabelsVisible();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20);
        boolean boolean22 = blockContainer21.isEmpty();
        java.util.List list23 = blockContainer21.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D24 = blockContainer21.getBounds();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle26.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = textTitle26.getPosition();
        double double30 = categoryAxis5.getCategoryMiddle(0, (int) (byte) 100, rectangle2D24, rectangleEdge29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setUpperMargin((double) 1);
        categoryAxis31.clearCategoryLabelToolTips();
        categoryAxis31.setTickLabelsVisible(false);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        boolean boolean39 = categoryAxis31.isTickLabelsVisible();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement46 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment42, verticalAlignment43, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement46);
        boolean boolean48 = blockContainer47.isEmpty();
        java.util.List list49 = blockContainer47.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D50 = blockContainer47.getBounds();
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle52.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = textTitle52.getPosition();
        double double56 = categoryAxis31.getCategoryMiddle(0, (int) (byte) 100, rectangle2D50, rectangleEdge55);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color58 = java.awt.Color.BLACK;
        int int59 = color58.getRGB();
        categoryPlot57.setRangeCrosshairPaint((java.awt.Paint) color58);
        int int61 = categoryPlot57.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot57.getDomainAxisLocation();
        double double63 = categoryPlot57.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot57.getRangeAxisEdge(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        try {
            org.jfree.chart.axis.AxisState axisState67 = categoryAxis0.draw(graphics2D3, (double) 1.0f, rectangle2D24, rectangle2D50, rectangleEdge65, plotRenderingInfo66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-16777216) + "'", int59 == (-16777216));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        polarPlot0.setBackgroundAlpha((float) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot0.zoomDomainAxes((double) 3, (double) 100L, plotRenderingInfo8, point2D9);
        java.awt.Stroke stroke11 = polarPlot0.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) shape7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment34, verticalAlignment35, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape41 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement38.add((org.jfree.chart.block.Block) textTitle40, (java.lang.Object) shape41);
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle40);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertNotNull(shape41);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge(3);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot0.getAxisOffset();
        float float29 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color31 = java.awt.Color.BLACK;
        int int32 = color31.getRGB();
        categoryPlot30.setRangeCrosshairPaint((java.awt.Paint) color31);
        int int34 = categoryPlot30.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = categoryPlot30.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot30.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        categoryPlot30.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis41.setInverted(true);
        categoryPlot30.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis45.setUpperMargin((double) 1);
        org.jfree.chart.plot.PolarPlot polarPlot48 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean49 = polarPlot48.isOutlineVisible();
        boolean boolean50 = polarPlot48.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        polarPlot48.setDataset(xYDataset51);
        java.awt.Stroke stroke53 = polarPlot48.getAngleGridlineStroke();
        categoryAxis45.setAxisLineStroke(stroke53);
        dateAxis41.setAxisLineStroke(stroke53);
        categoryPlot0.setDomainGridlineStroke(stroke53);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-16777216) + "'", int32 == (-16777216));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNull(legendItemCollection36);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        categoryAxis0.setUpperMargin(0.0d);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        categoryAxis0.setTickLabelFont(font10);
        categoryAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge(3);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot0.getAxisOffset();
        float float29 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getRangeMarkers(layer10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        org.jfree.chart.JFreeChart jFreeChart25 = chartProgressEvent24.getChart();
        int int26 = jFreeChart25.getBackgroundImageAlignment();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle28.setPadding((double) (byte) -1, (double) (-1), (double) (short) -1, (double) 100L);
        jFreeChart25.removeSubtitle((org.jfree.chart.title.Title) textTitle28);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.chart.axis.ValueAxis valueAxis74 = xYPlot50.getDomainAxis((-16777216));
        xYPlot50.clearRangeMarkers((-1));
        java.awt.Color color77 = java.awt.Color.pink;
        xYPlot50.setRangeCrosshairPaint((java.awt.Paint) color77);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertNull(valueAxis74);
        org.junit.Assert.assertNotNull(color77);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Color color3 = java.awt.Color.getHSBColor(2.0f, (float) (byte) 0, (float) 'a');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        java.awt.Color color2 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        java.awt.Paint paint4 = blockBorder3.getPaint();
        categoryAxis0.setTickLabelPaint(paint4);
        int int6 = categoryAxis0.getCategoryLabelPositionOffset();
        java.lang.String str7 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint19 = polarPlot18.getBackgroundPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1, paint19, stroke20);
        jFreeChart16.setBorderPaint(paint19);
        java.awt.Image image23 = jFreeChart16.getBackgroundImage();
        jFreeChart16.setTitle("LengthConstraintType.FIXED");
        try {
            org.jfree.chart.title.Title title27 = jFreeChart16.getSubtitle(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(image23);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 100L);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color5 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        textTitle4.setBackgroundPaint((java.awt.Paint) color5);
        textTitle4.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke11 = null;
        polarPlot10.setAngleGridlineStroke(stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot10.getInsets();
        boolean boolean14 = textTitle4.equals((java.lang.Object) rectangleInsets13);
        textTitle4.setToolTipText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment17, verticalAlignment18, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement21);
        boolean boolean23 = blockContainer22.isEmpty();
        org.jfree.chart.block.BlockFrame blockFrame24 = blockContainer22.getFrame();
        textTitle4.setFrame(blockFrame24);
        java.lang.Object obj26 = textTitle4.clone();
        boolean boolean27 = rectangleInsets0.equals(obj26);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94.0d + "'", double2 == 94.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis10.setInverted(true);
        dateAxis10.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis10.setRange(0.0d, 10.0d);
        dateAxis10.setPositiveArrowVisible(false);
        dateAxis10.setAutoRangeMinimumSize(8.0d);
        categoryPlot0.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis26.setInverted(true);
        java.awt.Stroke stroke29 = dateAxis26.getTickMarkStroke();
        java.awt.Shape shape30 = dateAxis26.getRightArrow();
        dateAxis26.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date34 = dateAxis26.calculateLowestVisibleTickValue(dateTickUnit33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis36.setInverted(true);
        java.awt.Stroke stroke39 = dateAxis36.getTickMarkStroke();
        java.awt.Shape shape40 = dateAxis36.getRightArrow();
        dateAxis36.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date44 = dateAxis36.calculateLowestVisibleTickValue(dateTickUnit43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double47 = rectangleInsets45.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement52 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment48, verticalAlignment49, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement52);
        boolean boolean54 = blockContainer53.isEmpty();
        java.util.List list55 = blockContainer53.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D56 = blockContainer53.getBounds();
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets45.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double59 = dateAxis26.dateToJava2D(date44, rectangle2D56, rectangleEdge58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        boolean boolean62 = categoryPlot0.render(graphics2D24, rectangle2D56, 0, plotRenderingInfo61);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 94.0d + "'", double47 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (-1L), (double) (short) -1, plotRenderingInfo10, point2D11);
        float float13 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(sortOrder14);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint19 = polarPlot18.getBackgroundPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1, paint19, stroke20);
        jFreeChart16.setBorderPaint(paint19);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        java.awt.Paint paint25 = categoryAxis23.getAxisLinePaint();
        jFreeChart16.setBackgroundPaint(paint25);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.GENERAL", graphics2D1, (float) (byte) 10, (float) (-1L), textAnchor4, (-55.25000000000002d), (float) 8, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.4d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        java.util.List list7 = blockContainer5.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D8 = blockContainer5.getBounds();
        blockContainer5.setWidth(8.0d);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        polarPlot11.setBackgroundImageAlignment(0);
        polarPlot11.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot11);
        java.awt.Font font17 = legendTitle16.getItemFont();
        java.awt.Paint paint18 = legendTitle16.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = legendTitle16.getHorizontalAlignment();
        java.awt.Font font20 = legendTitle16.getItemFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font22 = categoryAxis21.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 100, (double) (short) -1, 10.0d);
        categoryAxis21.setLabelInsets(rectangleInsets27);
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle16, (java.lang.Object) rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Font font5 = valueMarker4.getLabelFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker4.getLabelAnchor();
        java.awt.Paint paint7 = valueMarker4.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 100, (double) (short) -1, 10.0d);
        categoryAxis0.setLabelInsets(rectangleInsets6);
        double double9 = rectangleInsets6.trimHeight((double) 100.0f);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 101.0d + "'", double9 == 101.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (short) 100, "TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isOutlineVisible();
        boolean boolean7 = polarPlot5.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = polarPlot5.getAxis();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot5);
        categoryAxis0.setUpperMargin((double) ' ');
        java.awt.Paint paint13 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        dateAxis1.setVerticalTickLabels(true);
        java.util.Date date11 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("{0}");
        xYPlot50.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis72);
        boolean boolean74 = xYPlot50.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        org.jfree.chart.JFreeChart jFreeChart25 = chartProgressEvent24.getChart();
        chartProgressEvent24.setPercent((int) (byte) 100);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(jFreeChart25);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis19.setInverted(true);
        dateAxis19.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis19.setUpperMargin((double) (byte) 100);
        dateAxis19.setRangeWithMargins((-1.0d), (-1.0d));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer30);
        double double32 = categoryAxis16.getUpperMargin();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot1.setDataset(waferMapDataset6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint5 = polarPlot4.getBackgroundPaint();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 1, paint5, stroke6);
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer8);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset14, false);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset14, 0);
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 35.0d, (org.jfree.data.KeyedValues) pieDataset20);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        boolean boolean51 = xYPlot50.isRangeZoomable();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation52 = null;
        try {
            boolean boolean53 = xYPlot50.removeAnnotation(xYAnnotation52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        java.awt.geom.Point2D point2D73 = null;
        xYPlot50.zoomDomainAxes((double) 175, plotRenderingInfo72, point2D73);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        valueMarker7.notifyListeners(markerChangeEvent8);
        java.lang.String str10 = valueMarker7.getLabel();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.chart.axis.ValueAxis valueAxis74 = xYPlot50.getDomainAxis((-16777216));
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot();
        polarPlot75.setBackgroundImageAlignment(0);
        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis79.setInverted(true);
        java.awt.Stroke stroke82 = dateAxis79.getTickMarkStroke();
        polarPlot75.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis79);
        dateAxis79.setAutoRange(true);
        int int86 = xYPlot50.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis79);
        xYPlot50.setDomainCrosshairVisible(true);
        java.awt.Stroke stroke89 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        xYPlot50.setDomainCrosshairStroke(stroke89);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertNull(valueAxis74);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertNotNull(stroke89);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
        polarPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke7 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setVisible(false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRangeWithMargins((double) (byte) -1, (double) (byte) 0);
        dateAxis1.zoomRange((double) (-165), (double) (byte) -1);
        boolean boolean13 = dateAxis1.isNegativeArrowVisible();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        java.lang.Comparable comparable29 = multiplePiePlot28.getAggregatedItemsKey();
        java.awt.Font font30 = multiplePiePlot28.getNoDataMessageFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean32 = multiplePiePlot28.equals((java.lang.Object) dateTickUnit31);
        java.util.Date date33 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit31);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + "Other" + "'", comparable29.equals("Other"));
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setUpperMargin((double) 1);
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean19 = polarPlot18.isOutlineVisible();
        boolean boolean20 = polarPlot18.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        polarPlot18.setDataset(xYDataset21);
        java.awt.Stroke stroke23 = polarPlot18.getAngleGridlineStroke();
        categoryAxis15.setAxisLineStroke(stroke23);
        dateAxis11.setAxisLineStroke(stroke23);
        java.lang.String str26 = dateAxis11.getLabelToolTip();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("WMAP_Plot", "org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]]", "VerticalAlignment.CENTER", "Other", "LengthConstraintType.NONE");
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge(3);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 10, (int) (byte) 100, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint10 = polarPlot9.getBackgroundPaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 1, paint10, stroke11);
        java.awt.Paint paint13 = valueMarker12.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = valueMarker12.getLabelOffsetType();
        valueMarker7.setLabelOffsetType(lengthAdjustmentType14);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker7.setLabelTextAnchor(textAnchor16);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-16777216), (double) 500);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        java.lang.String str2 = projectInfo0.getName();
        projectInfo0.setVersion("hi!");
        java.awt.Color color5 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        boolean boolean7 = projectInfo0.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart" + "'", str2.equals("JFreeChart"));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot5.getOrientation();
        java.awt.Paint paint11 = categoryPlot5.getRangeGridlinePaint();
        java.awt.Paint paint12 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot5.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation13);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.Range range2 = new org.jfree.data.Range(8.0d, (double) 100.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation((int) (byte) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier5);
        float float7 = polarPlot0.getForegroundAlpha();
        boolean boolean8 = polarPlot0.isRadiusGridlinesVisible();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot23.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot23.getPieChart();
        org.jfree.chart.title.TextTitle textTitle26 = jFreeChart25.getTitle();
        java.lang.Object obj27 = jFreeChart25.getTextAntiAlias();
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean31 = blockBorder29.equals((java.lang.Object) paint30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean34 = verticalAlignment32.equals((java.lang.Object) stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint30, stroke33);
        jFreeChart25.setBorderStroke(stroke33);
        polarPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        polarPlot38.setBackgroundImageAlignment(0);
        polarPlot38.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot38);
        legendTitle43.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = legendTitle43.getLegendItemGraphicAnchor();
        jFreeChart25.removeSubtitle((org.jfree.chart.title.Title) legendTitle43);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = null;
        try {
            jFreeChart25.plotChanged(plotChangeEvent48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNotNull(textTitle26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setNotify(false);
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint19 = polarPlot18.getBackgroundPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1, paint19, stroke20);
        jFreeChart16.setBorderPaint(paint19);
        java.awt.Image image23 = jFreeChart16.getBackgroundImage();
        jFreeChart16.setTitle("LengthConstraintType.FIXED");
        java.lang.Object obj26 = jFreeChart16.clone();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        java.awt.Paint paint17 = jFreeChart16.getBackgroundPaint();
        jFreeChart16.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        xYPlot50.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        xYPlot50.setRangeAxis(valueAxis72);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        textTitle1.setMargin((-55.25000000000002d), 3.0d, 101.0d, (double) (-1));
        org.junit.Assert.assertNotNull(blockFrame4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        xYPlot50.setDataset(xYDataset73);
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean76 = polarPlot75.isOutlineVisible();
        boolean boolean77 = polarPlot75.isSubplot();
        polarPlot75.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation80 = polarPlot75.getOrientation();
        xYPlot50.setOrientation(plotOrientation80);
        java.awt.Paint paint82 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot50.setRangeTickBandPaint(paint82);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(plotOrientation80);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        legendTitle5.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle5.getLegendItemGraphicAnchor();
        org.jfree.chart.block.BlockFrame blockFrame9 = legendTitle5.getFrame();
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(blockFrame9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        xYPlot50.mapDatasetToRangeAxis((int) (byte) -1, 15);
        java.awt.Paint paint54 = xYPlot50.getDomainZeroBaselinePaint();
        int int55 = xYPlot50.getDomainAxisCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRange(0.0d, 10.0d);
        java.lang.Object obj10 = dateAxis1.clone();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint12 = polarPlot11.getBackgroundPaint();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) polarPlot11);
        java.awt.Paint paint14 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        java.awt.Shape shape5 = dateAxis1.getRightArrow();
        double double6 = dateAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean4 = polarPlot3.isOutlineVisible();
        boolean boolean5 = polarPlot3.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        polarPlot3.setDataset(xYDataset6);
        java.awt.Stroke stroke8 = polarPlot3.getAngleGridlineStroke();
        categoryAxis0.setAxisLineStroke(stroke8);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke11 = null;
        polarPlot10.setAngleGridlineStroke(stroke11);
        java.awt.Paint paint13 = polarPlot10.getAngleLabelPaint();
        categoryAxis0.setTickMarkPaint(paint13);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray25, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot33 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = multiplePiePlot33.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot33.getPieChart();
        java.awt.Paint paint36 = jFreeChart35.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor18, jFreeChart35, 3, (-16777216));
        categoryAxis0.setLabelPaint((java.awt.Paint) chartColor18);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.AxisState axisState42 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.Size2D size2D46 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, 0.0d, (double) (short) 100, rectangleAnchor49);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets43.createInsetRectangle(rectangle2D50, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        try {
            java.util.List list55 = categoryAxis0.refreshTicks(graphics2D41, axisState42, rectangle2D53, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(jFreeChart35);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset23, true);
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray32, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, true);
        org.jfree.data.Range range42 = org.jfree.data.Range.combine(range25, range41);
        java.lang.String str43 = range42.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range42);
        dateAxis1.setRangeWithMargins(range42);
        org.jfree.data.Range range47 = org.jfree.data.Range.expandToInclude(range42, 0.4d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Range[-1.0,10.0]" + "'", str43.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertNotNull(range47);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15, true);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset31, true);
        org.jfree.data.Range range34 = org.jfree.data.Range.combine(range17, range33);
        java.lang.String str35 = range34.toString();
        dateAxis1.setRange(range34, false, false);
        float float39 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Range[-1.0,10.0]" + "'", str35.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        polarPlot27.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot27.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        boolean boolean32 = categoryPlot0.equals((java.lang.Object) polarPlot27);
        polarPlot27.removeCornerTextItem("RectangleAnchor.BOTTOM");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement14.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) shape17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment20, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement23.add((org.jfree.chart.block.Block) textTitle25, (java.lang.Object) shape26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement14, (org.jfree.chart.block.Arrangement) flowArrangement23);
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        polarPlot29.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot29.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier32);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = null;
        polarPlot29.setDrawingSupplier(drawingSupplier34);
        float float36 = polarPlot29.getForegroundAlpha();
        boolean boolean37 = polarPlot29.isRadiusGridlinesVisible();
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray44, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray50);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot52 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset51);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = multiplePiePlot52.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart54 = multiplePiePlot52.getPieChart();
        org.jfree.chart.title.TextTitle textTitle55 = jFreeChart54.getTitle();
        java.lang.Object obj56 = jFreeChart54.getTextAntiAlias();
        org.jfree.chart.block.BlockBorder blockBorder58 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean60 = blockBorder58.equals((java.lang.Object) paint59);
        org.jfree.chart.util.VerticalAlignment verticalAlignment61 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke62 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean63 = verticalAlignment61.equals((java.lang.Object) stroke62);
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint59, stroke62);
        jFreeChart54.setBorderStroke(stroke62);
        polarPlot29.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart54);
        org.jfree.chart.plot.PolarPlot polarPlot67 = new org.jfree.chart.plot.PolarPlot();
        polarPlot67.setBackgroundImageAlignment(0);
        polarPlot67.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot67);
        legendTitle72.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = legendTitle72.getLegendItemGraphicAnchor();
        jFreeChart54.removeSubtitle((org.jfree.chart.title.Title) legendTitle72);
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = categoryPlot77.getRenderer((int) (byte) 0);
        categoryPlot77.mapDatasetToDomainAxis(255, 2);
        flowArrangement14.add((org.jfree.chart.block.Block) legendTitle72, (java.lang.Object) categoryPlot77);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(legendItemCollection53);
        org.junit.Assert.assertNotNull(jFreeChart54);
        org.junit.Assert.assertNotNull(textTitle55);
        org.junit.Assert.assertNull(obj56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(verticalAlignment61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNull(categoryItemRenderer79);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        polarPlot27.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot27.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        boolean boolean32 = categoryPlot0.equals((java.lang.Object) polarPlot27);
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint36 = polarPlot35.getBackgroundPaint();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 1, paint36, stroke37);
        java.awt.Paint paint39 = valueMarker38.getOutlinePaint();
        float float40 = valueMarker38.getAlpha();
        org.jfree.chart.util.Layer layer41 = null;
        try {
            boolean boolean42 = categoryPlot0.removeDomainMarker(255, (org.jfree.chart.plot.Marker) valueMarker38, layer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        dateAxis1.setAxisLineVisible(true);
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.pink;
        int int5 = color4.getGreen();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock7.setLineAlignment(horizontalAlignment8);
        java.util.List list10 = textBlock7.getLines();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean12 = textBlock7.equals((java.lang.Object) shape11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textBlock7.getLineAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 175 + "'", int5 == 175);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint7 = polarPlot6.getBackgroundPaint();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("UnitType.RELATIVE", font2, (org.jfree.chart.plot.Plot) polarPlot6, true);
        java.awt.Paint paint10 = jFreeChart9.getBorderPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray14);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = multiplePiePlot16.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart18 = multiplePiePlot16.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint21 = polarPlot20.getBackgroundPaint();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 1, paint21, stroke22);
        jFreeChart18.setBorderPaint(paint21);
        jFreeChart18.setTextAntiAlias(false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent29 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) str1, jFreeChart18, (int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(jFreeChart18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setWidth((double) 100);
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean11 = polarPlot10.isOutlineVisible();
        boolean boolean12 = polarPlot10.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        polarPlot10.setDataset(xYDataset13);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot10.setAngleLabelFont(font15);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.lang.Comparable comparable32 = multiplePiePlot31.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset33 = multiplePiePlot31.getDataset();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font15, (org.jfree.chart.plot.Plot) multiplePiePlot31, true);
        java.awt.Paint paint36 = jFreeChart35.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart35.getLegend((int) (short) 10);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        org.jfree.chart.event.ChartProgressListener chartProgressListener40 = null;
        jFreeChart35.removeProgressListener(chartProgressListener40);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + "Other" + "'", comparable32.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(legendTitle38);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        polarPlot27.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot27.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        boolean boolean32 = categoryPlot0.equals((java.lang.Object) polarPlot27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        try {
            polarPlot27.zoomRangeAxes((double) 8, plotRenderingInfo34, point2D35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        double double3 = piePlotState1.getLatestAngle();
        double double4 = piePlotState1.getPieCenterX();
        org.jfree.chart.entity.EntityCollection entityCollection5 = piePlotState1.getEntityCollection();
        piePlotState1.setTotal((double) ' ');
        int int8 = piePlotState1.getPassesRequired();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(entityCollection5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        try {
            org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        polarPlot0.removeCornerTextItem("TextBlockAnchor.TOP_RIGHT");
        java.awt.Paint paint5 = polarPlot0.getAngleGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, true);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray22, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset29, true);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range15, range31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("Range[-1.0,10.0]");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat37 = standardPieSectionLabelGenerator36.getPercentFormat();
        java.text.NumberFormat numberFormat38 = standardPieSectionLabelGenerator36.getNumberFormat();
        numberAxis34.setNumberFormatOverride(numberFormat38);
        numberAxis34.setAutoRangeStickyZero(true);
        java.awt.Shape shape42 = numberAxis34.getRightArrow();
        boolean boolean43 = range32.equals((java.lang.Object) shape42);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(numberFormat37);
        org.junit.Assert.assertNotNull(numberFormat38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setRightArrow(shape15);
        double double17 = dateAxis11.getLowerBound();
        java.lang.Object obj18 = dateAxis11.clone();
        java.awt.Shape shape19 = dateAxis11.getUpArrow();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis23.setInverted(true);
        dateAxis23.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis23.setUpperMargin((double) (byte) 100);
        dateAxis23.setRangeWithMargins((-1.0d), (-1.0d));
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double37 = rectangleInsets35.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment38, verticalAlignment39, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer43 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement42);
        boolean boolean44 = blockContainer43.isEmpty();
        java.util.List list45 = blockContainer43.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D46 = blockContainer43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets35.createOutsetRectangle(rectangle2D46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str49 = rectangleEdge48.toString();
        double double50 = dateAxis23.valueToJava2D((double) 100.0f, rectangle2D47, rectangleEdge48);
        try {
            double double51 = dateAxis11.java2DToValue(1.0d, rectangle2D21, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 94.0d + "'", double37 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "RectangleEdge.TOP" + "'", str49.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.NEGATIVE_INFINITY + "'", double50 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier5);
        float float7 = polarPlot0.getForegroundAlpha();
        boolean boolean8 = polarPlot0.isRadiusGridlinesVisible();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot23.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot23.getPieChart();
        org.jfree.chart.title.TextTitle textTitle26 = jFreeChart25.getTitle();
        java.lang.Object obj27 = jFreeChart25.getTextAntiAlias();
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean31 = blockBorder29.equals((java.lang.Object) paint30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean34 = verticalAlignment32.equals((java.lang.Object) stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint30, stroke33);
        jFreeChart25.setBorderStroke(stroke33);
        polarPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        polarPlot38.setBackgroundImageAlignment(0);
        polarPlot38.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot38);
        legendTitle43.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = legendTitle43.getLegendItemGraphicAnchor();
        jFreeChart25.removeSubtitle((org.jfree.chart.title.Title) legendTitle43);
        legendTitle43.setMargin(0.2d, 45.0d, 4.5d, (-100.0d));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNotNull(textTitle26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation();
        java.util.List list9 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        float float13 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.handleClick(100, 0, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset23);
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10.0d + "'", number26.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (-1.0d) + "'", number27.equals((-1.0d)));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent73 = null;
        xYPlot50.datasetChanged(datasetChangeEvent73);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedHeight();
        org.jfree.data.Range range5 = rectangleConstraint3.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Paint paint5 = valueMarker4.getOutlinePaint();
        float float6 = valueMarker4.getAlpha();
        java.awt.Stroke stroke7 = valueMarker4.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        xYPlot50.setDataset(xYDataset73);
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean76 = polarPlot75.isOutlineVisible();
        boolean boolean77 = polarPlot75.isSubplot();
        polarPlot75.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation80 = polarPlot75.getOrientation();
        xYPlot50.setOrientation(plotOrientation80);
        org.jfree.data.xy.XYDataset xYDataset82 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer83 = xYPlot50.getRendererForDataset(xYDataset82);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(plotOrientation80);
        org.junit.Assert.assertNull(xYItemRenderer83);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = chartChangeEvent33.getType();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        boolean boolean6 = textLine4.equals((java.lang.Object) 0);
        org.jfree.chart.text.TextFragment textFragment7 = null;
        textLine4.removeFragment(textFragment7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            textLine4.draw(graphics2D9, (float) 'a', (float) (byte) 10, textAnchor12, (float) 128, (float) 2, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterX();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis10.setInverted(true);
        dateAxis10.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis10.setRange(0.0d, 10.0d);
        dateAxis10.setPositiveArrowVisible(false);
        dateAxis10.setAutoRangeMinimumSize(8.0d);
        categoryPlot0.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot0.getRangeAxisEdge((-16777216));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = categoryAxis0.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis0.getCategoryMiddle((int) (byte) 10, 0, rectangle2D11, rectangleEdge12);
        categoryAxis0.setTickMarkOutsideLength((float) 1);
        categoryAxis0.setTickMarkInsideLength(100.0f);
        java.awt.Paint paint18 = categoryAxis0.getLabelPaint();
        categoryAxis0.setUpperMargin((double) 192);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo6, point2D7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setRightArrow(shape15);
        dateAxis11.setLabelURL("");
        dateAxis11.configure();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        polarPlot1.setBackgroundImageAlignment(0);
        polarPlot1.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot1);
        java.awt.Font font7 = legendTitle6.getItemFont();
        java.awt.Paint paint8 = legendTitle6.getBackgroundPaint();
        java.awt.Paint paint9 = legendTitle6.getBackgroundPaint();
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Font font13 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color14 = java.awt.Color.pink;
        int int15 = color14.getGreen();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("hi!", font13, (java.awt.Paint) color14);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, (java.awt.Paint) color14);
        columnArrangement0.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) textBlock17);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 175 + "'", int15 == 175);
        org.junit.Assert.assertNotNull(textBlock17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        boolean boolean26 = categoryPlot0.isRangeCrosshairVisible();
        int int27 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Font font2 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis3D0.removeChangeListener(axisChangeListener3);
        categoryAxis3D0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Range[-1.0,10.0]");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getPercentFormat();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator3.getNumberFormat();
        numberAxis1.setNumberFormatOverride(numberFormat5);
        org.jfree.data.RangeType rangeType7 = null;
        try {
            numberAxis1.setRangeType(rangeType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getRGB();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("{0}");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset17, true);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range19, range35);
        java.lang.String str37 = range36.toString();
        dateAxis3.setRange(range36, false, false);
        boolean boolean41 = color0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16777216) + "'", int1 == (-16777216));
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Range[-1.0,10.0]" + "'", str37.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, true);
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray37, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset44, true);
        org.jfree.data.Range range47 = org.jfree.data.Range.combine(range30, range46);
        dateAxis11.setRange(range30);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis50.setInverted(true);
        java.awt.Stroke stroke53 = dateAxis50.getTickMarkStroke();
        java.awt.Shape shape54 = dateAxis50.getRightArrow();
        dateAxis50.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date58 = dateAxis50.calculateLowestVisibleTickValue(dateTickUnit57);
        java.util.Date date59 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit57);
        boolean boolean60 = dateAxis11.isTickMarksVisible();
        dateAxis11.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        dateAxis1.setRangeWithMargins((-1.0d), (-1.0d));
        dateAxis1.resizeRange((double) 100.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = xYPlot50.getDomainMarkers(layer51);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("{0}");
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray67 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] { numberArray62, numberArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray68);
        org.jfree.data.Range range71 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset69, true);
        java.lang.Number[] numberArray78 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray84 = new java.lang.Number[][] { numberArray78, numberArray83 };
        org.jfree.data.category.CategoryDataset categoryDataset85 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray84);
        org.jfree.data.Range range87 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset85, true);
        org.jfree.data.Range range88 = org.jfree.data.Range.combine(range71, range87);
        dateAxis55.setRange(range88);
        xYPlot50.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) dateAxis55);
        org.jfree.chart.LegendItemCollection legendItemCollection91 = xYPlot50.getLegendItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertNotNull(numberArray78);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray84);
        org.junit.Assert.assertNotNull(categoryDataset85);
        org.junit.Assert.assertNotNull(range87);
        org.junit.Assert.assertNotNull(range88);
        org.junit.Assert.assertNotNull(legendItemCollection91);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        double double3 = piePlotState1.getLatestAngle();
        double double4 = piePlotState1.getPieCenterX();
        org.jfree.chart.entity.EntityCollection entityCollection5 = piePlotState1.getEntityCollection();
        piePlotState1.setTotal((double) ' ');
        piePlotState1.setPieCenterX(0.0d);
        piePlotState1.setPieCenterX(35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(entityCollection5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleEdge.TOP");
        java.awt.Paint paint2 = textFragment1.getPaint();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textFragment1.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str4 = jFreeChartResources0.getString("PieSection: 97, 100(100)");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key PieSection: 97, 100(100)");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        boolean boolean5 = jFreeChartResources0.containsKey("org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]]");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.lang.Object obj2 = standardPieSectionLabelGenerator0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = java.awt.Color.BLACK;
        int int5 = color4.getRGB();
        categoryPlot3.setRangeCrosshairPaint((java.awt.Paint) color4);
        int int7 = categoryPlot3.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot3.getOrientation();
        categoryPlot3.clearDomainMarkers((int) (byte) 1);
        boolean boolean11 = standardPieSectionLabelGenerator0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        try {
            java.text.AttributedString attributedString14 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset12, (java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-16777216) + "'", int5 == (-16777216));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        boolean boolean5 = textTitle1.getNotify();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray12, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = multiplePiePlot20.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart22 = multiplePiePlot20.getPieChart();
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart22.getTitle();
        boolean boolean24 = jFreeChart22.isNotify();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(jFreeChart22);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        org.jfree.chart.JFreeChart jFreeChart25 = chartProgressEvent24.getChart();
        int int26 = jFreeChart25.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 0.0d, (double) (short) 100, rectangleAnchor34);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createInsetRectangle(rectangle2D35, false, false);
        try {
            jFreeChart25.draw(graphics2D27, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D38);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.chart.axis.ValueAxis valueAxis74 = xYPlot50.getDomainAxis((-16777216));
        xYPlot50.clearRangeMarkers((-1));
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = xYPlot50.getDomainAxisEdge((int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertNull(valueAxis74);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("{0}");
        xYPlot50.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis72);
        xYPlot50.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis77.setInverted(true);
        dateAxis77.setTickMarksVisible(false);
        dateAxis77.setAutoTickUnitSelection(false);
        xYPlot50.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis77);
        xYPlot50.clearRangeMarkers();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
        java.awt.Stroke stroke5 = polarPlot0.getAngleGridlineStroke();
        org.jfree.chart.axis.TickUnit tickUnit6 = polarPlot0.getAngleTickUnit();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        int int12 = categoryPlot8.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot8.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot8.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis19.setInverted(true);
        dateAxis19.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis19.setUpperMargin((double) (byte) 100);
        dateAxis19.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot8.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color33 = java.awt.Color.BLACK;
        int int34 = color33.getRGB();
        categoryPlot32.setRangeCrosshairPaint((java.awt.Paint) color33);
        int int36 = categoryPlot32.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = categoryPlot32.getOrientation();
        categoryPlot32.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis42.setInverted(true);
        dateAxis42.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis42.setRange(0.0d, 10.0d);
        dateAxis42.setPositiveArrowVisible(false);
        dateAxis42.setAutoRangeMinimumSize(8.0d);
        categoryPlot32.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis42);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer56);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color59 = java.awt.Color.BLACK;
        int int60 = color59.getRGB();
        categoryPlot58.setRangeCrosshairPaint((java.awt.Paint) color59);
        int int62 = categoryPlot58.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = categoryPlot58.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection64 = categoryPlot58.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot58.setFixedRangeAxisSpace(axisSpace65);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis69.setInverted(true);
        categoryPlot58.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis69);
        java.awt.Shape shape73 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis69.setRightArrow(shape73);
        dateAxis69.setLabelURL("");
        int int77 = xYPlot57.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis69);
        xYPlot57.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer80 = null;
        java.util.Collection collection81 = categoryPlot79.getRangeMarkers(layer80);
        java.awt.Color color82 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder83 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color82);
        java.awt.Paint paint84 = blockBorder83.getPaint();
        categoryPlot79.setRangeCrosshairPaint(paint84);
        xYPlot57.setDomainZeroBaselinePaint(paint84);
        boolean boolean87 = polarPlot0.equals((java.lang.Object) paint84);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(tickUnit6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-16777216) + "'", int34 == (-16777216));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-16777216) + "'", int60 == (-16777216));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertNull(legendItemCollection64);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNull(collection81);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, true);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray22, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset29, true);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range15, range31);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset46, true);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray61 = new java.lang.Number[][] { numberArray55, numberArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray61);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset62, true);
        org.jfree.data.Range range65 = org.jfree.data.Range.combine(range48, range64);
        java.lang.String str66 = range48.toString();
        org.jfree.data.Range range69 = org.jfree.data.Range.expand(range48, 0.0d, 0.2d);
        org.jfree.data.Range range70 = org.jfree.data.Range.combine(range15, range48);
        double double72 = range48.constrain((double) 35.0f);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Range[-1.0,10.0]" + "'", str66.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 10.0d + "'", double72 == 10.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color4 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        textTitle3.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = null;
        polarPlot9.setAngleGridlineStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot9.getInsets();
        boolean boolean13 = textTitle3.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets12);
        java.awt.Paint paint15 = lineBorder14.getPaint();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean5 = verticalAlignment3.equals((java.lang.Object) stroke4);
        categoryAxis3D2.setTickMarkStroke(stroke4);
        dateAxis1.setAxisLineStroke(stroke4);
        double double8 = dateAxis1.getUpperBound();
        dateAxis1.setTickMarkInsideLength((float) (byte) 1);
        java.text.DateFormat dateFormat11 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(dateFormat11);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        java.awt.Paint paint27 = jFreeChart26.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart26.getLegend();
        jFreeChart26.clearSubtitles();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(legendTitle28);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, 0.0d, (double) (short) 100, rectangleAnchor11);
        try {
            categoryPlot0.drawBackground(graphics2D5, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes(100.0d, (double) (short) 10, plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot0.setRenderer(4, categoryItemRenderer15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        polarPlot0.setRenderer(polarItemRenderer3);
        java.lang.String str5 = polarPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Polar Plot" + "'", str5.equals("Polar Plot"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        xYPlot50.clearDomainMarkers((int) ' ');
        int int73 = xYPlot50.getRangeAxisCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, true);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset13, false);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 0);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset13, false);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, (-1.0d));
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer((int) (short) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color4 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        textTitle3.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = null;
        polarPlot9.setAngleGridlineStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot9.getInsets();
        boolean boolean13 = textTitle3.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets12);
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color17 = java.awt.Color.BLACK;
        int int18 = color17.getRGB();
        categoryPlot16.setRangeCrosshairPaint((java.awt.Paint) color17);
        int int20 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot16.getOrientation();
        java.awt.Paint paint22 = categoryPlot16.getRangeGridlinePaint();
        java.awt.Paint paint23 = categoryPlot16.getRangeGridlinePaint();
        boolean boolean24 = lineBorder14.equals((java.lang.Object) categoryPlot16);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16777216) + "'", int18 == (-16777216));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart16.getTitle();
        java.lang.Object obj18 = jFreeChart16.getTextAntiAlias();
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean22 = blockBorder20.equals((java.lang.Object) paint21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean25 = verticalAlignment23.equals((java.lang.Object) stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint21, stroke24);
        jFreeChart16.setBorderStroke(stroke24);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color30 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace31 = color30.getColorSpace();
        textTitle29.setBackgroundPaint((java.awt.Paint) color30);
        textTitle29.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke36 = null;
        polarPlot35.setAngleGridlineStroke(stroke36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = polarPlot35.getInsets();
        boolean boolean39 = textTitle29.equals((java.lang.Object) rectangleInsets38);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        try {
            java.awt.image.BufferedImage bufferedImage46 = jFreeChart16.createBufferedImage(1, 0, 3.0d, (double) (-16777216), chartRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (short) 100, "TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isOutlineVisible();
        boolean boolean7 = polarPlot5.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = polarPlot5.getAxis();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot5);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        polarPlot10.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        polarPlot10.setDrawingSupplier(drawingSupplier15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        java.awt.Color color19 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        java.awt.Paint paint21 = blockBorder20.getPaint();
        categoryAxis17.setTickLabelPaint(paint21);
        polarPlot10.setAngleLabelPaint(paint21);
        polarPlot5.setRadiusGridlinePaint(paint21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Font font3 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 10);
        categoryAxis3D1.setVisible(true);
        java.awt.Font font7 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (-1L));
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        polarPlot8.setBackgroundImageAlignment(0);
        polarPlot8.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        java.awt.Font font14 = legendTitle13.getItemFont();
        java.awt.Paint paint15 = legendTitle13.getBackgroundPaint();
        java.awt.Paint paint16 = legendTitle13.getItemPaint();
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("WMAP_Plot", font7, paint16);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = java.awt.Color.BLACK;
        int int4 = color3.getRGB();
        categoryPlot2.setRangeCrosshairPaint((java.awt.Paint) color3);
        int int6 = categoryPlot2.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot2.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot2.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis13.setInverted(true);
        dateAxis13.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis13.setUpperMargin((double) (byte) 100);
        dateAxis13.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot2.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color27 = java.awt.Color.BLACK;
        int int28 = color27.getRGB();
        categoryPlot26.setRangeCrosshairPaint((java.awt.Paint) color27);
        int int30 = categoryPlot26.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = categoryPlot26.getOrientation();
        categoryPlot26.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis36.setInverted(true);
        dateAxis36.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis36.setRange(0.0d, 10.0d);
        dateAxis36.setPositiveArrowVisible(false);
        dateAxis36.setAutoRangeMinimumSize(8.0d);
        categoryPlot26.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis36);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer50);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color53 = java.awt.Color.BLACK;
        int int54 = color53.getRGB();
        categoryPlot52.setRangeCrosshairPaint((java.awt.Paint) color53);
        int int56 = categoryPlot52.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = categoryPlot52.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot52.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot52.setFixedRangeAxisSpace(axisSpace59);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis63.setInverted(true);
        categoryPlot52.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis63);
        java.awt.Shape shape67 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis63.setRightArrow(shape67);
        dateAxis63.setLabelURL("");
        int int71 = xYPlot51.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis63);
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("{0}");
        xYPlot51.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis73);
        boolean boolean75 = verticalAlignment0.equals((java.lang.Object) xYPlot51);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-16777216) + "'", int28 == (-16777216));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-16777216) + "'", int54 == (-16777216));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNull(legendItemCollection58);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        xYPlot50.setDataset(xYDataset73);
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean76 = polarPlot75.isOutlineVisible();
        boolean boolean77 = polarPlot75.isSubplot();
        polarPlot75.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation80 = polarPlot75.getOrientation();
        xYPlot50.setOrientation(plotOrientation80);
        java.awt.Paint paint82 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot50.setDomainCrosshairPaint(paint82);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(plotOrientation80);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Stroke stroke2 = categoryAxis3D1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.awt.Color color4 = chartColor3.darker();
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        valueMarker7.setValue(0.2d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        org.jfree.chart.JFreeChart jFreeChart25 = chartProgressEvent24.getChart();
        int int26 = chartProgressEvent24.getPercent();
        chartProgressEvent24.setPercent((int) (byte) 10);
        int int29 = chartProgressEvent24.getPercent();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("{0}");
        xYPlot50.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis72);
        int int74 = xYPlot50.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation75 = xYPlot50.getRangeAxisLocation();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis77 = xYPlot50.getRangeAxisForDataset((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRange(0.0d, 10.0d);
        java.lang.Object obj10 = dateAxis1.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setUpperMargin((double) 1);
        categoryAxis11.clearCategoryLabelToolTips();
        categoryAxis11.setTickLabelsVisible(false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis11.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis11.getTickLabelInsets();
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets19, paint20);
        double double22 = rectangleInsets19.getRight();
        dateAxis1.setLabelInsets(rectangleInsets19);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        xYPlot50.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer73 = null;
        java.util.Collection collection74 = categoryPlot72.getRangeMarkers(layer73);
        java.awt.Color color75 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder76 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color75);
        java.awt.Paint paint77 = blockBorder76.getPaint();
        categoryPlot72.setRangeCrosshairPaint(paint77);
        xYPlot50.setDomainZeroBaselinePaint(paint77);
        xYPlot50.setDomainCrosshairValue((double) 0L, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(paint77);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n" + "'", str1.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n"));
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.pink;
        int int5 = color4.getGreen();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock7.setLineAlignment(horizontalAlignment8);
        java.util.List list10 = textBlock7.getLines();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        try {
            textBlock7.draw(graphics2D11, 35.0f, 2.0f, textBlockAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 175 + "'", int5 == 175);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setRangeWithMargins((double) 10L, (double) 10.0f);
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, (int) 'a', 100, (java.lang.Comparable) 100L, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "{0}");
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, true);
        org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset28, 1);
        pieSectionEntity14.setDataset(pieDataset32);
        boolean boolean34 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset32);
        org.jfree.data.general.PieDataset pieDataset37 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset32, (java.lang.Comparable) ' ', (double) (-1L));
        double double38 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset37);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(pieDataset32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(pieDataset37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 11.0d + "'", double38 == 11.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        java.awt.Paint paint27 = jFreeChart26.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart26.getLegend((int) (short) 10);
        int int30 = jFreeChart26.getBackgroundImageAlignment();
        java.lang.Object obj31 = jFreeChart26.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(legendTitle29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        dateAxis11.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis11.setUpperMargin((double) (byte) 100);
        dateAxis11.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis11, false);
        try {
            dateAxis11.setRangeWithMargins((double) (byte) 100, (-7.95d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-7.95).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = jFreeChart26.getPadding();
        java.awt.Stroke stroke28 = jFreeChart26.getBorderStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge(3);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle29.setToolTipText("");
        java.awt.Paint paint32 = textTitle29.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color34 = java.awt.Color.BLACK;
        int int35 = color34.getRGB();
        categoryPlot33.setRangeCrosshairPaint((java.awt.Paint) color34);
        int int37 = categoryPlot33.getRangeAxisCount();
        boolean boolean38 = textTitle29.equals((java.lang.Object) categoryPlot33);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot33.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder39);
        java.awt.Paint paint41 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-16777216) + "'", int35 == (-16777216));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.chart.axis.ValueAxis valueAxis74 = xYPlot50.getDomainAxis((-16777216));
        xYPlot50.clearRangeMarkers((-1));
        org.jfree.chart.axis.AxisLocation axisLocation77 = xYPlot50.getDomainAxisLocation();
        boolean boolean78 = xYPlot50.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertNull(valueAxis74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        java.awt.Color color11 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        java.awt.Paint paint13 = blockBorder12.getPaint();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        textTitle1.setMargin((double) '#', (double) (short) -1, (double) (byte) 100, (double) 8);
        java.awt.Paint paint20 = textTitle1.getPaint();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.Object obj0 = null;
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.pink;
        int int5 = color4.getGreen();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint8 = polarPlot7.getBackgroundPaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("UnitType.RELATIVE", font3, (org.jfree.chart.plot.Plot) polarPlot7, true);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 175 + "'", int5 == 175);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 100, 0.0f, (float) 15);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis4.setInverted(true);
        java.awt.Stroke stroke7 = dateAxis4.getTickMarkStroke();
        java.awt.Shape shape8 = dateAxis4.getRightArrow();
        dateAxis4.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date12 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis14.setInverted(true);
        java.awt.Stroke stroke17 = dateAxis14.getTickMarkStroke();
        java.awt.Shape shape18 = dateAxis14.getRightArrow();
        dateAxis14.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date22 = dateAxis14.calculateLowestVisibleTickValue(dateTickUnit21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double25 = rectangleInsets23.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment26, verticalAlignment27, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement30);
        boolean boolean32 = blockContainer31.isEmpty();
        java.util.List list33 = blockContainer31.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer31.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets23.createOutsetRectangle(rectangle2D34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double37 = dateAxis4.dateToJava2D(date22, rectangle2D34, rectangleEdge36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.PiePlotState piePlotState39 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo38);
        piePlotState39.setPieCenterY((double) 1.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo42);
        org.jfree.chart.entity.EntityCollection entityCollection44 = piePlotState43.getEntityCollection();
        double double45 = piePlotState43.getLatestAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.Size2D size2D49 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, 0.0d, (double) (short) 100, rectangleAnchor52);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets46.createInsetRectangle(rectangle2D53, false, false);
        piePlotState43.setLinkArea(rectangle2D53);
        piePlotState39.setPieArea(rectangle2D53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] { numberArray66, numberArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray72);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset73, true);
        org.jfree.data.general.PieDataset pieDataset77 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset73, 1);
        boolean boolean78 = rectangleAnchor59.equals((java.lang.Object) 1);
        java.awt.geom.Point2D point2D79 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor59);
        org.jfree.chart.plot.PlotState plotState80 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D34, point2D79, plotState80, plotRenderingInfo81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 94.0d + "'", double25 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNull(entityCollection44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(pieDataset77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(point2D79);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge(4);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 100, (double) (short) -1, 10.0d);
        categoryAxis10.setLabelInsets(rectangleInsets16);
        java.util.List list18 = categoryPlot0.getCategoriesForAxis(categoryAxis10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        xYPlot50.setDataset(xYDataset73);
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean76 = polarPlot75.isOutlineVisible();
        boolean boolean77 = polarPlot75.isSubplot();
        polarPlot75.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation80 = polarPlot75.getOrientation();
        xYPlot50.setOrientation(plotOrientation80);
        xYPlot50.setDomainCrosshairValue((-1.0d));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(plotOrientation80);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset16 = multiplePiePlot14.getDataset();
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset16);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 20.0d + "'", number17.equals(20.0d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        java.lang.String str3 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels(Double.NEGATIVE_INFINITY, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        double double15 = multiplePiePlot14.getLimit();
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean17 = polarPlot16.isOutlineVisible();
        boolean boolean18 = polarPlot16.isSubplot();
        polarPlot16.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = polarPlot16.getOrientation();
        boolean boolean22 = multiplePiePlot14.equals((java.lang.Object) plotOrientation21);
        multiplePiePlot14.setLimit((double) 10L);
        multiplePiePlot14.setLimit((double) 35.0f);
        java.lang.Comparable comparable27 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Paint paint28 = multiplePiePlot14.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + "Other" + "'", comparable27.equals("Other"));
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        java.awt.Paint paint11 = textTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle1.arrange(graphics2D12, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, true);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray22, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset29, true);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range15, range31);
        org.jfree.data.Range range34 = org.jfree.data.Range.expandToInclude(range15, (double) (-1.0f));
        boolean boolean37 = range15.intersects((double) 100L, 90.0d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        java.util.Iterator iterator16 = legendItemCollection15.iterator();
        java.lang.Object obj17 = legendItemCollection15.clone();
        java.util.Iterator iterator18 = legendItemCollection15.iterator();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(iterator16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(iterator18);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Other");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        dateAxis11.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis11.setUpperMargin((double) (byte) 100);
        dateAxis11.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis11, false);
        dateAxis11.centerRange(0.0d);
        java.text.DateFormat dateFormat26 = null;
        dateAxis11.setDateFormatOverride(dateFormat26);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis0.getTickLabelInsets();
        float float9 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = java.awt.Color.BLACK;
        int int12 = color11.getRGB();
        categoryPlot10.setRangeCrosshairPaint((java.awt.Paint) color11);
        int int14 = categoryPlot10.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot10.getOrientation();
        java.awt.Paint paint16 = categoryPlot10.getRangeGridlinePaint();
        java.awt.Paint paint17 = categoryPlot10.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot10.getDomainAxisLocation();
        java.util.List list19 = categoryPlot10.getCategories();
        double double20 = categoryPlot10.getRangeCrosshairValue();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis23.addCategoryLabelToolTip((java.lang.Comparable) (short) 100, "TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean29 = polarPlot28.isOutlineVisible();
        boolean boolean30 = polarPlot28.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = polarPlot28.getAxis();
        categoryAxis23.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot28);
        float float33 = categoryAxis23.getTickMarkInsideLength();
        categoryPlot10.setDomainAxis(4, categoryAxis23, false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16777216) + "'", int12 == (-16777216));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setTickMarksVisible(false);
        dateAxis1.setAutoTickUnitSelection(false);
        boolean boolean8 = dateAxis1.isVisible();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot23.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot23.getPieChart();
        org.jfree.chart.title.TextTitle textTitle26 = jFreeChart25.getTitle();
        java.lang.Object obj27 = jFreeChart25.getTextAntiAlias();
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean31 = blockBorder29.equals((java.lang.Object) paint30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean34 = verticalAlignment32.equals((java.lang.Object) stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint30, stroke33);
        jFreeChart25.setBorderStroke(stroke33);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean8, jFreeChart25);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNotNull(textTitle26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot5.getDomainAxis();
        categoryPlot5.setOutlineVisible(true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        categoryAxis3D0.setLabelAngle((double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        java.lang.String str3 = licences0.getLGPL();
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        xYPlot50.clearDomainMarkers((int) ' ');
        xYPlot50.setDomainCrosshairVisible(false);
        org.jfree.data.general.DatasetGroup datasetGroup75 = xYPlot50.getDatasetGroup();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(datasetGroup75);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        xYPlot50.clearRangeAxes();
        int int72 = xYPlot50.getDomainAxisCount();
        org.jfree.chart.plot.PolarPlot polarPlot73 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean74 = polarPlot73.isOutlineVisible();
        boolean boolean75 = polarPlot73.isSubplot();
        polarPlot73.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation78 = polarPlot73.getOrientation();
        xYPlot50.setOrientation(plotOrientation78);
        java.awt.Stroke stroke80 = xYPlot50.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(plotOrientation78);
        org.junit.Assert.assertNotNull(stroke80);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (double) '4', 0.0d, 0.05d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot0.zoomDomainAxes((double) (-1), (double) 100.0f, plotRenderingInfo7, point2D8);
        polarPlot0.setAngleGridlinesVisible(false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.pink;
        int int7 = color6.getGreen();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font3, (java.awt.Paint) color6);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean13 = verticalAlignment11.equals((java.lang.Object) stroke12);
        categoryAxis3D10.setTickMarkStroke(stroke12);
        java.awt.Paint paint15 = categoryAxis3D10.getLabelPaint();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[-1.0,10.0]", font3, paint15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis18.setInverted(true);
        java.awt.Stroke stroke21 = dateAxis18.getTickMarkStroke();
        java.awt.Shape shape22 = dateAxis18.getRightArrow();
        dateAxis18.setUpperMargin((double) 255);
        java.lang.String str25 = dateAxis18.getLabel();
        java.awt.Font font27 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color28 = java.awt.Color.pink;
        int int29 = color28.getGreen();
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("hi!", font27, (java.awt.Paint) color28);
        int int31 = color28.getGreen();
        dateAxis18.setLabelPaint((java.awt.Paint) color28);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer35 = new org.jfree.chart.text.G2TextMeasurer(graphics2D34);
        try {
            org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font3, (java.awt.Paint) color28, (float) (byte) 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 175 + "'", int7 == 175);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0}" + "'", str25.equals("{0}"));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 175 + "'", int29 == 175);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 175 + "'", int31 == 175);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (short) 100, "TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isOutlineVisible();
        boolean boolean7 = polarPlot5.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = polarPlot5.getAxis();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot5);
        categoryAxis0.setUpperMargin((double) ' ');
        java.lang.Object obj12 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Range[-1.0,10.0]");
        numberAxis1.setAutoRangeMinimumSize((double) 15);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ChartChangeEventType.GENERAL", (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        boolean boolean51 = xYPlot50.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        xYPlot50.setFixedRangeAxisSpace(axisSpace52);
        xYPlot50.clearDomainMarkers();
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean58 = blockBorder56.equals((java.lang.Object) paint57);
        org.jfree.chart.util.VerticalAlignment verticalAlignment59 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean61 = verticalAlignment59.equals((java.lang.Object) stroke60);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint57, stroke60);
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint65 = polarPlot64.getBackgroundPaint();
        java.awt.Stroke stroke66 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker((double) 1, paint65, stroke66);
        java.awt.Paint paint68 = valueMarker67.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType69 = valueMarker67.getLabelOffsetType();
        valueMarker62.setLabelOffsetType(lengthAdjustmentType69);
        try {
            boolean boolean71 = xYPlot50.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(verticalAlignment59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(lengthAdjustmentType69);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setTickMarksVisible(false);
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        jFreeChart21.removeLegend();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.PiePlotState piePlotState37 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo36);
        org.jfree.chart.entity.EntityCollection entityCollection38 = piePlotState37.getEntityCollection();
        double double39 = piePlotState37.getLatestAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.Size2D size2D43 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, 0.0d, (double) (short) 100, rectangleAnchor46);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets40.createInsetRectangle(rectangle2D47, false, false);
        piePlotState37.setLinkArea(rectangle2D47);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = null;
        try {
            jFreeChart21.draw(graphics2D35, rectangle2D47, chartRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertNull(entityCollection38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = xYPlot50.getDomainMarkers(layer51);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("{0}");
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray67 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] { numberArray62, numberArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray68);
        org.jfree.data.Range range71 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset69, true);
        java.lang.Number[] numberArray78 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray84 = new java.lang.Number[][] { numberArray78, numberArray83 };
        org.jfree.data.category.CategoryDataset categoryDataset85 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray84);
        org.jfree.data.Range range87 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset85, true);
        org.jfree.data.Range range88 = org.jfree.data.Range.combine(range71, range87);
        dateAxis55.setRange(range88);
        xYPlot50.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) dateAxis55);
        dateAxis55.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertNotNull(numberArray78);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray84);
        org.junit.Assert.assertNotNull(categoryDataset85);
        org.junit.Assert.assertNotNull(range87);
        org.junit.Assert.assertNotNull(range88);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        xYPlot50.setRangeCrosshairValue(4.0d, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint12 = polarPlot11.getBackgroundPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 1, paint12, stroke13);
        java.awt.Paint paint15 = valueMarker14.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = valueMarker14.getLabelOffsetType();
        org.jfree.chart.util.Layer layer17 = null;
        categoryPlot0.addRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker14, layer17);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]]");
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        int int12 = categoryPlot8.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation();
        double double14 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot8.removeChangeListener(plotChangeListener15);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset31);
        categoryPlot8.setDataset(0, categoryDataset31);
        valueMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        valueMarker7.setValue(0.2d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setRangeWithMargins((double) 10L, (double) 10.0f);
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, (int) 'a', 100, (java.lang.Comparable) 100L, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "{0}");
        java.lang.Object obj15 = pieSectionEntity14.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis17.setInverted(true);
        dateAxis17.setRangeWithMargins((double) 10L, (double) 10.0f);
        java.awt.Shape shape23 = dateAxis17.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape23, pieDataset24, (int) 'a', 100, (java.lang.Comparable) 100L, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "{0}");
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray37, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset44, true);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset44, 1);
        pieSectionEntity30.setDataset(pieDataset48);
        boolean boolean50 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset48);
        pieSectionEntity14.setDataset(pieDataset48);
        java.lang.Object obj52 = pieSectionEntity14.clone();
        java.lang.String str53 = pieSectionEntity14.getShapeCoords();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0,0,-2,-2,-2,2,-2,2" + "'", str53.equals("0,0,-2,-2,-2,2,-2,2"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis19.setInverted(true);
        dateAxis19.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis19.setUpperMargin((double) (byte) 100);
        dateAxis19.setRangeWithMargins((-1.0d), (-1.0d));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot31.getDomainAxisForDataset((int) 'a');
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(categoryAxis33);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Range[-1.0,10.0]");
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel((int) '#', attributedString3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle1.getPosition();
        textTitle1.setText("LengthConstraintType.NONE");
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "", "hi!");
        projectInfo0.addLibrary(library5);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(1, axisLocation11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean14 = polarPlot13.isOutlineVisible();
        boolean boolean15 = polarPlot13.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot13.setDataset(xYDataset16);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot13.setAngleLabelFont(font18);
        categoryPlot0.setNoDataMessageFont(font18);
        int int21 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setUpperMargin((double) 1);
        categoryAxis23.clearCategoryLabelToolTips();
        categoryAxis23.setTickLabelsVisible(false);
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis23);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.TOP_RIGHT", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "ThreadContext", "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = java.awt.Color.yellow;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color6, (float) 100L, (-165), textMeasurer9);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Font font14 = categoryAxis3D12.getTickLabelFont((java.lang.Comparable) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = java.awt.Color.BLACK;
        int int17 = color16.getRGB();
        categoryPlot15.setRangeCrosshairPaint((java.awt.Paint) color16);
        int int19 = categoryPlot15.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = categoryPlot15.getOrientation();
        java.awt.Paint paint21 = categoryPlot15.getRangeGridlinePaint();
        java.awt.Paint paint22 = categoryPlot15.getRangeGridlinePaint();
        textBlock10.addLine("", font14, paint22);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo24.setInfo("Range[-1.0,10.0]");
        java.lang.String str27 = basicProjectInfo24.getVersion();
        org.jfree.chart.ui.ProjectInfo projectInfo28 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str29 = projectInfo28.getCopyright();
        java.util.List list30 = projectInfo28.getContributors();
        basicProjectInfo24.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo28);
        org.jfree.chart.ui.Library[] libraryArray32 = basicProjectInfo24.getOptionalLibraries();
        boolean boolean33 = textBlock10.equals((java.lang.Object) basicProjectInfo24);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16777216) + "'", int17 == (-16777216));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(projectInfo28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str29.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(libraryArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        java.lang.Object obj3 = size2D2.clone();
        double double4 = size2D2.width;
        size2D2.setHeight((double) (short) 1);
        size2D2.width = 0.0d;
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 45.0d + "'", double4 == 45.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis10.setInverted(true);
        dateAxis10.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis10.setRange(0.0d, 10.0d);
        dateAxis10.setPositiveArrowVisible(false);
        dateAxis10.setAutoRangeMinimumSize(8.0d);
        categoryPlot0.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperBound(10.0d);
        dateAxis10.setUpperBound(45.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        boolean boolean51 = xYPlot50.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot50.getRangeAxis();
        java.awt.Paint paint53 = xYPlot50.getRangeCrosshairPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder54 = null;
        try {
            xYPlot50.setSeriesRenderingOrder(seriesRenderingOrder54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(valueAxis52);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        boolean boolean5 = textTitle1.getNotify();
        java.awt.Paint paint6 = textTitle1.getPaint();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setUpperMargin((double) 1);
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis10.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis10.isTickLabelsVisible();
        boolean boolean19 = textFragment8.equals((java.lang.Object) categoryAxis10);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis10.setTickMarkStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo24);
        double double26 = piePlotState25.getPieHRadius();
        double double27 = piePlotState25.getLatestAngle();
        double double28 = piePlotState25.getPieCenterX();
        double double29 = piePlotState25.getPieCenterX();
        piePlotState25.setPieCenterY(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis33.setInverted(true);
        dateAxis33.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis33.setUpperMargin((double) (byte) 100);
        dateAxis33.setRangeWithMargins((-1.0d), (-1.0d));
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double47 = rectangleInsets45.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement52 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment48, verticalAlignment49, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement52);
        boolean boolean54 = blockContainer53.isEmpty();
        java.util.List list55 = blockContainer53.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D56 = blockContainer53.getBounds();
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets45.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str59 = rectangleEdge58.toString();
        double double60 = dateAxis33.valueToJava2D((double) 100.0f, rectangle2D57, rectangleEdge58);
        piePlotState25.setLinkArea(rectangle2D57);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        double double63 = categoryAxis10.getCategoryEnd(0, 0, rectangle2D57, rectangleEdge62);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 94.0d + "'", double47 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "RectangleEdge.TOP" + "'", str59.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.NEGATIVE_INFINITY + "'", double60 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Font font6 = legendTitle5.getItemFont();
        java.awt.Paint paint7 = legendTitle5.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = legendTitle5.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D15 = legendTitle5.arrange(graphics2D9, rectangleConstraint12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double18 = rectangleInsets16.trimWidth((double) 100L);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets16);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 94.0d + "'", double18 == 94.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setTickMarksVisible(false);
        dateAxis1.setAutoTickUnitSelection(false);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        java.awt.Font font24 = multiplePiePlot22.getNoDataMessageFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean26 = multiplePiePlot22.equals((java.lang.Object) dateTickUnit25);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit25);
        double double28 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        java.lang.String str34 = chartChangeEventType32.toString();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor36 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        java.lang.String str37 = pieLabelDistributor36.toString();
        java.lang.String str38 = pieLabelDistributor36.toString();
        boolean boolean39 = chartChangeEventType32.equals((java.lang.Object) pieLabelDistributor36);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str34.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color2 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        textTitle1.setNotify(false);
        boolean boolean7 = textTitle1.getExpandToFitSpace();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        double double10 = piePlot3D9.getDepthFactor();
        java.awt.Paint paint11 = piePlot3D9.getBaseSectionOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis13.setInverted(true);
        java.awt.Stroke stroke16 = dateAxis13.getTickMarkStroke();
        java.awt.Shape shape17 = dateAxis13.getRightArrow();
        dateAxis13.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date21 = dateAxis13.calculateLowestVisibleTickValue(dateTickUnit20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis23.setInverted(true);
        java.awt.Stroke stroke26 = dateAxis23.getTickMarkStroke();
        java.awt.Shape shape27 = dateAxis23.getRightArrow();
        dateAxis23.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date31 = dateAxis23.calculateLowestVisibleTickValue(dateTickUnit30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double34 = rectangleInsets32.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement39 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment35, verticalAlignment36, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement39);
        boolean boolean41 = blockContainer40.isEmpty();
        java.util.List list42 = blockContainer40.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D43 = blockContainer40.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets32.createOutsetRectangle(rectangle2D43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double46 = dateAxis13.dateToJava2D(date31, rectangle2D43, rectangleEdge45);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis47.setUpperMargin((double) 1);
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean51 = polarPlot50.isOutlineVisible();
        boolean boolean52 = polarPlot50.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        polarPlot50.setDataset(xYDataset53);
        java.awt.Stroke stroke55 = polarPlot50.getAngleGridlineStroke();
        categoryAxis47.setAxisLineStroke(stroke55);
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke58 = null;
        polarPlot57.setAngleGridlineStroke(stroke58);
        java.awt.Paint paint60 = polarPlot57.getAngleLabelPaint();
        categoryAxis47.setTickMarkPaint(paint60);
        piePlot3D9.setSectionOutlinePaint((java.lang.Comparable) double46, paint60);
        textTitle1.setBackgroundPaint(paint60);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12d + "'", double10 == 0.12d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 94.0d + "'", double34 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        double double3 = piePlotState1.getLatestAngle();
        double double4 = piePlotState1.getPieCenterX();
        double double5 = piePlotState1.getPieCenterX();
        piePlotState1.setPieCenterY(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis9.setInverted(true);
        dateAxis9.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis9.setUpperMargin((double) (byte) 100);
        dateAxis9.setRangeWithMargins((-1.0d), (-1.0d));
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double23 = rectangleInsets21.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement28 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment24, verticalAlignment25, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement28);
        boolean boolean30 = blockContainer29.isEmpty();
        java.util.List list31 = blockContainer29.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D32 = blockContainer29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets21.createOutsetRectangle(rectangle2D32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str35 = rectangleEdge34.toString();
        double double36 = dateAxis9.valueToJava2D((double) 100.0f, rectangle2D33, rectangleEdge34);
        piePlotState1.setLinkArea(rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D38 = piePlotState1.getPieArea();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 94.0d + "'", double23 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleEdge.TOP" + "'", str35.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.NEGATIVE_INFINITY + "'", double36 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNull(rectangle2D38);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15, true);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, 1);
        piePlot3D1.setDataset(pieDataset19);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(pieDataset19);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = blockContainer13.isEmpty();
        org.jfree.chart.block.BlockFrame blockFrame15 = blockContainer13.getFrame();
        double double16 = blockContainer13.getContentXOffset();
        legendTitle5.setWrapper(blockContainer13);
        org.jfree.chart.block.BlockContainer blockContainer18 = null;
        legendTitle5.setWrapper(blockContainer18);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = java.awt.Color.BLACK;
        int int9 = color8.getRGB();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color8);
        int int11 = categoryPlot7.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot7.getDomainAxisLocation();
        double double13 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot7.removeChangeListener(plotChangeListener14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset30);
        categoryPlot7.setDataset(0, categoryDataset30);
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot7.getDomainAxisLocation(2);
        categoryPlot7.clearDomainMarkers(0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777216) + "'", int9 == (-16777216));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        java.awt.Paint paint3 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis5.setInverted(true);
        java.awt.Stroke stroke8 = dateAxis5.getTickMarkStroke();
        java.awt.Shape shape9 = dateAxis5.getRightArrow();
        dateAxis5.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date13 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis15.setInverted(true);
        java.awt.Stroke stroke18 = dateAxis15.getTickMarkStroke();
        java.awt.Shape shape19 = dateAxis15.getRightArrow();
        dateAxis15.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date23 = dateAxis15.calculateLowestVisibleTickValue(dateTickUnit22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment28, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement31);
        boolean boolean33 = blockContainer32.isEmpty();
        java.util.List list34 = blockContainer32.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D35 = blockContainer32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets24.createOutsetRectangle(rectangle2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double38 = dateAxis5.dateToJava2D(date23, rectangle2D35, rectangleEdge37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setUpperMargin((double) 1);
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean43 = polarPlot42.isOutlineVisible();
        boolean boolean44 = polarPlot42.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        polarPlot42.setDataset(xYDataset45);
        java.awt.Stroke stroke47 = polarPlot42.getAngleGridlineStroke();
        categoryAxis39.setAxisLineStroke(stroke47);
        org.jfree.chart.plot.PolarPlot polarPlot49 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke50 = null;
        polarPlot49.setAngleGridlineStroke(stroke50);
        java.awt.Paint paint52 = polarPlot49.getAngleLabelPaint();
        categoryAxis39.setTickMarkPaint(paint52);
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) double38, paint52);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor55 = piePlot3D1.getLabelDistributor();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = piePlot3D1.getLabelPadding();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 94.0d + "'", double26 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot0.setRenderer(categoryItemRenderer13, false);
        java.lang.Object obj16 = categoryPlot0.clone();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean20 = blockBorder18.equals((java.lang.Object) paint19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean23 = verticalAlignment21.equals((java.lang.Object) stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint19, stroke22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot25.getDomainAxisLocation();
        double double31 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot25.removeChangeListener(plotChangeListener32);
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray41, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray47);
        boolean boolean49 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset48);
        categoryPlot25.setDataset(0, categoryDataset48);
        valueMarker24.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot25);
        try {
            boolean boolean52 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setUpperMargin((double) 1);
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis10.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis10.isTickLabelsVisible();
        boolean boolean19 = textFragment8.equals((java.lang.Object) categoryAxis10);
        int int20 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray35);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset36);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = multiplePiePlot37.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart39 = multiplePiePlot37.getPieChart();
        org.jfree.chart.title.TextTitle textTitle40 = jFreeChart39.getTitle();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle40.setBackgroundPaint((java.awt.Paint) color41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot();
        polarPlot44.setBackgroundImageAlignment(0);
        polarPlot44.setBackgroundAlpha((float) 0);
        polarPlot44.clearCornerTextItems();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis52.setInverted(true);
        java.awt.Stroke stroke55 = dateAxis52.getTickMarkStroke();
        java.awt.Shape shape56 = dateAxis52.getRightArrow();
        dateAxis52.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit59 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date60 = dateAxis52.calculateLowestVisibleTickValue(dateTickUnit59);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        java.awt.Stroke stroke65 = dateAxis62.getTickMarkStroke();
        java.awt.Shape shape66 = dateAxis62.getRightArrow();
        dateAxis62.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit69 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date70 = dateAxis62.calculateLowestVisibleTickValue(dateTickUnit69);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double73 = rectangleInsets71.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment74 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment75 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement78 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment74, verticalAlignment75, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer79 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement78);
        boolean boolean80 = blockContainer79.isEmpty();
        java.util.List list81 = blockContainer79.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D82 = blockContainer79.getBounds();
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets71.createOutsetRectangle(rectangle2D82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double85 = dateAxis52.dateToJava2D(date70, rectangle2D82, rectangleEdge84);
        java.awt.geom.Point2D point2D86 = null;
        org.jfree.chart.plot.PlotState plotState87 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        polarPlot44.draw(graphics2D50, rectangle2D82, point2D86, plotState87, plotRenderingInfo88);
        textTitle40.draw(graphics2D43, rectangle2D82);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = null;
        java.util.List list92 = categoryAxis10.refreshTicks(graphics2D21, axisState22, rectangle2D82, rectangleEdge91);
        java.awt.Paint paint93 = categoryAxis10.getTickLabelPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertNotNull(jFreeChart39);
        org.junit.Assert.assertNotNull(textTitle40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(dateTickUnit59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(dateTickUnit69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 94.0d + "'", double73 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(list92);
        org.junit.Assert.assertNotNull(paint93);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean9 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Paint paint10 = categoryPlot0.getRangeCrosshairPaint();
        try {
            categoryPlot0.mapDatasetToDomainAxis((-16777216), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 3.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle2.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle2.getPosition();
        try {
            double double6 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        java.lang.Comparable comparable27 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        polarPlot28.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        multiplePiePlot22.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        java.lang.Object obj34 = null;
        boolean boolean35 = defaultDrawingSupplier31.equals(obj34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + "Other" + "'", comparable27.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator2);
        piePlot3D1.setStartAngle(35.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        boolean boolean51 = xYPlot50.isRangeZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation52 = xYPlot50.getOrientation();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(plotOrientation52);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.awt.Color color3 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        categoryPlot0.setRangeCrosshairPaint(paint5);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, true);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, true);
        categoryPlot0.setDataset(15, categoryDataset21);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart16.getTitle();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle17.setBackgroundPaint((java.awt.Paint) color18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        polarPlot21.setBackgroundImageAlignment(0);
        polarPlot21.setBackgroundAlpha((float) 0);
        polarPlot21.clearCornerTextItems();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis29.setInverted(true);
        java.awt.Stroke stroke32 = dateAxis29.getTickMarkStroke();
        java.awt.Shape shape33 = dateAxis29.getRightArrow();
        dateAxis29.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date37 = dateAxis29.calculateLowestVisibleTickValue(dateTickUnit36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis39.setInverted(true);
        java.awt.Stroke stroke42 = dateAxis39.getTickMarkStroke();
        java.awt.Shape shape43 = dateAxis39.getRightArrow();
        dateAxis39.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date47 = dateAxis39.calculateLowestVisibleTickValue(dateTickUnit46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double50 = rectangleInsets48.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment51 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment52 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement55 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment51, verticalAlignment52, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer56 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement55);
        boolean boolean57 = blockContainer56.isEmpty();
        java.util.List list58 = blockContainer56.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D59 = blockContainer56.getBounds();
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets48.createOutsetRectangle(rectangle2D59);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double62 = dateAxis29.dateToJava2D(date47, rectangle2D59, rectangleEdge61);
        java.awt.geom.Point2D point2D63 = null;
        org.jfree.chart.plot.PlotState plotState64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        polarPlot21.draw(graphics2D27, rectangle2D59, point2D63, plotState64, plotRenderingInfo65);
        textTitle17.draw(graphics2D20, rectangle2D59);
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle17.getBounds();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 94.0d + "'", double50 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Range[-1.0,10.0]");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getPercentFormat();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator3.getNumberFormat();
        numberAxis1.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit7);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(numberTickUnit7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        dateAxis1.setFixedAutoRange((double) 255);
        java.awt.Font font11 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        java.awt.Color color2 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        java.awt.Paint paint4 = blockBorder3.getPaint();
        categoryAxis0.setTickLabelPaint(paint4);
        int int6 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setUpperMargin((double) (short) 100);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color12 = java.awt.Color.BLACK;
        int int13 = color12.getRGB();
        categoryPlot11.setRangeCrosshairPaint((java.awt.Paint) color12);
        int int15 = categoryPlot11.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot11.getDomainAxisLocation();
        double double17 = categoryPlot11.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot11.getRenderer((int) (short) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot11.getDomainAxisEdge();
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray33);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot35 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = multiplePiePlot35.getLegendItems();
        java.util.Iterator iterator37 = legendItemCollection36.iterator();
        java.lang.Object obj38 = legendItemCollection36.clone();
        categoryPlot11.setFixedLegendItems(legendItemCollection36);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color42 = java.awt.Color.BLACK;
        int int43 = color42.getRGB();
        categoryPlot41.setRangeCrosshairPaint((java.awt.Paint) color42);
        int int45 = categoryPlot41.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot41.getDomainAxisLocation();
        double double47 = categoryPlot41.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener48 = null;
        categoryPlot41.removeChangeListener(plotChangeListener48);
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray63 = new java.lang.Number[][] { numberArray57, numberArray62 };
        org.jfree.data.category.CategoryDataset categoryDataset64 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray63);
        boolean boolean65 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset64);
        categoryPlot41.setDataset(0, categoryDataset64);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot41.getDomainAxisEdge(3);
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace70 = categoryAxis0.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D40, rectangleEdge68, axisSpace69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-16777216) + "'", int13 == (-16777216));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(iterator37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-16777216) + "'", int43 == (-16777216));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(categoryDataset64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean3 = polarPlot2.isOutlineVisible();
        boolean boolean4 = polarPlot2.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        polarPlot2.setDataset(xYDataset5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot2.setAngleLabelFont(font7);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset22);
        java.lang.Comparable comparable24 = multiplePiePlot23.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset25 = multiplePiePlot23.getDataset();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7, (org.jfree.chart.plot.Plot) multiplePiePlot23, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = jFreeChart27.getPadding();
        boolean boolean29 = textBlockAnchor0.equals((java.lang.Object) jFreeChart27);
        java.lang.Object obj30 = jFreeChart27.getTextAntiAlias();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + "Other" + "'", comparable24.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(obj30);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        xYPlot50.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer73 = null;
        java.util.Collection collection74 = categoryPlot72.getRangeMarkers(layer73);
        java.awt.Color color75 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder76 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color75);
        java.awt.Paint paint77 = blockBorder76.getPaint();
        categoryPlot72.setRangeCrosshairPaint(paint77);
        xYPlot50.setDomainZeroBaselinePaint(paint77);
        org.jfree.chart.axis.ValueAxis valueAxis80 = xYPlot50.getRangeAxis();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNull(valueAxis80);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.pink;
        int int5 = color4.getGreen();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint8 = polarPlot7.getBackgroundPaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("UnitType.RELATIVE", font3, (org.jfree.chart.plot.Plot) polarPlot7, true);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("Rotation.CLOCKWISE", font3);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 175 + "'", int5 == 175);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = java.awt.Color.BLACK;
        int int9 = color8.getRGB();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color8);
        int int11 = categoryPlot7.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot7.getDomainAxisLocation();
        double double13 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot7.removeChangeListener(plotChangeListener14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset30);
        categoryPlot7.setDataset(0, categoryDataset30);
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot7.getDomainAxisLocation(2);
        boolean boolean36 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Font font40 = categoryAxis3D38.getTickLabelFont((java.lang.Comparable) 10);
        categoryAxis3D38.setVisible(true);
        java.awt.Font font44 = categoryAxis3D38.getTickLabelFont((java.lang.Comparable) (-1L));
        java.awt.Paint paint45 = categoryAxis3D38.getTickMarkPaint();
        categoryPlot7.setDomainAxis(1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D38);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777216) + "'", int9 == (-16777216));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        categoryAxis3D0.setUpperMargin((double) 35.0f);
        int int4 = categoryAxis3D0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("{0}");
        xYPlot50.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis72);
        xYPlot50.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis77.setInverted(true);
        dateAxis77.setTickMarksVisible(false);
        dateAxis77.setAutoTickUnitSelection(false);
        xYPlot50.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis77);
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double87 = rectangleInsets85.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment88 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment89 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement92 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment88, verticalAlignment89, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer93 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement92);
        boolean boolean94 = blockContainer93.isEmpty();
        java.util.List list95 = blockContainer93.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D96 = blockContainer93.getBounds();
        java.awt.geom.Rectangle2D rectangle2D97 = rectangleInsets85.createOutsetRectangle(rectangle2D96);
        dateAxis77.setDownArrow((java.awt.Shape) rectangle2D97);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 94.0d + "'", double87 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertNotNull(list95);
        org.junit.Assert.assertNotNull(rectangle2D96);
        org.junit.Assert.assertNotNull(rectangle2D97);
    }
}

