import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { 1L, (short) 0, (short) 100, (short) 0 };
        double[] doubleArray10 = new double[] { 10.0d, 1.0f, ' ', 0.0d };
        double[] doubleArray15 = new double[] { 10.0d, 1.0f, ' ', 0.0d };
        double[] doubleArray20 = new double[] { 10.0d, 1.0f, ' ', 0.0d };
        double[] doubleArray25 = new double[] { 10.0d, 1.0f, ' ', 0.0d };
        double[] doubleArray30 = new double[] { 10.0d, 1.0f, ' ', 0.0d };
        double[] doubleArray35 = new double[] { 10.0d, 1.0f, ' ', 0.0d };
        double[][] doubleArray36 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray5, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'columnKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = null;
        try {
            polarPlot0.setInsets(rectangleInsets1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { 10L };
        try {
            float[] floatArray4 = color0.getComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) '#', 1.0f, (double) 100L, (float) (byte) 10, (float) (short) 10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = null;
        try {
            textTitle1.setTextAlignment(horizontalAlignment2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        try {
            polarPlot0.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (-1.0d), (double) (byte) 10, (int) (short) 10, (java.lang.Comparable) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, (int) (short) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.Marker marker6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeDomainMarker(marker6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        org.jfree.chart.block.Arrangement arrangement2 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7);
        try {
            org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0, arrangement2, (org.jfree.chart.block.Arrangement) flowArrangement7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("TextBlockAnchor.TOP_RIGHT");
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = color1.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double5 = categoryAxis3D0.getCategoryEnd((int) (byte) 0, (int) (short) 1, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            categoryPlot0.addRangeMarker(marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            boolean boolean28 = categoryPlot0.removeRangeMarker(marker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        java.awt.Font font2 = null;
        try {
            categoryAxis3D0.setLabelFont(font2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        java.awt.Graphics2D graphics2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textFragment8.calculateDimensions(graphics2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        try {
            org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset23, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.awt.Color color9 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        float[] floatArray11 = new float[] {};
        try {
            float[] floatArray12 = color6.getColorComponents(colorSpace10, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        pieLabelDistributor1.clear();
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint9 = polarPlot8.getBackgroundPaint();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 1, paint9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        try {
            boolean boolean13 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Other", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getGreen();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray5 = new float[] { 100, (short) -1 };
        try {
            float[] floatArray6 = color0.getColorComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 175 + "'", int1 == 175);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            categoryPlot0.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        boolean boolean6 = textLine4.equals((java.lang.Object) 0);
        org.jfree.chart.text.TextFragment textFragment7 = null;
        textLine4.removeFragment(textFragment7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textLine4.draw(graphics2D9, (float) 15, (float) 10L, textAnchor12, (float) 3, (float) 10L, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", font1, paint2, (float) ' ', textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TextAnchor.BASELINE_RIGHT", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            blockContainer5.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean3 = verticalAlignment1.equals((java.lang.Object) stroke2);
        categoryAxis3D0.setTickMarkStroke(stroke2);
        categoryAxis3D0.configure();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Font font1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color4 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font1, (java.awt.Paint) color4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot0.setRenderer(polarItemRenderer5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        textTitle1.setWidth(0.4d);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            waferMapPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 175, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot0.zoomDomainAxes((double) (byte) 1, plotRenderingInfo8, point2D9, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 0L, (float) (short) 0, textAnchor4, (double) 0.0f, (float) 0L, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str5.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        categoryPlot5.setRangeCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint17 = polarPlot16.getBackgroundPaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1, paint17, stroke18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker19.setOutlineStroke(stroke20);
        org.jfree.chart.util.Layer layer22 = null;
        try {
            boolean boolean23 = categoryPlot5.removeDomainMarker((int) (short) 10, (org.jfree.chart.plot.Marker) valueMarker19, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, true);
        org.jfree.data.KeyToGroupMap keyToGroupMap16 = null;
        try {
            org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, keyToGroupMap16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[-1.0,10.0]", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot6 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("Other", font2, plot6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range2 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 0L);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        java.awt.Color color2 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        java.awt.Paint paint4 = blockBorder3.getPaint();
        categoryAxis0.setTickLabelPaint(paint4);
        int int6 = categoryAxis0.getCategoryLabelPositionOffset();
        int int7 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str0.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double5 = dateAxis1.lengthToJava2D(45.0d, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel(4);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        java.lang.Object obj7 = blockContainer5.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        java.awt.Image image17 = jFreeChart16.getBackgroundImage();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNull(image17);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(tickUnit5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setLatestAngle(45.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font9 = categoryAxis8.getLabelFont();
        boolean boolean10 = rectangleInsets7.equals((java.lang.Object) font9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 0.4d);
        categoryAxis0.setFixedDimension(0.08d);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) shape7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = textTitle6.getPosition();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            textTitle6.setPadding(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        boolean boolean4 = textTitle1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        java.util.List list2 = projectInfo0.getContributors();
        projectInfo0.setLicenceText("");
        projectInfo0.addOptionalLibrary("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        polarPlot0.setBackgroundAlpha((float) ' ');
        polarPlot0.addCornerTextItem("RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, true);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 1);
        try {
            java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRangeWithMargins((double) (byte) -1, (double) (byte) 0);
        try {
            dateAxis1.setRangeAboutValue(0.08d, (-100.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (50.08) <= upper (-49.92).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleAnchor.TOP_RIGHT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        categoryAxis3D0.setLabelAngle((double) (byte) 0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement12.add((org.jfree.chart.block.Block) textTitle14, (java.lang.Object) shape15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle14.getPosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            org.jfree.chart.axis.AxisState axisState19 = categoryAxis3D0.draw(graphics2D4, (double) (byte) 10, rectangle2D6, rectangle2D7, rectangleEdge17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart16.getTitle();
        java.lang.Object obj18 = jFreeChart16.getTextAntiAlias();
        org.jfree.chart.ui.ProjectInfo projectInfo19 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str20 = projectInfo19.getCopyright();
        try {
            jFreeChart16.setTextAntiAlias((java.lang.Object) projectInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: JFreeChart version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(projectInfo19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str20.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.block.BlockFrame blockFrame2 = null;
        try {
            textTitle1.setFrame(blockFrame2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.05d, (double) 0L, (double) (byte) 10, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.block.BlockFrame blockFrame7 = blockContainer5.getFrame();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            blockContainer5.setBounds(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(blockFrame7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        try {
            org.jfree.chart.plot.XYPlot xYPlot17 = jFreeChart16.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str5 = rectangleEdge4.toString();
        try {
            double double6 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.TOP" + "'", str5.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        boolean boolean6 = textLine4.equals((java.lang.Object) 0);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        polarPlot7.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        int int12 = polarPlot7.getSeriesCount();
        boolean boolean13 = textLine4.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) shape7);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        try {
            java.lang.String str13 = chartEntity10.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setURLText("RectangleEdge.TOP");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleEdge.TOP", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "Other", "");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot0.getAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = polarPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.pink;
        int int6 = color5.getGreen();
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font4, (java.awt.Paint) color8, (float) '#');
        boolean boolean11 = lengthConstraintType0.equals((java.lang.Object) textFragment10);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 175 + "'", int6 == 175);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) shape7);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        chartEntity10.setURLText("hi!");
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setUpperMargin((double) 1);
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis10.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis10.isTickLabelsVisible();
        boolean boolean19 = textFragment8.equals((java.lang.Object) categoryAxis10);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment24, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement27.add((org.jfree.chart.block.Block) textTitle29, (java.lang.Object) shape30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = textTitle29.getPosition();
        try {
            double double33 = categoryAxis10.getCategoryMiddle((int) (short) 0, (int) '#', rectangle2D22, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getBackgroundPaint();
        java.awt.Font font2 = polarPlot0.getNoDataMessageFont();
        org.jfree.data.general.DatasetGroup datasetGroup3 = polarPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(datasetGroup3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot5.getDrawingSupplier();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(drawingSupplier11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        int int5 = color2.getRed();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        try {
            dateAxis11.setRangeAboutValue((double) 10, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.5) <= upper (9.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextBlockAnchor.TOP_RIGHT", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Range[-1.0,10.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Range[-1.0,10.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        double double15 = multiplePiePlot14.getLimit();
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean17 = polarPlot16.isOutlineVisible();
        boolean boolean18 = polarPlot16.isSubplot();
        polarPlot16.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = polarPlot16.getOrientation();
        boolean boolean22 = multiplePiePlot14.equals((java.lang.Object) plotOrientation21);
        java.awt.Image image23 = multiplePiePlot14.getBackgroundImage();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(image23);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        dateAxis1.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRange(0.0d, 10.0d);
        dateAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel((int) (byte) 10, attributedString4);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        flowArrangement4.clear();
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.LegendItem legendItem16 = null;
        legendItemCollection15.add(legendItem16);
        int int18 = legendItemCollection15.getItemCount();
        java.lang.Object obj19 = legendItemCollection15.clone();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "RectangleAnchor.TOP_RIGHT", "RectangleEdge.TOP", "hi!");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setInfo("Range[-1.0,10.0]");
        java.lang.String str3 = basicProjectInfo0.getVersion();
        java.lang.String str4 = basicProjectInfo0.getName();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        int int16 = legendItemCollection15.getItemCount();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 100, (double) (short) -1, 10.0d);
        double double6 = rectangleInsets4.trimWidth((double) 10);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-100.0d) + "'", double6 == (-100.0d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        boolean boolean3 = standardPieSectionLabelGenerator0.equals((java.lang.Object) 0.08d);
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range4 = rectangleConstraint3.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray9, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset16, true);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 1);
        boolean boolean21 = size2D2.equals((java.lang.Object) 1);
        size2D2.setHeight((double) 35.0f);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = java.awt.Color.white;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke2 = null;
        polarPlot1.setAngleGridlineStroke(stroke2);
        polarPlot1.removeCornerTextItem("RectangleEdge.TOP");
        boolean boolean6 = color0.equals((java.lang.Object) "RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = color1.getGreen();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        float[] floatArray9 = new float[] { (-1L), 0.0f, 35.0f, '4', (byte) 0 };
        float[] floatArray10 = color3.getComponents(floatArray9);
        float[] floatArray11 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) -1, (int) '4', floatArray10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(1, axisLocation11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean14 = polarPlot13.isOutlineVisible();
        boolean boolean15 = polarPlot13.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot13.setDataset(xYDataset16);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot13.setAngleLabelFont(font18);
        categoryPlot0.setNoDataMessageFont(font18);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(plotOrientation21);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setUpperMargin((double) 10.0f);
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRange(0.0d, 10.0d);
        dateAxis1.setPositiveArrowVisible(false);
        java.util.TimeZone timeZone12 = null;
        try {
            dateAxis1.setTimeZone(timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean3 = verticalAlignment1.equals((java.lang.Object) stroke2);
        categoryAxis3D0.setTickMarkStroke(stroke2);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement13.add((org.jfree.chart.block.Block) textTitle15, (java.lang.Object) shape16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = textTitle15.getPosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            org.jfree.chart.axis.AxisState axisState20 = categoryAxis3D0.draw(graphics2D5, (-100.0d), rectangle2D7, rectangle2D8, rectangleEdge18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 10, 4.5d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color4 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        textTitle3.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = null;
        polarPlot9.setAngleGridlineStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot9.getInsets();
        boolean boolean13 = textTitle3.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets12);
        double double15 = rectangleInsets12.getRight();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range18, lengthConstraintType19, 0.0d, range38, lengthConstraintType39);
        double double41 = rectangleConstraint40.getHeight();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        java.awt.Paint paint27 = jFreeChart26.getBackgroundPaint();
        jFreeChart26.removeLegend();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        double double3 = size2D2.getHeight();
        size2D2.setHeight(4.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("LengthConstraintType.NONE");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.addOptionalLibrary("LengthConstraintType.NONE");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        boolean boolean6 = textLine4.equals((java.lang.Object) 0);
        org.jfree.chart.text.TextFragment textFragment7 = null;
        textLine4.addFragment(textFragment7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("");
        textLine4.removeFragment(textFragment10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedHeight();
        java.lang.String str5 = rectangleConstraint3.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        float[] floatArray7 = new float[] { (-1L), 0.0f, 35.0f, '4', (byte) 0 };
        float[] floatArray8 = color1.getComponents(floatArray7);
        java.awt.Color color9 = java.awt.Color.getColor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        boolean boolean3 = standardPieSectionLabelGenerator0.equals((java.lang.Object) 0.08d);
        java.lang.String str4 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot0.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = polarPlot0.isRadiusGridlinesVisible();
        java.awt.Stroke stroke10 = polarPlot0.getAngleGridlineStroke();
        org.jfree.chart.axis.TickUnit tickUnit11 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(tickUnit11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation();
        java.awt.Stroke stroke9 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = java.awt.Color.BLACK;
        int int9 = color8.getRGB();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color8);
        int int11 = categoryPlot7.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot7.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = java.awt.Color.BLACK;
        int int15 = color14.getRGB();
        categoryPlot13.setRangeCrosshairPaint((java.awt.Paint) color14);
        int int17 = categoryPlot13.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot13.getDomainAxisLocation();
        categoryPlot7.setRangeAxisLocation(axisLocation18);
        categoryPlot0.setRangeAxisLocation(axisLocation18, true);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777216) + "'", int9 == (-16777216));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16777216) + "'", int15 == (-16777216));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer((int) (short) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint13 = polarPlot12.getBackgroundPaint();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 1, paint13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker15.setOutlineStroke(stroke16);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        valueMarker15.setLabelPaint(paint18);
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = categoryPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker15, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Font font16 = multiplePiePlot14.getNoDataMessageFont();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset30, true);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset46, true);
        org.jfree.data.Range range49 = org.jfree.data.Range.combine(range32, range48);
        boolean boolean50 = multiplePiePlot14.equals((java.lang.Object) range32);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Font font2 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 10);
        try {
            java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setUpperMargin((double) 1);
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis10.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis10.isTickLabelsVisible();
        boolean boolean19 = textFragment8.equals((java.lang.Object) categoryAxis10);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis10.setTickMarkStroke(stroke20);
        java.awt.Stroke stroke22 = categoryAxis10.getAxisLineStroke();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Stroke stroke16 = multiplePiePlot14.getOutlineStroke();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 0.4d);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = java.awt.Color.BLACK;
        int int6 = color5.getRGB();
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color5);
        int int8 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        categoryAxis0.setLabelInsets(rectangleInsets11);
        double double14 = rectangleInsets11.trimHeight(0.05d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-16777216) + "'", int6 == (-16777216));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-7.95d) + "'", double14 == (-7.95d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 0.4d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double8 = categoryAxis0.getCategoryEnd((-1), 1, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", graphics2D1, (double) 255, (-1.0f), (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = categoryAxis0.isTickLabelsVisible();
        categoryAxis0.setLowerMargin(100.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint6 = polarPlot5.getBackgroundPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 1, paint6, stroke7);
        java.awt.Paint paint9 = valueMarker8.getOutlinePaint();
        float float10 = valueMarker8.getAlpha();
        org.jfree.chart.util.Layer layer11 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
        try {
            valueMarker8.setLabelAnchor(rectangleAnchor13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 100, (double) (short) -1, 10.0d);
        categoryAxis0.setLabelInsets(rectangleInsets6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets6.createInsetRectangle(rectangle2D8, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setRangeWithMargins((double) 10L, (double) 10.0f);
        java.util.TimeZone timeZone7 = null;
        try {
            dateAxis1.setTimeZone(timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset(1);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(1, axisLocation11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean14 = polarPlot13.isOutlineVisible();
        boolean boolean15 = polarPlot13.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot13.setDataset(xYDataset16);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot13.setAngleLabelFont(font18);
        categoryPlot0.setNoDataMessageFont(font18);
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint23 = polarPlot22.getBackgroundPaint();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 1, paint23, stroke24);
        java.awt.Paint paint26 = valueMarker25.getOutlinePaint();
        float float27 = valueMarker25.getAlpha();
        try {
            boolean boolean28 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        java.awt.Color color11 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        java.awt.Paint paint13 = blockBorder12.getPaint();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        java.awt.Paint paint15 = blockBorder12.getPaint();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge(3);
        java.awt.Paint paint28 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1L), (org.jfree.data.Range) dateRange1);
        org.junit.Assert.assertNotNull(dateRange1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        polarPlot0.rendererChanged(rendererChangeEvent3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range18, lengthConstraintType19, 0.0d, range38, lengthConstraintType39);
        java.lang.String str41 = lengthConstraintType19.toString();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "LengthConstraintType.FIXED" + "'", str41.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color2 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        textTitle1.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke8 = null;
        polarPlot7.setAngleGridlineStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot7.getInsets();
        boolean boolean11 = textTitle1.equals((java.lang.Object) rectangleInsets10);
        textTitle1.setToolTipText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment15, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement18);
        boolean boolean20 = blockContainer19.isEmpty();
        org.jfree.chart.block.BlockFrame blockFrame21 = blockContainer19.getFrame();
        textTitle1.setFrame(blockFrame21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle1.getMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(blockFrame21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 0, (float) 10L, (float) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-165) + "'", int3 == (-165));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 1, 94.0d, plotRenderingInfo7, point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Font font16 = multiplePiePlot14.getNoDataMessageFont();
        multiplePiePlot14.setLimit(0.0d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        polarPlot0.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "TextBlockAnchor.TOP_RIGHT", "Range[-1.0,10.0]", "hi!");
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        boolean boolean5 = textTitle1.getNotify();
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color9 = java.awt.Color.pink;
        int int10 = color9.getGreen();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color12, (float) '#');
        java.lang.String str15 = textFragment14.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setUpperMargin((double) 1);
        categoryAxis16.clearCategoryLabelToolTips();
        categoryAxis16.setTickLabelsVisible(false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        boolean boolean24 = categoryAxis16.isTickLabelsVisible();
        boolean boolean25 = textFragment14.equals((java.lang.Object) categoryAxis16);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        boolean boolean27 = textFragment14.equals((java.lang.Object) color26);
        textTitle1.setBackgroundPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 175 + "'", int10 == 175);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRangeWithMargins((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setAutoTickUnitSelection(true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        double double3 = piePlotState1.getLatestAngle();
        double double4 = piePlotState1.getPieCenterX();
        piePlotState1.setTotal((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(1, axisLocation11);
        float float13 = categoryPlot0.getForegroundAlpha();
        java.awt.Paint paint14 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.setRangeCrosshairValue((double) 'a');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot0.rendererChanged(rendererChangeEvent7);
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Font font14 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color15 = java.awt.Color.pink;
        int int16 = color15.getGreen();
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("hi!", font14, (java.awt.Paint) color15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!", font14, (java.awt.Paint) color18, (float) '#');
        java.awt.Font font23 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color24 = java.awt.Color.pink;
        int int25 = color24.getGreen();
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("hi!", font23, (java.awt.Paint) color24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font23, (java.awt.Paint) color27, (float) '#');
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color9, color11, color18, color27 };
        java.awt.Paint[] paintArray31 = null;
        java.awt.Color color32 = java.awt.Color.BLACK;
        int int33 = color32.getRGB();
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] { color32 };
        java.awt.Stroke[] strokeArray35 = null;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean40 = verticalAlignment38.equals((java.lang.Object) stroke39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray43 = new java.awt.Stroke[] { stroke36, stroke37, stroke39, stroke41, stroke42 };
        java.awt.Shape[] shapeArray44 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, paintArray34, strokeArray35, strokeArray43, shapeArray44);
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
        try {
            java.awt.Paint paint47 = defaultDrawingSupplier45.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 175 + "'", int16 == 175);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 175 + "'", int25 == 175);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-16777216) + "'", int33 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(strokeArray43);
        org.junit.Assert.assertNotNull(shapeArray44);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setVisible(false);
        java.awt.Paint paint6 = null;
        try {
            categoryAxis0.setTickMarkPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.block.BlockFrame blockFrame7 = blockContainer5.getFrame();
        double double8 = blockContainer5.getContentXOffset();
        java.util.List list9 = blockContainer5.getBlocks();
        try {
            java.util.Collection collection10 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list9);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(blockFrame7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot0.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = java.awt.Color.BLACK;
        int int12 = color11.getRGB();
        categoryPlot10.setRangeCrosshairPaint((java.awt.Paint) color11);
        int int14 = categoryPlot10.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color17 = java.awt.Color.BLACK;
        int int18 = color17.getRGB();
        categoryPlot16.setRangeCrosshairPaint((java.awt.Paint) color17);
        int int20 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot16.getDomainAxisLocation();
        categoryPlot10.setRangeAxisLocation(1, axisLocation21);
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean24 = polarPlot23.isOutlineVisible();
        boolean boolean25 = polarPlot23.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        polarPlot23.setDataset(xYDataset26);
        java.awt.Font font28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot23.setAngleLabelFont(font28);
        categoryPlot10.setNoDataMessageFont(font28);
        polarPlot0.setAngleLabelFont(font28);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16777216) + "'", int12 == (-16777216));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16777216) + "'", int18 == (-16777216));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        java.lang.Object obj34 = null;
        boolean boolean35 = color2.equals(obj34);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(1, axisLocation11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = java.awt.Color.BLACK;
        int int16 = color15.getRGB();
        categoryPlot14.setRangeCrosshairPaint((java.awt.Paint) color15);
        int int18 = categoryPlot14.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = categoryPlot14.getOrientation();
        java.awt.Paint paint20 = categoryPlot14.getRangeGridlinePaint();
        java.awt.Paint paint21 = categoryPlot14.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = categoryPlot14.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color24 = java.awt.Color.BLACK;
        int int25 = color24.getRGB();
        categoryPlot23.setRangeCrosshairPaint((java.awt.Paint) color24);
        int int27 = categoryPlot23.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = categoryPlot23.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color30 = java.awt.Color.BLACK;
        int int31 = color30.getRGB();
        categoryPlot29.setRangeCrosshairPaint((java.awt.Paint) color30);
        int int33 = categoryPlot29.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot29.getDomainAxisLocation();
        categoryPlot23.setRangeAxisLocation(axisLocation34);
        categoryPlot14.setRangeAxisLocation(axisLocation34, true);
        try {
            categoryPlot0.setRangeAxisLocation((int) (byte) -1, axisLocation34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-16777216) + "'", int16 == (-16777216));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-16777216) + "'", int25 == (-16777216));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-16777216) + "'", int31 == (-16777216));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        double double5 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color4 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        textTitle3.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = null;
        polarPlot9.setAngleGridlineStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot9.getInsets();
        boolean boolean13 = textTitle3.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets12);
        java.lang.String str15 = rectangleInsets12.toString();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str15.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Font font16 = multiplePiePlot14.getNoDataMessageFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean18 = multiplePiePlot14.equals((java.lang.Object) dateTickUnit17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = multiplePiePlot14.getDataset();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryDataset19);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        java.awt.Paint paint11 = textTitle1.getBackgroundPaint();
        double double12 = textTitle1.getContentYOffset();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRange(0.0d, 10.0d);
        dateAxis1.setPositiveArrowVisible(false);
        dateAxis1.setAutoRangeMinimumSize(8.0d);
        try {
            dateAxis1.setRange((double) 100, (-100.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        boolean boolean2 = rotation0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        double double3 = size2D2.getHeight();
        java.lang.Object obj4 = size2D2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = null;
        try {
            categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        try {
            org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = java.awt.Color.BLACK;
        int int9 = color8.getRGB();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color8);
        int int11 = categoryPlot7.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot7.getDomainAxisLocation();
        double double13 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot7.removeChangeListener(plotChangeListener14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset30);
        categoryPlot7.setDataset(0, categoryDataset30);
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        boolean boolean34 = categoryPlot7.isOutlineVisible();
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = categoryPlot7.getDomainMarkers(3, layer36);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777216) + "'", int9 == (-16777216));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(collection37);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        size2D2.width = (byte) 1;
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("{0}");
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray33, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset40, true);
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray49, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray55);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset56, true);
        org.jfree.data.Range range59 = org.jfree.data.Range.combine(range42, range58);
        java.lang.String str60 = range59.toString();
        dateAxis26.setRange(range59, false, false);
        try {
            jFreeChart20.setTextAntiAlias((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: false incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Range[-1.0,10.0]" + "'", str60.equals("Range[-1.0,10.0]"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        try {
            java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) font1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot0.addDomainMarker(100, categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Color color3 = java.awt.Color.ORANGE;
        float[] floatArray10 = new float[] { 0L, (-1L), '4', 0L, 100.0f, 3 };
        float[] floatArray11 = color3.getRGBColorComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB((-1), 100, (int) (byte) 100, floatArray11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((double) 10L, plotRenderingInfo11, point2D12);
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint17 = polarPlot16.getBackgroundPaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1, paint17, stroke18);
        java.awt.Paint paint20 = valueMarker19.getOutlinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        try {
            boolean boolean22 = categoryPlot0.removeRangeMarker(10, (org.jfree.chart.plot.Marker) valueMarker19, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRangeWithMargins((double) (byte) -1, (double) (byte) 0);
        double double10 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean10 = polarPlot9.isOutlineVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        try {
            polarPlot9.zoomRangeAxes((double) 1, plotRenderingInfo13, point2D14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean3 = verticalAlignment1.equals((java.lang.Object) stroke2);
        categoryAxis3D0.setTickMarkStroke(stroke2);
        categoryAxis3D0.setTickMarkOutsideLength((float) (-1L));
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", graphics2D1, 1.0f, (float) (byte) 100, textAnchor4, (double) (short) 1, (float) 10, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getRGB();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.pink;
        int int7 = color6.getGreen();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font5, (java.awt.Paint) color6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font5, (java.awt.Paint) color9, (float) '#');
        java.awt.Font font14 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color15 = java.awt.Color.pink;
        int int16 = color15.getGreen();
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("hi!", font14, (java.awt.Paint) color15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!", font14, (java.awt.Paint) color18, (float) '#');
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color0, color2, color9, color18 };
        java.awt.Paint[] paintArray22 = null;
        java.awt.Color color23 = java.awt.Color.BLACK;
        int int24 = color23.getRGB();
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color23 };
        java.awt.Stroke[] strokeArray26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean31 = verticalAlignment29.equals((java.lang.Object) stroke30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke27, stroke28, stroke30, stroke32, stroke33 };
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray25, strokeArray26, strokeArray34, shapeArray35);
        try {
            java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16777216) + "'", int1 == (-16777216));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 175 + "'", int7 == 175);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 175 + "'", int16 == 175);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-16777216) + "'", int24 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shapeArray35);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Paint paint5 = valueMarker4.getOutlinePaint();
        valueMarker4.setValue((double) 10L);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat9 = standardPieSectionLabelGenerator8.getPercentFormat();
        java.text.AttributedString attributedString11 = null;
        standardPieSectionLabelGenerator8.setAttributedLabel((int) (byte) 0, attributedString11);
        java.lang.Class<?> wildcardClass13 = standardPieSectionLabelGenerator8.getClass();
        try {
            java.util.EventListener[] eventListenerArray14 = valueMarker4.getListeners((java.lang.Class) wildcardClass13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.labels.StandardPieSectionLabelGenerator; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        java.awt.geom.Rectangle2D rectangle2D3 = piePlotState1.getExplodedPieArea();
        int int4 = piePlotState1.getPassesRequired();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        boolean boolean8 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        try {
            categoryPlot0.setRenderer((int) (byte) -1, categoryItemRenderer10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint19 = polarPlot18.getBackgroundPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1, paint19, stroke20);
        jFreeChart16.setBorderPaint(paint19);
        java.awt.Image image23 = jFreeChart16.getBackgroundImage();
        jFreeChart16.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(image23);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(tableOrder1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis0.getTickLabelInsets();
        java.awt.Paint paint9 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, paint9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setUpperMargin((double) 1);
        categoryAxis12.clearCategoryLabelToolTips();
        categoryAxis12.setTickLabelsVisible(false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis12.setLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = categoryAxis12.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean22 = polarPlot21.isOutlineVisible();
        categoryAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot21);
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, 0.0d, (double) (short) 100, rectangleAnchor31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle34.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = textTitle34.getPosition();
        double double38 = categoryAxis12.getCategoryStart((int) (byte) 100, (int) (byte) 10, rectangle2D32, rectangleEdge37);
        try {
            blockBorder10.draw(graphics2D11, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-55.25000000000002d) + "'", double38 == (-55.25000000000002d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        java.awt.Paint paint27 = jFreeChart26.getBackgroundPaint();
        jFreeChart26.fireChartChanged();
        jFreeChart26.fireChartChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
        java.awt.Stroke stroke5 = polarPlot0.getAngleGridlineStroke();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot0.setAngleGridlineStroke(stroke6);
        int int8 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) shape7);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.lang.String str11 = chartEntity10.getToolTipText();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str11.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 0.4d);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = java.awt.Color.BLACK;
        int int6 = color5.getRGB();
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color5);
        int int8 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        categoryAxis0.setLabelInsets(rectangleInsets11);
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint15 = polarPlot14.getBackgroundPaint();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 1, paint15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker17.setOutlineStroke(stroke18);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        valueMarker17.setLabelPaint(paint20);
        categoryAxis0.setTickMarkPaint(paint20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-16777216) + "'", int6 == (-16777216));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        java.lang.Object obj34 = chartChangeEvent33.getSource();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean10 = polarPlot9.isOutlineVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot9);
        float float12 = polarPlot9.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = java.awt.Color.BLACK;
        int int11 = color10.getRGB();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color10);
        int int13 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot9.getOrientation();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        categoryPlot0.setRangeCrosshairPaint(paint15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16777216) + "'", int11 == (-16777216));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.awt.color.ColorSpace colorSpace5 = color2.getColorSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement14.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) shape17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment20, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement23.add((org.jfree.chart.block.Block) textTitle25, (java.lang.Object) shape26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement14, (org.jfree.chart.block.Arrangement) flowArrangement23);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.setUpperMargin((double) 1);
        categoryAxis30.clearCategoryLabelToolTips();
        categoryAxis30.setTickLabelsVisible(false);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis30.setLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = categoryAxis30.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean40 = polarPlot39.isOutlineVisible();
        categoryAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot39);
        org.jfree.chart.util.Size2D size2D46 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, 0.0d, (double) (short) 100, rectangleAnchor49);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle52.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = textTitle52.getPosition();
        double double56 = categoryAxis30.getCategoryStart((int) (byte) 100, (int) (byte) 10, rectangle2D50, rectangleEdge55);
        try {
            categoryPlot0.drawBackground(graphics2D29, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-55.25000000000002d) + "'", double56 == (-55.25000000000002d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset23, true);
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray32, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, true);
        org.jfree.data.Range range42 = org.jfree.data.Range.combine(range25, range41);
        java.lang.String str43 = range42.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range42);
        dateAxis1.setRangeWithMargins(range42);
        java.lang.Object obj46 = null;
        boolean boolean47 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) range42, obj46);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Range[-1.0,10.0]" + "'", str43.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        boolean boolean6 = textLine4.equals((java.lang.Object) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        boolean boolean10 = textLine4.equals((java.lang.Object) 0.0d);
        java.awt.Font font13 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color14 = java.awt.Color.pink;
        int int15 = color14.getGreen();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("hi!", font13, (java.awt.Paint) color14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("hi!", font13, (java.awt.Paint) color17, (float) '#');
        java.lang.String str20 = textFragment19.getText();
        textLine4.addFragment(textFragment19);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 175 + "'", int15 == 175);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setUpperMargin((double) 1);
        categoryAxis26.clearCategoryLabelToolTips();
        categoryAxis26.setTickLabelsVisible(false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis26.setLabelPaint((java.awt.Paint) color32);
        boolean boolean34 = categoryAxis26.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean36 = polarPlot35.isOutlineVisible();
        categoryAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot35);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, 0.0d, (double) (short) 100, rectangleAnchor45);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle48.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = textTitle48.getPosition();
        double double52 = categoryAxis26.getCategoryStart((int) (byte) 100, (int) (byte) 10, rectangle2D46, rectangleEdge51);
        try {
            jFreeChart20.draw(graphics2D25, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-55.25000000000002d) + "'", double52 == (-55.25000000000002d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.GENERAL", "ChartChangeEventType.GENERAL", "Range[-1.0,10.0]", image3, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "TextAnchor.BASELINE_RIGHT", "ChartChangeEventType.GENERAL");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color2 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        textTitle1.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke8 = null;
        polarPlot7.setAngleGridlineStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot7.getInsets();
        boolean boolean11 = textTitle1.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle1.setPosition(rectangleEdge12);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRange(0.0d, 10.0d);
        dateAxis1.setPositiveArrowVisible(false);
        dateAxis1.setAutoRangeMinimumSize(8.0d);
        try {
            dateAxis1.zoomRange(0.4d, 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (9.0) <= upper (6.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 0.4d);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = java.awt.Color.BLACK;
        int int6 = color5.getRGB();
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color5);
        int int8 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        categoryAxis0.setLabelInsets(rectangleInsets11);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "TextBlockAnchor.TOP_RIGHT", "");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-16777216) + "'", int6 == (-16777216));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Font font16 = multiplePiePlot14.getNoDataMessageFont();
        java.awt.Color color17 = java.awt.Color.BLACK;
        int int18 = color17.getRGB();
        multiplePiePlot14.setAggregatedItemsPaint((java.awt.Paint) color17);
        java.awt.Image image20 = multiplePiePlot14.getBackgroundImage();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16777216) + "'", int18 == (-16777216));
        org.junit.Assert.assertNull(image20);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.lang.String str3 = textTitle1.getURLText();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint23 = polarPlot22.getBackgroundPaint();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 1, paint23, stroke24);
        jFreeChart20.setBorderPaint(paint23);
        java.awt.Image image27 = jFreeChart20.getBackgroundImage();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(image27);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range18, lengthConstraintType19, 0.0d, range38, lengthConstraintType39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("{0}");
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray49, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray55);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset56, true);
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray71 = new java.lang.Number[][] { numberArray65, numberArray70 };
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray71);
        org.jfree.data.Range range74 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset72, true);
        org.jfree.data.Range range75 = org.jfree.data.Range.combine(range58, range74);
        java.lang.String str76 = range75.toString();
        dateAxis42.setRange(range75, false, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = rectangleConstraint40.toRangeHeight(range75);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Range[-1.0,10.0]" + "'", str76.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint80);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, 0.0d, (double) (short) 100, rectangleAnchor13);
        try {
            blockContainer5.draw(graphics2D7, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot0.rendererChanged(rendererChangeEvent7);
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Font font14 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color15 = java.awt.Color.pink;
        int int16 = color15.getGreen();
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("hi!", font14, (java.awt.Paint) color15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!", font14, (java.awt.Paint) color18, (float) '#');
        java.awt.Font font23 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color24 = java.awt.Color.pink;
        int int25 = color24.getGreen();
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("hi!", font23, (java.awt.Paint) color24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font23, (java.awt.Paint) color27, (float) '#');
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color9, color11, color18, color27 };
        java.awt.Paint[] paintArray31 = null;
        java.awt.Color color32 = java.awt.Color.BLACK;
        int int33 = color32.getRGB();
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] { color32 };
        java.awt.Stroke[] strokeArray35 = null;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean40 = verticalAlignment38.equals((java.lang.Object) stroke39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray43 = new java.awt.Stroke[] { stroke36, stroke37, stroke39, stroke41, stroke42 };
        java.awt.Shape[] shapeArray44 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, paintArray34, strokeArray35, strokeArray43, shapeArray44);
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
        try {
            java.awt.Shape shape47 = defaultDrawingSupplier45.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 175 + "'", int16 == 175);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 175 + "'", int25 == 175);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-16777216) + "'", int33 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(strokeArray43);
        org.junit.Assert.assertNotNull(shapeArray44);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean4 = polarPlot3.isOutlineVisible();
        boolean boolean5 = polarPlot3.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        polarPlot3.setDataset(xYDataset6);
        java.awt.Stroke stroke8 = polarPlot3.getAngleGridlineStroke();
        categoryAxis0.setAxisLineStroke(stroke8);
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.GENERAL", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-16777216), (double) 175, (double) (-1), (double) (-1.0f));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot0.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = polarPlot0.isRadiusGridlinesVisible();
        try {
            polarPlot0.zoom((double) 35.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Color color6 = java.awt.Color.GRAY;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.ORANGE;
        float[] floatArray15 = new float[] { 0L, (-1L), '4', 0L, 100.0f, 3 };
        float[] floatArray16 = color8.getRGBColorComponents(floatArray15);
        float[] floatArray17 = color6.getRGBColorComponents(floatArray15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        boolean boolean2 = polarPlot0.isSubplot();
        int int3 = polarPlot0.getSeriesCount();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        polarPlot0.setBackgroundPaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Font font6 = legendTitle5.getItemFont();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double10 = rectangleInsets8.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15);
        boolean boolean17 = blockContainer16.isEmpty();
        java.util.List list18 = blockContainer16.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets8.createOutsetRectangle(rectangle2D19);
        try {
            legendTitle5.draw(graphics2D7, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 94.0d + "'", double10 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel((int) (byte) 0, attributedString3);
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.lang.String str6 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setTickMarksVisible(false);
        dateAxis1.setAutoTickUnitSelection(false);
        boolean boolean8 = dateAxis1.isVisible();
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis1.setTimeline(timeline9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.yellow;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setRightArrow(shape15);
        double double17 = dateAxis11.getLowerBound();
        java.lang.Object obj18 = dateAxis11.clone();
        java.awt.Paint paint19 = dateAxis11.getAxisLinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("Other");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Other");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint19 = polarPlot18.getBackgroundPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1, paint19, stroke20);
        jFreeChart16.setBorderPaint(paint19);
        org.jfree.chart.util.Rotation rotation23 = org.jfree.chart.util.Rotation.CLOCKWISE;
        try {
            jFreeChart16.setTextAntiAlias((java.lang.Object) rotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Rotation.CLOCKWISE incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rotation23);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRangeWithMargins((double) (byte) -1, (double) (byte) 0);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.Plot plot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setUpperMargin((double) 1);
        categoryAxis12.clearCategoryLabelToolTips();
        categoryAxis12.setTickLabelsVisible(false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis12.setLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = categoryAxis12.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean22 = polarPlot21.isOutlineVisible();
        categoryAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot21);
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, 0.0d, (double) (short) 100, rectangleAnchor31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle34.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = textTitle34.getPosition();
        double double38 = categoryAxis12.getCategoryStart((int) (byte) 100, (int) (byte) 10, rectangle2D32, rectangleEdge37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement43 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment39, verticalAlignment40, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement43.add((org.jfree.chart.block.Block) textTitle45, (java.lang.Object) shape46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = textTitle45.getPosition();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace50 = dateAxis1.reserveSpace(graphics2D10, plot11, rectangle2D32, rectangleEdge48, axisSpace49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-55.25000000000002d) + "'", double38 == (-55.25000000000002d));
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("{0}", "ChartChangeEventType.GENERAL");
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("hi!");
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        int int12 = categoryPlot8.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation();
        double double14 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot8.removeChangeListener(plotChangeListener15);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset31);
        categoryPlot8.setDataset(0, categoryDataset31);
        valueMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        try {
            valueMarker7.setLabelOffsetType(lengthAdjustmentType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.lang.Object obj2 = standardPieSectionLabelGenerator0.clone();
        java.lang.String str3 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, (int) (short) 0, (int) (byte) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray10, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = multiplePiePlot18.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot18.getPieChart();
        java.awt.Paint paint21 = jFreeChart20.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) chartColor3, jFreeChart20, 3, (-16777216));
        java.lang.String str25 = chartProgressEvent24.toString();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]]" + "'", str25.equals("org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]]"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        waferMapPlot1.setRenderer(waferMapRenderer6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Color color6 = java.awt.Color.GRAY;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer((int) (short) 100, categoryItemRenderer9, true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(legendItemCollection12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        java.awt.Paint paint6 = waferMapPlot1.getNoDataMessagePaint();
        java.lang.String str7 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "WMAP_Plot" + "'", str7.equals("WMAP_Plot"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setUpperMargin((double) 1);
        categoryAxis8.clearCategoryLabelToolTips();
        categoryAxis8.setTickLabelsVisible(false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis8.setLabelPaint((java.awt.Paint) color14);
        java.util.List list16 = categoryPlot0.getCategoriesForAxis(categoryAxis8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15, true);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset31, true);
        org.jfree.data.Range range34 = org.jfree.data.Range.combine(range17, range33);
        java.lang.String str35 = range34.toString();
        dateAxis1.setRange(range34, false, false);
        try {
            dateAxis1.setRange((double) 8, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Range[-1.0,10.0]" + "'", str35.equals("Range[-1.0,10.0]"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) 1);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean10 = polarPlot9.isOutlineVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot9);
        java.awt.Paint paint12 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) stroke1);
        java.lang.String str3 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.TOP" + "'", str3.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        java.awt.Stroke stroke4 = polarPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color2 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        textTitle1.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke8 = null;
        polarPlot7.setAngleGridlineStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot7.getInsets();
        boolean boolean11 = textTitle1.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint13 = polarPlot12.getBackgroundPaint();
        java.awt.Font font14 = polarPlot12.getNoDataMessageFont();
        textTitle1.setFont(font14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot23.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot23.getPieChart();
        org.jfree.chart.title.TextTitle textTitle26 = jFreeChart25.getTitle();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle26.setBackgroundPaint((java.awt.Paint) color27);
        categoryPlot0.setOutlinePaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNotNull(textTitle26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset23, true);
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray32, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, true);
        org.jfree.data.Range range42 = org.jfree.data.Range.combine(range25, range41);
        java.lang.String str43 = range42.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range42);
        dateAxis1.setRangeWithMargins(range42);
        dateAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Range[-1.0,10.0]" + "'", str43.equals("Range[-1.0,10.0]"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean7 = polarPlot6.isOutlineVisible();
        boolean boolean8 = polarPlot6.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        polarPlot6.setDataset(xYDataset9);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot6.setAngleLabelFont(font11);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray19, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        java.lang.Comparable comparable28 = multiplePiePlot27.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset29 = multiplePiePlot27.getDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font11, (org.jfree.chart.plot.Plot) multiplePiePlot27, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = jFreeChart31.getPadding();
        boolean boolean33 = jFreeChart31.getAntiAlias();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment34, verticalAlignment35, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer39 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement38);
        boolean boolean40 = blockContainer39.isEmpty();
        java.util.List list41 = blockContainer39.getBlocks();
        jFreeChart31.setSubtitles(list41);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart31);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + "Other" + "'", comparable28.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot0.getDomainAxisForDataset((int) (short) 100);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        int int5 = polarPlot0.getSeriesCount();
        org.jfree.chart.axis.TickUnit tickUnit6 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(tickUnit6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        jFreeChart21.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray12, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = multiplePiePlot20.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart22 = multiplePiePlot20.getPieChart();
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart22.getTitle();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle23.setBackgroundPaint((java.awt.Paint) color24);
        blockContainer5.add((org.jfree.chart.block.Block) textTitle23);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(jFreeChart22);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        java.awt.Paint paint17 = jFreeChart16.getBackgroundPaint();
        org.jfree.chart.title.Title title19 = null;
        try {
            jFreeChart16.addSubtitle(10, title19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle1.getMargin();
        double double13 = rectangleInsets11.extendWidth(0.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets11.createInsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setTickMarksVisible(false);
        dateAxis1.setAutoTickUnitSelection(false);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        java.awt.Font font24 = multiplePiePlot22.getNoDataMessageFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean26 = multiplePiePlot22.equals((java.lang.Object) dateTickUnit25);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit25);
        org.jfree.chart.plot.Plot plot28 = dateAxis1.getPlot();
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(plot28);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 100, (double) (short) -1, 10.0d);
        double double6 = rectangleInsets4.trimWidth((double) 10);
        double double8 = rectangleInsets4.calculateTopOutset((double) 1L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-100.0d) + "'", double6 == (-100.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setInfo("Range[-1.0,10.0]");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.getCopyright();
        java.lang.String str5 = projectInfo3.getName();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        java.lang.String str7 = projectInfo3.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str4.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart" + "'", str5.equals("JFreeChart"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str7.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset14, 1);
        try {
            java.lang.String str20 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset18, (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 0.2");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(pieDataset18);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        legendTitle5.setWrapper(blockContainer8);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot1.setDataset(waferMapDataset6);
        int int8 = waferMapPlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.setDrawSharedDomainAxis(false);
        int int9 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 0.4d);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = java.awt.Color.BLACK;
        int int6 = color5.getRGB();
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color5);
        int int8 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        categoryAxis0.setLabelInsets(rectangleInsets11);
        categoryAxis0.setLabelToolTip("TextBlockAnchor.TOP_RIGHT");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-16777216) + "'", int6 == (-16777216));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot1.setDataset(waferMapDataset6);
        java.lang.String str8 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "WMAP_Plot" + "'", str8.equals("WMAP_Plot"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Color color6 = java.awt.Color.GRAY;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer((int) (short) 100, categoryItemRenderer9, true);
        org.jfree.chart.util.SortOrder sortOrder12 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, (double) (-1L), plotRenderingInfo11, point2D12);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setRightArrow(shape15);
        double double17 = dateAxis11.getLowerBound();
        java.lang.Object obj18 = dateAxis11.clone();
        try {
            dateAxis11.setUpperMargin((-100.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-99.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.util.List list3 = categoryPlot0.getCategories();
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, (-1));
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        java.lang.Comparable comparable27 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        polarPlot28.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        multiplePiePlot22.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        java.awt.Shape shape34 = defaultDrawingSupplier31.getNextShape();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + "Other" + "'", comparable27.equals("Other"));
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        double double3 = piePlotState1.getLatestAngle();
        int int4 = piePlotState1.getPassesRequired();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = java.awt.Color.BLACK;
        int int12 = color11.getRGB();
        categoryPlot10.setRangeCrosshairPaint((java.awt.Paint) color11);
        int int14 = categoryPlot10.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot10.getOrientation();
        java.awt.Paint paint16 = categoryPlot10.getRangeGridlinePaint();
        java.awt.Paint paint17 = categoryPlot10.getRangeGridlinePaint();
        java.awt.Stroke stroke18 = categoryPlot10.getRangeCrosshairStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16777216) + "'", int12 == (-16777216));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset30, true);
        org.jfree.data.Range range33 = org.jfree.data.Range.combine(range16, range32);
        java.lang.String str34 = range33.toString();
        double double35 = range33.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range33);
        double double37 = range33.getCentralValue();
        org.jfree.data.Range range39 = org.jfree.data.Range.expandToInclude(range33, (double) (-1L));
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Range[-1.0,10.0]" + "'", str34.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-1.0d) + "'", double35 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.5d + "'", double37 == 4.5d);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart16.getTitle();
        double double18 = textTitle17.getWidth();
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle17.getVerticalAlignment();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setRangeWithMargins((double) 10L, (double) 10.0f);
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, (int) 'a', 100, (java.lang.Comparable) 100L, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "{0}");
        java.lang.String str15 = pieSectionEntity14.toString();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieSection: 97, 100(100)" + "'", str15.equals("PieSection: 97, 100(100)"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = piePlotState1.getEntityCollection();
        double double3 = piePlotState1.getTotal();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation(0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.Timeline timeline11 = dateAxis1.getTimeline();
        org.junit.Assert.assertNotNull(timeline11);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setUpperMargin((double) 1);
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis10.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis10.isTickLabelsVisible();
        boolean boolean19 = textFragment8.equals((java.lang.Object) categoryAxis10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        boolean boolean21 = textFragment8.equals((java.lang.Object) color20);
        java.awt.Graphics2D graphics2D22 = null;
        try {
            org.jfree.chart.util.Size2D size2D23 = textFragment8.calculateDimensions(graphics2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNull(categoryDataset1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setUpperMargin((double) 1);
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis10.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis10.isTickLabelsVisible();
        boolean boolean19 = textFragment8.equals((java.lang.Object) categoryAxis10);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis10.setTickMarkStroke(stroke20);
        java.awt.Stroke stroke22 = categoryAxis10.getTickMarkStroke();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean24 = polarPlot23.isOutlineVisible();
        boolean boolean25 = polarPlot23.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        polarPlot23.setDataset(xYDataset26);
        java.awt.Font font28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot23.setAngleLabelFont(font28);
        java.awt.Paint paint30 = polarPlot23.getRadiusGridlinePaint();
        categoryAxis10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot23);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(1, axisLocation11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent13);
        categoryPlot0.clearDomainMarkers((int) (short) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, true);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray22, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset29, true);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range15, range31);
        java.lang.String str33 = range15.toString();
        org.jfree.data.Range range36 = org.jfree.data.Range.expand(range15, 0.0d, 0.2d);
        org.jfree.data.Range range39 = org.jfree.data.Range.shift(range15, (double) (byte) -1, false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Range[-1.0,10.0]" + "'", str33.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        java.lang.String str9 = textFragment8.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setUpperMargin((double) 1);
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis10.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis10.isTickLabelsVisible();
        boolean boolean19 = textFragment8.equals((java.lang.Object) categoryAxis10);
        int int20 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setUpperMargin((double) 1);
        categoryAxis23.clearCategoryLabelToolTips();
        categoryAxis23.setTickLabelsVisible(false);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis23.setLabelPaint((java.awt.Paint) color29);
        boolean boolean31 = categoryAxis23.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean33 = polarPlot32.isOutlineVisible();
        categoryAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot32);
        org.jfree.chart.util.Size2D size2D39 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 0.0d, (double) (short) 100, rectangleAnchor42);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle45.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = textTitle45.getPosition();
        double double49 = categoryAxis23.getCategoryStart((int) (byte) 100, (int) (byte) 10, rectangle2D43, rectangleEdge48);
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, 0.0d, (double) (short) 100, rectangleAnchor55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        try {
            org.jfree.chart.axis.AxisState axisState59 = categoryAxis10.draw(graphics2D21, (double) (byte) 10, rectangle2D43, rectangle2D56, rectangleEdge57, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-55.25000000000002d) + "'", double49 == (-55.25000000000002d));
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel((int) (byte) 0, attributedString3);
        java.lang.Object obj5 = null;
        boolean boolean6 = standardPieSectionLabelGenerator0.equals(obj5);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer((int) (short) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.setRangeWithMargins((double) 10L, (double) 10.0f);
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, (int) 'a', 100, (java.lang.Comparable) 100L, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "{0}");
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, true);
        org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset28, 1);
        pieSectionEntity14.setDataset(pieDataset32);
        java.lang.Comparable comparable34 = null;
        pieSectionEntity14.setSectionKey(comparable34);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(pieDataset32);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getItemLabelPadding();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        polarPlot0.setBackgroundAlpha((float) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot0.zoomDomainAxes((double) 3, (double) 100L, plotRenderingInfo8, point2D9);
        java.awt.Stroke stroke11 = polarPlot0.getAngleGridlineStroke();
        boolean boolean12 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        legendTitle5.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle5.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            legendTitle5.setItemLabelPadding(rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        java.awt.Shape shape2 = dateAxis1.getLeftArrow();
        double double3 = dateAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        dateAxis11.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis11.setUpperMargin((double) (byte) 100);
        dateAxis11.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis11, false);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement32 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment28, verticalAlignment29, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement32);
        boolean boolean34 = blockContainer33.isEmpty();
        java.util.List list35 = blockContainer33.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer33.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        boolean boolean39 = categoryPlot0.render(graphics2D27, rectangle2D36, 8, plotRenderingInfo38);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle5.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = java.awt.Color.BLACK;
        int int9 = color8.getRGB();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color8);
        int int11 = categoryPlot7.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot7.getDomainAxisLocation();
        double double13 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot7.removeChangeListener(plotChangeListener14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset30);
        categoryPlot7.setDataset(0, categoryDataset30);
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        boolean boolean34 = categoryPlot7.isOutlineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color37 = java.awt.Color.BLACK;
        int int38 = color37.getRGB();
        categoryPlot36.setRangeCrosshairPaint((java.awt.Paint) color37);
        int int40 = categoryPlot36.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot36.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color43 = java.awt.Color.BLACK;
        int int44 = color43.getRGB();
        categoryPlot42.setRangeCrosshairPaint((java.awt.Paint) color43);
        int int46 = categoryPlot42.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot42.getDomainAxisLocation();
        categoryPlot36.setRangeAxisLocation(axisLocation47);
        categoryPlot7.setRangeAxisLocation(2, axisLocation47);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777216) + "'", int9 == (-16777216));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-16777216) + "'", int38 == (-16777216));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-16777216) + "'", int44 == (-16777216));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(axisLocation47);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        java.util.List list7 = blockContainer5.getBlocks();
        blockContainer5.setWidth(0.4d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis5.setInverted(true);
        dateAxis5.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis5.setRange(0.0d, 10.0d);
        java.lang.Object obj14 = dateAxis5.clone();
        org.jfree.data.Range range15 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        dateAxis5.zoomRange((double) 1L, (double) 1L);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (-1L), (double) (short) -1, plotRenderingInfo10, point2D11);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray19, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        categoryPlot0.setDataset(categoryDataset26);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(sortOrder29);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.util.List list3 = categoryPlot0.getCategories();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleEdge.TOP");
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer((int) (short) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        java.awt.Paint paint12 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setRange(0.0d, 10.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = java.awt.Color.BLACK;
        int int12 = color11.getRGB();
        categoryPlot10.setRangeCrosshairPaint((java.awt.Paint) color11);
        int int14 = categoryPlot10.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot10.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot10.setFixedRangeAxisSpace(axisSpace17);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis21.setInverted(true);
        categoryPlot10.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset38, true);
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray53 = new java.lang.Number[][] { numberArray47, numberArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray53);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset54, true);
        org.jfree.data.Range range57 = org.jfree.data.Range.combine(range40, range56);
        dateAxis21.setRange(range40);
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis60.setInverted(true);
        java.awt.Stroke stroke63 = dateAxis60.getTickMarkStroke();
        java.awt.Shape shape64 = dateAxis60.getRightArrow();
        dateAxis60.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit67 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date68 = dateAxis60.calculateLowestVisibleTickValue(dateTickUnit67);
        java.util.Date date69 = dateAxis21.calculateLowestVisibleTickValue(dateTickUnit67);
        dateAxis1.setMaximumDate(date69);
        dateAxis1.setTickMarkInsideLength((float) 15);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16777216) + "'", int12 == (-16777216));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(dateTickUnit67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(date69);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = java.awt.Color.BLACK;
        int int11 = color10.getRGB();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color10);
        int int13 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot9.getOrientation();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        java.awt.Paint paint16 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation17);
        int int19 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16777216) + "'", int11 == (-16777216));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis4.setInverted(true);
        java.awt.Stroke stroke7 = dateAxis4.getTickMarkStroke();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = java.awt.Color.BLACK;
        int int11 = color10.getRGB();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color10);
        int int13 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot9.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot9.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis20.setInverted(true);
        categoryPlot9.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray30, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray46, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray52);
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset53, true);
        org.jfree.data.Range range56 = org.jfree.data.Range.combine(range39, range55);
        dateAxis20.setRange(range39);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis59.setInverted(true);
        java.awt.Stroke stroke62 = dateAxis59.getTickMarkStroke();
        java.awt.Shape shape63 = dateAxis59.getRightArrow();
        dateAxis59.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date67 = dateAxis59.calculateLowestVisibleTickValue(dateTickUnit66);
        java.util.Date date68 = dateAxis20.calculateLowestVisibleTickValue(dateTickUnit66);
        dateAxis4.setTickUnit(dateTickUnit66, false, false);
        java.text.DateFormat dateFormat72 = dateAxis4.getDateFormatOverride();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16777216) + "'", int11 == (-16777216));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(dateTickUnit66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNull(dateFormat72);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = multiplePiePlot15.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot15.getPieChart();
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle18.setBackgroundPaint((java.awt.Paint) color19);
        boolean boolean21 = horizontalAlignment0.equals((java.lang.Object) textTitle18);
        java.lang.String str22 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str22.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = piePlotState1.getInfo();
        double double4 = piePlotState1.getPieHRadius();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Color color6 = java.awt.Color.GRAY;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer((int) (short) 100, categoryItemRenderer9, true);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = java.awt.Color.BLACK;
        int int16 = color15.getRGB();
        categoryPlot14.setRangeCrosshairPaint((java.awt.Paint) color15);
        int int18 = categoryPlot14.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color21 = java.awt.Color.BLACK;
        int int22 = color21.getRGB();
        categoryPlot20.setRangeCrosshairPaint((java.awt.Paint) color21);
        int int24 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot20.getDomainAxisLocation();
        categoryPlot14.setRangeAxisLocation(1, axisLocation25);
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean28 = polarPlot27.isOutlineVisible();
        boolean boolean29 = polarPlot27.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        polarPlot27.setDataset(xYDataset30);
        java.awt.Font font32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot27.setAngleLabelFont(font32);
        categoryPlot14.setNoDataMessageFont(font32);
        categoryPlot0.setNoDataMessageFont(font32);
        boolean boolean36 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-16777216) + "'", int16 == (-16777216));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16777216) + "'", int22 == (-16777216));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        categoryPlot5.setRangeCrosshairValue((double) '4', true);
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot5.getDomainMarkers((int) (byte) 10, layer16);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis5.setInverted(true);
        dateAxis5.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis5.setRange(0.0d, 10.0d);
        java.lang.Object obj14 = dateAxis5.clone();
        org.jfree.data.Range range15 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        dateAxis5.centerRange((double) 1.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) shape7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = textTitle6.getPosition();
        java.lang.String str10 = textTitle6.getID();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 1, paint2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = java.awt.Color.BLACK;
        int int9 = color8.getRGB();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color8);
        int int11 = categoryPlot7.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot7.getDomainAxisLocation();
        double double13 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot7.removeChangeListener(plotChangeListener14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset30);
        categoryPlot7.setDataset(0, categoryDataset30);
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        java.awt.Stroke stroke34 = categoryPlot7.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot7.getDomainAxisForDataset(2);
        categoryPlot7.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777216) + "'", int9 == (-16777216));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(categoryAxis36);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        dateAxis1.setRangeWithMargins((-1.0d), (-1.0d));
        java.awt.Paint paint12 = dateAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Font font6 = legendTitle5.getItemFont();
        java.awt.Paint paint7 = legendTitle5.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = legendTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) (byte) -1, 100.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlignment(0);
        polarPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        legendTitle5.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle5.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle5.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean5 = verticalAlignment3.equals((java.lang.Object) stroke4);
        categoryAxis3D2.setTickMarkStroke(stroke4);
        dateAxis1.setAxisLineStroke(stroke4);
        double double8 = dateAxis1.getUpperBound();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setUpperMargin((double) 1);
        categoryAxis11.clearCategoryLabelToolTips();
        categoryAxis11.setTickLabelsVisible(false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis11.setLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = categoryAxis11.isTickLabelsVisible();
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean21 = polarPlot20.isOutlineVisible();
        categoryAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot20);
        org.jfree.chart.util.Size2D size2D27 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, 0.0d, (double) (short) 100, rectangleAnchor30);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle33.setToolTipText("");
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = textTitle33.getPosition();
        double double37 = categoryAxis11.getCategoryStart((int) (byte) 100, (int) (byte) 10, rectangle2D31, rectangleEdge36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color39 = java.awt.Color.BLACK;
        int int40 = color39.getRGB();
        categoryPlot38.setRangeCrosshairPaint((java.awt.Paint) color39);
        int int42 = categoryPlot38.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = categoryPlot38.getOrientation();
        java.awt.Paint paint44 = categoryPlot38.getRangeGridlinePaint();
        java.awt.Paint paint45 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot38.getRangeAxisEdge(4);
        try {
            java.util.List list48 = dateAxis1.refreshTicks(graphics2D9, axisState10, rectangle2D31, rectangleEdge47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-55.25000000000002d) + "'", double37 == (-55.25000000000002d));
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-16777216) + "'", int40 == (-16777216));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxisForDataset(100);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("VerticalAlignment.CENTER", "RectangleAnchor.BOTTOM");
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean2 = blockBorder0.equals((java.lang.Object) paint1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis5.setInverted(true);
        java.awt.Stroke stroke8 = dateAxis5.getTickMarkStroke();
        java.awt.Shape shape9 = dateAxis5.getRightArrow();
        dateAxis5.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date13 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis15.setInverted(true);
        java.awt.Stroke stroke18 = dateAxis15.getTickMarkStroke();
        java.awt.Shape shape19 = dateAxis15.getRightArrow();
        dateAxis15.setUpperMargin((double) 255);
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date23 = dateAxis15.calculateLowestVisibleTickValue(dateTickUnit22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.trimWidth((double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment28, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement31);
        boolean boolean33 = blockContainer32.isEmpty();
        java.util.List list34 = blockContainer32.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D35 = blockContainer32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets24.createOutsetRectangle(rectangle2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double38 = dateAxis5.dateToJava2D(date23, rectangle2D35, rectangleEdge37);
        try {
            blockBorder0.draw(graphics2D3, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 94.0d + "'", double26 == 94.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = java.awt.Color.yellow;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color6, (float) 100L, (-165), textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock10.calculateDimensions(graphics2D11);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        boolean boolean51 = xYPlot50.isRangeZoomable();
        org.jfree.chart.plot.PolarPlot polarPlot54 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint55 = polarPlot54.getBackgroundPaint();
        java.awt.Stroke stroke56 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) 1, paint55, stroke56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker57.setOutlineStroke(stroke58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color61 = java.awt.Color.BLACK;
        int int62 = color61.getRGB();
        categoryPlot60.setRangeCrosshairPaint((java.awt.Paint) color61);
        int int64 = categoryPlot60.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation65 = categoryPlot60.getDomainAxisLocation();
        double double66 = categoryPlot60.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener67 = null;
        categoryPlot60.removeChangeListener(plotChangeListener67);
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray81 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray82 = new java.lang.Number[][] { numberArray76, numberArray81 };
        org.jfree.data.category.CategoryDataset categoryDataset83 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray82);
        boolean boolean84 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset83);
        categoryPlot60.setDataset(0, categoryDataset83);
        valueMarker57.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot60);
        org.jfree.chart.util.Layer layer87 = null;
        try {
            xYPlot50.addDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker57, layer87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-16777216) + "'", int62 == (-16777216));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray81);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(categoryDataset83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isOutlineVisible();
        boolean boolean3 = polarPlot1.isSubplot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        polarPlot1.setDataset(xYDataset4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        polarPlot1.setAngleLabelFont(font6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.lang.Comparable comparable23 = multiplePiePlot22.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = multiplePiePlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6, (org.jfree.chart.plot.Plot) multiplePiePlot22, true);
        java.awt.Paint paint27 = jFreeChart26.getBackgroundPaint();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis29.setInverted(true);
        java.awt.Stroke stroke32 = dateAxis29.getTickMarkStroke();
        jFreeChart26.setBorderStroke(stroke32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "hi!", "UnitType.RELATIVE", "org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.ChartColor[r=3,g=0,b=100]]");
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5);
        boolean boolean7 = blockContainer6.isEmpty();
        org.jfree.chart.block.BlockFrame blockFrame8 = blockContainer6.getFrame();
        double double9 = blockContainer6.getContentXOffset();
        java.util.List list10 = blockContainer6.getBlocks();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = columnArrangement0.arrange(blockContainer6, graphics2D11, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(blockFrame8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Comparable comparable15 = multiplePiePlot14.getAggregatedItemsKey();
        java.awt.Font font16 = multiplePiePlot14.getNoDataMessageFont();
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot14.getDataExtractOrder();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(tableOrder17);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis11.setInverted(true);
        categoryPlot0.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setRightArrow(shape15);
        dateAxis11.setLabelURL("");
        try {
            dateAxis11.setRange((double) ' ', (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        int int12 = categoryPlot8.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation();
        double double14 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot8.removeChangeListener(plotChangeListener15);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset31);
        categoryPlot8.setDataset(0, categoryDataset31);
        valueMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = valueMarker7.getLabelOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel((int) (byte) 0, attributedString4);
        java.lang.Class<?> wildcardClass6 = standardPieSectionLabelGenerator1.getClass();
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextBlockAnchor.TOP_RIGHT", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(uRL7);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.pink;
        int int3 = color2.getGreen();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = multiplePiePlot19.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot19.getPieChart();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1, paint24, stroke25);
        jFreeChart21.setBorderPaint(paint24);
        java.awt.Image image28 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = chartChangeEvent31.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart21, chartChangeEventType32);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        try {
            jFreeChart21.handleClick((-16777216), (int) (byte) 10, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 175 + "'", int3 == 175);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation11);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean16 = blockBorder14.equals((java.lang.Object) paint15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean19 = verticalAlignment17.equals((java.lang.Object) stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint15, stroke18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        valueMarker20.notifyListeners(markerChangeEvent21);
        try {
            boolean boolean23 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color6, (float) '#');
        float float9 = textFragment8.getBaselineOffset();
        java.awt.Font font10 = textFragment8.getFont();
        java.awt.Font font11 = textFragment8.getFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 35.0f + "'", float9 == 35.0f);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        valueMarker7.notifyListeners(markerChangeEvent8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        valueMarker7.notifyListeners(markerChangeEvent10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        xYPlot50.mapDatasetToRangeAxis((int) (byte) -1, 15);
        org.jfree.chart.axis.AxisSpace axisSpace54 = xYPlot50.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNull(axisSpace54);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "", "", "hi!");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        boolean boolean19 = library4.equals((java.lang.Object) "");
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean19, jFreeChart20);
        java.lang.String str22 = chartChangeEvent21.toString();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=false]" + "'", str22.equals("org.jfree.chart.event.ChartChangeEvent[source=false]"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) stroke3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, 0.0d, 4.5d);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (-16777216));
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getRGB();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(1, axisLocation11);
        float float13 = categoryPlot0.getForegroundAlpha();
        java.awt.Paint paint14 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        int int16 = categoryPlot0.getIndexOf(categoryItemRenderer15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot0.setRenderer((int) (byte) 100, categoryItemRenderer18, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        valueMarker7.notifyListeners(markerChangeEvent8);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint13 = polarPlot12.getBackgroundPaint();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 1, paint13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker15.setOutlineStroke(stroke16);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        valueMarker15.setLabelPaint(paint18);
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        polarPlot20.setBackgroundImageAlignment(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
        polarPlot20.setDrawingSupplier(drawingSupplier25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        polarPlot20.rendererChanged(rendererChangeEvent27);
        boolean boolean29 = polarPlot20.isRadiusGridlinesVisible();
        java.awt.Stroke stroke30 = polarPlot20.getAngleGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1, paint18, stroke30);
        valueMarker7.setOutlineStroke(stroke30);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color4 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        textTitle3.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = null;
        polarPlot9.setAngleGridlineStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot9.getInsets();
        boolean boolean13 = textTitle3.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets12);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            lineBorder14.draw(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23, (double) '#');
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 20.0d + "'", number28.equals(20.0d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel((int) (byte) 0, attributedString4);
        java.lang.Class<?> wildcardClass6 = standardPieSectionLabelGenerator1.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("{0}");
        xYPlot50.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis72);
        xYPlot50.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PolarPlot polarPlot78 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint79 = polarPlot78.getBackgroundPaint();
        java.awt.Stroke stroke80 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker81 = new org.jfree.chart.plot.ValueMarker((double) 1, paint79, stroke80);
        java.awt.Stroke stroke82 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        valueMarker81.setOutlineStroke(stroke82);
        org.jfree.chart.util.Layer layer84 = null;
        try {
            xYPlot50.addDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker81, layer84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(stroke82);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot14.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot14.getPieChart();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart16.getPadding();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("Other");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Other");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.BLACK;
        int int7 = color6.getRGB();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color6);
        int int9 = categoryPlot5.getRangeAxisCount();
        boolean boolean10 = textTitle1.equals((java.lang.Object) categoryPlot5);
        java.awt.Color color11 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        java.awt.Paint paint13 = blockBorder12.getPaint();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, 0.0d);
        boolean boolean18 = blockBorder12.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16777216) + "'", int7 == (-16777216));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(4, (int) (byte) 100, 3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.removeChangeListener(plotChangeListener7);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        boolean boolean26 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke27 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean3 = blockBorder1.equals((java.lang.Object) paint2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean6 = verticalAlignment4.equals((java.lang.Object) stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint2, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getRGB();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color9);
        int int12 = categoryPlot8.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation();
        double double14 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot8.removeChangeListener(plotChangeListener15);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset31);
        categoryPlot8.setDataset(0, categoryDataset31);
        valueMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint38 = polarPlot37.getBackgroundPaint();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 1, paint38, stroke39);
        java.awt.Paint paint41 = valueMarker40.getOutlinePaint();
        valueMarker40.setValue((double) 10L);
        java.lang.Object obj44 = valueMarker40.clone();
        org.jfree.chart.util.Layer layer45 = null;
        try {
            boolean boolean46 = categoryPlot8.removeRangeMarker((-16777216), (org.jfree.chart.plot.Marker) valueMarker40, layer45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset14, true);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset30, true);
        org.jfree.data.Range range33 = org.jfree.data.Range.combine(range16, range32);
        java.lang.String str34 = range33.toString();
        double double35 = range33.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range33);
        double double37 = range33.getUpperBound();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Range[-1.0,10.0]" + "'", str34.equals("Range[-1.0,10.0]"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-1.0d) + "'", double35 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color2 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        textTitle1.setNotify(false);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke8 = null;
        polarPlot7.setAngleGridlineStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot7.getInsets();
        boolean boolean11 = textTitle1.equals((java.lang.Object) rectangleInsets10);
        textTitle1.setToolTipText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment15, (double) 0L, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement18);
        boolean boolean20 = blockContainer19.isEmpty();
        org.jfree.chart.block.BlockFrame blockFrame21 = blockContainer19.getFrame();
        textTitle1.setFrame(blockFrame21);
        boolean boolean23 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(blockFrame21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis52.setInverted(true);
        dateAxis52.setTickMarksVisible(false);
        dateAxis52.setAutoTickUnitSelection(false);
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray71 = new java.lang.Number[][] { numberArray65, numberArray70 };
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray71);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot73 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset72);
        java.lang.Comparable comparable74 = multiplePiePlot73.getAggregatedItemsKey();
        java.awt.Font font75 = multiplePiePlot73.getNoDataMessageFont();
        org.jfree.chart.axis.DateTickUnit dateTickUnit76 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean77 = multiplePiePlot73.equals((java.lang.Object) dateTickUnit76);
        java.util.Date date78 = dateAxis52.calculateLowestVisibleTickValue(dateTickUnit76);
        dateAxis35.setMinimumDate(date78);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertTrue("'" + comparable74 + "' != '" + "Other" + "'", comparable74.equals("Other"));
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertNotNull(dateTickUnit76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(date78);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        boolean boolean51 = xYPlot50.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        xYPlot50.setFixedRangeAxisSpace(axisSpace52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        xYPlot50.zoomDomainAxes((double) 2, plotRenderingInfo55, point2D56);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        piePlotState1.setPassesRequired((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        polarPlot1.setBackgroundImageAlignment(0);
        polarPlot1.setBackgroundAlpha((float) 0);
        polarPlot1.clearCornerTextItems();
        boolean boolean7 = objectList0.equals((java.lang.Object) polarPlot1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer((int) (short) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = java.awt.Color.BLACK;
        int int12 = color11.getRGB();
        categoryPlot10.setRangeCrosshairPaint((java.awt.Paint) color11);
        int int14 = categoryPlot10.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot10.getDomainAxisLocation();
        double double16 = categoryPlot10.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot10.removeChangeListener(plotChangeListener17);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray32);
        boolean boolean34 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        categoryPlot10.setDataset(0, categoryDataset33);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33, (double) '#');
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        categoryPlot0.setDataset((int) '#', categoryDataset33);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D(45.0d, (double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 0.0d, (double) (short) 100, rectangleAnchor48);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets42.createInsetRectangle(rectangle2D49, false, false);
        java.awt.geom.Point2D point2D53 = null;
        org.jfree.chart.plot.PlotState plotState54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        try {
            categoryPlot0.draw(graphics2D41, rectangle2D52, point2D53, plotState54, plotRenderingInfo55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16777216) + "'", int12 == (-16777216));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis1.setUpperMargin((double) (byte) 100);
        dateAxis1.setFixedAutoRange((double) 2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.pink;
        int int5 = color4.getGreen();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock7.setLineAlignment(horizontalAlignment8);
        java.util.List list10 = textBlock7.getLines();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean12 = textBlock7.equals((java.lang.Object) shape11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 10, 1.0d, (-1L), (-1L) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = multiplePiePlot28.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart30 = multiplePiePlot28.getPieChart();
        org.jfree.chart.title.TextTitle textTitle31 = jFreeChart30.getTitle();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle31.setBackgroundPaint((java.awt.Paint) color32);
        boolean boolean34 = horizontalAlignment13.equals((java.lang.Object) textTitle31);
        textBlock7.setLineAlignment(horizontalAlignment13);
        java.util.List list36 = textBlock7.getLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 175 + "'", int5 == 175);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(jFreeChart30);
        org.junit.Assert.assertNotNull(textTitle31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = java.awt.Color.BLACK;
        int int3 = color2.getRGB();
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color2);
        int int5 = categoryPlot1.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot1.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis12.setInverted(true);
        dateAxis12.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis12.setUpperMargin((double) (byte) 100);
        dateAxis12.setRangeWithMargins((-1.0d), (-1.0d));
        categoryPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getRGB();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color26);
        int int29 = categoryPlot25.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot25.getOrientation();
        categoryPlot25.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis35.setInverted(true);
        dateAxis35.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis35.setRange(0.0d, 10.0d);
        dateAxis35.setPositiveArrowVisible(false);
        dateAxis35.setAutoRangeMinimumSize(8.0d);
        categoryPlot25.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color52 = java.awt.Color.BLACK;
        int int53 = color52.getRGB();
        categoryPlot51.setRangeCrosshairPaint((java.awt.Paint) color52);
        int int55 = categoryPlot51.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = categoryPlot51.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot51.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace58);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis62.setInverted(true);
        categoryPlot51.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis62.setRightArrow(shape66);
        dateAxis62.setLabelURL("");
        int int70 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = xYPlot50.getRenderer((-1));
        org.jfree.chart.block.BlockBorder blockBorder74 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean76 = blockBorder74.equals((java.lang.Object) paint75);
        org.jfree.chart.util.VerticalAlignment verticalAlignment77 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke78 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean79 = verticalAlignment77.equals((java.lang.Object) stroke78);
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint75, stroke78);
        xYPlot50.setDomainCrosshairPaint(paint75);
        org.jfree.data.xy.XYDataset xYDataset82 = null;
        int int83 = xYPlot50.indexOf(xYDataset82);
        org.jfree.chart.axis.DateAxis dateAxis85 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis85.setInverted(true);
        dateAxis85.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis85.setUpperMargin((double) (byte) 100);
        dateAxis85.setFixedAutoRange((double) 255);
        org.jfree.data.Range range95 = xYPlot50.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis85);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16777216) + "'", int53 == (-16777216));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer72);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(verticalAlignment77);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNull(range95);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getRGB();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        double double8 = rectangleInsets7.getBottom();
        double double10 = rectangleInsets7.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-8.0d) + "'", double10 == (-8.0d));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        java.lang.String str3 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 35.0f, (double) 8);
        int int7 = pieLabelDistributor1.getItemCount();
        java.lang.String str8 = pieLabelDistributor1.toString();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord10 = pieLabelDistributor1.getPieLabelRecord((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = null;
        polarPlot0.setAngleGridlineStroke(stroke1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("{0}");
        dateAxis5.setInverted(true);
        dateAxis5.resizeRange((double) (byte) -1, (double) (byte) 0);
        dateAxis5.setRange(0.0d, 10.0d);
        java.lang.Object obj14 = dateAxis5.clone();
        org.jfree.data.Range range15 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.Plot plot16 = dateAxis5.getPlot();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(plot16);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }
}

