import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        java.util.Date date4 = day2.getStart();
        int int5 = day2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.fireSeriesChanged();
        try {
            timeSeries4.removeAgedItems(1560192680024L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries4.removeChangeListener(seriesChangeListener9);
        timeSeries4.setMaximumItemCount(1900);
        java.lang.String str13 = timeSeries4.getRangeDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        long long16 = year14.getFirstMillisecond();
        java.lang.String str17 = year14.toString();
        long long18 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        int int20 = year14.getYear();
        long long21 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year14.previous();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        try {
            timeSeries4.add(regularTimePeriod22, (double) 1559372400000L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long3 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        boolean boolean8 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries7);
//        java.lang.Object obj9 = timeSeriesDataItem5.clone();
//        java.lang.Object obj10 = null;
//        int int11 = timeSeriesDataItem5.compareTo(obj10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        int int15 = spreadsheetDate13.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int18 = spreadsheetDate17.getYYYY();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        int int21 = day19.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        boolean boolean23 = spreadsheetDate17.isOnOrAfter(serialDate22);
//        boolean boolean24 = spreadsheetDate13.isBefore(serialDate22);
//        boolean boolean25 = timeSeriesDataItem5.equals((java.lang.Object) spreadsheetDate13);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int29 = spreadsheetDate28.getYYYY();
//        java.lang.String str30 = spreadsheetDate28.toString();
//        boolean boolean31 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int32 = spreadsheetDate28.getYYYY();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test05");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = spreadsheetDate10.equals(obj21);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192758822L + "'", long15 == 1560192758822L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        int int9 = month7.getMonth();
        boolean boolean10 = day2.equals((java.lang.Object) month7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        int int16 = month7.compareTo((java.lang.Object) regularTimePeriod15);
        java.lang.String str17 = month7.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "January 2019" + "'", str17.equals("January 2019"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.lang.String str2 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setMaximumItemAge((long) (byte) 100);
        java.lang.String str9 = timeSeries4.getDescription();
        java.lang.String str10 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test12");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getSerialIndex();
//        boolean boolean7 = month4.equals((java.lang.Object) long6);
//        boolean boolean8 = spreadsheetDate1.equals((java.lang.Object) long6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
//        timeSeries13.setDomainDescription("");
//        boolean boolean16 = timeSeries13.isEmpty();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
//        timeSeries21.setDomainDescription("");
//        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        java.lang.Object obj25 = timeSeries21.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        java.lang.String str29 = timeSeries21.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192758935L + "'", long6 == 1560192758935L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        boolean boolean9 = day5.equals((java.lang.Object) 6);
//        org.jfree.data.time.SerialDate serialDate10 = day5.getSerialDate();
//        java.lang.String str11 = serialDate10.toString();
//        serialDate10.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(2019, serialDate10);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate15);
//        int int17 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class8);
        timeSeries9.setDomainDescription("");
        boolean boolean12 = timeSeries9.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.Comparable comparable16 = timeSeries15.getKey();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        java.util.Collection collection19 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        boolean boolean20 = year0.equals((java.lang.Object) timeSeries15);
        java.lang.Class class21 = timeSeries15.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        int int29 = day28.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) 1560192673353L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + true + "'", comparable16.equals(true));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        java.util.Date date3 = spreadsheetDate2.toDate();
        int int4 = spreadsheetDate2.getYYYY();
        int int5 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date7 = spreadsheetDate2.toDate();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test16");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getSerialIndex();
//        boolean boolean7 = month4.equals((java.lang.Object) long6);
//        boolean boolean8 = spreadsheetDate1.equals((java.lang.Object) long6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate13);
//        boolean boolean15 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        int int19 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate23.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean26 = spreadsheetDate1.isInRange(serialDate20, serialDate25);
//        int int27 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int31 = spreadsheetDate30.getYYYY();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
//        int int34 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        boolean boolean36 = spreadsheetDate30.isOnOrAfter(serialDate35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date40 = spreadsheetDate39.toDate();
//        int int41 = spreadsheetDate39.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date44 = spreadsheetDate43.toDate();
//        int int45 = spreadsheetDate43.toSerial();
//        int int46 = spreadsheetDate43.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int49 = spreadsheetDate48.getYYYY();
//        java.lang.String str50 = spreadsheetDate48.toString();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        long long53 = fixedMillisecond52.getSerialIndex();
//        boolean boolean54 = month51.equals((java.lang.Object) long53);
//        boolean boolean55 = spreadsheetDate48.equals((java.lang.Object) long53);
//        boolean boolean57 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate48, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int60 = spreadsheetDate59.getYYYY();
//        java.lang.String str61 = spreadsheetDate59.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate65 = spreadsheetDate63.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean67 = spreadsheetDate43.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate59, (org.jfree.data.time.SerialDate) spreadsheetDate63, 7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate70);
//        spreadsheetDate70.setDescription("2019");
//        int int75 = spreadsheetDate70.getDayOfWeek();
//        int int76 = spreadsheetDate70.toSerial();
//        boolean boolean77 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        boolean boolean79 = spreadsheetDate1.isInRange(serialDate37, (org.jfree.data.time.SerialDate) spreadsheetDate59, (int) (byte) 1);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.previous();
//        int int82 = day80.getDayOfMonth();
//        boolean boolean84 = day80.equals((java.lang.Object) 6);
//        org.jfree.data.time.SerialDate serialDate85 = day80.getSerialDate();
//        java.util.Date date86 = day80.getStart();
//        boolean boolean87 = spreadsheetDate59.equals((java.lang.Object) day80);
//        try {
//            org.jfree.data.time.SerialDate serialDate89 = spreadsheetDate59.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192759110L + "'", long6 == 1560192759110L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560192759122L + "'", long53 == 1560192759122L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1900 + "'", int60 == 1900);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2 + "'", int75 == 2);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 100 + "'", int76 == 100);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 10 + "'", int82 == 10);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test17");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long2 = fixedMillisecond1.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond1.peg(calendar3);
//        long long5 = fixedMillisecond1.getFirstMillisecond();
//        long long6 = fixedMillisecond1.getMiddleMillisecond();
//        long long7 = fixedMillisecond1.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        int int12 = fixedMillisecond1.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        long long14 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) ' ');
//        timeSeriesDataItem16.setValue((java.lang.Number) 1560192716190L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
//    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test18");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class4);
//        timeSeries5.setDomainDescription("");
//        boolean boolean8 = timeSeries5.isEmpty();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
//        timeSeries13.setDomainDescription("");
//        java.util.Collection collection16 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        timeSeries5.fireSeriesChanged();
//        timeSeries5.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        boolean boolean22 = year20.equals((java.lang.Object) (-1L));
//        int int24 = year20.compareTo((java.lang.Object) 10L);
//        long long25 = year20.getLastMillisecond();
//        long long26 = year20.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date30 = spreadsheetDate29.toDate();
//        int int31 = spreadsheetDate29.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date34 = spreadsheetDate33.toDate();
//        int int35 = spreadsheetDate33.toSerial();
//        int int36 = spreadsheetDate33.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int39 = spreadsheetDate38.getYYYY();
//        java.lang.String str40 = spreadsheetDate38.toString();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        long long43 = fixedMillisecond42.getSerialIndex();
//        boolean boolean44 = month41.equals((java.lang.Object) long43);
//        boolean boolean45 = spreadsheetDate38.equals((java.lang.Object) long43);
//        boolean boolean47 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate38, (int) (byte) 1);
//        boolean boolean48 = year20.equals((java.lang.Object) spreadsheetDate33);
//        int int49 = spreadsheetDate33.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int54 = spreadsheetDate53.getYYYY();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
//        int int57 = day55.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate58 = day55.getSerialDate();
//        boolean boolean59 = spreadsheetDate53.isOnOrAfter(serialDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date62 = spreadsheetDate61.toDate();
//        int int63 = spreadsheetDate61.getYYYY();
//        int int64 = spreadsheetDate61.toSerial();
//        boolean boolean65 = spreadsheetDate53.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(1969, (org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate66);
//        boolean boolean68 = spreadsheetDate33.isOnOrAfter(serialDate66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int73 = spreadsheetDate72.getYYYY();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day74.previous();
//        int int76 = day74.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate77 = day74.getSerialDate();
//        boolean boolean78 = spreadsheetDate72.isOnOrAfter(serialDate77);
//        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate72);
//        java.lang.Class class85 = null;
//        org.jfree.data.time.TimeSeries timeSeries86 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class85);
//        timeSeries86.setDomainDescription("");
//        boolean boolean89 = timeSeries86.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries86.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond90, (org.jfree.data.time.RegularTimePeriod) year91);
//        timeSeries86.clear();
//        java.lang.Class<?> wildcardClass94 = timeSeries86.getClass();
//        org.jfree.data.time.TimeSeries timeSeries95 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate79, "org.jfree.data.general.SeriesException: Time", "hi!", (java.lang.Class) wildcardClass94);
//        org.jfree.data.time.SerialDate serialDate96 = org.jfree.data.time.SerialDate.addMonths(12, serialDate79);
//        boolean boolean97 = spreadsheetDate33.isOnOrBefore(serialDate79);
//        try {
//            org.jfree.data.time.SerialDate serialDate98 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-458), serialDate79);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1562097599999L + "'", long26 == 1562097599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560192759172L + "'", long43 == 1560192759172L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 9 + "'", int49 == 9);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1900 + "'", int54 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1900 + "'", int63 == 1900);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1900 + "'", int73 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 10 + "'", int76 == 10);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
//        org.junit.Assert.assertNotNull(timeSeries92);
//        org.junit.Assert.assertNotNull(wildcardClass94);
//        org.junit.Assert.assertNotNull(serialDate96);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
//    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test19");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.util.Date date3 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int6 = spreadsheetDate5.getYYYY();
//        java.lang.String str7 = spreadsheetDate5.toString();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getSerialIndex();
//        boolean boolean11 = month8.equals((java.lang.Object) long10);
//        boolean boolean12 = spreadsheetDate5.equals((java.lang.Object) long10);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        int int16 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate17);
//        boolean boolean19 = spreadsheetDate5.isOn(serialDate18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        int int23 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate27.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean30 = spreadsheetDate5.isInRange(serialDate24, serialDate29);
//        boolean boolean31 = spreadsheetDate1.isOnOrAfter(serialDate24);
//        try {
//            org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate1.getPreviousDayOfWeek((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560192759200L + "'", long10 == 1560192759200L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test20");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate8);
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        int int14 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate15);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date21 = spreadsheetDate20.toDate();
//        int int22 = spreadsheetDate20.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
//        int int26 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate27);
//        boolean boolean29 = spreadsheetDate20.isOnOrBefore(serialDate27);
//        boolean boolean31 = spreadsheetDate1.isInRange(serialDate16, serialDate27, (int) '#');
//        int int32 = spreadsheetDate1.toSerial();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class36);
//        timeSeries37.setDomainDescription("");
//        boolean boolean40 = timeSeries37.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) year42);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond41.getLastMillisecond(calendar44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond41.getLastMillisecond(calendar46);
//        long long48 = fixedMillisecond41.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 2019);
//        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeriesDataItem50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int54 = spreadsheetDate53.getYYYY();
//        java.lang.String str55 = spreadsheetDate53.toString();
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        long long58 = fixedMillisecond57.getSerialIndex();
//        boolean boolean59 = month56.equals((java.lang.Object) long58);
//        boolean boolean60 = spreadsheetDate53.equals((java.lang.Object) long58);
//        int int61 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560192759223L + "'", long45 == 1560192759223L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560192759223L + "'", long47 == 1560192759223L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560192759223L + "'", long48 == 1560192759223L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1900 + "'", int54 == 1900);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "9-April-1900" + "'", str55.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560192759226L + "'", long58 == 1560192759226L);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.lang.String str6 = year5.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        boolean boolean6 = timeSeries4.getNotify();
        java.lang.String str7 = timeSeries4.getDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1561964399999L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        boolean boolean8 = timeSeries7.getNotify();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (short) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) (-1L));
        long long11 = year8.getLastMillisecond();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
        timeSeries16.setDomainDescription("");
        boolean boolean19 = timeSeries16.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries16.clear();
        java.lang.Class<?> wildcardClass24 = timeSeries16.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        java.util.Date date30 = regularTimePeriod29.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.previous();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date39, timeZone40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date39, timeZone42);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date36, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone42);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, (java.lang.Class) wildcardClass24);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem7, (java.lang.Class) wildcardClass24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries48.removeChangeListener(seriesChangeListener49);
        java.util.List list51 = timeSeries48.getItems();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 32L + "'", long34 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertNotNull(list51);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.util.List list12 = timeSeries4.getItems();
        java.lang.String str13 = timeSeries4.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long16 = fixedMillisecond15.getSerialIndex();
        java.util.Calendar calendar17 = null;
        fixedMillisecond15.peg(calendar17);
        long long19 = fixedMillisecond15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond15.next();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 32L + "'", long19 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long2 = fixedMillisecond1.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond1.peg(calendar3);
//        long long5 = fixedMillisecond1.getFirstMillisecond();
//        long long6 = fixedMillisecond1.getMiddleMillisecond();
//        long long7 = fixedMillisecond1.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        int int12 = fixedMillisecond1.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        java.lang.Object obj14 = timeSeries13.clone();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.util.Date date16 = year15.getStart();
//        long long17 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) 1561964399999L);
//        try {
//            timeSeries13.add(timeSeriesDataItem19);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        int int18 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long28 = fixedMillisecond27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (byte) -1);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.previous();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        long long39 = day38.getMiddleMillisecond();
        int int40 = fixedMillisecond27.compareTo((java.lang.Object) day38);
        int int41 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day38);
        java.lang.Object obj42 = null;
        boolean boolean43 = day38.equals(obj42);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 32L + "'", long35 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-14400001L) + "'", long39 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        long long5 = fixedMillisecond1.getSerialIndex();
        long long6 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond1.getStart();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
//        timeSeries8.setDomainDescription("");
//        boolean boolean11 = timeSeries8.isEmpty();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
//        timeSeries16.setDomainDescription("");
//        java.util.Collection collection19 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        boolean boolean20 = timeSeries8.getNotify();
//        boolean boolean21 = spreadsheetDate1.equals((java.lang.Object) timeSeries8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.previous();
//        java.util.Date date27 = regularTimePeriod26.getEnd();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.util.Date date30 = year29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30, timeZone31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30, timeZone33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date27, timeZone33);
//        org.jfree.data.time.Year year36 = month35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long40 = fixedMillisecond39.getSerialIndex();
//        java.util.Calendar calendar41 = null;
//        fixedMillisecond39.peg(calendar41);
//        long long43 = fixedMillisecond39.getFirstMillisecond();
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        long long45 = fixedMillisecond39.getLastMillisecond();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        int int48 = day46.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
//        int int50 = fixedMillisecond39.compareTo((java.lang.Object) day46);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int53 = spreadsheetDate52.getYYYY();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.previous();
//        int int56 = day54.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate57 = day54.getSerialDate();
//        boolean boolean58 = spreadsheetDate52.isOnOrAfter(serialDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int61 = spreadsheetDate60.getYYYY();
//        org.jfree.data.time.SerialDate serialDate62 = serialDate57.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        int int63 = fixedMillisecond39.compareTo((java.lang.Object) serialDate62);
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class67);
//        timeSeries68.setRangeDescription("hi!");
//        timeSeries68.setMaximumItemAge((long) (byte) 100);
//        timeSeries68.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond76.next();
//        java.util.Date date78 = fixedMillisecond76.getStart();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
//        int int81 = day79.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate82 = day79.getSerialDate();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean84 = day79.equals((java.lang.Object) timeZone83);
//        java.lang.Object obj85 = null;
//        int int86 = day79.compareTo(obj85);
//        long long87 = day79.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries68.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, (org.jfree.data.time.RegularTimePeriod) day79);
//        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond();
//        long long91 = fixedMillisecond90.getSerialIndex();
//        boolean boolean92 = month89.equals((java.lang.Object) long91);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = month89.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = timeSeries88.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month89, (java.lang.Number) 1560192688835L);
//        org.jfree.data.time.Year year96 = month89.getYear();
//        org.jfree.data.time.TimeSeries timeSeries97 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) month89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = null;
//        try {
//            int int99 = timeSeries8.getIndex(regularTimePeriod98);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 32L + "'", long40 == 32L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 32L + "'", long43 == 32L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 32L + "'", long44 == 32L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 32L + "'", long45 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1900 + "'", int53 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1900 + "'", int61 == 1900);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1560150000000L + "'", long87 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1560192760194L + "'", long91 == 1560192760194L);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertNull(timeSeriesDataItem95);
//        org.junit.Assert.assertNotNull(year96);
//        org.junit.Assert.assertNotNull(timeSeries97);
//    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test31");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getSerialIndex();
//        boolean boolean7 = month4.equals((java.lang.Object) long6);
//        boolean boolean8 = spreadsheetDate1.equals((java.lang.Object) long6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate13);
//        boolean boolean15 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        int int19 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate23.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean26 = spreadsheetDate1.isInRange(serialDate20, serialDate25);
//        int int27 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int31 = spreadsheetDate30.getYYYY();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
//        int int34 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        boolean boolean36 = spreadsheetDate30.isOnOrAfter(serialDate35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date40 = spreadsheetDate39.toDate();
//        int int41 = spreadsheetDate39.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date44 = spreadsheetDate43.toDate();
//        int int45 = spreadsheetDate43.toSerial();
//        int int46 = spreadsheetDate43.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int49 = spreadsheetDate48.getYYYY();
//        java.lang.String str50 = spreadsheetDate48.toString();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        long long53 = fixedMillisecond52.getSerialIndex();
//        boolean boolean54 = month51.equals((java.lang.Object) long53);
//        boolean boolean55 = spreadsheetDate48.equals((java.lang.Object) long53);
//        boolean boolean57 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate48, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int60 = spreadsheetDate59.getYYYY();
//        java.lang.String str61 = spreadsheetDate59.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate65 = spreadsheetDate63.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean67 = spreadsheetDate43.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate59, (org.jfree.data.time.SerialDate) spreadsheetDate63, 7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate70);
//        spreadsheetDate70.setDescription("2019");
//        int int75 = spreadsheetDate70.getDayOfWeek();
//        int int76 = spreadsheetDate70.toSerial();
//        boolean boolean77 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        boolean boolean79 = spreadsheetDate1.isInRange(serialDate37, (org.jfree.data.time.SerialDate) spreadsheetDate59, (int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate81 = spreadsheetDate1.getFollowingDayOfWeek(3);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192760212L + "'", long6 == 1560192760212L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560192760222L + "'", long53 == 1560192760222L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1900 + "'", int60 == 1900);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2 + "'", int75 == 2);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 100 + "'", int76 == 100);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertNotNull(serialDate81);
//    }
//}

