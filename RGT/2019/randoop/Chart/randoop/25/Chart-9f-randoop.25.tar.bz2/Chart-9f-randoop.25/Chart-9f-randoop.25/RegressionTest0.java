import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        try {
            timeSeries4.delete((int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        try {
            timeSeries4.setMaximumItemAge((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries4.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = null;
        try {
            timeSeries4.add(timeSeriesDataItem7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(5, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        try {
            java.lang.Number number8 = timeSeries4.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.addAndOrUpdate(timeSeries7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        try {
            java.lang.Number number17 = timeSeries12.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries4.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        try {
            timeSeries4.removeAgedItems(1L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries4.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setMaximumItemAge((long) (byte) 100);
        timeSeries4.setNotify(true);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) (-1L));
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class3 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries(comparable0, "SerialDate.weekInMonthToString(): invalid code.", "hi!", class3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            java.lang.Number number5 = timeSeries3.getValue(regularTimePeriod4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getLastMillisecond();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        try {
            timeSeries4.update(100, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        timeSeries4.setDomainDescription("");
        java.lang.Class class19 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        long long22 = year20.getSerialIndex();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year20, (double) 1L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) (-1L));
        int int11 = year7.compareTo((java.lang.Object) 10L);
        long long12 = year7.getLastMillisecond();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year7, 1.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2019, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone5);
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date0, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        int int5 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getSerialIndex();
//        boolean boolean3 = month0.equals((java.lang.Object) long2);
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = month0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192664978L + "'", long2 == 1560192664978L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries4.getTimePeriod(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        int int3 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate4);
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, 0.0d);
        try {
            java.lang.Number number20 = timeSeries12.getValue(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long9 = fixedMillisecond8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (byte) -1);
        java.lang.Object obj12 = timeSeriesDataItem11.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class16);
        timeSeries17.setRangeDescription("hi!");
        timeSeries17.setMaximumItemAge((long) (byte) 100);
        boolean boolean22 = timeSeriesDataItem11.equals((java.lang.Object) timeSeries17);
        try {
            timeSeries4.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        java.lang.String str5 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        int int8 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day6, (double) (byte) 0, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = month9.getLastMillisecond();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1549007999999L + "'", long12 == 1549007999999L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        long long3 = year1.getFirstMillisecond();
        java.lang.String str4 = year1.toString();
        long long5 = year1.getLastMillisecond();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
//        int int4 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 0, serialDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        java.util.Date date4 = day2.getStart();
        int int5 = day2.getYear();
        int int6 = day2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("9-April-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
        org.jfree.data.time.Year year14 = month13.getYear();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year14, (double) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(year14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date5, timeZone11);
        boolean boolean15 = month13.equals((java.lang.Object) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.Year year4 = month3.getYear();
        long long5 = month3.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month3.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, 12, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        try {
            timeSeries4.setMaximumItemCount((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long19 = fixedMillisecond18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) (byte) -1);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        try {
            timeSeries4.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 32L + "'", long19 == 32L);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        java.lang.String str12 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(4, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "April" + "'", str2.equals("April"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        timeSeries4.setDomainDescription("");
        java.lang.Class class19 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        boolean boolean23 = year20.equals((java.lang.Object) day22);
        java.util.Date date24 = day22.getStart();
        int int25 = day22.getYear();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day22, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long10 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) -1);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = year0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day2.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        int int8 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate9);
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean13 = day2.equals((java.lang.Object) (byte) 1);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day2.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.String str3 = spreadsheetDate1.toString();
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getFollowingDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        int int5 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate6.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int3 = spreadsheetDate2.getYYYY();
        java.lang.String str4 = spreadsheetDate2.toString();
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Time");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable throwable5 = null;
        try {
            seriesException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Nearest");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(8, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, 0.0d);
        int int19 = year16.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.lang.String str25 = day24.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        int int27 = timeSeriesDataItem21.compareTo((java.lang.Object) regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, 6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
//        int int4 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) 'a', serialDate5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.util.Date date0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class4);
        timeSeries5.setDomainDescription("");
        boolean boolean8 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries5.clear();
        java.lang.Class<?> wildcardClass13 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.previous();
        java.util.Date date19 = regularTimePeriod18.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.previous();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date28, timeZone29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date28, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date25, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone31);
        try {
            org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date0, timeZone31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 32L + "'", long23 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        java.lang.String str6 = regularTimePeriod4.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        try {
            java.lang.Number number13 = timeSeries4.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date22 = spreadsheetDate21.toDate();
//        int int23 = spreadsheetDate21.toSerial();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
//        int int27 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate28);
//        boolean boolean30 = spreadsheetDate21.isOnOrBefore(serialDate28);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
//        int int34 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate35);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date41 = spreadsheetDate40.toDate();
//        int int42 = spreadsheetDate40.toSerial();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
//        int int46 = day44.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate47);
//        boolean boolean49 = spreadsheetDate40.isOnOrBefore(serialDate47);
//        boolean boolean51 = spreadsheetDate21.isInRange(serialDate36, serialDate47, (int) '#');
//        int int52 = spreadsheetDate21.toSerial();
//        boolean boolean53 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        try {
//            org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate21.getPreviousDayOfWeek(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192671860L + "'", long15 == 1560192671860L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, 0.0d);
        int int19 = year16.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar24 = null;
        fixedMillisecond23.peg(calendar24);
        boolean boolean26 = timeSeriesDataItem21.equals((java.lang.Object) calendar24);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.removeAgedItems((long) (byte) 10, false);
        timeSeries1.setMaximumItemAge(100L);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "hi!" + "'", comparable7.equals("hi!"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month3.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
//        int int4 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        try {
            timeSeries1.delete(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate8);
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        java.lang.Object obj11 = null;
//        try {
//            int int12 = spreadsheetDate1.compareTo(obj11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
        timeSeries21.setDomainDescription("");
        boolean boolean24 = timeSeries21.isEmpty();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class28);
        timeSeries29.setDomainDescription("");
        java.util.Collection collection32 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries12.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = null;
        try {
            timeSeries21.add(timeSeriesDataItem34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
//        timeSeries12.setDomainDescription("");
//        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Object obj16 = timeSeries12.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        int int18 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        long long19 = fixedMillisecond17.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560192673678L + "'", long19 == 1560192673678L);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.util.List list12 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long15 = fixedMillisecond14.getSerialIndex();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate3 = null;
        try {
            int int4 = spreadsheetDate1.compare(serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-460));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setDescription("Nearest");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        java.util.Collection collection14 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy(2019, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + true + "'", comparable11.equals(true));
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "February" + "'", str1.equals("February"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date5, timeZone11);
        java.lang.String str14 = month13.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "December 1969" + "'", str14.equals("December 1969"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9999, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        timeSeries4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) (-1L));
        int int23 = year19.compareTo((java.lang.Object) 10L);
        long long24 = year19.getLastMillisecond();
        long long25 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        int int5 = month4.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        java.lang.String str9 = timeSeries3.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        long long5 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate8);
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        int int14 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate15);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date21 = spreadsheetDate20.toDate();
//        int int22 = spreadsheetDate20.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
//        int int26 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate27);
//        boolean boolean29 = spreadsheetDate20.isOnOrBefore(serialDate27);
//        boolean boolean31 = spreadsheetDate1.isInRange(serialDate16, serialDate27, (int) '#');
//        try {
//            org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate1.getNearestDayOfWeek((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192675041L + "'", long1 == 1560192675041L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.next();
        java.util.Date date10 = fixedMillisecond8.getStart();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 24229L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month9);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("December 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int3 = spreadsheetDate2.getYYYY();
//        java.lang.String str4 = spreadsheetDate2.toString();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getSerialIndex();
//        boolean boolean8 = month5.equals((java.lang.Object) long7);
//        boolean boolean9 = spreadsheetDate2.equals((java.lang.Object) long7);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class13);
//        timeSeries14.setDomainDescription("");
//        boolean boolean17 = timeSeries14.isEmpty();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class21);
//        timeSeries22.setDomainDescription("");
//        java.util.Collection collection25 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries22);
//        java.lang.Object obj26 = timeSeries22.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        int int28 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        boolean boolean29 = spreadsheetDate2.equals((java.lang.Object) timeSeries22);
//        try {
//            org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560192675205L + "'", long7 == 1560192675205L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) 1549007999999L);
        timeSeriesDataItem4.setValue((java.lang.Number) 24229L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(6, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June" + "'", str2.equals("June"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 6, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Last");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        timeSeries4.setDescription("");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = null;
        try {
            timeSeries4.add(timeSeriesDataItem7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) 1549007999999L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        boolean boolean12 = timeSeriesDataItem4.equals((java.lang.Object) day9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem4.getPeriod();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        timeSeries4.clear();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        int int15 = day13.getMonth();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day13, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.lang.Class<?> wildcardClass12 = timeSeries4.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.previous();
        java.util.Date date18 = regularTimePeriod17.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date27, timeZone28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date27, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date24, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone30);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date18);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 32L + "'", long22 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        long long4 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
//        timeSeries12.setDomainDescription("");
//        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        boolean boolean21 = year19.equals((java.lang.Object) (-1L));
//        int int23 = year19.compareTo((java.lang.Object) 10L);
//        long long24 = year19.getLastMillisecond();
//        long long25 = year19.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
//        java.util.Date date27 = year19.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int32 = spreadsheetDate31.getYYYY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        int int35 = day33.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day33.getSerialDate();
//        boolean boolean37 = spreadsheetDate31.isOnOrAfter(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate31);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class44);
//        timeSeries45.setDomainDescription("");
//        boolean boolean48 = timeSeries45.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (org.jfree.data.time.RegularTimePeriod) year50);
//        timeSeries45.clear();
//        java.lang.Class<?> wildcardClass53 = timeSeries45.getClass();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate38, "org.jfree.data.general.SeriesException: Time", "hi!", (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year28, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date58 = spreadsheetDate57.toDate();
//        int int59 = spreadsheetDate57.toSerial();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.previous();
//        int int63 = day61.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate64 = day61.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate64);
//        boolean boolean66 = spreadsheetDate57.isOnOrBefore(serialDate64);
//        boolean boolean67 = year28.equals((java.lang.Object) boolean66);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1530561599999L + "'", long6 == 1530561599999L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.lang.Object obj10 = timeSeries4.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries4.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.lang.String str9 = fixedMillisecond8.toString();
        long long10 = fixedMillisecond8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        try {
            timeSeries4.add(regularTimePeriod11, (java.lang.Number) 1549007999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str9.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
        java.lang.Number number17 = null;
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number17, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        timeSeries4.setMaximumItemAge((long) (byte) 100);
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
//        java.util.Date date14 = fixedMillisecond12.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        int int17 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = day15.equals((java.lang.Object) timeZone19);
//        java.lang.Object obj21 = null;
//        int int22 = day15.compareTo(obj21);
//        long long23 = day15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day15);
//        try {
//            timeSeries24.setMaximumItemCount((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560150000000L + "'", long23 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        java.util.List list11 = timeSeries10.getItems();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long3 = fixedMillisecond2.getSerialIndex();
        int int4 = year0.compareTo((java.lang.Object) fixedMillisecond2);
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int22 = spreadsheetDate21.getYYYY();
//        java.lang.String str23 = spreadsheetDate21.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate25.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean29 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate25, 7);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class33);
//        timeSeries34.setDomainDescription("");
//        boolean boolean37 = timeSeries34.isEmpty();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class41);
//        timeSeries42.setDomainDescription("");
//        java.util.Collection collection45 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries42);
//        java.lang.Class class49 = null;
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class49);
//        timeSeries50.setDomainDescription("");
//        boolean boolean53 = timeSeries50.isEmpty();
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class57);
//        timeSeries58.setDomainDescription("");
//        java.util.Collection collection61 = timeSeries50.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        timeSeries50.fireSeriesChanged();
//        timeSeries50.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.util.Collection collection65 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries50);
//        boolean boolean66 = spreadsheetDate25.equals((java.lang.Object) collection65);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192679722L + "'", long15 == 1560192679722L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(collection61);
//        org.junit.Assert.assertNotNull(collection65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getSerialIndex();
//        boolean boolean7 = month4.equals((java.lang.Object) long6);
//        boolean boolean8 = spreadsheetDate1.equals((java.lang.Object) long6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
//        timeSeries13.setDomainDescription("");
//        boolean boolean16 = timeSeries13.isEmpty();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
//        timeSeries21.setDomainDescription("");
//        java.util.Collection collection24 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        java.lang.Object obj25 = timeSeries21.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        try {
//            timeSeries21.setMaximumItemCount((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192679953L + "'", long6 == 1560192679953L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2019);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 29 + "'", int1 == 29);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        long long5 = fixedMillisecond1.getLastMillisecond();
        long long6 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long2 = fixedMillisecond1.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond1.peg(calendar3);
//        long long5 = fixedMillisecond1.getFirstMillisecond();
//        long long6 = fixedMillisecond1.getMiddleMillisecond();
//        long long7 = fixedMillisecond1.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        int int12 = fixedMillisecond1.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) 10);
//        java.lang.Number number15 = timeSeriesDataItem14.getValue();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0d + "'", number15.equals(10.0d));
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        timeSeries4.setMaximumItemAge((long) 9999);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) (-1L));
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20, timeZone21);
        org.jfree.data.time.Year year23 = month22.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        boolean boolean30 = year23.equals((java.lang.Object) date29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year23.previous();
        long long32 = regularTimePeriod31.getMiddleMillisecond();
        try {
            org.jfree.data.time.TimeSeries timeSeries33 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, regularTimePeriod31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 32L + "'", long27 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1530561599999L + "'", long32 == 1530561599999L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        java.lang.String str17 = timeSeries4.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries4.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day22, (double) 1560192675323L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setMaximumItemAge((long) (byte) 100);
        timeSeries4.setNotify(true);
        try {
            java.lang.Number number12 = timeSeries4.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int22 = spreadsheetDate21.getYYYY();
//        java.lang.String str23 = spreadsheetDate21.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate25.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean29 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate25, 7);
//        int int30 = spreadsheetDate5.toSerial();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192680739L + "'", long15 == 1560192680739L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long9 = fixedMillisecond8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (byte) -1);
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        int int3 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean6 = day1.equals((java.lang.Object) timeZone5);
//        try {
//            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date0, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(31);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Nearest");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = year9.getYear();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1969);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int3 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        boolean boolean8 = spreadsheetDate2.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        try {
//            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, serialDate12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date22 = spreadsheetDate21.toDate();
//        int int23 = spreadsheetDate21.toSerial();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
//        int int27 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate28);
//        boolean boolean30 = spreadsheetDate21.isOnOrBefore(serialDate28);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
//        int int34 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate35);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date41 = spreadsheetDate40.toDate();
//        int int42 = spreadsheetDate40.toSerial();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
//        int int46 = day44.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate47);
//        boolean boolean49 = spreadsheetDate40.isOnOrBefore(serialDate47);
//        boolean boolean51 = spreadsheetDate21.isInRange(serialDate36, serialDate47, (int) '#');
//        int int52 = spreadsheetDate21.toSerial();
//        boolean boolean53 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate56.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addYears(31, (org.jfree.data.time.SerialDate) spreadsheetDate56);
//        boolean boolean60 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192681127L + "'", long15 == 1560192681127L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class9);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long14 = fixedMillisecond13.getSerialIndex();
        java.lang.Number number15 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setMaximumItemCount((int) (byte) 0);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate2.getPreviousDayOfWeek((int) (byte) 1);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1546329600000L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        timeSeries3.setDescription("ERROR : Relative To String");
        boolean boolean8 = timeSeries3.getNotify();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
        timeSeries13.setDomainDescription("");
        boolean boolean16 = timeSeries13.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) year18);
        timeSeries13.clear();
        java.util.List list21 = timeSeries13.getItems();
        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(collection22);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getDayOfMonth();
//        java.util.Date date4 = day0.getStart();
//        java.util.Date date5 = day0.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.Year year4 = month3.getYear();
        long long5 = year4.getMiddleMillisecond();
        java.lang.Object obj6 = null;
        int int7 = year4.compareTo(obj6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class10);
        timeSeries11.setDomainDescription("");
        boolean boolean14 = timeSeries11.isEmpty();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class18);
        timeSeries19.setDomainDescription("");
        java.util.Collection collection22 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year23, (double) 1560150000000L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class10);
        timeSeries11.setRangeDescription("hi!");
        int int14 = fixedMillisecond6.compareTo((java.lang.Object) timeSeries11);
        java.util.Calendar calendar15 = null;
        fixedMillisecond6.peg(calendar15);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        boolean boolean5 = month3.equals((java.lang.Object) (-1.0d));
        java.lang.String str6 = month3.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December 1969" + "'", str6.equals("December 1969"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        timeSeries3.setDescription("ERROR : Relative To String");
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        boolean boolean15 = timeSeries12.isEmpty();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class19);
        timeSeries20.setDomainDescription("");
        java.util.Collection collection23 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries20.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (double) 1560192666073L);
        try {
            timeSeries3.add(timeSeriesDataItem33, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Time");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        java.lang.String str6 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: Time" + "'", str6.equals("org.jfree.data.general.SeriesException: Time"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1, timeZone4);
        java.lang.Object obj6 = null;
        boolean boolean7 = month5.equals(obj6);
        int int8 = month5.getYearValue();
        int int9 = month5.getYearValue();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month5.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        timeSeries3.setDescription("ERROR : Relative To String");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        java.lang.String str17 = timeSeries4.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries4.removeChangeListener(seriesChangeListener18);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setMaximumItemAge(1560192662407L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long6 = fixedMillisecond5.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) (byte) -1);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class13);
        timeSeries14.setRangeDescription("hi!");
        timeSeries14.setMaximumItemAge((long) (byte) 100);
        boolean boolean19 = timeSeriesDataItem8.equals((java.lang.Object) timeSeries14);
        timeSeriesDataItem8.setValue((java.lang.Number) (short) 1);
        timeSeriesDataItem8.setValue((java.lang.Number) 1577865599999L);
        try {
            timeSeries1.add(timeSeriesDataItem8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jan" + "'", str2.equals("Jan"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Jan");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        java.lang.Object obj9 = timeSeriesDataItem7.clone();
        java.lang.Object obj10 = timeSeriesDataItem7.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
//        timeSeries12.setDomainDescription("");
//        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        boolean boolean21 = year19.equals((java.lang.Object) (-1L));
//        int int23 = year19.compareTo((java.lang.Object) 10L);
//        long long24 = year19.getLastMillisecond();
//        long long25 = year19.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date29 = spreadsheetDate28.toDate();
//        int int30 = spreadsheetDate28.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date33 = spreadsheetDate32.toDate();
//        int int34 = spreadsheetDate32.toSerial();
//        int int35 = spreadsheetDate32.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int38 = spreadsheetDate37.getYYYY();
//        java.lang.String str39 = spreadsheetDate37.toString();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        long long42 = fixedMillisecond41.getSerialIndex();
//        boolean boolean43 = month40.equals((java.lang.Object) long42);
//        boolean boolean44 = spreadsheetDate37.equals((java.lang.Object) long42);
//        boolean boolean46 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate37, (int) (byte) 1);
//        boolean boolean47 = year19.equals((java.lang.Object) spreadsheetDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int50 = spreadsheetDate49.getYYYY();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day51.previous();
//        int int53 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate54 = day51.getSerialDate();
//        boolean boolean55 = spreadsheetDate49.isOnOrAfter(serialDate54);
//        boolean boolean56 = spreadsheetDate32.isOnOrAfter(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1900 + "'", int35 == 1900);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560192684983L + "'", long42 == 1560192684983L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setDescription("Nearest");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries12.getTimePeriod(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
//        timeSeries12.setDomainDescription("");
//        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        boolean boolean21 = year19.equals((java.lang.Object) (-1L));
//        int int23 = year19.compareTo((java.lang.Object) 10L);
//        long long24 = year19.getLastMillisecond();
//        long long25 = year19.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date29 = spreadsheetDate28.toDate();
//        int int30 = spreadsheetDate28.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date33 = spreadsheetDate32.toDate();
//        int int34 = spreadsheetDate32.toSerial();
//        int int35 = spreadsheetDate32.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int38 = spreadsheetDate37.getYYYY();
//        java.lang.String str39 = spreadsheetDate37.toString();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        long long42 = fixedMillisecond41.getSerialIndex();
//        boolean boolean43 = month40.equals((java.lang.Object) long42);
//        boolean boolean44 = spreadsheetDate37.equals((java.lang.Object) long42);
//        boolean boolean46 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate37, (int) (byte) 1);
//        boolean boolean47 = year19.equals((java.lang.Object) spreadsheetDate32);
//        spreadsheetDate32.setDescription("");
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1900 + "'", int35 == 1900);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560192685983L + "'", long42 == 1560192685983L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        int int4 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        int int8 = spreadsheetDate6.toSerial();
//        int int9 = spreadsheetDate6.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int12 = spreadsheetDate11.getYYYY();
//        java.lang.String str13 = spreadsheetDate11.toString();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getSerialIndex();
//        boolean boolean17 = month14.equals((java.lang.Object) long16);
//        boolean boolean18 = spreadsheetDate11.equals((java.lang.Object) long16);
//        boolean boolean20 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate11, (int) (byte) 1);
//        try {
//            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192686075L + "'", long16 == 1560192686075L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
        timeSeries21.setDomainDescription("");
        boolean boolean24 = timeSeries21.isEmpty();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class28);
        timeSeries29.setDomainDescription("");
        java.util.Collection collection32 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries12.addAndOrUpdate(timeSeries21);
        try {
            timeSeries33.delete((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1969);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        java.lang.String str8 = day6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        boolean boolean7 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries6);
        timeSeries6.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1, timeZone4);
        long long6 = month5.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24229L + "'", long6 == 24229L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month3.next();
        long long9 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1549007999999L + "'", long9 == 1549007999999L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setMaximumItemAge(1560192662407L);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        int int5 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.lang.String str8 = fixedMillisecond7.toString();
        java.lang.Number number9 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str8.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        long long13 = year11.getFirstMillisecond();
        java.lang.String str14 = year11.toString();
        long long15 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        java.lang.Number number17 = timeSeries10.getValue(regularTimePeriod16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        long long23 = month21.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (short) 100);
        int int26 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class30);
        timeSeries31.setDomainDescription("");
        boolean boolean34 = timeSeries31.isEmpty();
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class38);
        timeSeries39.setDomainDescription("");
        java.util.Collection collection42 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year43, 0.0d);
        try {
            timeSeries10.update((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 1560192681127L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1549007999999L + "'", long23 == 1549007999999L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
        timeSeries21.setDomainDescription("");
        boolean boolean24 = timeSeries21.isEmpty();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class28);
        timeSeries29.setDomainDescription("");
        java.util.Collection collection32 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries12.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries12.createCopy(5, 1969);
        long long37 = timeSeries12.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        int int23 = day21.getDayOfMonth();
//        boolean boolean25 = day21.equals((java.lang.Object) 6);
//        org.jfree.data.time.SerialDate serialDate26 = day21.getSerialDate();
//        boolean boolean27 = spreadsheetDate10.equals((java.lang.Object) day21);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192686460L + "'", long15 == 1560192686460L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1, timeZone4);
        long long6 = month5.getFirstMillisecond();
        long long7 = month5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.next();
        org.jfree.data.time.Year year9 = month5.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class19);
        timeSeries20.setDomainDescription("");
        boolean boolean23 = timeSeries20.isEmpty();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class27);
        timeSeries28.setDomainDescription("");
        java.util.Collection collection31 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries20.fireSeriesChanged();
        timeSeries20.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.util.Collection collection35 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1900, 8, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class5);
//        timeSeries6.setDomainDescription("");
//        boolean boolean9 = timeSeries6.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond10.getLastMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond10.getLastMillisecond(calendar15);
//        long long17 = fixedMillisecond10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, regularTimePeriod18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192686856L + "'", long14 == 1560192686856L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192686856L + "'", long16 == 1560192686856L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560192686856L + "'", long17 == 1560192686856L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#', 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate8);
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        int int14 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate15);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date21 = spreadsheetDate20.toDate();
//        int int22 = spreadsheetDate20.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
//        int int26 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate27);
//        boolean boolean29 = spreadsheetDate20.isOnOrBefore(serialDate27);
//        boolean boolean31 = spreadsheetDate1.isInRange(serialDate16, serialDate27, (int) '#');
//        try {
//            org.jfree.data.time.SerialDate serialDate33 = serialDate16.getPreviousDayOfWeek((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long2 = fixedMillisecond1.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond1.peg(calendar3);
//        long long5 = fixedMillisecond1.getFirstMillisecond();
//        long long6 = fixedMillisecond1.getMiddleMillisecond();
//        long long7 = fixedMillisecond1.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        int int12 = fixedMillisecond1.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) 10);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day8.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        timeSeries4.setMaximumItemAge((long) (byte) 100);
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
//        java.util.Date date14 = fixedMillisecond12.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        int int17 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = day15.equals((java.lang.Object) timeZone19);
//        java.lang.Object obj21 = null;
//        int int22 = day15.compareTo(obj21);
//        long long23 = day15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day15);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries4.getTimePeriod(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560150000000L + "'", long23 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        timeSeries4.clear();
        timeSeries4.setDescription("December 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.previous();
        long long26 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond22.next();
        try {
            org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.createCopy(regularTimePeriod20, regularTimePeriod27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 32L + "'", long24 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 32L + "'", long26 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class4);
        timeSeries5.setDomainDescription("");
        boolean boolean8 = timeSeries5.isEmpty();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
        timeSeries13.setDomainDescription("");
        java.util.Collection collection16 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, 0.0d);
        int int20 = year17.getYear();
        long long21 = year17.getLastMillisecond();
        try {
            org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((-460), year17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries12.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 1560192666073L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long28 = fixedMillisecond27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (byte) -1);
        java.lang.Object obj31 = timeSeriesDataItem30.clone();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class35);
        timeSeries36.setRangeDescription("hi!");
        timeSeries36.setMaximumItemAge((long) (byte) 100);
        boolean boolean41 = timeSeriesDataItem30.equals((java.lang.Object) timeSeries36);
        timeSeriesDataItem30.setValue((java.lang.Number) (short) 1);
        java.lang.Object obj44 = timeSeriesDataItem30.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem30.getPeriod();
        try {
            timeSeries12.add(timeSeriesDataItem30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 23640L + "'", long4 == 23640L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener10);
        try {
            timeSeries4.delete(4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.String str3 = spreadsheetDate1.toString();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
        timeSeries8.setDomainDescription("");
        boolean boolean11 = timeSeries8.isEmpty();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
        timeSeries16.setDomainDescription("");
        java.util.Collection collection19 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries8.getNotify();
        boolean boolean21 = spreadsheetDate1.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23, timeZone24);
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.next();
        try {
            int int28 = spreadsheetDate1.compareTo((java.lang.Object) year26);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        timeSeries4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Class class19 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(class19);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(23640L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date6);
        boolean boolean11 = fixedMillisecond1.equals((java.lang.Object) serialDate10);
        java.lang.String str12 = serialDate10.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setDescription("Nearest");
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class21);
        timeSeries22.setDomainDescription("");
        boolean boolean25 = timeSeries22.isEmpty();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class29);
        timeSeries30.setDomainDescription("");
        java.util.Collection collection33 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, 0.0d);
        try {
            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year34, (double) 29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int3 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        boolean boolean8 = spreadsheetDate2.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
//        timeSeries16.setDomainDescription("");
//        boolean boolean19 = timeSeries16.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) year21);
//        timeSeries16.clear();
//        java.lang.Class<?> wildcardClass24 = timeSeries16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, "org.jfree.data.general.SeriesException: Time", "hi!", (java.lang.Class) wildcardClass24);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener26);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.removeAgedItems((long) (byte) 10, false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        timeSeries1.setKey((java.lang.Comparable) day7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.util.List list12 = timeSeries4.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.createCopy(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.removeAgedItems((long) (byte) 10, false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (byte) -1);
        try {
            timeSeries1.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate8);
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getFollowingDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        spreadsheetDate2.setDescription("2019");
        try {
            org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate2.getFollowingDayOfWeek(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long21 = fixedMillisecond20.getSerialIndex();
        int int22 = year18.compareTo((java.lang.Object) fixedMillisecond20);
        try {
            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (double) 1560192662407L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 32L + "'", long21 == 32L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
//        timeSeries4.clear();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
//        timeSeries4.setDescription("2019");
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.util.Date date17 = year16.getStart();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
//        long long21 = month19.getLastMillisecond();
//        long long22 = month19.getFirstMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
//        int int26 = day24.getDayOfMonth();
//        boolean boolean28 = day24.equals((java.lang.Object) 6);
//        int int29 = day24.getMonth();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1549007999999L + "'", long21 == 1549007999999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        java.lang.Class class14 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: Time");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        java.lang.Class class12 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.addAndOrUpdate(timeSeries13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        boolean boolean7 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries6);
        timeSeries6.fireSeriesChanged();
        timeSeries6.setKey((java.lang.Comparable) 9223372036854775807L);
        timeSeries6.setNotify(false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getLastMillisecond(calendar11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond8.getLastMillisecond(calendar13);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = fixedMillisecond8.equals(obj15);
//        long long17 = fixedMillisecond8.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560192690207L + "'", long12 == 1560192690207L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192690207L + "'", long14 == 1560192690207L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560192690207L + "'", long17 == 1560192690207L);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
        timeSeries21.setDomainDescription("");
        boolean boolean24 = timeSeries21.isEmpty();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class28);
        timeSeries29.setDomainDescription("");
        java.util.Collection collection32 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries12.addAndOrUpdate(timeSeries21);
        timeSeries33.clear();
        try {
            java.lang.Number number36 = timeSeries33.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Time");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
        java.lang.String str7 = timePeriodFormatException6.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str9 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: Time" + "'", str9.equals("org.jfree.data.general.SeriesException: Time"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries4);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.util.Date date13 = year12.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        boolean boolean15 = year12.equals((java.lang.Object) day14);
//        java.util.Date date16 = day14.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        int int20 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean25 = day14.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        boolean boolean28 = year26.equals((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year26.previous();
//        long long30 = year26.getFirstMillisecond();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class34);
//        timeSeries35.setDomainDescription("");
//        boolean boolean38 = timeSeries35.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) year40);
//        java.lang.Comparable comparable42 = timeSeries41.getKey();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        java.util.Collection collection45 = timeSeries41.getTimePeriodsUniqueToOtherSeries(timeSeries44);
//        boolean boolean46 = year26.equals((java.lang.Object) timeSeries41);
//        int int47 = day14.compareTo((java.lang.Object) boolean46);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day14, (double) 1560192674484L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + true + "'", comparable42.equals(true));
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean16 = timeSeries4.getNotify();
        timeSeries4.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, 0, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate8);
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = serialDate8.getPreviousDayOfWeek((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        timeSeries4.setMaximumItemCount(6);
        java.lang.Object obj10 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
        org.jfree.data.time.Year year5 = month4.getYear();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1900, year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        java.lang.String str5 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long8 = fixedMillisecond7.getSerialIndex();
//        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        timeSeries4.removeAgedItems(false);
//        java.lang.Class class12 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
//        timeSeries21.setDomainDescription("");
//        boolean boolean24 = timeSeries21.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) year26);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getLastMillisecond(calendar28);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond25.getLastMillisecond(calendar30);
//        long long32 = fixedMillisecond25.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond25.previous();
//        try {
//            timeSeries4.update(regularTimePeriod33, (java.lang.Number) 1560192690255L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
//        org.junit.Assert.assertNull(number9);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560192691895L + "'", long29 == 1560192691895L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560192691895L + "'", long31 == 1560192691895L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560192691895L + "'", long32 == 1560192691895L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.util.List list12 = timeSeries4.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
        timeSeries8.setDomainDescription("");
        boolean boolean11 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries8.clear();
        java.lang.Class<?> wildcardClass16 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
        java.util.Date date22 = regularTimePeriod21.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date31, timeZone34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date28, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone34);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, (java.lang.Class) wildcardClass16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.addChangeListener(seriesChangeListener39);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 32L + "'", long26 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod37);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
        timeSeries8.setDomainDescription("");
        boolean boolean11 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries8.clear();
        java.lang.Class<?> wildcardClass16 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
        java.util.Date date22 = regularTimePeriod21.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date31, timeZone34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date28, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone34);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, (java.lang.Class) wildcardClass16);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 32L + "'", long26 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class40);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1561964399999L);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(31, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        long long11 = year9.getLastMillisecond();
        int int12 = year9.getYear();
        java.lang.String str13 = year9.toString();
        long long14 = year9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        java.lang.Class class12 = timeSeries4.getTimePeriodClass();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class16);
        timeSeries17.setDomainDescription("");
        boolean boolean20 = timeSeries17.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long23 = fixedMillisecond22.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (byte) -1);
        java.lang.Object obj26 = timeSeriesDataItem25.clone();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class30);
        timeSeries31.setRangeDescription("hi!");
        timeSeries31.setMaximumItemAge((long) (byte) 100);
        boolean boolean36 = timeSeriesDataItem25.equals((java.lang.Object) timeSeries31);
        timeSeriesDataItem25.setValue((java.lang.Number) (short) 1);
        java.lang.Object obj39 = timeSeriesDataItem25.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem25.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries17.addOrUpdate(regularTimePeriod40, (java.lang.Number) 1560192675041L);
        try {
            timeSeries4.update(regularTimePeriod40, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 32L + "'", long23 == 32L);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class19);
        timeSeries20.setDomainDescription("");
        boolean boolean23 = timeSeries20.isEmpty();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class27);
        timeSeries28.setDomainDescription("");
        java.util.Collection collection31 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries20.fireSeriesChanged();
        timeSeries20.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.util.Collection collection35 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries12.removeChangeListener(seriesChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long40 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) (byte) -1);
        java.lang.Object obj43 = timeSeriesDataItem42.clone();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class47);
        timeSeries48.setRangeDescription("hi!");
        timeSeries48.setMaximumItemAge((long) (byte) 100);
        boolean boolean53 = timeSeriesDataItem42.equals((java.lang.Object) timeSeries48);
        java.lang.Number number54 = timeSeriesDataItem42.getValue();
        boolean boolean55 = timeSeries12.equals((java.lang.Object) number54);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 32L + "'", long40 == 32L);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (byte) -1 + "'", number54.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        java.lang.Object obj4 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.String str3 = spreadsheetDate1.toString();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
        timeSeries8.setDomainDescription("");
        boolean boolean11 = timeSeries8.isEmpty();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
        timeSeries16.setDomainDescription("");
        java.util.Collection collection19 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries8.getNotify();
        boolean boolean21 = spreadsheetDate1.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.previous();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30, timeZone33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date27, timeZone33);
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeries8.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        long long8 = day6.getFirstMillisecond();
        int int9 = day6.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        int int9 = month7.getMonth();
        boolean boolean10 = day2.equals((java.lang.Object) month7);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month7.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.String str3 = spreadsheetDate1.toString();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
        timeSeries8.setDomainDescription("");
        boolean boolean11 = timeSeries8.isEmpty();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
        timeSeries16.setDomainDescription("");
        java.util.Collection collection19 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries8.getNotify();
        boolean boolean21 = spreadsheetDate1.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.previous();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30, timeZone33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date27, timeZone33);
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        java.lang.String str38 = timeSeries8.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        long long5 = year0.getLastMillisecond();
        boolean boolean7 = year0.equals((java.lang.Object) 1560192681127L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        timeSeries4.setMaximumItemAge((long) 9999);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener14);
        java.lang.Object obj16 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(obj16);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day20.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192694116L + "'", long15 == 1560192694116L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class10);
        timeSeries11.setDomainDescription("");
        boolean boolean14 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) year16);
        timeSeries11.clear();
        java.lang.Class<?> wildcardClass19 = timeSeries11.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.previous();
        java.util.Date date25 = regularTimePeriod24.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.previous();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34, timeZone35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date34, timeZone37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date31, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone37);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date5, timeZone37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date44 = fixedMillisecond43.getTime();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getStart();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date47, timeZone48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date47, timeZone50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date44, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date5, timeZone50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 32L + "'", long23 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 32L + "'", long29 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(timeZone50);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year6 = month5.getYear();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(29, year6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) "January 2019");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(11, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.previous();
        long long8 = fixedMillisecond4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond4.next();
        int int10 = day0.compareTo((java.lang.Object) fixedMillisecond4);
        long long11 = fixedMillisecond4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        long long11 = year9.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            year9.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.previous();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date18, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date15, timeZone21);
        org.jfree.data.time.Year year24 = month23.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = month23.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("April");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        timeSeries4.setMaximumItemAge((long) (byte) 100);
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
//        java.util.Date date14 = fixedMillisecond12.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        int int17 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = day15.equals((java.lang.Object) timeZone19);
//        java.lang.Object obj21 = null;
//        int int22 = day15.compareTo(obj21);
//        long long23 = day15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day15);
//        int int25 = timeSeries4.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries4.addChangeListener(seriesChangeListener26);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560150000000L + "'", long23 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getSerialIndex();
//        boolean boolean7 = month4.equals((java.lang.Object) long6);
//        boolean boolean8 = spreadsheetDate1.equals((java.lang.Object) long6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate13);
//        boolean boolean15 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        int int19 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate23.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean26 = spreadsheetDate1.isInRange(serialDate20, serialDate25);
//        int int27 = spreadsheetDate1.getDayOfWeek();
//        int int28 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries30.removeAgedItems((long) (byte) 10, false);
//        timeSeries30.setMaximumItemAge(100L);
//        timeSeries30.clear();
//        try {
//            int int37 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries30);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192697166L + "'", long6 == 1560192697166L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        timeSeries4.setMaximumItemAge((long) 9999);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timeSeries4.isEmpty();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setMaximumItemAge(1560192662407L);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        int int5 = timeSeries1.getItemCount();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.next();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.lang.String str18 = fixedMillisecond17.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 1560192671308L);
        try {
            timeSeries1.add(timeSeriesDataItem20, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1549007999999L + "'", long11 == 1549007999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, (int) (byte) 100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.String str3 = spreadsheetDate1.toString();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
        timeSeries8.setDomainDescription("");
        boolean boolean11 = timeSeries8.isEmpty();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
        timeSeries16.setDomainDescription("");
        java.util.Collection collection19 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries8.getNotify();
        boolean boolean21 = spreadsheetDate1.equals((java.lang.Object) timeSeries8);
        spreadsheetDate1.setDescription("10-June-2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean5 = day0.equals((java.lang.Object) timeZone4);
//        java.lang.Object obj6 = null;
//        int int7 = day0.compareTo(obj6);
//        long long8 = day0.getFirstMillisecond();
//        long long9 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long2 = fixedMillisecond1.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond1.peg(calendar3);
//        long long5 = fixedMillisecond1.getFirstMillisecond();
//        long long6 = fixedMillisecond1.getMiddleMillisecond();
//        long long7 = fixedMillisecond1.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        int int12 = fixedMillisecond1.compareTo((java.lang.Object) day8);
//        int int13 = day8.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        timeSeries3.setDescription("ERROR : Relative To String");
        try {
            java.lang.Number number9 = timeSeries3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
        long long17 = fixedMillisecond13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond13.next();
        java.util.Date date19 = fixedMillisecond13.getTime();
        long long20 = fixedMillisecond13.getMiddleMillisecond();
        boolean boolean21 = month9.equals((java.lang.Object) fixedMillisecond13);
        java.util.Calendar calendar22 = null;
        try {
            month9.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class10);
        timeSeries11.setDomainDescription("");
        boolean boolean14 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) year16);
        timeSeries11.clear();
        java.lang.Class<?> wildcardClass19 = timeSeries11.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.previous();
        java.util.Date date25 = regularTimePeriod24.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.previous();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34, timeZone35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date34, timeZone37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date31, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone37);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date5, timeZone37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month41, (double) 1560192693390L);
        long long44 = month41.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 32L + "'", long23 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 32L + "'", long29 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-2649600000L) + "'", long44 == (-2649600000L));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        java.util.Collection collection14 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.previous();
        java.util.Date date20 = regularTimePeriod19.getStart();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class24);
        timeSeries25.setDomainDescription("");
        boolean boolean28 = timeSeries25.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) year30);
        timeSeries25.clear();
        java.lang.Class<?> wildcardClass33 = timeSeries25.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.previous();
        java.util.Date date39 = regularTimePeriod38.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond41.previous();
        java.util.Date date45 = regularTimePeriod44.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        java.util.Date date48 = year47.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date48, timeZone49);
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48, timeZone51);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date45, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone51);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date20, timeZone51);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        int int57 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + true + "'", comparable11.equals(true));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32L + "'", long18 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 32L + "'", long37 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 32L + "'", long43 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        long long14 = timeSeries4.getMaximumItemAge();
        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries4.addChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNull(class15);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getSerialIndex();
//        boolean boolean3 = month0.equals((java.lang.Object) long2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = month0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192699521L + "'", long2 == 1560192699521L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        timeSeries4.setDescription("2019");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
        long long21 = month19.getLastMillisecond();
        long long22 = month19.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month19);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener24);
        java.lang.Comparable comparable26 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1549007999999L + "'", long21 == 1549007999999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + true + "'", comparable26.equals(true));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Time");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        java.lang.String str6 = seriesException3.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: Time" + "'", str6.equals("org.jfree.data.general.SeriesException: Time"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.fireSeriesChanged();
        try {
            timeSeries4.removeAgedItems(1560192664429L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class19);
        timeSeries20.setDomainDescription("");
        boolean boolean23 = timeSeries20.isEmpty();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class27);
        timeSeries28.setDomainDescription("");
        java.util.Collection collection31 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries20.fireSeriesChanged();
        timeSeries20.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.util.Collection collection35 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        timeSeries20.setMaximumItemCount((int) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long40 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) (byte) -1);
        int int44 = timeSeriesDataItem42.compareTo((java.lang.Object) 1549007999999L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.lang.String str48 = day47.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day47.previous();
        boolean boolean50 = timeSeriesDataItem42.equals((java.lang.Object) day47);
        try {
            timeSeries20.add(timeSeriesDataItem42, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 32L + "'", long40 == 32L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 10);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 10 + "'", obj3.equals((short) 10));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 10 + "'", obj4.equals((short) 10));
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries1.removeAgedItems((long) (byte) 10, false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        int int8 = day6.getDayOfMonth();
//        boolean boolean10 = day6.equals((java.lang.Object) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate(regularTimePeriod11, 0.0d);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class17);
//        timeSeries18.setDomainDescription("");
//        boolean boolean21 = timeSeries18.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) year23);
//        timeSeries18.clear();
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries18.removePropertyChangeListener(propertyChangeListener26);
//        timeSeries18.setDescription("2019");
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        java.util.Date date31 = year30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31, timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.previous();
//        long long35 = month33.getLastMillisecond();
//        long long36 = month33.getFirstMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) month33);
//        java.lang.String str38 = month33.toString();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month33);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1549007999999L + "'", long35 == 1549007999999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January 2019" + "'", str38.equals("January 2019"));
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getLastMillisecond(calendar11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond8.getLastMillisecond(calendar13);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = fixedMillisecond8.equals(obj15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.util.Date date18 = year17.getStart();
//        long long19 = year17.getSerialIndex();
//        long long20 = year17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
//        int int22 = fixedMillisecond8.compareTo((java.lang.Object) year17);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560192700447L + "'", long12 == 1560192700447L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192700447L + "'", long14 == 1560192700447L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        timeSeries4.clear();
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries4.removeChangeListener(seriesChangeListener9);
        timeSeries4.setMaximumItemCount(0);
        java.lang.Comparable comparable13 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + true + "'", comparable13.equals(true));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        java.lang.String str17 = timeSeries4.getRangeDescription();
        java.util.List list18 = timeSeries4.getItems();
        java.lang.Class class19 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21);
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month24);
        long long26 = month24.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1549007999999L + "'", long26 == 1549007999999L);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.previous();
//        long long8 = fixedMillisecond4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond4.next();
//        int int10 = day0.compareTo((java.lang.Object) fixedMillisecond4);
//        int int11 = day0.getDayOfMonth();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day0.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.fireSeriesChanged();
        timeSeries4.setMaximumItemCount((int) (byte) 100);
        try {
            java.lang.Number number14 = timeSeries4.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        timeSeries4.setMaximumItemCount(6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.previous();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date18, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date15, timeZone21);
        org.jfree.data.time.Year year24 = month23.getYear();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(year24);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean4 = year1.equals((java.lang.Object) day3);
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        boolean boolean7 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries6);
        timeSeries6.fireSeriesChanged();
        java.lang.Comparable comparable9 = timeSeries6.getKey();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "hi!" + "'", comparable9.equals("hi!"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class4);
        timeSeries5.setDomainDescription("");
        boolean boolean8 = timeSeries5.isEmpty();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
        timeSeries13.setDomainDescription("");
        java.util.Collection collection16 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, 0.0d);
        int int20 = year17.getYear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, year17);
        int int23 = year17.compareTo((java.lang.Object) 1560192684983L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9999, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        boolean boolean7 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries6);
        timeSeries6.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 11, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        timeSeries4.setMaximumItemAge((long) (byte) 100);
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
//        java.util.Date date14 = fixedMillisecond12.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        int int17 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = day15.equals((java.lang.Object) timeZone19);
//        java.lang.Object obj21 = null;
//        int int22 = day15.compareTo(obj21);
//        long long23 = day15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day15);
//        java.util.Calendar calendar25 = null;
//        try {
//            day15.peg(calendar25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560150000000L + "'", long23 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date5, timeZone11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, "Nearest", "February", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(class18);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getSerialIndex();
//        boolean boolean3 = month0.equals((java.lang.Object) long2);
//        java.lang.String str4 = month0.toString();
//        long long5 = month0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192701201L + "'", long2 == 1560192701201L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        try {
            timeSeries3.update((int) (byte) 10, (java.lang.Number) 1560192686142L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int6 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        int int9 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        boolean boolean11 = spreadsheetDate5.isOnOrAfter(serialDate10);
//        boolean boolean12 = spreadsheetDate1.isBefore(serialDate10);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean17 = year14.equals((java.lang.Object) day16);
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(0, serialDate18);
//        boolean boolean20 = spreadsheetDate1.isBefore(serialDate19);
//        int int21 = spreadsheetDate1.toSerial();
//        int int22 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean4 = year1.equals((java.lang.Object) day3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(5, year1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int9 = spreadsheetDate7.getMonth();
        int int10 = year1.compareTo((java.lang.Object) int9);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class6);
//        timeSeries7.setDomainDescription("");
//        boolean boolean10 = timeSeries7.isEmpty();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class14);
//        timeSeries15.setDomainDescription("");
//        java.util.Collection collection18 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        java.lang.Object obj19 = timeSeries15.clone();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class23);
//        timeSeries24.setDomainDescription("");
//        boolean boolean27 = timeSeries24.isEmpty();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class31);
//        timeSeries32.setDomainDescription("");
//        java.util.Collection collection35 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries15.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries15.createCopy(5, 1969);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
//        int int42 = day40.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = day40.getSerialDate();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean45 = day40.equals((java.lang.Object) timeZone44);
//        java.lang.Object obj46 = null;
//        int int47 = day40.compareTo(obj46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (double) (-57600000L));
//        int int50 = year0.compareTo((java.lang.Object) (-57600000L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year0.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1900, (int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = year0.equals((java.lang.Object) day2);
//        long long4 = day2.getLastMillisecond();
//        int int5 = day2.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = year0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day2.getStart();
//        long long5 = day2.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day2.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount(2019);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            timeSeries3.add(timeSeriesDataItem6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) -1);
        java.lang.Object obj5 = timeSeriesDataItem4.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class9);
        timeSeries10.setRangeDescription("hi!");
        timeSeries10.setMaximumItemAge((long) (byte) 100);
        boolean boolean15 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries10);
        timeSeriesDataItem4.setValue((java.lang.Number) (short) 1);
        java.lang.Object obj18 = timeSeriesDataItem4.clone();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getStart();
        long long21 = year19.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1561964399999L);
        boolean boolean24 = timeSeriesDataItem4.equals((java.lang.Object) timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date1, timeZone4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setMaximumItemAge((long) (byte) 100);
        timeSeries4.setNotify(true);
        try {
            timeSeries4.removeAgedItems(1560192669696L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
        timeSeries21.setDomainDescription("");
        boolean boolean24 = timeSeries21.isEmpty();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class28);
        timeSeries29.setDomainDescription("");
        java.util.Collection collection32 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries12.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries34 = null;
        try {
            java.util.Collection collection35 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
        long long17 = fixedMillisecond13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond13.next();
        java.util.Date date19 = fixedMillisecond13.getTime();
        long long20 = fixedMillisecond13.getMiddleMillisecond();
        boolean boolean21 = month9.equals((java.lang.Object) fixedMillisecond13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond13.next();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (short) 100);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        timeSeries4.setMaximumItemCount(6);
        try {
            timeSeries4.removeAgedItems((-1L), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int3 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        boolean boolean8 = spreadsheetDate2.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        java.lang.Class<?> wildcardClass10 = spreadsheetDate2.getClass();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        try {
            timeSeries3.update(100, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        java.lang.String str8 = day6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long3 = day2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2200406400001L) + "'", long3 == (-2200406400001L));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        timeSeries4.setDescription("2019");
        try {
            timeSeries4.delete(0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getFirstMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond7.getTime();
        java.util.Date date13 = fixedMillisecond7.getStart();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        timeSeries4.setMaximumItemAge((long) (byte) 100);
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
//        java.util.Date date14 = fixedMillisecond12.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        int int17 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = day15.equals((java.lang.Object) timeZone19);
//        java.lang.Object obj21 = null;
//        int int22 = day15.compareTo(obj21);
//        long long23 = day15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day15);
//        long long25 = fixedMillisecond12.getLastMillisecond();
//        java.util.Calendar calendar26 = null;
//        fixedMillisecond12.peg(calendar26);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560150000000L + "'", long23 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries4.fireSeriesChanged();
        java.lang.String str17 = timeSeries4.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries4.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = null;
        try {
            timeSeries4.add(timeSeriesDataItem20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        int int3 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(7);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        int int2 = spreadsheetDate1.getYYYY();
        java.util.Date date3 = spreadsheetDate1.toDate();
        int int4 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int4 = spreadsheetDate3.getYYYY();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        boolean boolean9 = spreadsheetDate3.isOnOrAfter(serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int12 = spreadsheetDate11.getYYYY();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate13);
//        try {
//            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class9);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long14 = fixedMillisecond13.getSerialIndex();
        java.lang.Number number15 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        long long17 = timeSeries10.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        int int16 = timeSeries12.getItemCount();
        java.lang.String str17 = timeSeries12.getRangeDescription();
        timeSeries12.setDomainDescription("2019");
        timeSeries12.setNotify(true);
        timeSeries12.setDomainDescription("April");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class9);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long14 = fixedMillisecond13.getSerialIndex();
        java.lang.Number number15 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class20);
        timeSeries21.setDomainDescription("");
        boolean boolean24 = timeSeries21.isEmpty();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class28);
        timeSeries29.setDomainDescription("");
        java.util.Collection collection32 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        boolean boolean33 = timeSeries21.getNotify();
        boolean boolean34 = timeSeries21.getNotify();
        java.util.Collection collection35 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        int int16 = timeSeries12.getItemCount();
        java.lang.String str17 = timeSeries12.getRangeDescription();
        try {
            timeSeries12.delete((-459), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getLastMillisecond(calendar11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond8.getLastMillisecond(calendar13);
//        long long15 = fixedMillisecond8.getLastMillisecond();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class19);
//        timeSeries20.setDomainDescription("");
//        boolean boolean23 = timeSeries20.isEmpty();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class27);
//        timeSeries28.setDomainDescription("");
//        java.util.Collection collection31 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//        java.lang.Object obj32 = timeSeries28.clone();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class36);
//        timeSeries37.setDomainDescription("");
//        boolean boolean40 = timeSeries37.isEmpty();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class44);
//        timeSeries45.setDomainDescription("");
//        java.util.Collection collection48 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries45);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries28.addAndOrUpdate(timeSeries37);
//        int int50 = fixedMillisecond8.compareTo((java.lang.Object) timeSeries49);
//        java.util.Calendar calendar51 = null;
//        fixedMillisecond8.peg(calendar51);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560192704883L + "'", long12 == 1560192704883L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192704883L + "'", long14 == 1560192704883L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192704883L + "'", long15 == 1560192704883L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class4);
        timeSeries5.setDomainDescription("");
        boolean boolean8 = timeSeries5.isEmpty();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
        timeSeries13.setDomainDescription("");
        java.util.Collection collection16 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, 0.0d);
        int int20 = year17.getYear();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class24);
        timeSeries25.setDomainDescription("");
        boolean boolean28 = timeSeries25.isEmpty();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class32);
        timeSeries33.setDomainDescription("");
        java.util.Collection collection36 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        boolean boolean37 = year17.equals((java.lang.Object) timeSeries33);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, year17);
        java.lang.Object obj39 = null;
        boolean boolean40 = year17.equals(obj39);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1, timeZone4);
        java.lang.Object obj6 = null;
        boolean boolean7 = month5.equals(obj6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.previous();
        long long9 = month5.getSerialIndex();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month5.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24229L + "'", long9 == 24229L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        java.util.List list17 = timeSeries12.getItems();
        timeSeries12.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(list17);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        int int7 = spreadsheetDate5.toSerial();
//        int int8 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int11 = spreadsheetDate10.getYYYY();
//        java.lang.String str12 = spreadsheetDate10.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        boolean boolean16 = month13.equals((java.lang.Object) long15);
//        boolean boolean17 = spreadsheetDate10.equals((java.lang.Object) long15);
//        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int22 = spreadsheetDate21.getYYYY();
//        java.lang.String str23 = spreadsheetDate21.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate25.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean29 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate25, 7);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        java.util.Date date31 = year30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31, timeZone32);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date31, timeZone34);
//        java.lang.Object obj36 = null;
//        boolean boolean37 = month35.equals(obj36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.previous();
//        try {
//            int int39 = spreadsheetDate21.compareTo((java.lang.Object) regularTimePeriod38);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Month cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192705081L + "'", long15 == 1560192705081L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class9);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long14 = fixedMillisecond13.getSerialIndex();
        java.lang.Number number15 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries10.removeAgedItems(false);
        boolean boolean18 = fixedMillisecond1.equals((java.lang.Object) timeSeries10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192693355L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount(2019);
        java.lang.String str6 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        long long9 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 1561964399999L);
        try {
            timeSeries3.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.removeAgedItems((long) (byte) 10, false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        timeSeries1.setKey((java.lang.Comparable) day7);
        int int11 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, 0.0d);
        int int19 = year16.getYear();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class23);
        timeSeries24.setDomainDescription("");
        boolean boolean27 = timeSeries24.isEmpty();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class31);
        timeSeries32.setDomainDescription("");
        java.util.Collection collection35 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        boolean boolean36 = year16.equals((java.lang.Object) timeSeries32);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener37);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int2 = spreadsheetDate1.getYYYY();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
//        timeSeries8.setDomainDescription("");
//        boolean boolean11 = timeSeries8.isEmpty();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
//        timeSeries16.setDomainDescription("");
//        java.util.Collection collection19 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        boolean boolean20 = timeSeries8.getNotify();
//        boolean boolean21 = spreadsheetDate1.equals((java.lang.Object) timeSeries8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int24 = spreadsheetDate23.getYYYY();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
//        int int27 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        boolean boolean29 = spreadsheetDate23.isOnOrAfter(serialDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date32 = spreadsheetDate31.toDate();
//        int int33 = spreadsheetDate31.getYYYY();
//        int int34 = spreadsheetDate31.toSerial();
//        boolean boolean35 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int38 = spreadsheetDate37.getYYYY();
//        java.lang.String str39 = spreadsheetDate37.toString();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        long long42 = fixedMillisecond41.getSerialIndex();
//        boolean boolean43 = month40.equals((java.lang.Object) long42);
//        boolean boolean44 = spreadsheetDate37.equals((java.lang.Object) long42);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        int int48 = day46.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate49);
//        boolean boolean51 = spreadsheetDate37.isOn(serialDate50);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        int int55 = day53.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate56 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate56);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate59.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean62 = spreadsheetDate37.isInRange(serialDate56, serialDate61);
//        int int63 = spreadsheetDate37.getDayOfWeek();
//        boolean boolean64 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.SerialDate serialDate65 = null;
//        try {
//            boolean boolean66 = spreadsheetDate31.isBefore(serialDate65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560192706559L + "'", long42 == 1560192706559L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        try {
            java.lang.Number number7 = timeSeries1.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
        timeSeries12.setDomainDescription("");
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Object obj16 = timeSeries12.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        int int18 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long28 = fixedMillisecond27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (byte) -1);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.previous();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        long long39 = day38.getMiddleMillisecond();
        int int40 = fixedMillisecond27.compareTo((java.lang.Object) day38);
        int int41 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long44 = fixedMillisecond43.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        boolean boolean49 = timeSeriesDataItem46.equals((java.lang.Object) timeSeries48);
        java.lang.Object obj50 = timeSeriesDataItem46.clone();
        try {
            timeSeries12.add(timeSeriesDataItem46, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 32L + "'", long35 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-14400001L) + "'", long39 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 32L + "'", long44 == 32L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate6);
//        spreadsheetDate6.setDescription("2019");
//        int int11 = spreadsheetDate6.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int14 = spreadsheetDate13.getYYYY();
//        java.lang.String str15 = spreadsheetDate13.toString();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class19);
//        timeSeries20.setDomainDescription("");
//        boolean boolean23 = timeSeries20.isEmpty();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class27);
//        timeSeries28.setDomainDescription("");
//        java.util.Collection collection31 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//        boolean boolean32 = timeSeries20.getNotify();
//        boolean boolean33 = spreadsheetDate13.equals((java.lang.Object) timeSeries20);
//        boolean boolean34 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date37 = spreadsheetDate36.toDate();
//        int int38 = spreadsheetDate36.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date41 = spreadsheetDate40.toDate();
//        int int42 = spreadsheetDate40.toSerial();
//        int int43 = spreadsheetDate40.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int46 = spreadsheetDate45.getYYYY();
//        java.lang.String str47 = spreadsheetDate45.toString();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        long long50 = fixedMillisecond49.getSerialIndex();
//        boolean boolean51 = month48.equals((java.lang.Object) long50);
//        boolean boolean52 = spreadsheetDate45.equals((java.lang.Object) long50);
//        boolean boolean54 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, (org.jfree.data.time.SerialDate) spreadsheetDate45, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int57 = spreadsheetDate56.getYYYY();
//        java.lang.String str58 = spreadsheetDate56.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate62 = spreadsheetDate60.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean64 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, (org.jfree.data.time.SerialDate) spreadsheetDate60, 7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date67 = spreadsheetDate66.toDate();
//        int int68 = spreadsheetDate66.toSerial();
//        boolean boolean70 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, (org.jfree.data.time.SerialDate) spreadsheetDate66, (int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate71 = null;
//        try {
//            boolean boolean73 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, serialDate71, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560192706644L + "'", long50 == 1560192706644L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1900 + "'", int57 == 1900);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        int int6 = month3.getMonth();
        long long7 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549007999999L + "'", long7 == 1549007999999L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 1560192673787L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (-1L));
        int int4 = year0.compareTo((java.lang.Object) 10L);
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.removeAgedItems((long) (byte) 10, false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        timeSeries1.setKey((java.lang.Comparable) day7);
        long long11 = day7.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day7.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean3 = year0.equals((java.lang.Object) day2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        int int9 = month7.getMonth();
        boolean boolean10 = day2.equals((java.lang.Object) month7);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date12, timeZone15);
        java.lang.Object obj17 = null;
        boolean boolean18 = month16.equals(obj17);
        int int19 = month16.getYearValue();
        java.lang.String str20 = month16.toString();
        int int21 = month7.compareTo((java.lang.Object) str20);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "January 2019" + "'", str20.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str3 = day2.toString();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class7);
        timeSeries8.setDomainDescription("");
        boolean boolean11 = timeSeries8.isEmpty();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class15);
        timeSeries16.setDomainDescription("");
        java.util.Collection collection19 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class23);
        timeSeries24.setDomainDescription("");
        boolean boolean27 = timeSeries24.isEmpty();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class31);
        timeSeries32.setDomainDescription("");
        java.util.Collection collection35 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, 0.0d);
        int int39 = year36.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, (double) (-57600000L));
        boolean boolean42 = day2.equals((java.lang.Object) (-57600000L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) 6);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        int int11 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate12);
//        int int14 = month6.compareTo((java.lang.Object) serialDate13);
//        long long15 = month6.getFirstMillisecond();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        boolean boolean18 = year16.equals((java.lang.Object) (-1L));
//        int int20 = year16.compareTo((java.lang.Object) 10L);
//        long long21 = year16.getMiddleMillisecond();
//        int int22 = month6.compareTo((java.lang.Object) year16);
//        boolean boolean23 = day0.equals((java.lang.Object) month6);
//        java.util.Calendar calendar24 = null;
//        try {
//            month6.peg(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        int int4 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        int int8 = spreadsheetDate6.toSerial();
//        int int9 = spreadsheetDate6.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int12 = spreadsheetDate11.getYYYY();
//        java.lang.String str13 = spreadsheetDate11.toString();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getSerialIndex();
//        boolean boolean17 = month14.equals((java.lang.Object) long16);
//        boolean boolean18 = spreadsheetDate11.equals((java.lang.Object) long16);
//        boolean boolean20 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate11, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int23 = spreadsheetDate22.getYYYY();
//        java.lang.String str24 = spreadsheetDate22.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate26.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean30 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate26, 7);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate22);
//        int int32 = spreadsheetDate22.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192707006L + "'", long16 == 1560192707006L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class4);
//        timeSeries5.setDomainDescription("");
//        boolean boolean8 = timeSeries5.isEmpty();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class12);
//        timeSeries13.setDomainDescription("");
//        java.util.Collection collection16 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        timeSeries5.fireSeriesChanged();
//        timeSeries5.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        boolean boolean22 = year20.equals((java.lang.Object) (-1L));
//        int int24 = year20.compareTo((java.lang.Object) 10L);
//        long long25 = year20.getLastMillisecond();
//        long long26 = year20.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date30 = spreadsheetDate29.toDate();
//        int int31 = spreadsheetDate29.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date34 = spreadsheetDate33.toDate();
//        int int35 = spreadsheetDate33.toSerial();
//        int int36 = spreadsheetDate33.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int39 = spreadsheetDate38.getYYYY();
//        java.lang.String str40 = spreadsheetDate38.toString();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        long long43 = fixedMillisecond42.getSerialIndex();
//        boolean boolean44 = month41.equals((java.lang.Object) long43);
//        boolean boolean45 = spreadsheetDate38.equals((java.lang.Object) long43);
//        boolean boolean47 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate38, (int) (byte) 1);
//        boolean boolean48 = year20.equals((java.lang.Object) spreadsheetDate33);
//        int int49 = spreadsheetDate33.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int54 = spreadsheetDate53.getYYYY();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
//        int int57 = day55.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate58 = day55.getSerialDate();
//        boolean boolean59 = spreadsheetDate53.isOnOrAfter(serialDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date62 = spreadsheetDate61.toDate();
//        int int63 = spreadsheetDate61.getYYYY();
//        int int64 = spreadsheetDate61.toSerial();
//        boolean boolean65 = spreadsheetDate53.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(1969, (org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate66);
//        boolean boolean68 = spreadsheetDate33.isOnOrAfter(serialDate66);
//        try {
//            org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2019, (org.jfree.data.time.SerialDate) spreadsheetDate33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1562097599999L + "'", long26 == 1562097599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560192707347L + "'", long43 == 1560192707347L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 9 + "'", int49 == 9);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1900 + "'", int54 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1900 + "'", int63 == 1900);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        int int6 = month3.getMonth();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        int int9 = day7.getMonth();
        int int10 = month3.compareTo((java.lang.Object) int9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549007999999L + "'", long5 == 1549007999999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.lang.String str2 = fixedMillisecond1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("February");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        long long5 = year1.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((-459), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long9 = fixedMillisecond8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (byte) -1);
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getStart();
        long long17 = year15.getSerialIndex();
        long long18 = year15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 43626L);
        int int22 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate2.getPreviousDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int6 = spreadsheetDate2.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        timeSeries4.setDomainDescription("");
        boolean boolean7 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        timeSeries4.setDescription("2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.getDataItem(regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        int int4 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        int int8 = spreadsheetDate6.toSerial();
//        int int9 = spreadsheetDate6.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int12 = spreadsheetDate11.getYYYY();
//        java.lang.String str13 = spreadsheetDate11.toString();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getSerialIndex();
//        boolean boolean17 = month14.equals((java.lang.Object) long16);
//        boolean boolean18 = spreadsheetDate11.equals((java.lang.Object) long16);
//        boolean boolean20 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate11, (int) (byte) 1);
//        try {
//            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1969, (org.jfree.data.time.SerialDate) spreadsheetDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192707892L + "'", long16 == 1560192707892L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int3 = spreadsheetDate2.getYYYY();
//        java.lang.String str4 = spreadsheetDate2.toString();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getSerialIndex();
//        boolean boolean8 = month5.equals((java.lang.Object) long7);
//        boolean boolean9 = spreadsheetDate2.equals((java.lang.Object) long7);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
//        int int13 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate14);
//        boolean boolean16 = spreadsheetDate2.isOn(serialDate15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        int int20 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate24.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean27 = spreadsheetDate2.isInRange(serialDate21, serialDate26);
//        int int28 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int32 = spreadsheetDate31.getYYYY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        int int35 = day33.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day33.getSerialDate();
//        boolean boolean37 = spreadsheetDate31.isOnOrAfter(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date41 = spreadsheetDate40.toDate();
//        int int42 = spreadsheetDate40.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        java.util.Date date45 = spreadsheetDate44.toDate();
//        int int46 = spreadsheetDate44.toSerial();
//        int int47 = spreadsheetDate44.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int50 = spreadsheetDate49.getYYYY();
//        java.lang.String str51 = spreadsheetDate49.toString();
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        long long54 = fixedMillisecond53.getSerialIndex();
//        boolean boolean55 = month52.equals((java.lang.Object) long54);
//        boolean boolean56 = spreadsheetDate49.equals((java.lang.Object) long54);
//        boolean boolean58 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate44, (org.jfree.data.time.SerialDate) spreadsheetDate49, (int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        int int61 = spreadsheetDate60.getYYYY();
//        java.lang.String str62 = spreadsheetDate60.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate64.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean68 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate60, (org.jfree.data.time.SerialDate) spreadsheetDate64, 7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate71);
//        spreadsheetDate71.setDescription("2019");
//        int int76 = spreadsheetDate71.getDayOfWeek();
//        int int77 = spreadsheetDate71.toSerial();
//        boolean boolean78 = spreadsheetDate60.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        boolean boolean80 = spreadsheetDate2.isInRange(serialDate38, (org.jfree.data.time.SerialDate) spreadsheetDate60, (int) (byte) 1);
//        try {
//            org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560192707905L + "'", long7 == 1560192707905L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560192707932L + "'", long54 == 1560192707932L);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1900 + "'", int61 == 1900);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 100 + "'", int77 == 100);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long8 = fixedMillisecond7.getSerialIndex();
        java.lang.Number number9 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries4.removeAgedItems(false);
        timeSeries4.setMaximumItemAge((long) 9999);
        int int14 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class3);
//        timeSeries4.setDomainDescription("");
//        boolean boolean7 = timeSeries4.isEmpty();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class11);
//        timeSeries12.setDomainDescription("");
//        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Object obj16 = timeSeries12.clone();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class22);
//        timeSeries23.setDomainDescription("");
//        boolean boolean26 = timeSeries23.isEmpty();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "", class30);
//        timeSeries31.setDomainDescription("");
//        java.util.Collection collection34 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries31.addChangeListener(seriesChangeListener38);
//        timeSeries31.setMaximumItemCount((int) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        long long44 = fixedMillisecond43.getSerialIndex();
//        java.util.Calendar calendar45 = null;
//        fixedMillisecond43.peg(calendar45);
//        long long47 = fixedMillisecond43.getFirstMillisecond();
//        long long48 = fixedMillisecond43.getMiddleMillisecond();
//        long long49 = fixedMillisecond43.getLastMillisecond();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
//        int int52 = day50.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
//        int int54 = fixedMillisecond43.compareTo((java.lang.Object) day50);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond43);
//        long long56 = fixedMillisecond43.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (double) ' ');
//        int int59 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries12.addAndOrUpdate(timeSeries31);
//        java.util.List list61 = timeSeries60.getItems();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 32L + "'", long44 == 32L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 32L + "'", long47 == 32L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 32L + "'", long49 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 32L + "'", long56 == 32L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertNotNull(list61);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.lang.String str2 = fixedMillisecond1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1560192671308L);
        java.lang.Number number5 = timeSeriesDataItem4.getValue();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1560192671308L + "'", number5.equals(1560192671308L));
    }
}

