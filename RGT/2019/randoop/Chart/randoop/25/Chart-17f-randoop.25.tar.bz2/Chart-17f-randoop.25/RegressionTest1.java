import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 0.0d);
        timeSeriesDataItem10.setValue((java.lang.Number) 100);
        timeSeriesDataItem10.setValue((java.lang.Number) 1L);
        boolean boolean16 = timeSeriesDataItem10.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Number number17 = timeSeriesDataItem10.getValue();
        boolean boolean18 = month0.equals((java.lang.Object) timeSeriesDataItem10);
        java.lang.Number number19 = null;
        timeSeriesDataItem10.setValue(number19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        boolean boolean23 = timeSeriesDataItem10.equals((java.lang.Object) fixedMillisecond22);
        long long24 = fixedMillisecond22.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1L + "'", number17.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 35L + "'", long24 == 35L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        int int22 = timeSeries19.getItemCount();
        long long23 = timeSeries19.getMaximumItemAge();
        timeSeries19.fireSeriesChanged();
        java.util.Collection collection25 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getDayOfWeek();
        int int31 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getDayOfWeek();
        int int37 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = spreadsheetDate35.getMonth();
        java.util.Date date40 = spreadsheetDate35.toDate();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date40);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date40);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols45 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int46 = day44.compareTo((java.lang.Object) dateFormatSymbols45);
        java.util.Date date47 = day44.getStart();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols50 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int51 = day49.compareTo((java.lang.Object) dateFormatSymbols50);
        java.util.Date date52 = day49.getStart();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date52);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date52, timeZone55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date47, timeZone55);
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        int int62 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) year61);
        timeSeries60.setMaximumItemAge((long) 1);
        boolean boolean65 = timeSeries60.getNotify();
        java.lang.String str66 = timeSeries60.getDescription();
        java.lang.Class class68 = null;
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class68);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        int int71 = timeSeries69.getIndex((org.jfree.data.time.RegularTimePeriod) year70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year70.next();
        java.lang.String str73 = year70.toString();
        timeSeries60.setKey((java.lang.Comparable) year70);
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = month75.previous();
        org.jfree.data.time.Year year77 = month75.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries60.getDataItem((org.jfree.data.time.RegularTimePeriod) year77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year77.previous();
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols81 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int82 = day80.compareTo((java.lang.Object) dateFormatSymbols81);
        java.util.Date date83 = day80.getStart();
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols86 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int87 = day85.compareTo((java.lang.Object) dateFormatSymbols86);
        java.util.Date date88 = day85.getStart();
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date88);
        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond(date88);
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date88, timeZone91);
        org.jfree.data.time.Month month93 = new org.jfree.data.time.Month(date83, timeZone91);
        boolean boolean94 = year77.equals((java.lang.Object) timeZone91);
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date47, timeZone91);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date40, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries98 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) day96, regularTimePeriod97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(dateFormatSymbols45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(dateFormatSymbols50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "2019" + "'", str73.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(year77);
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(dateFormatSymbols81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(dateFormatSymbols86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0d);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        java.lang.Class<?> wildcardClass10 = timeSeriesDataItem8.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        org.jfree.data.time.Year year14 = month12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.previous();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols20 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int21 = day19.compareTo((java.lang.Object) dateFormatSymbols20);
        java.util.Date date22 = day19.getStart();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        java.lang.Class class24 = null;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols26 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int27 = day25.compareTo((java.lang.Object) dateFormatSymbols26);
        java.util.Date date28 = day25.getStart();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date28, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date22, timeZone31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date36 = spreadsheetDate35.toDate();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols38 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int39 = day37.compareTo((java.lang.Object) dateFormatSymbols38);
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        java.lang.Class class42 = null;
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols44 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int45 = day43.compareTo((java.lang.Object) dateFormatSymbols44);
        java.util.Date date46 = day43.getStart();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date46, timeZone47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date46, timeZone49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date40, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date36, timeZone49);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(dateFormatSymbols20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateFormatSymbols26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(dateFormatSymbols38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateFormatSymbols44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols5 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int6 = day4.compareTo((java.lang.Object) dateFormatSymbols5);
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, class12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(dateFormatSymbols5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13, 10);
        java.util.Date date17 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean22 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getDayOfWeek();
        int int33 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getDayOfWeek();
        int int39 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate29.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean41 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean42 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getDayOfWeek();
        int int49 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        int int54 = spreadsheetDate53.getDayOfWeek();
        int int55 = spreadsheetDate51.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(9, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        java.lang.String str59 = spreadsheetDate45.getDescription();
        int int60 = spreadsheetDate45.getYYYY();
        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1900 + "'", int60 == 1900);
        org.junit.Assert.assertNotNull(serialDate61);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int7 = day5.compareTo((java.lang.Object) dateFormatSymbols6);
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date3, timeZone11);
        org.jfree.data.time.Year year14 = month13.getYear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.String str20 = timeSeries17.getRangeDescription();
        timeSeries17.setMaximumItemCount(1900);
        boolean boolean23 = month13.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(13);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 0.0d);
        java.lang.Object obj37 = timeSeriesDataItem36.clone();
        java.lang.Class<?> wildcardClass38 = timeSeriesDataItem36.getClass();
        java.net.URL uRL39 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.previous();
        org.jfree.data.time.Year year42 = month40.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month40.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass38, (java.lang.Class) wildcardClass44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate25, "", "April", (java.lang.Class) wildcardClass38);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent47 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "");
        java.lang.Object obj48 = seriesChangeEvent47.getSource();
        int int49 = month13.compareTo((java.lang.Object) seriesChangeEvent47);
        java.lang.String str50 = seriesChangeEvent47.toString();
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(uRL39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertTrue("'" + obj48 + "' != '" + "" + "'", obj48.equals(""));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=]" + "'", str50.equals("org.jfree.data.general.SeriesChangeEvent[source=]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getDayOfWeek();
        int int7 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        int int12 = spreadsheetDate11.getDayOfWeek();
        int int13 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2);
        int int16 = spreadsheetDate15.getDayOfWeek();
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15, 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate15, class24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(2);
        int int34 = spreadsheetDate33.getDayOfWeek();
        int int35 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        int int40 = spreadsheetDate39.getDayOfWeek();
        int int41 = spreadsheetDate37.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean43 = spreadsheetDate29.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean44 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        int int50 = spreadsheetDate49.getDayOfWeek();
        int int51 = spreadsheetDate47.compare((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(2);
        int int56 = spreadsheetDate55.getDayOfWeek();
        int int57 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean58 = spreadsheetDate47.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(9, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate60 = spreadsheetDate39.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        java.lang.String str61 = spreadsheetDate47.getDescription();
        int int62 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        try {
            org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addDays((-571), (org.jfree.data.time.SerialDate) spreadsheetDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2 + "'", int56 == 2);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Comparable comparable8 = timeSeries2.getKey();
        timeSeries2.clear();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        boolean boolean15 = timeSeries2.equals((java.lang.Object) int14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        timeSeries2.setMaximumItemAge((long) (short) 10);
        java.lang.String str8 = timeSeries2.getDomainDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        int int16 = year12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1));
        timeSeries2.fireSeriesChanged();
        timeSeries2.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        int int12 = timeSeries9.getItemCount();
        timeSeries9.setNotify(false);
        java.util.Collection collection15 = timeSeries9.getTimePeriods();
        long long16 = timeSeries9.getMaximumItemAge();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.lang.String str23 = year20.toString();
        java.lang.Number number24 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
        java.lang.String str31 = year28.toString();
        int int32 = year28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year28.previous();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year28);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries34.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        boolean boolean5 = day0.equals((java.lang.Object) 1560441922447L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
//        long long6 = fixedMillisecond3.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond3.getTime();
//        boolean boolean8 = month0.equals((java.lang.Object) fixedMillisecond3);
//        long long9 = month0.getFirstMillisecond();
//        int int10 = month0.getYearValue();
//        long long11 = month0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441970909L + "'", long5 == 1560441970909L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441970909L + "'", long6 == 1560441970909L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getDayOfWeek();
        int int8 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        int int13 = spreadsheetDate12.getDayOfWeek();
        int int14 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        int int17 = spreadsheetDate16.getDayOfWeek();
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16, 10);
        int int20 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        java.lang.Class<?> wildcardClass22 = timeSeries21.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        java.lang.Comparable comparable7 = timeSeries2.getKey();
        timeSeries2.setDomainDescription("hi!");
        java.lang.Comparable comparable10 = timeSeries2.getKey();
        long long11 = timeSeries2.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10 + "'", comparable7.equals(10));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10 + "'", comparable10.equals(10));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        timeSeries2.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener4);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        int int15 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year14);
//        timeSeries13.setMaximumItemAge((long) 1);
//        boolean boolean18 = timeSeries13.getNotify();
//        java.lang.String str19 = timeSeries13.getDescription();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        int int24 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        java.lang.String str26 = year23.toString();
//        timeSeries13.setKey((java.lang.Comparable) year23);
//        long long28 = year23.getLastMillisecond();
//        boolean boolean29 = fixedMillisecond8.equals((java.lang.Object) long28);
//        long long30 = fixedMillisecond8.getFirstMillisecond();
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond8.peg(calendar31);
//        try {
//            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 1560441909725L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560441971072L + "'", long10 == 1560441971072L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560441971072L + "'", long30 == 1560441971072L);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (-458));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
//        java.util.Date date3 = day0.getStart();
//        int int4 = day0.getDayOfMonth();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        long long9 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(dateFormatSymbols1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (-11322));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        java.lang.Comparable comparable7 = timeSeries2.getKey();
        java.lang.Class class8 = null;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols10 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int11 = day9.compareTo((java.lang.Object) dateFormatSymbols10);
        java.util.Date date12 = day9.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date12);
        java.lang.String str16 = year15.toString();
        timeSeries2.setKey((java.lang.Comparable) str16);
        timeSeries2.setDomainDescription("ClassContext");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10 + "'", comparable7.equals(10));
        org.junit.Assert.assertNotNull(dateFormatSymbols10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
//        java.util.Date date3 = day0.getStart();
//        int int4 = day0.getDayOfMonth();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateFormatSymbols1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        java.lang.Comparable comparable7 = timeSeries2.getKey();
        timeSeries2.setDomainDescription("hi!");
        java.lang.String str10 = timeSeries2.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10 + "'", comparable7.equals(10));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols2 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int3 = day1.compareTo((java.lang.Object) dateFormatSymbols2);
        java.util.Date date4 = day1.getStart();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        long long8 = month7.getLastMillisecond();
        org.junit.Assert.assertNotNull(dateFormatSymbols2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13, 10);
        int int17 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getDayOfWeek();
        int int33 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean35 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean36 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean42 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean44 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate50.getDayOfWeek();
        int int52 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getDayOfWeek();
        int int58 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean60 = spreadsheetDate46.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean61 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(2);
        int int66 = spreadsheetDate65.getDayOfWeek();
        int int67 = spreadsheetDate63.compare((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(2);
        int int72 = spreadsheetDate71.getDayOfWeek();
        int int73 = spreadsheetDate69.compare((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(2);
        int int76 = spreadsheetDate75.getDayOfWeek();
        boolean boolean78 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate71, (org.jfree.data.time.SerialDate) spreadsheetDate75, 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        int int83 = spreadsheetDate82.getDayOfWeek();
        int int84 = spreadsheetDate80.compare((org.jfree.data.time.SerialDate) spreadsheetDate82);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(2);
        int int89 = spreadsheetDate88.getDayOfWeek();
        int int90 = spreadsheetDate86.compare((org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean91 = spreadsheetDate80.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate88);
        spreadsheetDate80.setDescription("13-June-2019");
        boolean boolean95 = spreadsheetDate56.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate80, 1900);
        int int96 = spreadsheetDate80.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2 + "'", int66 == 2);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2 + "'", int83 == 2);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 2 + "'", int89 == 2);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        java.util.Collection collection7 = timeSeries2.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            int int9 = timeSeries2.getIndex(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int7 = day5.compareTo((java.lang.Object) dateFormatSymbols6);
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date3, timeZone11);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeries16.setMaximumItemAge((long) 1);
        boolean boolean21 = timeSeries16.getNotify();
        java.lang.String str22 = timeSeries16.getDescription();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int27 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.next();
        java.lang.String str29 = year26.toString();
        timeSeries16.setKey((java.lang.Comparable) year26);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.previous();
        org.jfree.data.time.Year year33 = month31.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year33.previous();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols37 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int38 = day36.compareTo((java.lang.Object) dateFormatSymbols37);
        java.util.Date date39 = day36.getStart();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols42 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int43 = day41.compareTo((java.lang.Object) dateFormatSymbols42);
        java.util.Date date44 = day41.getStart();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date44, timeZone47);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date39, timeZone47);
        boolean boolean50 = year33.equals((java.lang.Object) timeZone47);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date3, timeZone47);
        java.lang.Class class54 = null;
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        int int57 = timeSeries55.getIndex((org.jfree.data.time.RegularTimePeriod) year56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) 0.0d);
        java.lang.Object obj60 = timeSeriesDataItem59.clone();
        java.lang.Class<?> wildcardClass61 = timeSeriesDataItem59.getClass();
        java.net.URL uRL62 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols64 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int65 = day63.compareTo((java.lang.Object) dateFormatSymbols64);
        java.util.Date date66 = day63.getStart();
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date66);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date66);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date66);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date66);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date66, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date3, timeZone71);
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(dateFormatSymbols37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(dateFormatSymbols42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(uRL62);
        org.junit.Assert.assertNotNull(dateFormatSymbols64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        int int7 = timeSeries2.getItemCount();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        timeSeries17.setMaximumItemAge((long) 1);
        boolean boolean22 = timeSeries17.getNotify();
        java.lang.String str23 = timeSeries17.getDescription();
        int int24 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries17);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.addAndOrUpdate(timeSeries27);
        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries27);
        java.util.Collection collection32 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        timeSeries27.setMaximumItemCount(12);
        timeSeries27.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(collection32);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, (java.lang.Class) wildcardClass16);
        boolean boolean18 = timeSeries17.getNotify();
        java.lang.Object obj19 = timeSeries17.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(obj19);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
//        long long6 = month5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441973925L + "'", long2 == 1560441973925L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441973925L + "'", long3 == 1560441973925L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.removeAgedItems(true);
        timeSeries2.setDescription("ClassContext");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        long long11 = month9.getFirstMillisecond();
        java.lang.Number number12 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        java.lang.String str6 = timeSeries2.getRangeDescription();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (short) 0);
        try {
            timeSeries2.add(timeSeriesDataItem9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
//        int int5 = timeSeries2.getItemCount();
//        timeSeries2.setDomainDescription("");
//        java.lang.Object obj8 = timeSeries2.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) (short) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.previous();
//        java.lang.Number number13 = timeSeries2.getValue(regularTimePeriod12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        int int19 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int24 = spreadsheetDate23.getDayOfWeek();
//        int int25 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        boolean boolean26 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        spreadsheetDate15.setDescription("13-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int31 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 1546329600000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond33.next();
//        try {
//            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 'a', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560441974022L + "'", long35 == 1560441974022L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560441974022L + "'", long36 == 1560441974022L);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
//        org.jfree.data.time.Year year7 = month5.getYear();
//        long long8 = month5.getLastMillisecond();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0.0d);
//        timeSeriesDataItem15.setValue((java.lang.Number) 100);
//        timeSeriesDataItem15.setValue((java.lang.Number) 1L);
//        boolean boolean21 = timeSeriesDataItem15.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.Number number22 = timeSeriesDataItem15.getValue();
//        boolean boolean23 = month5.equals((java.lang.Object) timeSeriesDataItem15);
//        boolean boolean25 = timeSeriesDataItem15.equals((java.lang.Object) (byte) 0);
//        java.lang.Object obj26 = timeSeriesDataItem15.clone();
//        int int27 = fixedMillisecond0.compareTo(obj26);
//        java.util.Date date28 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441974043L + "'", long2 == 1560441974043L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441974043L + "'", long4 == 1560441974043L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1L + "'", number22.equals(1L));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13, 10);
        int int17 = spreadsheetDate9.toSerial();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int5 = spreadsheetDate4.getDayOfWeek();
//        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int11 = spreadsheetDate10.getDayOfWeek();
//        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int15 = spreadsheetDate14.getDayOfWeek();
//        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int23 = spreadsheetDate22.getDayOfWeek();
//        int int24 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int29 = spreadsheetDate28.getDayOfWeek();
//        int int30 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        boolean boolean31 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        spreadsheetDate20.setDescription("13-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int36 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int42 = spreadsheetDate41.getDayOfWeek();
//        int int43 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int48 = spreadsheetDate47.getDayOfWeek();
//        int int49 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int52 = spreadsheetDate51.getDayOfWeek();
//        boolean boolean54 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate51, 10);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
//        java.util.Date date58 = spreadsheetDate57.toDate();
//        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate51.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean61 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate51, (int) (byte) -1);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.previous();
//        org.jfree.data.time.Year year64 = month62.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month62.previous();
//        java.lang.Class<?> wildcardClass66 = regularTimePeriod65.getClass();
//        boolean boolean67 = spreadsheetDate51.equals((java.lang.Object) regularTimePeriod65);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month68.previous();
//        org.jfree.data.time.Year year70 = month68.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
//        long long74 = fixedMillisecond71.getFirstMillisecond();
//        java.util.Date date75 = fixedMillisecond71.getTime();
//        boolean boolean76 = month68.equals((java.lang.Object) fixedMillisecond71);
//        long long77 = month68.getFirstMillisecond();
//        int int78 = month68.getYearValue();
//        try {
//            int int79 = spreadsheetDate51.compareTo((java.lang.Object) int78);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560441974189L + "'", long73 == 1560441974189L);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560441974189L + "'", long74 == 1560441974189L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1559372400000L + "'", long77 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0d);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        java.lang.Class<?> wildcardClass10 = timeSeriesDataItem8.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(classLoader13);
        org.junit.Assert.assertNull(inputStream14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Object obj0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.previous();
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) month1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        timeSeries2.setMaximumItemAge((long) (short) 10);
        try {
            java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getDayOfWeek();
        int int9 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        int int15 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean17 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        try {
            org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate1.getPreviousDayOfWeek((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        java.lang.Comparable comparable7 = timeSeries2.getKey();
        timeSeries2.setDomainDescription("hi!");
        timeSeries2.setDescription("Value");
        java.lang.String str12 = timeSeries2.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries2.add(regularTimePeriod13, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10 + "'", comparable7.equals(10));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Class class1 = null;
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 0.0d);
        java.lang.Object obj11 = timeSeriesDataItem10.clone();
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem10.getClass();
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols15 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int16 = day14.compareTo((java.lang.Object) dateFormatSymbols15);
        java.util.Date date17 = day14.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("August", (java.lang.Class) wildcardClass12);
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class1, (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNotNull(dateFormatSymbols15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getFirstMillisecond();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (short) 1);
        boolean boolean11 = month0.equals((java.lang.Object) (short) 1);
        java.lang.String str12 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month0.previous();
        java.util.Calendar calendar14 = null;
        try {
            month0.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, (java.lang.Class) wildcardClass16);
        boolean boolean18 = timeSeries17.getNotify();
        try {
            timeSeries17.update(9999, (java.lang.Number) 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        spreadsheetDate1.setDescription("13-June-2019");
        java.util.Date date15 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int7 = day5.compareTo((java.lang.Object) dateFormatSymbols6);
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date3, timeZone11);
        org.jfree.data.time.Year year14 = month13.getYear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.String str20 = timeSeries17.getRangeDescription();
        timeSeries17.setMaximumItemCount(1900);
        boolean boolean23 = month13.equals((java.lang.Object) timeSeries17);
        int int24 = month13.getMonth();
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("August");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0d);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        timeSeriesDataItem8.setValue((java.lang.Number) (short) 10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        java.lang.String str15 = timePeriodFormatException13.toString();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) timePeriodFormatException13);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.String str18 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: August" + "'", str18.equals("org.jfree.data.general.SeriesException: August"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560441910826L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, (java.lang.Class) wildcardClass16);
        boolean boolean18 = timeSeries17.getNotify();
        timeSeries17.removeAgedItems(false);
        int int21 = timeSeries17.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getMonth();
        java.util.Date date14 = spreadsheetDate9.toDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date14);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate17.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        int int8 = timeSeries5.getItemCount();
        java.lang.Object obj9 = timeSeries5.clone();
        boolean boolean10 = year2.equals(obj9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols12 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int13 = day11.compareTo((java.lang.Object) dateFormatSymbols12);
        java.util.Date date14 = day11.getStart();
        int int15 = day11.getYear();
        int int16 = day11.getMonth();
        int int17 = year2.compareTo((java.lang.Object) int16);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateFormatSymbols12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (short) 0);
        timeSeriesDataItem2.setValue((java.lang.Number) (byte) 100);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        boolean boolean7 = timeSeries2.getNotify();
        try {
            timeSeries2.setMaximumItemCount((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        int int22 = timeSeries19.getItemCount();
        long long23 = timeSeries19.getMaximumItemAge();
        timeSeries19.fireSeriesChanged();
        java.util.Collection collection25 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener26);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "June 2019", "ThreadContext", class3);
        timeSeries4.setRangeDescription("hi!");
        java.lang.String str7 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0d);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        timeSeries15.setMaximumItemAge((long) 1);
        boolean boolean20 = timeSeries15.getNotify();
        java.lang.String str21 = timeSeries15.getDescription();
        int int22 = timeSeriesDataItem12.compareTo((java.lang.Object) timeSeries15);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int27 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        int int28 = timeSeries25.getItemCount();
        java.lang.String str29 = timeSeries25.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries15.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.addAndOrUpdate(timeSeries15);
        int int32 = timeSeries15.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.addAndOrUpdate(timeSeries19);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries19);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries26.setMaximumItemAge((long) 1);
        boolean boolean31 = timeSeries26.getNotify();
        java.lang.String str32 = timeSeries26.getDescription();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int37 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
        java.lang.String str39 = year36.toString();
        timeSeries26.setKey((java.lang.Comparable) year36);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        long long43 = regularTimePeriod42.getMiddleMillisecond();
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year36, (java.lang.Object) regularTimePeriod42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
        long long46 = year36.getSerialIndex();
        long long47 = year36.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1558033199999L + "'", long43 == 1558033199999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate8.getDayOfWeek();
        boolean boolean10 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
        int int20 = spreadsheetDate19.getDayOfWeek();
        int int21 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getDayOfWeek();
        boolean boolean32 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate29, 10);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getDayOfWeek();
        int int39 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(2);
        int int44 = spreadsheetDate43.getDayOfWeek();
        int int45 = spreadsheetDate41.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean46 = spreadsheetDate35.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        spreadsheetDate35.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getDayOfWeek();
        int int58 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(2);
        int int63 = spreadsheetDate62.getDayOfWeek();
        int int64 = spreadsheetDate60.compare((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(2);
        int int67 = spreadsheetDate66.getDayOfWeek();
        boolean boolean69 = spreadsheetDate54.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate62, (org.jfree.data.time.SerialDate) spreadsheetDate66, 10);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date73 = spreadsheetDate72.toDate();
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate66.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate72);
        boolean boolean76 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate66, (int) (byte) -1);
        boolean boolean77 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate66);
        spreadsheetDate66.setDescription("ClassContext");
        boolean boolean80 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean83 = spreadsheetDate66.isOn((org.jfree.data.time.SerialDate) spreadsheetDate82);
        boolean boolean84 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(serialDate85);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        boolean boolean5 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate8.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        int int16 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        int int21 = spreadsheetDate20.getDayOfWeek();
        int int22 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getDayOfWeek();
        boolean boolean27 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate24, 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        int int33 = spreadsheetDate32.getDayOfWeek();
        int int34 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
        int int39 = spreadsheetDate38.getDayOfWeek();
        int int40 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        spreadsheetDate30.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        int int46 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getDayOfWeek();
        int int53 = spreadsheetDate49.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        int int58 = spreadsheetDate57.getDayOfWeek();
        int int59 = spreadsheetDate55.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(2);
        int int62 = spreadsheetDate61.getDayOfWeek();
        boolean boolean64 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate61, 10);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date68 = spreadsheetDate67.toDate();
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean71 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate61, (int) (byte) -1);
        boolean boolean72 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        spreadsheetDate61.setDescription("ClassContext");
        boolean boolean75 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date78 = spreadsheetDate77.toDate();
        boolean boolean79 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.String str5 = timeSeries2.getRangeDescription();
        timeSeries2.setMaximumItemAge(1560441922447L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int7 = day5.compareTo((java.lang.Object) dateFormatSymbols6);
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date3, timeZone11);
        org.jfree.data.time.Year year14 = month13.getYear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.String str20 = timeSeries17.getRangeDescription();
        timeSeries17.setMaximumItemCount(1900);
        boolean boolean23 = month13.equals((java.lang.Object) timeSeries17);
        java.util.List list24 = timeSeries17.getItems();
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.removeAgedItems(true);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (short) 1);
        java.lang.String str15 = year10.toString();
        long long16 = year10.getLastMillisecond();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.Year year19 = month17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.next();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 0.0d);
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        int int29 = month17.compareTo(obj28);
        boolean boolean30 = year10.equals(obj28);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        int int10 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
//        timeSeries8.setMaximumItemAge((long) 1);
//        boolean boolean13 = timeSeries8.getNotify();
//        java.lang.String str14 = timeSeries8.getDescription();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        java.lang.String str21 = year18.toString();
//        timeSeries8.setKey((java.lang.Comparable) year18);
//        long long23 = year18.getLastMillisecond();
//        boolean boolean24 = fixedMillisecond3.equals((java.lang.Object) long23);
//        long long25 = fixedMillisecond3.getFirstMillisecond();
//        java.util.Date date26 = fixedMillisecond3.getTime();
//        boolean boolean27 = day0.equals((java.lang.Object) fixedMillisecond3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441979771L + "'", long5 == 1560441979771L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560441979771L + "'", long25 == 1560441979771L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, (java.lang.Class) wildcardClass16);
        timeSeries17.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, (java.lang.Number) 1560441910409L);
        try {
            java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1560441910409L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
//        long long6 = fixedMillisecond3.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond3.getTime();
//        boolean boolean8 = month0.equals((java.lang.Object) fixedMillisecond3);
//        java.util.Date date9 = fixedMillisecond3.getTime();
//        long long10 = fixedMillisecond3.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441979997L + "'", long5 == 1560441979997L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441979997L + "'", long6 == 1560441979997L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560441979997L + "'", long10 == 1560441979997L);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        spreadsheetDate1.setDescription("");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0d);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        timeSeries15.setMaximumItemAge((long) 1);
        boolean boolean20 = timeSeries15.getNotify();
        java.lang.String str21 = timeSeries15.getDescription();
        int int22 = timeSeriesDataItem12.compareTo((java.lang.Object) timeSeries15);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int27 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        int int28 = timeSeries25.getItemCount();
        java.lang.String str29 = timeSeries25.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries15.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.addAndOrUpdate(timeSeries15);
        timeSeries15.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
//        timeSeries2.setMaximumItemAge((long) 1);
//        boolean boolean7 = timeSeries2.getNotify();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        boolean boolean13 = day10.equals((java.lang.Object) 97L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
//        try {
//            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (-1));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        timeSeries2.setDomainDescription("");
        timeSeries2.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.String str8 = timeSeries2.getDescription();
        timeSeries2.fireSeriesChanged();
        long long10 = timeSeries2.getMaximumItemAge();
        try {
            java.lang.Number number12 = timeSeries2.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int5 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0.0d);
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem7.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.util.Date date12 = null;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int15 = day13.compareTo((java.lang.Object) dateFormatSymbols14);
        java.util.Date date16 = day13.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(inputStream10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        timeSeries2.setNotify(false);
        java.util.Collection collection8 = timeSeries2.getTimePeriods();
        long long9 = timeSeries2.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.lang.String str16 = year13.toString();
        java.lang.Number number17 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        int int18 = year13.getYear();
        java.lang.String str19 = year13.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        long long3 = timeSeries2.getMaximumItemAge();
        int int4 = timeSeries2.getItemCount();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int7 = day5.compareTo((java.lang.Object) dateFormatSymbols6);
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int12 = day10.compareTo((java.lang.Object) dateFormatSymbols11);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13, timeZone16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date8, timeZone16);
        org.jfree.data.time.Year year19 = month18.getYear();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.String str25 = timeSeries22.getRangeDescription();
        timeSeries22.setMaximumItemCount(1900);
        boolean boolean28 = month18.equals((java.lang.Object) timeSeries22);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries2.addChangeListener(seriesChangeListener30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        int int3 = timeSeries2.getItemCount();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month4);
        int int6 = month4.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month4.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getYear();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class4);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
//        int int8 = timeSeries5.getItemCount();
//        timeSeries5.setMaximumItemAge((long) (short) 10);
//        java.lang.String str11 = timeSeries5.getDomainDescription();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
//        java.lang.String str18 = year15.toString();
//        int int19 = year15.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1));
//        java.lang.Object obj22 = null;
//        int int23 = year15.compareTo(obj22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
//        int int26 = year15.compareTo((java.lang.Object) regularTimePeriod25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod25, (double) (-1.0f));
//        int int29 = day0.compareTo((java.lang.Object) timeSeriesDataItem28);
//        long long30 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.removeAgedItems(true);
        java.lang.String str7 = timeSeries2.getDescription();
        timeSeries2.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year3);
        long long7 = year3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        int int12 = timeSeries9.getItemCount();
        timeSeries9.setNotify(false);
        java.util.Collection collection15 = timeSeries9.getTimePeriods();
        long long16 = timeSeries9.getMaximumItemAge();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.lang.String str23 = year20.toString();
        java.lang.Number number24 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
        java.lang.String str31 = year28.toString();
        int int32 = year28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year28.previous();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year28);
        java.lang.String str35 = timeSeries34.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        timeSeries2.setNotify(false);
        java.util.Collection collection8 = timeSeries2.getTimePeriods();
        long long9 = timeSeries2.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.lang.String str16 = year13.toString();
        java.lang.Number number17 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(13);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 0.0d);
        java.lang.Object obj31 = timeSeriesDataItem30.clone();
        java.lang.Class<?> wildcardClass32 = timeSeriesDataItem30.getClass();
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        org.jfree.data.time.Year year36 = month34.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.previous();
        java.lang.Class<?> wildcardClass38 = regularTimePeriod37.getClass();
        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass32, (java.lang.Class) wildcardClass38);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate19, "", "April", (java.lang.Class) wildcardClass32);
        java.lang.String str41 = timeSeries40.getDescription();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.previous();
        org.jfree.data.time.Year year44 = month42.getYear();
        long long45 = month42.getLastMillisecond();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        int int50 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 0.0d);
        timeSeriesDataItem52.setValue((java.lang.Number) 100);
        timeSeriesDataItem52.setValue((java.lang.Number) 1L);
        boolean boolean58 = timeSeriesDataItem52.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Number number59 = timeSeriesDataItem52.getValue();
        boolean boolean60 = month42.equals((java.lang.Object) timeSeriesDataItem52);
        java.lang.Object obj61 = null;
        int int62 = month42.compareTo(obj61);
        long long63 = month42.getSerialIndex();
        boolean boolean64 = timeSeries40.equals((java.lang.Object) month42);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month42, (double) 1560441962042L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(year44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1561964399999L + "'", long45 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 1L + "'", number59.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 24234L + "'", long63 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0d);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        java.lang.Class<?> wildcardClass10 = timeSeriesDataItem8.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(classLoader13);
        org.junit.Assert.assertNotNull(uRL14);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        timeSeries2.setDomainDescription("");
        try {
            timeSeries2.delete(3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols3 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int4 = day2.compareTo((java.lang.Object) dateFormatSymbols3);
        java.util.Date date5 = day2.getStart();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date11 = spreadsheetDate10.toDate();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0d);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        java.lang.Class<?> wildcardClass21 = timeSeriesDataItem19.getClass();
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols24 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int25 = day23.compareTo((java.lang.Object) dateFormatSymbols24);
        java.util.Date date26 = day23.getStart();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date26);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date26, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date11, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date5, timeZone31);
        try {
            org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date0, timeZone31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNotNull(dateFormatSymbols24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getDayOfWeek();
        int int9 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        int int15 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean17 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getDayOfWeek();
        int int25 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getDayOfWeek();
        int int31 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(9, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str35 = spreadsheetDate21.getDescription();
        int int36 = spreadsheetDate21.getYYYY();
        int int37 = spreadsheetDate21.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate21.getPreviousDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        spreadsheetDate1.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        int int17 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getDayOfWeek();
        int int23 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        timeSeries2.setMaximumItemCount((int) 'a');
        timeSeries2.setMaximumItemAge((long) 100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate14, class23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getDayOfWeek();
        int int31 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getDayOfWeek();
        int int37 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        int int40 = spreadsheetDate39.getDayOfWeek();
        boolean boolean42 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate39, 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getDayOfWeek();
        int int49 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        int int54 = spreadsheetDate53.getDayOfWeek();
        int int55 = spreadsheetDate51.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        spreadsheetDate45.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(2);
        int int67 = spreadsheetDate66.getDayOfWeek();
        int int68 = spreadsheetDate64.compare((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(2);
        int int73 = spreadsheetDate72.getDayOfWeek();
        int int74 = spreadsheetDate70.compare((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(2);
        int int77 = spreadsheetDate76.getDayOfWeek();
        boolean boolean79 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate72, (org.jfree.data.time.SerialDate) spreadsheetDate76, 10);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date83 = spreadsheetDate82.toDate();
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate76.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate82);
        boolean boolean86 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, (org.jfree.data.time.SerialDate) spreadsheetDate76, (int) (byte) -1);
        boolean boolean87 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        try {
            org.jfree.data.time.SerialDate serialDate89 = spreadsheetDate39.getNearestDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2 + "'", int73 == 2);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1, (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.String str8 = timeSeries2.getDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        timeSeries2.setKey((java.lang.Comparable) year12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries2.addChangeListener(seriesChangeListener17);
        int int19 = timeSeries2.getItemCount();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.previous();
        org.jfree.data.time.Year year22 = month20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month20.next();
        org.jfree.data.time.Year year24 = month20.getYear();
        int int25 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0d);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        timeSeries15.setMaximumItemAge((long) 1);
        boolean boolean20 = timeSeries15.getNotify();
        java.lang.String str21 = timeSeries15.getDescription();
        int int22 = timeSeriesDataItem12.compareTo((java.lang.Object) timeSeries15);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int27 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        int int28 = timeSeries25.getItemCount();
        java.lang.String str29 = timeSeries25.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries15.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.addAndOrUpdate(timeSeries15);
        java.lang.Comparable comparable32 = timeSeries2.getKey();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 10 + "'", comparable32.equals(10));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.String str8 = timeSeries2.getDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        timeSeries2.setKey((java.lang.Comparable) year12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries2.addChangeListener(seriesChangeListener17);
        int int19 = timeSeries2.getItemCount();
        timeSeries2.setMaximumItemAge(1560441906603L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
//        long long6 = fixedMillisecond3.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond3.getTime();
//        boolean boolean8 = month0.equals((java.lang.Object) fixedMillisecond3);
//        long long9 = month0.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
//        int int12 = month0.compareTo((java.lang.Object) year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441984522L + "'", long5 == 1560441984522L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441984522L + "'", long6 == 1560441984522L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getDayOfWeek();
        int int8 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        int int13 = spreadsheetDate12.getDayOfWeek();
        int int14 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        int int17 = spreadsheetDate16.getDayOfWeek();
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16, 10);
        int int20 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        int int22 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
//        long long7 = fixedMillisecond5.getFirstMillisecond();
//        long long8 = fixedMillisecond5.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) (-571));
//        long long11 = fixedMillisecond5.getFirstMillisecond();
//        long long12 = fixedMillisecond5.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(dateFormatSymbols1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "May" + "'", str1.equals("May"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getMonth();
        java.util.Date date14 = spreadsheetDate9.toDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols19 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int20 = day18.compareTo((java.lang.Object) dateFormatSymbols19);
        java.util.Date date21 = day18.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols24 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int25 = day23.compareTo((java.lang.Object) dateFormatSymbols24);
        java.util.Date date26 = day23.getStart();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date26, timeZone29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date21, timeZone29);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        int int36 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
        timeSeries34.setMaximumItemAge((long) 1);
        boolean boolean39 = timeSeries34.getNotify();
        java.lang.String str40 = timeSeries34.getDescription();
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        int int45 = timeSeries43.getIndex((org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.next();
        java.lang.String str47 = year44.toString();
        timeSeries34.setKey((java.lang.Comparable) year44);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month49.previous();
        org.jfree.data.time.Year year51 = month49.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) year51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year51.previous();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols55 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int56 = day54.compareTo((java.lang.Object) dateFormatSymbols55);
        java.util.Date date57 = day54.getStart();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols60 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int61 = day59.compareTo((java.lang.Object) dateFormatSymbols60);
        java.util.Date date62 = day59.getStart();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date62);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date62, timeZone65);
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date57, timeZone65);
        boolean boolean68 = year51.equals((java.lang.Object) timeZone65);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date21, timeZone65);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date14, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day70.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day70.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(dateFormatSymbols19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(dateFormatSymbols24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019" + "'", str47.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(dateFormatSymbols55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(dateFormatSymbols60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        timeSeries2.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        int int15 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
        int int20 = spreadsheetDate19.getDayOfWeek();
        int int21 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getDayOfWeek();
        boolean boolean26 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate23, 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getDayOfWeek();
        int int33 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getDayOfWeek();
        int int39 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate29.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        spreadsheetDate29.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate50.getDayOfWeek();
        int int52 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getDayOfWeek();
        int int58 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getDayOfWeek();
        boolean boolean63 = spreadsheetDate48.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, (org.jfree.data.time.SerialDate) spreadsheetDate60, 10);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date67 = spreadsheetDate66.toDate();
        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate60.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean70 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate60, (int) (byte) -1);
        boolean boolean71 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
        spreadsheetDate60.setDescription("ClassContext");
        java.lang.Class class76 = null;
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        int int79 = timeSeries77.getIndex((org.jfree.data.time.RegularTimePeriod) year78);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year78, (java.lang.Number) 0.0d);
        java.lang.Object obj82 = timeSeriesDataItem81.clone();
        java.lang.Class<?> wildcardClass83 = timeSeriesDataItem81.getClass();
        java.net.URL uRL84 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass83);
        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ClassContext", (java.lang.Class) wildcardClass83);
        java.util.Collection collection86 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries85);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNull(uRL84);
        org.junit.Assert.assertNotNull(collection86);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols2 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int3 = day1.compareTo((java.lang.Object) dateFormatSymbols2);
        java.util.Date date4 = day1.getStart();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.junit.Assert.assertNotNull(dateFormatSymbols2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        int int7 = timeSeries2.getItemCount();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        timeSeries17.setMaximumItemAge((long) 1);
        boolean boolean22 = timeSeries17.getNotify();
        java.lang.String str23 = timeSeries17.getDescription();
        int int24 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries17);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.addAndOrUpdate(timeSeries27);
        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries27);
        java.util.Collection collection32 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries2.addChangeListener(seriesChangeListener33);
        java.lang.String str35 = timeSeries2.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries2.addChangeListener(seriesChangeListener36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.String str8 = timeSeries2.getDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        timeSeries2.setKey((java.lang.Comparable) year12);
        timeSeries2.setMaximumItemAge((long) (short) 100);
        timeSeries2.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.lang.String str4 = regularTimePeriod3.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "14-June-2019" + "'", str4.equals("14-June-2019"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.addAndOrUpdate(timeSeries19);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries19);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries26.setMaximumItemAge((long) 1);
        boolean boolean31 = timeSeries26.getNotify();
        java.lang.String str32 = timeSeries26.getDescription();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int37 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
        java.lang.String str39 = year36.toString();
        timeSeries26.setKey((java.lang.Comparable) year36);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        long long43 = regularTimePeriod42.getMiddleMillisecond();
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year36, (java.lang.Object) regularTimePeriod42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month46.previous();
        long long48 = month46.getFirstMillisecond();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        int int53 = timeSeries51.getIndex((org.jfree.data.time.RegularTimePeriod) year52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) (short) 1);
        boolean boolean57 = month46.equals((java.lang.Object) (short) 1);
        try {
            timeSeries19.update((org.jfree.data.time.RegularTimePeriod) month46, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1558033199999L + "'", long43 == 1558033199999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1559372400000L + "'", long48 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "June 2019", "ThreadContext", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        java.lang.Comparable comparable7 = timeSeries2.getKey();
        timeSeries2.setDomainDescription("hi!");
        java.lang.Comparable comparable10 = timeSeries2.getKey();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10 + "'", comparable7.equals(10));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10 + "'", comparable10.equals(10));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int8 = day6.compareTo((java.lang.Object) dateFormatSymbols7);
        java.util.Date date9 = day6.getStart();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date3, timeZone12);
        int int15 = month14.getYearValue();
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        long long3 = timeSeries2.getMaximumItemAge();
//        timeSeries2.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
//        timeSeries10.setMaximumItemAge((long) 1);
//        boolean boolean15 = timeSeries10.getNotify();
//        java.lang.String str16 = timeSeries10.getDescription();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
//        java.lang.String str23 = year20.toString();
//        timeSeries10.setKey((java.lang.Comparable) year20);
//        long long25 = year20.getLastMillisecond();
//        boolean boolean26 = fixedMillisecond5.equals((java.lang.Object) long25);
//        long long27 = fixedMillisecond5.getFirstMillisecond();
//        long long28 = fixedMillisecond5.getMiddleMillisecond();
//        try {
//            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 1560441922447L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441987231L + "'", long7 == 1560441987231L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560441987231L + "'", long27 == 1560441987231L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560441987231L + "'", long28 == 1560441987231L);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = year0.equals(obj2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
//        int int5 = timeSeries2.getItemCount();
//        long long6 = timeSeries2.getMaximumItemAge();
//        timeSeries2.fireSeriesChanged();
//        java.lang.String str8 = timeSeries2.getDescription();
//        timeSeries2.setMaximumItemAge(1560441906603L);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        int int15 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 0.0d);
//        java.lang.Object obj18 = timeSeriesDataItem17.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (java.lang.Number) 1560441910409L);
//        java.lang.Number number22 = timeSeries2.getValue(regularTimePeriod19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        boolean boolean26 = day23.equals((java.lang.Object) 97L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) 1560441944048L);
//        try {
//            timeSeries2.add(timeSeriesDataItem29, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13, 10);
        int int17 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getDayOfWeek();
        int int33 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean35 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean36 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean42 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean44 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate50.getDayOfWeek();
        int int52 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getDayOfWeek();
        int int58 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean60 = spreadsheetDate46.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean61 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(2);
        int int66 = spreadsheetDate65.getDayOfWeek();
        int int67 = spreadsheetDate63.compare((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(2);
        int int72 = spreadsheetDate71.getDayOfWeek();
        int int73 = spreadsheetDate69.compare((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(2);
        int int76 = spreadsheetDate75.getDayOfWeek();
        boolean boolean78 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate71, (org.jfree.data.time.SerialDate) spreadsheetDate75, 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        int int83 = spreadsheetDate82.getDayOfWeek();
        int int84 = spreadsheetDate80.compare((org.jfree.data.time.SerialDate) spreadsheetDate82);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(2);
        int int89 = spreadsheetDate88.getDayOfWeek();
        int int90 = spreadsheetDate86.compare((org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean91 = spreadsheetDate80.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate88);
        spreadsheetDate80.setDescription("13-June-2019");
        boolean boolean95 = spreadsheetDate56.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate80, 1900);
        int int96 = spreadsheetDate63.getDayOfMonth();
        java.lang.Class<?> wildcardClass97 = spreadsheetDate63.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2 + "'", int66 == 2);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2 + "'", int83 == 2);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 2 + "'", int89 == 2);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
        org.junit.Assert.assertNotNull(wildcardClass97);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getFirstMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441987911L + "'", long2 == 1560441987911L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441987911L + "'", long3 == 1560441987911L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441987911L + "'", long6 == 1560441987911L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441987911L + "'", long8 == 1560441987911L);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
//        java.lang.Object obj15 = timeSeriesDataItem14.clone();
//        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, (java.lang.Class) wildcardClass16);
//        boolean boolean18 = timeSeries17.getNotify();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
//        long long21 = regularTimePeriod20.getMiddleMillisecond();
//        boolean boolean22 = timeSeries17.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols24 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int25 = day23.compareTo((java.lang.Object) dateFormatSymbols24);
//        java.util.Date date26 = day23.getStart();
//        int int27 = day23.getDayOfMonth();
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        long long30 = day23.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate31 = day23.getSerialDate();
//        int int32 = day23.getDayOfMonth();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        int int37 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) (short) 1);
//        java.lang.String str41 = year36.toString();
//        long long42 = year36.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year36);
//        int int44 = day23.getDayOfMonth();
//        java.util.Calendar calendar45 = null;
//        try {
//            long long46 = day23.getLastMillisecond(calendar45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1558033199999L + "'", long21 == 1558033199999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateFormatSymbols24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 13 + "'", int27 == 13);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 13 + "'", int32 == 13);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 13 + "'", int44 == 13);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate14, class23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.previous();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.previous();
        java.lang.Class<?> wildcardClass32 = regularTimePeriod31.getClass();
        try {
            timeSeries24.add(regularTimePeriod31, (double) 2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate8.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        int int16 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        int int21 = spreadsheetDate20.getDayOfWeek();
        int int22 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getDayOfWeek();
        boolean boolean27 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate24, 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        int int33 = spreadsheetDate32.getDayOfWeek();
        int int34 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
        int int39 = spreadsheetDate38.getDayOfWeek();
        int int40 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        spreadsheetDate30.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        int int46 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getDayOfWeek();
        int int53 = spreadsheetDate49.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        int int58 = spreadsheetDate57.getDayOfWeek();
        int int59 = spreadsheetDate55.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(2);
        int int62 = spreadsheetDate61.getDayOfWeek();
        boolean boolean64 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate61, 10);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date68 = spreadsheetDate67.toDate();
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean71 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate61, (int) (byte) -1);
        boolean boolean72 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean73 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        timeSeries5.clear();
        java.lang.Comparable comparable9 = timeSeries5.getKey();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries12.setMaximumItemAge((long) 1);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.String str18 = timeSeries12.getDescription();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
        java.lang.String str25 = year22.toString();
        timeSeries12.setKey((java.lang.Comparable) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.previous();
        org.jfree.data.time.Year year29 = month27.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) year29);
        java.util.Collection collection31 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        boolean boolean32 = timeSeries5.isEmpty();
        int int33 = year2.compareTo((java.lang.Object) boolean32);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10 + "'", comparable9.equals(10));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Value");
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        long long3 = timeSeries2.getMaximumItemAge();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols5 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int6 = day4.compareTo((java.lang.Object) dateFormatSymbols5);
//        java.util.Date date7 = day4.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
//        long long11 = fixedMillisecond9.getFirstMillisecond();
//        long long12 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (-571));
//        try {
//            timeSeries2.add(timeSeriesDataItem14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(dateFormatSymbols5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        boolean boolean5 = day0.equals((java.lang.Object) 1560441922447L);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0.0d);
        java.lang.Object obj16 = timeSeriesDataItem15.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0d);
        java.lang.Object obj24 = timeSeriesDataItem23.clone();
        java.lang.Class<?> wildcardClass25 = timeSeriesDataItem23.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15, (java.lang.Class) wildcardClass25);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 0.0d);
        java.lang.Object obj34 = timeSeriesDataItem33.clone();
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        int int39 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 0.0d);
        java.lang.Object obj42 = timeSeriesDataItem41.clone();
        java.lang.Class<?> wildcardClass43 = timeSeriesDataItem41.getClass();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem33, (java.lang.Class) wildcardClass43);
        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass25, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560441922447L, "ClassContext", "Thu Jun 13 09:05:46 PDT 2019", (java.lang.Class) wildcardClass25);
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(obj45);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        boolean boolean5 = day0.equals((java.lang.Object) 1560441922447L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getDayOfWeek();
        int int8 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        int int13 = spreadsheetDate12.getDayOfWeek();
        int int14 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        int int17 = spreadsheetDate16.getDayOfWeek();
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16, 10);
        int int20 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str21 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getDayOfWeek();
        int int31 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getDayOfWeek();
        int int37 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        int int40 = spreadsheetDate39.getDayOfWeek();
        boolean boolean42 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate39, 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getDayOfWeek();
        int int49 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        int int54 = spreadsheetDate53.getDayOfWeek();
        int int55 = spreadsheetDate51.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        spreadsheetDate45.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(2);
        int int67 = spreadsheetDate66.getDayOfWeek();
        int int68 = spreadsheetDate64.compare((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(2);
        int int73 = spreadsheetDate72.getDayOfWeek();
        int int74 = spreadsheetDate70.compare((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(2);
        int int77 = spreadsheetDate76.getDayOfWeek();
        boolean boolean79 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate72, (org.jfree.data.time.SerialDate) spreadsheetDate76, 10);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date83 = spreadsheetDate82.toDate();
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate76.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate82);
        boolean boolean86 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, (org.jfree.data.time.SerialDate) spreadsheetDate76, (int) (byte) -1);
        boolean boolean87 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean88 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate76);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2 + "'", int73 == 2);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getDayOfWeek();
        int int24 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
        int int29 = spreadsheetDate28.getDayOfWeek();
        int int30 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean31 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        spreadsheetDate20.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getDayOfWeek();
        int int43 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getDayOfWeek();
        int int49 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getDayOfWeek();
        boolean boolean54 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate51, 10);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date58 = spreadsheetDate57.toDate();
        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate51.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean61 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate51, (int) (byte) -1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(2);
        int int67 = spreadsheetDate66.getDayOfWeek();
        int int68 = spreadsheetDate64.compare((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(2);
        int int73 = spreadsheetDate72.getDayOfWeek();
        int int74 = spreadsheetDate70.compare((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(2);
        int int77 = spreadsheetDate76.getDayOfWeek();
        boolean boolean79 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate72, (org.jfree.data.time.SerialDate) spreadsheetDate76, 10);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date83 = spreadsheetDate82.toDate();
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate76.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate82);
        boolean boolean85 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate82);
        java.lang.String str86 = spreadsheetDate82.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2 + "'", int73 == 2);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "1-January-1900" + "'", str86.equals("1-January-1900"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 0.0d);
        timeSeriesDataItem10.setValue((java.lang.Number) 100);
        timeSeriesDataItem10.setValue((java.lang.Number) 1L);
        boolean boolean16 = timeSeriesDataItem10.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Number number17 = timeSeriesDataItem10.getValue();
        boolean boolean18 = month0.equals((java.lang.Object) timeSeriesDataItem10);
        boolean boolean20 = timeSeriesDataItem10.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj21 = timeSeriesDataItem10.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getDayOfWeek();
        int int33 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        spreadsheetDate23.setDescription("13-June-2019");
        boolean boolean37 = timeSeriesDataItem10.equals((java.lang.Object) "13-June-2019");
        java.lang.Number number38 = timeSeriesDataItem10.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1L + "'", number17.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1L + "'", number38.equals(1L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols5 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int6 = day4.compareTo((java.lang.Object) dateFormatSymbols5);
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7, timeZone10);
        long long12 = year11.getFirstMillisecond();
        boolean boolean13 = day0.equals((java.lang.Object) long12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(dateFormatSymbols5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        boolean boolean6 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2);
        int int16 = spreadsheetDate15.getDayOfWeek();
        int int17 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getDayOfWeek();
        int int23 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getDayOfWeek();
        boolean boolean28 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate25, 10);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(2);
        int int34 = spreadsheetDate33.getDayOfWeek();
        int int35 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        int int40 = spreadsheetDate39.getDayOfWeek();
        int int41 = spreadsheetDate37.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        spreadsheetDate31.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        int int47 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getDayOfWeek();
        int int54 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(2);
        int int59 = spreadsheetDate58.getDayOfWeek();
        int int60 = spreadsheetDate56.compare((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(2);
        int int63 = spreadsheetDate62.getDayOfWeek();
        boolean boolean65 = spreadsheetDate50.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate62, 10);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date69 = spreadsheetDate68.toDate();
        org.jfree.data.time.SerialDate serialDate70 = spreadsheetDate62.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate68);
        boolean boolean72 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate62, (int) (byte) -1);
        boolean boolean73 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        spreadsheetDate62.setDescription("ClassContext");
        boolean boolean76 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addMonths(12, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2 + "'", int53 == 2);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(serialDate77);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getDayOfWeek();
        int int9 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        int int15 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean17 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getDayOfWeek();
        int int25 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getDayOfWeek();
        int int31 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(9, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        int int22 = timeSeries19.getItemCount();
        java.lang.String str23 = timeSeries19.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries9.addAndOrUpdate(timeSeries19);
        timeSeries9.clear();
        java.lang.Class class26 = timeSeries9.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNull(class26);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
        int int18 = spreadsheetDate10.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getDayOfWeek();
        int int28 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        int int33 = spreadsheetDate32.getDayOfWeek();
        int int34 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean35 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean36 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean37 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean43 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean45 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getDayOfWeek();
        int int53 = spreadsheetDate49.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        int int58 = spreadsheetDate57.getDayOfWeek();
        int int59 = spreadsheetDate55.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean60 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean61 = spreadsheetDate47.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean62 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        try {
            org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getDayOfWeek();
        int int29 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(2);
        int int34 = spreadsheetDate33.getDayOfWeek();
        int int35 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getDayOfWeek();
        boolean boolean40 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate37, 10);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date44 = spreadsheetDate43.toDate();
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.lang.Object obj46 = null;
        boolean boolean47 = spreadsheetDate37.equals(obj46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getDayOfWeek();
        int int54 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(2);
        int int59 = spreadsheetDate58.getDayOfWeek();
        int int60 = spreadsheetDate56.compare((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(2);
        int int63 = spreadsheetDate62.getDayOfWeek();
        boolean boolean65 = spreadsheetDate50.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate62, 10);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date69 = spreadsheetDate68.toDate();
        org.jfree.data.time.SerialDate serialDate70 = spreadsheetDate62.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate68);
        spreadsheetDate68.setDescription("Thu Jun 13 09:05:46 PDT 2019");
        boolean boolean73 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SerialDate serialDate74 = serialDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2 + "'", int53 == 2);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(serialDate74);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Comparable comparable8 = timeSeries2.getKey();
        java.lang.Comparable comparable9 = timeSeries2.getKey();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10 + "'", comparable9.equals(10));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        long long6 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        java.lang.String str8 = timeSeries2.getDescription();
        timeSeries2.setRangeDescription("January");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class4);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
//        timeSeries5.setMaximumItemAge((long) 1);
//        boolean boolean10 = timeSeries5.getNotify();
//        java.lang.String str11 = timeSeries5.getDescription();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
//        java.lang.String str18 = year15.toString();
//        timeSeries5.setKey((java.lang.Comparable) year15);
//        long long20 = year15.getLastMillisecond();
//        boolean boolean21 = fixedMillisecond0.equals((java.lang.Object) long20);
//        long long22 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date23 = fixedMillisecond0.getTime();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 0.0d);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class<?> wildcardClass33 = timeSeriesDataItem31.getClass();
//        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols36 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int37 = day35.compareTo((java.lang.Object) dateFormatSymbols36);
//        java.util.Date date38 = day35.getStart();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date38);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date38, timeZone43);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date23, timeZone43);
//        java.util.Calendar calendar46 = null;
//        try {
//            long long47 = month45.getFirstMillisecond(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441992543L + "'", long2 == 1560441992543L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560441992543L + "'", long22 == 1560441992543L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNull(uRL34);
//        org.junit.Assert.assertNotNull(dateFormatSymbols36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
        java.util.Date date18 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean23 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate25);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
//        org.jfree.data.time.Year year7 = month5.getYear();
//        long long8 = month5.getLastMillisecond();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0.0d);
//        timeSeriesDataItem15.setValue((java.lang.Number) 100);
//        timeSeriesDataItem15.setValue((java.lang.Number) 1L);
//        boolean boolean21 = timeSeriesDataItem15.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.Number number22 = timeSeriesDataItem15.getValue();
//        boolean boolean23 = month5.equals((java.lang.Object) timeSeriesDataItem15);
//        boolean boolean25 = timeSeriesDataItem15.equals((java.lang.Object) (byte) 0);
//        java.lang.Object obj26 = timeSeriesDataItem15.clone();
//        int int27 = fixedMillisecond0.compareTo(obj26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441992629L + "'", long2 == 1560441992629L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441992629L + "'", long4 == 1560441992629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1L + "'", number22.equals(1L));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
//        int int5 = timeSeries2.getItemCount();
//        timeSeries2.setMaximumItemAge((long) (short) 10);
//        java.lang.String str8 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols10 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int11 = day9.compareTo((java.lang.Object) dateFormatSymbols10);
//        int int12 = day9.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class14 = timeSeries2.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.previous();
//        org.jfree.data.time.Year year17 = month15.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 2958465);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(dateFormatSymbols10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(13);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0d);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem12.getClass();
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.Year year18 = month16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass14, (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate1, "", "April", (java.lang.Class) wildcardClass14);
        java.lang.String str23 = timeSeries22.getDescription();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.previous();
        org.jfree.data.time.Year year26 = month24.getYear();
        long long27 = month24.getLastMillisecond();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 0.0d);
        timeSeriesDataItem34.setValue((java.lang.Number) 100);
        timeSeriesDataItem34.setValue((java.lang.Number) 1L);
        boolean boolean40 = timeSeriesDataItem34.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Number number41 = timeSeriesDataItem34.getValue();
        boolean boolean42 = month24.equals((java.lang.Object) timeSeriesDataItem34);
        java.lang.Object obj43 = null;
        int int44 = month24.compareTo(obj43);
        long long45 = month24.getSerialIndex();
        boolean boolean46 = timeSeries22.equals((java.lang.Object) month24);
        long long47 = month24.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1L + "'", number41.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 24234L + "'", long45 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1559372400000L + "'", long47 == 1559372400000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getLastMillisecond();
        java.lang.String str4 = month0.toString();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        long long6 = fixedMillisecond5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
//        org.junit.Assert.assertNotNull(dateFormatSymbols1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.removeAgedItems(true);
        java.lang.String str7 = timeSeries2.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.addChangeListener(seriesChangeListener8);
        timeSeries2.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getDayOfWeek();
        int int24 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
        int int29 = spreadsheetDate28.getDayOfWeek();
        int int30 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean31 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        spreadsheetDate20.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getDayOfWeek();
        int int43 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getDayOfWeek();
        int int49 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getDayOfWeek();
        boolean boolean54 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate51, 10);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date58 = spreadsheetDate57.toDate();
        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate51.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean61 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate51, (int) (byte) -1);
        int int62 = spreadsheetDate51.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(2);
        int int67 = spreadsheetDate66.getDayOfWeek();
        boolean boolean68 = spreadsheetDate64.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int69 = spreadsheetDate64.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean74 = spreadsheetDate71.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate64.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate71);
        boolean boolean76 = spreadsheetDate51.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate64);
        int int77 = spreadsheetDate64.toSerial();
        spreadsheetDate64.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2 + "'", int69 == 2);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 0.0d);
//        java.lang.Object obj19 = timeSeriesDataItem18.clone();
//        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem18.getClass();
//        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
//        org.jfree.data.time.Year year24 = month22.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.previous();
//        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
//        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass20, (java.lang.Class) wildcardClass26);
//        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", (java.lang.Class) wildcardClass20);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "Time", "Value", (java.lang.Class) wildcardClass20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441993302L + "'", long2 == 1560441993302L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441993302L + "'", long4 == 1560441993302L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNull(uRL21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNull(obj27);
//        org.junit.Assert.assertNull(inputStream28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        int int12 = timeSeries9.getItemCount();
        timeSeries9.setNotify(false);
        java.util.Collection collection15 = timeSeries9.getTimePeriods();
        long long16 = timeSeries9.getMaximumItemAge();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.lang.String str23 = year20.toString();
        java.lang.Number number24 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
        java.lang.String str31 = year28.toString();
        int int32 = year28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year28.previous();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols36 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int37 = day35.compareTo((java.lang.Object) dateFormatSymbols36);
        java.util.Date date38 = day35.getStart();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols41 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int42 = day40.compareTo((java.lang.Object) dateFormatSymbols41);
        java.util.Date date43 = day40.getStart();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date43);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date43, timeZone46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date38, timeZone46);
        org.jfree.data.time.Year year49 = month48.getYear();
        java.lang.Number number50 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month51.previous();
        org.jfree.data.time.Year year53 = month51.getYear();
        long long54 = year53.getSerialIndex();
        int int55 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year53);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(dateFormatSymbols36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateFormatSymbols41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNull(number50);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        spreadsheetDate1.setDescription("ThreadContext");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.addAndOrUpdate(timeSeries19);
        try {
            timeSeries22.delete((int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        long long3 = timeSeries2.getMaximumItemAge();
        int int4 = timeSeries2.getItemCount();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int7 = day5.compareTo((java.lang.Object) dateFormatSymbols6);
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int12 = day10.compareTo((java.lang.Object) dateFormatSymbols11);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13, timeZone16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date8, timeZone16);
        org.jfree.data.time.Year year19 = month18.getYear();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.String str25 = timeSeries22.getRangeDescription();
        timeSeries22.setMaximumItemCount(1900);
        boolean boolean28 = month18.equals((java.lang.Object) timeSeries22);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
        timeSeries32.setMaximumItemAge((long) 1);
        boolean boolean37 = timeSeries32.getNotify();
        java.lang.String str38 = timeSeries32.getDescription();
        timeSeries32.fireSeriesChanged();
        long long40 = timeSeries32.getMaximumItemAge();
        java.util.Collection collection41 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
        org.junit.Assert.assertNotNull(collection41);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0d);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 0.0d);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class<?> wildcardClass18 = timeSeriesDataItem16.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem8, (java.lang.Class) wildcardClass18);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 0.0d);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 0.0d);
        java.lang.Object obj35 = timeSeriesDataItem34.clone();
        java.lang.Class<?> wildcardClass36 = timeSeriesDataItem34.getClass();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem26, (java.lang.Class) wildcardClass36);
        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass36);
        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Overwritten values from: 10", (java.lang.Class) wildcardClass36);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNull(inputStream39);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod5.getClass();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 0.0d);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class<?> wildcardClass18 = timeSeriesDataItem16.getClass();
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.previous();
        org.jfree.data.time.Year year22 = month20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month20.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass24);
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", (java.lang.Class) wildcardClass18);
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass18);
        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("2019", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(uRL19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(inputStream26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(inputStream28);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "June 2019", "ThreadContext", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        timeSeries4.setRangeDescription("");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.addAndOrUpdate(timeSeries19);
        timeSeries19.setRangeDescription("Value");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        spreadsheetDate1.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        int int17 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        int int8 = timeSeriesDataItem2.compareTo((java.lang.Object) long7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 0.0d);
        timeSeriesDataItem10.setValue((java.lang.Number) 100);
        timeSeriesDataItem10.setValue((java.lang.Number) 1L);
        boolean boolean16 = timeSeriesDataItem10.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Number number17 = timeSeriesDataItem10.getValue();
        boolean boolean18 = month0.equals((java.lang.Object) timeSeriesDataItem10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem10.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1L + "'", number17.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0d);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries9.setMaximumItemAge((long) 1);
        boolean boolean14 = timeSeries9.getNotify();
        java.lang.String str15 = timeSeries9.getDescription();
        int int16 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries9);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.addAndOrUpdate(timeSeries19);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries19);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries26.setMaximumItemAge((long) 1);
        boolean boolean31 = timeSeries26.getNotify();
        java.lang.String str32 = timeSeries26.getDescription();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int37 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
        java.lang.String str39 = year36.toString();
        timeSeries26.setKey((java.lang.Comparable) year36);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        long long43 = regularTimePeriod42.getMiddleMillisecond();
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year36, (java.lang.Object) regularTimePeriod42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
        long long46 = year36.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1558033199999L + "'", long43 == 1558033199999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0d);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 0.0d);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class<?> wildcardClass18 = timeSeriesDataItem16.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem8, (java.lang.Class) wildcardClass18);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 0.0d);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 0.0d);
        java.lang.Object obj35 = timeSeriesDataItem34.clone();
        java.lang.Class<?> wildcardClass36 = timeSeriesDataItem34.getClass();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem26, (java.lang.Class) wildcardClass36);
        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass36);
        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("January", (java.lang.Class) wildcardClass36);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNull(inputStream39);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 8, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 0.0d);
//        java.lang.Object obj19 = timeSeriesDataItem18.clone();
//        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem18.getClass();
//        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
//        org.jfree.data.time.Year year24 = month22.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.previous();
//        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
//        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass20, (java.lang.Class) wildcardClass26);
//        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", (java.lang.Class) wildcardClass20);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "Time", "Value", (java.lang.Class) wildcardClass20);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        int int34 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
//        int int35 = timeSeries32.getItemCount();
//        java.lang.Object obj36 = timeSeries32.clone();
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        int int41 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) year40);
//        int int42 = timeSeries39.getItemCount();
//        timeSeries39.setNotify(false);
//        java.util.Collection collection45 = timeSeries39.getTimePeriods();
//        long long46 = timeSeries39.getMaximumItemAge();
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        int int51 = timeSeries49.getIndex((org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.next();
//        java.lang.String str53 = year50.toString();
//        java.lang.Number number54 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) year50);
//        java.lang.Class class56 = null;
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        int int59 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year58.next();
//        java.lang.String str61 = year58.toString();
//        int int62 = year58.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year58.previous();
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year50, (org.jfree.data.time.RegularTimePeriod) year58);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols66 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int67 = day65.compareTo((java.lang.Object) dateFormatSymbols66);
//        java.util.Date date68 = day65.getStart();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols71 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int72 = day70.compareTo((java.lang.Object) dateFormatSymbols71);
//        java.util.Date date73 = day70.getStart();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date73);
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date73, timeZone76);
//        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date68, timeZone76);
//        org.jfree.data.time.Year year79 = month78.getYear();
//        java.lang.Number number80 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) year79);
//        boolean boolean81 = fixedMillisecond0.equals((java.lang.Object) year79);
//        java.util.Calendar calendar82 = null;
//        long long83 = fixedMillisecond0.getLastMillisecond(calendar82);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441995249L + "'", long2 == 1560441995249L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441995249L + "'", long4 == 1560441995249L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNull(uRL21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNull(obj27);
//        org.junit.Assert.assertNull(inputStream28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
//        org.junit.Assert.assertNull(number54);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertNotNull(dateFormatSymbols66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(dateFormatSymbols71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNotNull(year79);
//        org.junit.Assert.assertNull(number80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560441995249L + "'", long83 == 1560441995249L);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441996002L + "'", long2 == 1560441996002L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441996002L + "'", long3 == 1560441996002L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441996002L + "'", long5 == 1560441996002L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560441910826L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(13);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0d);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem12.getClass();
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.Year year18 = month16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass14, (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate1, "", "April", (java.lang.Class) wildcardClass14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "");
        java.lang.String str24 = seriesChangeEvent23.toString();
        java.lang.Object obj25 = seriesChangeEvent23.getSource();
        java.lang.Object obj26 = seriesChangeEvent23.getSource();
        java.lang.String str27 = seriesChangeEvent23.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=]" + "'", str24.equals("org.jfree.data.general.SeriesChangeEvent[source=]"));
        org.junit.Assert.assertTrue("'" + obj25 + "' != '" + "" + "'", obj25.equals(""));
        org.junit.Assert.assertTrue("'" + obj26 + "' != '" + "" + "'", obj26.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=]" + "'", str27.equals("org.jfree.data.general.SeriesChangeEvent[source=]"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        timeSeries2.setNotify(false);
        java.util.Collection collection8 = timeSeries2.getTimePeriods();
        long long9 = timeSeries2.getMaximumItemAge();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.lang.String str16 = year13.toString();
        java.lang.Number number17 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries2.addChangeListener(seriesChangeListener18);
        try {
            timeSeries2.delete(11, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "June 2019", "ThreadContext", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        java.lang.Comparable comparable7 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0f) + "'", comparable7.equals((-1.0f)));
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        int int2 = day0.compareTo((java.lang.Object) dateFormatSymbols1);
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond6.peg(calendar8);
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond6.peg(calendar10);
//        org.junit.Assert.assertNotNull(dateFormatSymbols1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.previous();
        org.jfree.data.time.Year year9 = month7.getYear();
        long long10 = month7.getLastMillisecond();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 0.0d);
        timeSeriesDataItem17.setValue((java.lang.Number) 100);
        timeSeriesDataItem17.setValue((java.lang.Number) 1L);
        boolean boolean23 = timeSeriesDataItem17.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Number number24 = timeSeriesDataItem17.getValue();
        boolean boolean25 = month7.equals((java.lang.Object) timeSeriesDataItem17);
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1L + "'", number24.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries2.setMaximumItemAge((long) 1);
        java.lang.Comparable comparable7 = timeSeries2.getKey();
        java.lang.Class class8 = null;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols10 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int11 = day9.compareTo((java.lang.Object) dateFormatSymbols10);
        java.util.Date date12 = day9.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date12);
        java.lang.String str16 = year15.toString();
        timeSeries2.setKey((java.lang.Comparable) str16);
        timeSeries2.setDescription("ThreadContext");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10 + "'", comparable7.equals(10));
        org.junit.Assert.assertNotNull(dateFormatSymbols10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
//        int int12 = year10.getYear();
//        int int13 = fixedMillisecond0.compareTo((java.lang.Object) year10);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441996267L + "'", long2 == 1560441996267L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441996267L + "'", long3 == 1560441996267L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441996267L + "'", long6 == 1560441996267L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("May");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 1, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "January" + "'", str2.equals("January"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        long long3 = timeSeries2.getMaximumItemAge();
        int int4 = timeSeries2.getItemCount();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int7 = day5.compareTo((java.lang.Object) dateFormatSymbols6);
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int12 = day10.compareTo((java.lang.Object) dateFormatSymbols11);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13, timeZone16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date8, timeZone16);
        org.jfree.data.time.Year year19 = month18.getYear();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.String str25 = timeSeries22.getRangeDescription();
        timeSeries22.setMaximumItemCount(1900);
        boolean boolean28 = month18.equals((java.lang.Object) timeSeries22);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries2.removeChangeListener(seriesChangeListener30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year3);
//        int int5 = timeSeries2.getItemCount();
//        java.lang.Object obj6 = timeSeries2.clone();
//        int int7 = timeSeries2.getItemCount();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0d);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
//        timeSeries17.setMaximumItemAge((long) 1);
//        boolean boolean22 = timeSeries17.getNotify();
//        java.lang.String str23 = timeSeries17.getDescription();
//        int int24 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries17);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.addAndOrUpdate(timeSeries27);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries27);
//        java.util.Collection collection32 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        long long33 = timeSeries27.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond34.getMiddleMillisecond(calendar37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond34.getLastMillisecond(calendar39);
//        java.lang.Number number41 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar44 = null;
//        fixedMillisecond43.peg(calendar44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond43.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries27.addOrUpdate(regularTimePeriod46, (java.lang.Number) 9999);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month49.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560441996442L + "'", long36 == 1560441996442L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560441996442L + "'", long38 == 1560441996442L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560441996442L + "'", long40 == 1560441996442L);
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getDayOfWeek();
        int int9 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getDayOfWeek();
        int int15 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getDayOfWeek();
        boolean boolean20 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17, 10);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getDayOfWeek();
        int int33 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        spreadsheetDate23.setDescription("13-June-2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
        int int39 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getDayOfWeek();
        int int46 = spreadsheetDate42.compare((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate50.getDayOfWeek();
        int int52 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        int int55 = spreadsheetDate54.getDayOfWeek();
        boolean boolean57 = spreadsheetDate42.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 10);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date61 = spreadsheetDate60.toDate();
        org.jfree.data.time.SerialDate serialDate62 = spreadsheetDate54.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean64 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate54, (int) (byte) -1);
        boolean boolean65 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
        spreadsheetDate54.setDescription("ClassContext");
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class70);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        int int73 = timeSeries71.getIndex((org.jfree.data.time.RegularTimePeriod) year72);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year72, (java.lang.Number) 0.0d);
        java.lang.Object obj76 = timeSeriesDataItem75.clone();
        java.lang.Class<?> wildcardClass77 = timeSeriesDataItem75.getClass();
        java.net.URL uRL78 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass77);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ClassContext", (java.lang.Class) wildcardClass77);
        java.lang.ClassLoader classLoader80 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass77);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNull(uRL78);
        org.junit.Assert.assertNotNull(classLoader80);
    }
}

