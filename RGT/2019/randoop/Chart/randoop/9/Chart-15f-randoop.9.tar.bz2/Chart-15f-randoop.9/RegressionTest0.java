import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range1, lengthConstraintType2, (double) 1.0f, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, (double) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) -1, (float) 1, (double) 100, (float) (byte) 0, 0.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.Plot plot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = dateAxis1.reserveSpace(graphics2D2, plot3, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 10L, 0.0f, (double) 'a', (float) ' ', (float) 10);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        java.util.Date date6 = null;
        java.util.Date date7 = null;
        try {
            dateAxis1.setRange(date6, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) plotChangeListener8, (java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.text.TextLine textLine4 = textBlock3.getLastLine();
        org.jfree.chart.text.TextLine textLine5 = null;
        textBlock3.addLine(textLine5);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNull(textLine4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean11 = dateAxis10.isAxisLineVisible();
        dateAxis10.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        polarPlot15.addChangeListener(plotChangeListener16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = polarPlot15.getDrawingSupplier();
        java.awt.Color color19 = java.awt.Color.PINK;
        polarPlot15.setNoDataMessagePaint((java.awt.Paint) color19);
        dateAxis1.setTickLabelPaint((java.awt.Paint) color19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        dateAxis1.setFixedAutoRange((double) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { 0.0f };
        try {
            float[] floatArray4 = color0.getComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        java.awt.Color color11 = java.awt.Color.PINK;
        polarPlot7.setNoDataMessagePaint((java.awt.Paint) color11);
        float[] floatArray16 = new float[] { (short) 10, 10, (-1.0f) };
        try {
            float[] floatArray17 = color11.getComponents(floatArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        org.jfree.chart.title.Title title24 = null;
        try {
            jFreeChart23.addSubtitle(title24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        dateAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = java.awt.Color.PINK;
        float[] floatArray3 = new float[] { (byte) -1, 10L };
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray4 = null;
        try {
            float[] floatArray5 = color1.getComponents(colorSpace3, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        flowArrangement7.clear();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = null;
        try {
            piePlot3D0.setLabelDistributor(abstractPieLabelDistributor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        java.awt.Stroke stroke11 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color2.getComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor24 = null;
        try {
            piePlot3D20.setLabelDistributor(abstractPieLabelDistributor24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            textLine1.draw(graphics2D2, 10.0f, (float) 0, textAnchor5, (float) (byte) 1, 0.0f, 0.12d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        try {
            org.jfree.chart.title.Title title27 = jFreeChart23.getSubtitle((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        float[] floatArray9 = new float[] { 10.0f, (short) 0, (byte) 10, (byte) 100, 100, (byte) -1 };
        float[] floatArray10 = java.awt.Color.RGBtoHSB(100, (int) (byte) 100, (int) '4', floatArray9);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        piePlot3D0.zoom((double) 100L);
        boolean boolean4 = piePlot3D0.getIgnoreNullValues();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            piePlot3D0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        polarPlot7.removeCornerTextItem("hi!");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) horizontalAlignment1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) 1L);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range18 = dateAxis14.getRange();
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range18, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(45.0d, range18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint11.toRangeHeight(range18);
        try {
            org.jfree.chart.util.Size2D size2D24 = flowArrangement6.arrange(blockContainer7, graphics2D8, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) ' ', (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-14745631) + "'", int3 == (-14745631));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double3 = piePlot3D0.getExplodePercent((java.lang.Comparable) (-1L));
        piePlot3D0.setInteriorGap(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-17.0d) + "'", double2 == (-17.0d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double3 = rectangleInsets0.getTop();
        double double5 = rectangleInsets0.calculateBottomInset(8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            java.awt.Color color1 = java.awt.Color.decode("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"(C)opyright 2000-2007, by Object Refinery Limited and Contributors\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-1L), (double) 1.0f, 0, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 0, (float) (short) 10, textAnchor4, (-17.0d), (float) (short) -1, (float) (byte) -1);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { 1.0d, Double.NEGATIVE_INFINITY, (-1.0d), ' ' };
        java.lang.Comparable[] comparableArray5 = null;
        double[] doubleArray9 = new double[] { (-1.0f), (byte) -1, 4.0d };
        double[] doubleArray13 = new double[] { (-1.0f), (byte) -1, 4.0d };
        double[] doubleArray17 = new double[] { (-1.0f), (byte) -1, 4.0d };
        double[][] doubleArray18 = new double[][] { doubleArray9, doubleArray13, doubleArray17 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray5, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color0, paint1 };
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Stroke[] strokeArray6 = new java.awt.Stroke[] { stroke5 };
        java.awt.Stroke stroke7 = null;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke7 };
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray11 = new java.awt.Shape[] { shape9, shape10 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, paintArray4, strokeArray6, strokeArray8, shapeArray11);
        try {
            java.awt.Paint paint13 = defaultDrawingSupplier12.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shapeArray11);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double3 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets0.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        try {
            xYPlot0.setDomainAxisLocation((-14745631), axisLocation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 'a', (double) 1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot7.zoomDomainAxes((double) (byte) 1, 1.0E-5d, plotRenderingInfo14, point2D15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) 'a', 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle9.setHorizontalAlignment(horizontalAlignment10);
        java.lang.Object obj12 = legendTitle9.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("PlotOrientation.VERTICAL", font1, paint2, (float) 1L, (int) (short) -1, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        java.awt.Color color26 = java.awt.Color.PINK;
        jFreeChart23.setBorderPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = jFreeChart23.getBackgroundPaint();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        double double3 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Paint paint4 = piePlot3D0.getLabelOutlinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            piePlot3D0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL" + "'", str1.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL"));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double11 = dateAxis2.valueToJava2D((double) (short) 10, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 100, (double) 2, 0.0d, (double) (short) -1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL", font1, paint2, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, 100.0d, (double) (byte) -1, rectangleAnchor19);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        piePlot21.setIgnoreNullValues(false);
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot21.setSectionOutlinePaint((java.lang.Comparable) '#', paint25);
        boolean boolean27 = size2D16.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        polarPlot7.setOutlineVisible(false);
        java.awt.Color color10 = java.awt.Color.red;
        polarPlot7.setRadiusGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = null;
        try {
            dateAxis13.setTickMarkPosition(dateTickMarkPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        java.awt.Color color26 = java.awt.Color.BLACK;
        jFreeChart23.setBorderPaint((java.awt.Paint) color26);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot28 = jFreeChart23.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot3D cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = polarPlot7.getRadiusGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot7.getAxis();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(valueAxis11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.chart.event.ChartProgressEvent[source=-1]");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot18.getFixedDomainAxisSpace();
        xYPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot18.getDomainAxisLocation();
        double double23 = xYPlot18.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot18.rendererChanged(rendererChangeEvent24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        piePlot27.setIgnoreNullValues(false);
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot27.setSectionOutlinePaint((java.lang.Comparable) '#', paint31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor35 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean37 = textBlockAnchor35.equals((java.lang.Object) horizontalAlignment36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement41 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment36, verticalAlignment38, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot34, (org.jfree.chart.block.Arrangement) flowArrangement41, arrangement42);
        legendTitle43.setWidth(1.0d);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D50 = legendTitle43.arrange(graphics2D46, rectangleConstraint49);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, 100.0d, (double) (byte) -1, rectangleAnchor53);
        org.jfree.chart.plot.PiePlot3D piePlot3D55 = new org.jfree.chart.plot.PiePlot3D();
        double double56 = piePlot3D55.getDepthFactor();
        double double57 = piePlot3D55.getMaximumExplodePercent();
        boolean boolean58 = piePlot3D55.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        org.jfree.chart.plot.PiePlotState piePlotState61 = piePlot27.initialise(graphics2D33, rectangle2D54, (org.jfree.chart.plot.PiePlot) piePlot3D55, (java.lang.Integer) 100, plotRenderingInfo60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        xYPlot18.drawAnnotations(graphics2D26, rectangle2D54, plotRenderingInfo62);
        try {
            legendTitle9.draw(graphics2D17, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(textBlockAnchor35);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.12d + "'", double56 == 0.12d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(piePlotState61);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean7 = textBlock3.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean11 = dateAxis10.isAxisLineVisible();
        dateAxis10.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat14 = dateAxis10.getDateFormatOverride();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis10.setTickLabelFont(font15);
        java.awt.Color color17 = java.awt.Color.red;
        textBlock3.addLine("", font15, (java.awt.Paint) color17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = null;
        try {
            textBlock3.draw(graphics2D19, 0.0f, (float) 'a', textBlockAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(dateFormat14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        java.awt.Paint paint25 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("ClassContext", font17, paint25, (float) (byte) 0, textMeasurer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        java.awt.Paint paint12 = polarPlot7.getAngleGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot0.getDomainAxisEdge();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 35 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        double double25 = piePlot3D21.getShadowXOffset();
        boolean boolean26 = textBlockAnchor0.equals((java.lang.Object) piePlot3D21);
        piePlot3D21.setMinimumArcAngleToDraw((double) (short) 100);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        java.awt.Color color26 = java.awt.Color.PINK;
        jFreeChart23.setBorderPaint((java.awt.Paint) color26);
        java.util.List list28 = null;
        try {
            jFreeChart23.setSubtitles(list28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.lang.Object obj10 = polarPlot7.clone();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        java.lang.String str13 = polarPlot7.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Polar Plot" + "'", str13.equals("Polar Plot"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis3.java2DToValue((double) (short) -1, rectangle2D5, rectangleEdge6);
        org.jfree.data.Range range8 = numberAxis3.getRange();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setIgnoreNullValues(false);
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot10.setSectionOutlinePaint((java.lang.Comparable) '#', paint14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean20 = textBlockAnchor18.equals((java.lang.Object) horizontalAlignment19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment21, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17, (org.jfree.chart.block.Arrangement) flowArrangement24, arrangement25);
        legendTitle26.setWidth(1.0d);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D33 = legendTitle26.arrange(graphics2D29, rectangleConstraint32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, 100.0d, (double) (byte) -1, rectangleAnchor36);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        double double40 = piePlot3D38.getMaximumExplodePercent();
        boolean boolean41 = piePlot3D38.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.PiePlotState piePlotState44 = piePlot10.initialise(graphics2D16, rectangle2D37, (org.jfree.chart.plot.PiePlot) piePlot3D38, (java.lang.Integer) 100, plotRenderingInfo43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = numberAxis3.lengthToJava2D((double) 10, rectangle2D37, rectangleEdge45);
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace49 = xYPlot48.getFixedDomainAxisSpace();
        xYPlot48.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot48.getDomainAxisLocation();
        int int53 = xYPlot48.getRangeAxisCount();
        java.awt.geom.Point2D point2D54 = xYPlot48.getQuadrantOrigin();
        xYPlot47.setQuadrantOrigin(point2D54);
        org.jfree.chart.plot.PlotState plotState56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            piePlot3D0.draw(graphics2D2, rectangle2D37, point2D54, plotState56, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(piePlotState44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(axisSpace49);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(point2D54);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        int int28 = chartProgressEvent27.getPercent();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot7.zoomRangeAxes((double) (short) 1, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        polarPlot7.handleClick((-1), 0, plotRenderingInfo19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        java.awt.Shape shape8 = dateAxis2.getRightArrow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        blockContainer11.clear();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer11.arrange(graphics2D13);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(size2D14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PlotOrientation.VERTICAL", graphics2D1, (float) (short) 100, (float) '#', textAnchor4, (double) (byte) -1, (float) 15, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("ClassContext", font8, paint9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font8);
        java.awt.Color color15 = java.awt.Color.getColor("", 0);
        java.awt.Color color16 = java.awt.Color.getColor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", color15);
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL", font8, (java.awt.Paint) color15, (float) (-14745631), textMeasurer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.event.ChartProgressEvent[source=-1]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = piePlot3D0.getOutlineStroke();
        piePlot3D0.setLabelLinksVisible(false);
        double double12 = piePlot3D0.getLabelGap();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        boolean boolean17 = legendTitle9.getNotify();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        java.awt.Paint paint11 = polarPlot7.getAngleLabelPaint();
        polarPlot7.setAngleLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = xYPlot0.equals((java.lang.Object) stroke9);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        java.awt.Color color26 = java.awt.Color.PINK;
        jFreeChart23.setBorderPaint((java.awt.Paint) color26);
        java.lang.Object obj28 = jFreeChart23.getTextAntiAlias();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean34 = textBlockAnchor32.equals((java.lang.Object) horizontalAlignment33);
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment33, verticalAlignment35, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot31, (org.jfree.chart.block.Arrangement) flowArrangement38, arrangement39);
        legendTitle40.setWidth(1.0d);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D47 = legendTitle40.arrange(graphics2D43, rectangleConstraint46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D51 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, 100.0d, (double) (byte) -1, rectangleAnchor50);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets30.createInsetRectangle(rectangle2D51);
        try {
            jFreeChart23.draw(graphics2D29, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean6 = textBlockAnchor4.equals((java.lang.Object) horizontalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment7, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, (org.jfree.chart.block.Arrangement) flowArrangement10, arrangement11);
        legendTitle12.setWidth(1.0d);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D19 = legendTitle12.arrange(graphics2D15, rectangleConstraint18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, 100.0d, (double) (byte) -1, rectangleAnchor22);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets2.createInsetRectangle(rectangle2D23);
        try {
            blockBorder0.draw(graphics2D1, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        double double35 = piePlot3D28.getDepthFactor();
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            piePlot3D28.drawOutline(graphics2D36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.12d + "'", double35 == 0.12d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 10);
        java.text.DateFormat dateFormat8 = null;
        dateAxis1.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        try {
            java.util.Date date11 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint28 = jFreeChart24.getBorderPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        try {
            java.awt.image.BufferedImage bufferedImage33 = jFreeChart24.createBufferedImage((int) (byte) 10, (int) (byte) 10, (int) ' ', chartRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle9.setHorizontalAlignment(horizontalAlignment10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D12);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setFixedAutoRange((double) (short) 1);
        double double4 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.addFragment(textFragment2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        dateAxis1.setUpperMargin((double) '4');
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis1.setTickUnit(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint10 = dateAxis6.getTickMarkPaint();
        xYPlot0.setDomainGridlinePaint(paint10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            xYPlot0.addDomainMarker(marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart23.removeProgressListener(chartProgressListener24);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        java.awt.Font font12 = null;
        try {
            legendTitle9.setItemFont(font12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        boolean boolean26 = jFreeChart23.isBorderVisible();
        float float27 = jFreeChart23.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        boolean boolean3 = piePlot3D0.getDarkerSides();
        java.awt.Paint paint4 = piePlot3D0.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        piePlot3D0.setInsets(rectangleInsets5, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        boolean boolean16 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot14.getRangeAxis(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(valueAxis20);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke3);
        try {
            java.awt.Stroke stroke6 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to java.lang.Integer");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = numberAxis15.getStandardTickUnits();
        boolean boolean17 = numberAxis15.isInverted();
        numberAxis15.configure();
        int int19 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot14.addRangeMarker(marker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        java.awt.Paint paint12 = null;
        try {
            polarPlot7.setAngleLabelPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        blockContainer11.clear();
        java.util.List list13 = blockContainer11.getBlocks();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setIgnoreNullValues(false);
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot15.setSectionOutlinePaint((java.lang.Comparable) '#', paint19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean25 = textBlockAnchor23.equals((java.lang.Object) horizontalAlignment24);
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot22, (org.jfree.chart.block.Arrangement) flowArrangement29, arrangement30);
        legendTitle31.setWidth(1.0d);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D38 = legendTitle31.arrange(graphics2D34, rectangleConstraint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, 100.0d, (double) (byte) -1, rectangleAnchor41);
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D();
        double double44 = piePlot3D43.getDepthFactor();
        double double45 = piePlot3D43.getMaximumExplodePercent();
        boolean boolean46 = piePlot3D43.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.plot.PiePlotState piePlotState49 = piePlot15.initialise(graphics2D21, rectangle2D42, (org.jfree.chart.plot.PiePlot) piePlot3D43, (java.lang.Integer) 100, plotRenderingInfo48);
        try {
            blockContainer11.draw(graphics2D14, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.12d + "'", double44 == 0.12d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(piePlotState49);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint6 = dateAxis2.getTickMarkPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) dateAxis2);
        basicProjectInfo0.setCopyright("Polar Plot");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        java.lang.String str17 = size2D16.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str17.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setFixedAutoRange((double) (short) 1);
        double double4 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot3D0.getLabelPadding();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.12d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        try {
            dateAxis1.zoomRange((double) ' ', (-17.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.0) <= upper (-17.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        java.lang.String str8 = dateAxis1.getLabel();
        dateAxis1.setFixedDimension((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 10);
        java.awt.Shape shape8 = dateAxis1.getRightArrow();
        boolean boolean9 = dateAxis1.isInverted();
        dateAxis1.setAutoRangeMinimumSize((double) '#', true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        dateAxis4.resizeRange(0.025d, (double) 0.0f);
        boolean boolean19 = dateAxis4.isHiddenValue((long) (short) 1);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean24 = dateAxis23.isAxisLineVisible();
        dateAxis23.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range27 = dateAxis23.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = numberAxis29.java2DToValue((double) (short) -1, rectangle2D31, rectangleEdge32);
        org.jfree.data.Range range34 = numberAxis29.getRange();
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot();
        piePlot36.setIgnoreNullValues(false);
        java.awt.Paint paint40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot36.setSectionOutlinePaint((java.lang.Comparable) '#', paint40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean46 = textBlockAnchor44.equals((java.lang.Object) horizontalAlignment45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment45, verticalAlignment47, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot43, (org.jfree.chart.block.Arrangement) flowArrangement50, arrangement51);
        legendTitle52.setWidth(1.0d);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D59 = legendTitle52.arrange(graphics2D55, rectangleConstraint58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 100.0d, (double) (byte) -1, rectangleAnchor62);
        org.jfree.chart.plot.PiePlot3D piePlot3D64 = new org.jfree.chart.plot.PiePlot3D();
        double double65 = piePlot3D64.getDepthFactor();
        double double66 = piePlot3D64.getMaximumExplodePercent();
        boolean boolean67 = piePlot3D64.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.plot.PiePlotState piePlotState70 = piePlot36.initialise(graphics2D42, rectangle2D63, (org.jfree.chart.plot.PiePlot) piePlot3D64, (java.lang.Integer) 100, plotRenderingInfo69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis29.lengthToJava2D((double) 10, rectangle2D63, rectangleEdge71);
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace74 = xYPlot73.getFixedDomainAxisSpace();
        xYPlot73.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation77 = xYPlot73.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = xYPlot73.getDomainAxisEdge();
        double double79 = dateAxis23.java2DToValue(0.0d, rectangle2D63, rectangleEdge78);
        try {
            double double80 = dateAxis4.lengthToJava2D((double) '#', rectangle2D21, rectangleEdge78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.NEGATIVE_INFINITY + "'", double33 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.12d + "'", double65 == 0.12d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(piePlotState70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNull(axisSpace74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + (-9.223372036854776E18d) + "'", double79 == (-9.223372036854776E18d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelToolTip("");
        dateAxis1.setAutoTickUnitSelection(false);
        dateAxis1.setRangeAboutValue((double) 'a', 0.0d);
        dateAxis1.zoomRange((double) (-1), (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelToolTip("");
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        double double11 = piePlot3D10.getDepthFactor();
        double double13 = piePlot3D10.getExplodePercent((java.lang.Comparable) (-1L));
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3D10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.12d + "'", double11 == 0.12d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot7.zoomRangeAxes((double) (short) 1, plotRenderingInfo14, point2D15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        polarPlot7.drawBackgroundImage(graphics2D17, rectangle2D18);
        int int20 = polarPlot7.getSeriesCount();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        polarPlot7.setDataset(xYDataset21);
        java.lang.String str23 = polarPlot7.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
        waferMapPlot0.setBackgroundAlpha((float) 100);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double12 = rectangleInsets10.trimHeight((double) (byte) -1);
        double double14 = rectangleInsets10.trimWidth(0.0d);
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets10);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-9.0d) + "'", double12 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-16.0d) + "'", double14 == (-16.0d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Paint paint9 = piePlot3D0.getBaseSectionOutlinePaint();
        java.awt.Shape shape10 = null;
        try {
            piePlot3D0.setLegendItemShape(shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            xYPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        dateAxis1.setUpperMargin((double) '4');
        double double12 = dateAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.0d + "'", double12 == 52.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        double double3 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot3D0.getSectionPaint((java.lang.Comparable) (short) 10);
        java.awt.Shape shape6 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        chartEntity8.setURLText("hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        boolean boolean2 = numberAxis0.isInverted();
        java.awt.Shape shape3 = numberAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.util.List list17 = categoryPlot16.getCategories();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot16.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot19.getFixedDomainAxisSpace();
        xYPlot19.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot19.getDomainAxisLocation();
        int int24 = xYPlot19.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke26 = piePlot3D25.getLabelOutlineStroke();
        piePlot3D25.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke30 = piePlot3D29.getLabelOutlineStroke();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D29.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke32);
        piePlot3D25.setBaseSectionOutlineStroke(stroke32);
        xYPlot19.setRangeGridlineStroke(stroke32);
        categoryPlot16.setRangeGridlineStroke(stroke32);
        java.awt.Paint paint37 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        double double41 = piePlot3D38.getExplodePercent((java.lang.Comparable) (-1L));
        java.awt.Stroke stroke42 = piePlot3D38.getOutlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(8.0d, (java.awt.Paint) color1, stroke32, paint37, stroke42, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = xYPlot0.equals((java.lang.Object) stroke9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Paint paint11 = legendTitle9.getItemPaint();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setVisible(true);
        org.jfree.data.Range range8 = null;
        try {
            dateAxis1.setRangeWithMargins(range8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Color color2 = java.awt.Color.getColor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", (int) (short) 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean38 = dateAxis37.isAxisLineVisible();
        dateAxis37.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font41 = dateAxis37.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean46 = textBlockAnchor44.equals((java.lang.Object) horizontalAlignment45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment45, verticalAlignment47, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot43, (org.jfree.chart.block.Arrangement) flowArrangement50, arrangement51);
        legendTitle52.setWidth(1.0d);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D59 = legendTitle52.arrange(graphics2D55, rectangleConstraint58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 100.0d, (double) (byte) -1, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets42.createInsetRectangle(rectangle2D63);
        dateAxis37.setDownArrow((java.awt.Shape) rectangle2D64);
        categoryPlot14.drawBackgroundImage(graphics2D35, rectangle2D64);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = categoryPlot14.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNull(legendItemCollection67);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean38 = dateAxis37.isAxisLineVisible();
        dateAxis37.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font41 = dateAxis37.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean46 = textBlockAnchor44.equals((java.lang.Object) horizontalAlignment45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment45, verticalAlignment47, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot43, (org.jfree.chart.block.Arrangement) flowArrangement50, arrangement51);
        legendTitle52.setWidth(1.0d);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D59 = legendTitle52.arrange(graphics2D55, rectangleConstraint58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 100.0d, (double) (byte) -1, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets42.createInsetRectangle(rectangle2D63);
        dateAxis37.setDownArrow((java.awt.Shape) rectangle2D64);
        categoryPlot14.drawBackgroundImage(graphics2D35, rectangle2D64);
        org.jfree.chart.plot.Marker marker68 = null;
        org.jfree.chart.util.Layer layer69 = null;
        try {
            boolean boolean70 = categoryPlot14.removeDomainMarker((int) (byte) 10, marker68, layer69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        polarPlot7.zoomDomainAxes((double) 0.5f, 32.0d, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot7.getAxis();
        java.awt.Paint paint20 = polarPlot7.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            boolean boolean21 = categoryPlot14.removeAnnotation(categoryAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot6.getFixedDomainAxisSpace();
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot6.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation10);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setLabelAngle((double) (short) -1);
        boolean boolean17 = dateAxis14.isInverted();
        java.awt.Shape shape18 = dateAxis14.getDownArrow();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis14, false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.title.Title title11 = titleChangeEvent10.getTitle();
        org.jfree.chart.JFreeChart jFreeChart12 = titleChangeEvent10.getChart();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(title11);
        org.junit.Assert.assertNull(jFreeChart12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setDownArrow(shape10);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape10, "hi!", "");
        java.lang.String str15 = chartEntity14.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartEntity: tooltip = hi!" + "'", str15.equals("ChartEntity: tooltip = hi!"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            boolean boolean10 = xYPlot0.removeRangeMarker(0, marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 10);
        boolean boolean8 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartEntity: tooltip = hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        boolean boolean16 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        try {
            categoryPlot14.setRenderer((int) (short) -1, categoryItemRenderer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = null;
        try {
            piePlot3D1.setLabelDistributor(abstractPieLabelDistributor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("Size2D[width=0.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        dateAxis2.setLabelAngle((double) (short) -1);
        double double5 = dateAxis2.getLabelAngle();
        java.awt.Font font6 = dateAxis2.getTickLabelFont();
        java.awt.Color color9 = java.awt.Color.getColor("ClassContext", 10);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL", font6, (java.awt.Paint) color9, 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke7 = piePlot3D6.getLabelOutlineStroke();
        piePlot3D6.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke11 = piePlot3D10.getLabelOutlineStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D10.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke13);
        piePlot3D6.setBaseSectionOutlineStroke(stroke13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot3D6.getSimpleLabelOffset();
        boolean boolean17 = range5.equals((java.lang.Object) rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", graphics2D1, (float) 4, 0.5f, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textFragment1.draw(graphics2D2, (float) (-1), 100.0f, textAnchor5, (float) (-1L), (float) (-14745631), (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.Object obj17 = categoryAxis4.clone();
        java.awt.Font font20 = null;
        java.awt.Paint paint21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, paint21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean26 = textBlock22.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean30 = dateAxis29.isAxisLineVisible();
        dateAxis29.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat33 = dateAxis29.getDateFormatOverride();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis29.setTickLabelFont(font34);
        java.awt.Color color36 = java.awt.Color.red;
        textBlock22.addLine("", font34, (java.awt.Paint) color36);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) piePlot3D38, false);
        boolean boolean42 = jFreeChart41.isNotify();
        float float43 = jFreeChart41.getBackgroundImageAlpha();
        java.awt.Color color44 = java.awt.Color.PINK;
        jFreeChart41.setBorderPaint((java.awt.Paint) color44);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis4, jFreeChart41, chartChangeEventType46);
        int int48 = categoryPlot0.getDomainAxisIndex(categoryAxis4);
        double double49 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(dateFormat33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        boolean boolean12 = polarPlot7.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        dateAxis13.setLabelToolTip("");
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis13.setMaximumDate(date20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        java.util.List list24 = categoryPlot23.getCategories();
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot23.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot26.getFixedDomainAxisSpace();
        xYPlot26.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot26.getDomainAxisLocation();
        int int31 = xYPlot26.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke33 = piePlot3D32.getLabelOutlineStroke();
        piePlot3D32.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke37 = piePlot3D36.getLabelOutlineStroke();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D36.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke39);
        piePlot3D32.setBaseSectionOutlineStroke(stroke39);
        xYPlot26.setRangeGridlineStroke(stroke39);
        categoryPlot23.setRangeGridlineStroke(stroke39);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean47 = dateAxis46.isAxisLineVisible();
        dateAxis46.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font50 = dateAxis46.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor53 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean55 = textBlockAnchor53.equals((java.lang.Object) horizontalAlignment54);
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement59 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment54, verticalAlignment56, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot52, (org.jfree.chart.block.Arrangement) flowArrangement59, arrangement60);
        legendTitle61.setWidth(1.0d);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D68 = legendTitle61.arrange(graphics2D64, rectangleConstraint67);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, 100.0d, (double) (byte) -1, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets51.createInsetRectangle(rectangle2D72);
        dateAxis46.setDownArrow((java.awt.Shape) rectangle2D73);
        categoryPlot23.drawBackgroundImage(graphics2D44, rectangle2D73);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = categoryPlot76.getRangeAxisEdge((int) (byte) 1);
        double double79 = categoryAxis1.getCategoryMiddle((int) (byte) 100, 1, rectangle2D73, rectangleEdge78);
        double double80 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(list24);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(textBlockAnchor53);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(size2D68);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + (-180.99999999999997d) + "'", double79 == (-180.99999999999997d));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.05d + "'", double80 == 0.05d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        polarPlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = polarPlot19.getDrawingSupplier();
        java.awt.Color color23 = java.awt.Color.PINK;
        polarPlot19.setNoDataMessagePaint((java.awt.Paint) color23);
        textTitle10.setPaint((java.awt.Paint) color23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        try {
            textTitle10.setTextAlignment(horizontalAlignment26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setCategoryLabelPositionOffset((int) (short) 10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis0.setMarkerBand(markerAxisBand2);
        org.jfree.data.RangeType rangeType4 = null;
        try {
            numberAxis0.setRangeType(rangeType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.util.TableOrder tableOrder3 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        java.awt.Stroke stroke10 = null;
        try {
            xYPlot0.setDomainCrosshairStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot6.getFixedDomainAxisSpace();
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot6.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation10);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setRangeAxes(valueAxisArray12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Polar Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        try {
            xYPlot0.addRangeMarker(marker4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.lang.String str28 = chartProgressEvent27.toString();
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        chartProgressEvent27.setChart(jFreeChart29);
        int int31 = chartProgressEvent27.getType();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1]" + "'", str28.equals("org.jfree.chart.event.ChartProgressEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setFixedAutoRange((double) (short) 1);
        dateAxis1.zoomRange((-9.223372036854776E18d), (double) (byte) 100);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        java.awt.Paint paint8 = dateAxis2.getLabelPaint();
        boolean boolean9 = dateAxis2.isVisible();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        xYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment14, verticalAlignment15, (double) (byte) 10, (double) 100);
        org.jfree.chart.block.Block block19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean24 = textBlockAnchor22.equals((java.lang.Object) horizontalAlignment23);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement28 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment25, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot21, (org.jfree.chart.block.Arrangement) flowArrangement28, arrangement29);
        legendTitle30.setWidth(1.0d);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D37 = legendTitle30.arrange(graphics2D33, rectangleConstraint36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 100.0d, (double) (byte) -1, rectangleAnchor40);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets20.createInsetRectangle(rectangle2D41);
        columnArrangement18.add(block19, (java.lang.Object) rectangle2D42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        xYPlot10.drawAnnotations(graphics2D13, rectangle2D42, plotRenderingInfo44);
        dateAxis2.setDownArrow((java.awt.Shape) rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        java.util.List list3 = null;
        projectInfo0.setContributors(list3);
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint28 = jFreeChart24.getBorderPaint();
        jFreeChart24.setAntiAlias(false);
        org.jfree.chart.plot.Plot plot31 = jFreeChart24.getPlot();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace33 = xYPlot32.getFixedDomainAxisSpace();
        xYPlot32.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot32.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean39 = dateAxis38.isAxisLineVisible();
        dateAxis38.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint42 = dateAxis38.getTickMarkPaint();
        xYPlot32.setDomainGridlinePaint(paint42);
        plot31.setBackgroundPaint(paint42);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertNull(axisSpace33);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        boolean boolean12 = textTitle10.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) horizontalAlignment3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment5, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement8, arrangement9);
        legendTitle10.setWidth(1.0d);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D17 = legendTitle10.arrange(graphics2D13, rectangleConstraint16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 100.0d, (double) (byte) -1, rectangleAnchor20);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets0.createInsetRectangle(rectangle2D21);
        double double24 = rectangleInsets0.calculateRightOutset((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.lang.Object obj15 = categoryAxis2.clone();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean19 = dateAxis18.isAxisLineVisible();
        dateAxis18.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font22 = dateAxis18.getTickLabelFont();
        categoryAxis2.setTickLabelFont((java.lang.Comparable) (-9.0d), font22);
        int int24 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) "Other", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setIgnoreNullValues(false);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot9.setSectionOutlinePaint((java.lang.Comparable) '#', paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) horizontalAlignment18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment20, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) flowArrangement23, arrangement24);
        legendTitle25.setWidth(1.0d);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D32 = legendTitle25.arrange(graphics2D28, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 100.0d, (double) (byte) -1, rectangleAnchor35);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        double double38 = piePlot3D37.getDepthFactor();
        double double39 = piePlot3D37.getMaximumExplodePercent();
        boolean boolean40 = piePlot3D37.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = piePlot9.initialise(graphics2D15, rectangle2D36, (org.jfree.chart.plot.PiePlot) piePlot3D37, (java.lang.Integer) 100, plotRenderingInfo42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D36, plotRenderingInfo44);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.Marker marker47 = null;
        try {
            xYPlot0.addRangeMarker(marker47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.12d + "'", double38 == 0.12d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(piePlotState43);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range16 = dateAxis12.getRange();
        org.jfree.data.Range range19 = org.jfree.data.Range.expand(range16, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(45.0d, range16);
        boolean boolean21 = dateAxis1.equals((java.lang.Object) 45.0d);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setLabelAngle((double) (short) -1);
        boolean boolean26 = dateAxis23.isInverted();
        java.awt.Shape shape27 = dateAxis23.getDownArrow();
        dateAxis1.setLeftArrow(shape27);
        java.awt.Stroke stroke29 = dateAxis1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke7 = piePlot3D6.getLabelOutlineStroke();
        piePlot3D6.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke11 = piePlot3D10.getLabelOutlineStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D10.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke13);
        piePlot3D6.setBaseSectionOutlineStroke(stroke13);
        xYPlot0.setRangeGridlineStroke(stroke13);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation21);
        java.lang.Object obj23 = xYPlot0.clone();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        dateAxis9.setLabelAngle((double) (short) -1);
        java.awt.Shape shape12 = dateAxis9.getLeftArrow();
        java.util.Date date13 = dateAxis9.getMinimumDate();
        dateAxis1.setMinimumDate(date13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setLabelAngle((double) (short) -1);
        boolean boolean4 = dateAxis1.isInverted();
        java.awt.Shape shape5 = dateAxis1.getDownArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Paint paint9 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D0.getSimpleLabelOffset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = piePlot3D0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = xYPlot0.equals((java.lang.Object) stroke9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.title.Title title11 = titleChangeEvent10.getTitle();
        org.jfree.chart.title.Title title12 = titleChangeEvent10.getTitle();
        double double13 = title12.getContentYOffset();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(title11);
        org.junit.Assert.assertNotNull(title12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot3D0.getSimpleLabelOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        polarPlot7.zoomDomainAxes((double) 0.5f, 32.0d, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot7.getAxis();
        java.awt.Shape shape20 = valueAxis19.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double3 = piePlot3D0.getExplodePercent((java.lang.Comparable) (-1L));
        java.awt.Stroke stroke4 = piePlot3D0.getOutlineStroke();
        piePlot3D0.setShadowYOffset((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        piePlot0.setSectionOutlinesVisible(false);
        piePlot0.setNoDataMessage("ChartEntity: tooltip = hi!");
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Paint paint1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.util.List list17 = categoryPlot16.getCategories();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot16.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot16.datasetChanged(datasetChangeEvent19);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        double double23 = piePlot3D22.getDepthFactor();
        double double25 = piePlot3D22.getExplodePercent((java.lang.Comparable) (-1L));
        java.awt.Stroke stroke26 = piePlot3D22.getOutlineStroke();
        categoryPlot16.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke29 = piePlot3D28.getLabelOutlineStroke();
        java.lang.Object obj30 = piePlot3D28.clone();
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D28.setSectionPaint((java.lang.Comparable) 1.0d, paint32);
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint35 = piePlot3D34.getLabelOutlinePaint();
        piePlot3D28.setLabelBackgroundPaint(paint35);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke38 = piePlot3D37.getLabelOutlineStroke();
        java.awt.Stroke stroke40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D37.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke40);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 15, paint1, stroke26, paint35, stroke40, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.12d + "'", double23 == 0.12d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot0.setDataset(0, xYDataset2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint10 = categoryAxis6.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint11 = categoryAxis6.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean19 = dateAxis18.isAxisLineVisible();
        dateAxis18.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat22 = dateAxis18.getDateFormatOverride();
        dateAxis18.setLabelToolTip("");
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis18.setMaximumDate(date25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer27);
        java.util.List list29 = categoryPlot28.getCategories();
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot28.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace32 = xYPlot31.getFixedDomainAxisSpace();
        xYPlot31.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation();
        int int36 = xYPlot31.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke38 = piePlot3D37.getLabelOutlineStroke();
        piePlot3D37.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke42 = piePlot3D41.getLabelOutlineStroke();
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D41.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke44);
        piePlot3D37.setBaseSectionOutlineStroke(stroke44);
        xYPlot31.setRangeGridlineStroke(stroke44);
        categoryPlot28.setRangeGridlineStroke(stroke44);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean52 = dateAxis51.isAxisLineVisible();
        dateAxis51.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font55 = dateAxis51.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor58 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment59 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean60 = textBlockAnchor58.equals((java.lang.Object) horizontalAlignment59);
        org.jfree.chart.util.VerticalAlignment verticalAlignment61 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement64 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment59, verticalAlignment61, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement65 = null;
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot57, (org.jfree.chart.block.Arrangement) flowArrangement64, arrangement65);
        legendTitle66.setWidth(1.0d);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D73 = legendTitle66.arrange(graphics2D69, rectangleConstraint72);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor76 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D77 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D73, 100.0d, (double) (byte) -1, rectangleAnchor76);
        java.awt.geom.Rectangle2D rectangle2D78 = rectangleInsets56.createInsetRectangle(rectangle2D77);
        dateAxis51.setDownArrow((java.awt.Shape) rectangle2D78);
        categoryPlot28.drawBackgroundImage(graphics2D49, rectangle2D78);
        org.jfree.chart.plot.CategoryPlot categoryPlot81 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = categoryPlot81.getRangeAxisEdge((int) (byte) 1);
        double double84 = categoryAxis6.getCategoryMiddle((int) (byte) 100, 1, rectangle2D78, rectangleEdge83);
        xYPlot0.drawBackgroundImage(graphics2D4, rectangle2D78);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(dateFormat22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(list29);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(textBlockAnchor58);
        org.junit.Assert.assertNotNull(horizontalAlignment59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(verticalAlignment61);
        org.junit.Assert.assertNotNull(size2D73);
        org.junit.Assert.assertNotNull(rectangleAnchor76);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + (-180.99999999999997d) + "'", double84 == (-180.99999999999997d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.Object obj17 = categoryAxis4.clone();
        java.awt.Font font20 = null;
        java.awt.Paint paint21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, paint21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean26 = textBlock22.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean30 = dateAxis29.isAxisLineVisible();
        dateAxis29.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat33 = dateAxis29.getDateFormatOverride();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis29.setTickLabelFont(font34);
        java.awt.Color color36 = java.awt.Color.red;
        textBlock22.addLine("", font34, (java.awt.Paint) color36);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) piePlot3D38, false);
        boolean boolean42 = jFreeChart41.isNotify();
        float float43 = jFreeChart41.getBackgroundImageAlpha();
        java.awt.Color color44 = java.awt.Color.PINK;
        jFreeChart41.setBorderPaint((java.awt.Paint) color44);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis4, jFreeChart41, chartChangeEventType46);
        int int48 = categoryPlot0.getDomainAxisIndex(categoryAxis4);
        double double49 = categoryAxis4.getUpperMargin();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(dateFormat33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        jFreeChart23.clearSubtitles();
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        double double28 = piePlot3D27.getDepthFactor();
        double double29 = piePlot3D27.getMaximumExplodePercent();
        double double30 = piePlot3D27.getMaximumExplodePercent();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setLabelLinkStroke(stroke31);
        jFreeChart23.setBorderStroke(stroke31);
        org.jfree.chart.plot.Plot plot34 = jFreeChart23.getPlot();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot35 = jFreeChart23.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot3D cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.12d + "'", double28 == 0.12d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(plot34);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=0.0, height=0.0]", font1, (java.awt.Paint) color2, 2.0f, textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setLabelAngle((double) (short) -1);
        double double4 = dateAxis1.getLabelAngle();
        java.awt.Font font5 = dateAxis1.getTickLabelFont();
        double double6 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis3D0.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "HorizontalAlignment.CENTER", "ChartEntity: tooltip = (C)opyright 2000-2007, by Object Refinery Limited and Contributors", "Polar Plot");
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        double double25 = piePlot3D21.getShadowXOffset();
        boolean boolean26 = textBlockAnchor0.equals((java.lang.Object) piePlot3D21);
        java.awt.Paint paint27 = piePlot3D21.getOutlinePaint();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        java.awt.Paint paint8 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            xYPlot0.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        double double3 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D0.setLabelLinkStroke(stroke4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        dateAxis11.setLabelToolTip("");
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis11.setMaximumDate(date18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        java.lang.Object obj22 = categoryAxis9.clone();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean26 = dateAxis25.isAxisLineVisible();
        dateAxis25.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font29 = dateAxis25.getTickLabelFont();
        categoryAxis9.setTickLabelFont((java.lang.Comparable) (-9.0d), font29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.AxisState axisState32 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double35 = rectangleInsets33.trimHeight((double) (byte) -1);
        double double36 = rectangleInsets33.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean41 = textBlockAnchor39.equals((java.lang.Object) horizontalAlignment40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment40, verticalAlignment42, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot38, (org.jfree.chart.block.Arrangement) flowArrangement45, arrangement46);
        legendTitle47.setWidth(1.0d);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D54 = legendTitle47.arrange(graphics2D50, rectangleConstraint53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D54, 100.0d, (double) (byte) -1, rectangleAnchor57);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets37.createInsetRectangle(rectangle2D58);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets33.createAdjustedRectangle(rectangle2D58, lengthAdjustmentType60, lengthAdjustmentType61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.util.List list64 = categoryAxis9.refreshTicks(graphics2D31, axisState32, rectangle2D62, rectangleEdge63);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean68 = dateAxis67.isAxisLineVisible();
        dateAxis67.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer71 = null;
        org.jfree.chart.plot.PolarPlot polarPlot72 = new org.jfree.chart.plot.PolarPlot(xYDataset65, (org.jfree.chart.axis.ValueAxis) dateAxis67, polarItemRenderer71);
        org.jfree.chart.event.PlotChangeListener plotChangeListener73 = null;
        polarPlot72.addChangeListener(plotChangeListener73);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier75 = polarPlot72.getDrawingSupplier();
        java.awt.Color color76 = java.awt.Color.PINK;
        polarPlot72.setNoDataMessagePaint((java.awt.Paint) color76);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        org.jfree.chart.plot.XYPlot xYPlot80 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace82 = xYPlot81.getFixedDomainAxisSpace();
        xYPlot81.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation85 = xYPlot81.getDomainAxisLocation();
        int int86 = xYPlot81.getRangeAxisCount();
        java.awt.geom.Point2D point2D87 = xYPlot81.getQuadrantOrigin();
        xYPlot80.setQuadrantOrigin(point2D87);
        polarPlot72.zoomDomainAxes(0.0d, plotRenderingInfo79, point2D87);
        org.jfree.chart.plot.PlotState plotState90 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = null;
        try {
            piePlot3D0.draw(graphics2D6, rectangle2D62, point2D87, plotState90, plotRenderingInfo91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-9.0d) + "'", double35 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(size2D54);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(drawingSupplier75);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNull(axisSpace82);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(point2D87);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            textFragment1.draw(graphics2D2, (float) 1, 100.0f, textAnchor5, 10.0f, (float) (short) 10, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        double double3 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot3D0.getSectionPaint((java.lang.Comparable) (short) 10);
        java.awt.Shape shape6 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.lang.String str9 = chartEntity8.toString();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        try {
            java.lang.String str12 = chartEntity8.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartEntity: tooltip = (C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str9.equals("ChartEntity: tooltip = (C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        try {
            java.awt.Paint paint9 = xYPlot0.getQuadrantPaint(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (15) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '#', (double) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean6 = textBlockAnchor4.equals((java.lang.Object) horizontalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment7, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, (org.jfree.chart.block.Arrangement) flowArrangement10, arrangement11);
        legendTitle12.setWidth(1.0d);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D19 = legendTitle12.arrange(graphics2D15, rectangleConstraint18);
        org.jfree.chart.util.Size2D size2D20 = rectangleConstraint2.calculateConstrainedSize(size2D19);
        org.jfree.data.Range range21 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("PlotOrientation.VERTICAL");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1L, (double) 1L, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        polarPlot7.setOutlineVisible(false);
        java.awt.Image image10 = polarPlot7.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        blockContainer11.clear();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean15 = textBlockAnchor13.equals((java.lang.Object) horizontalAlignment14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment16, 0.0d, (double) 1L);
        blockContainer11.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement19);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(100.0d, (-16.0d), (double) 2, 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        categoryPlot14.mapDatasetToRangeAxis((int) (byte) 0, (int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot14.getDomainAxisForDataset((int) '#');
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D();
        double double27 = piePlot3D26.getDepthFactor();
        double double28 = piePlot3D26.getMaximumExplodePercent();
        piePlot3D26.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 10);
        java.awt.Paint paint32 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot3D26.setLabelShadowPaint(paint32);
        categoryAxis25.setAxisLinePaint(paint32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(categoryAxis25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.12d + "'", double27 == 0.12d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        double double25 = piePlot3D21.getShadowXOffset();
        boolean boolean26 = textBlockAnchor0.equals((java.lang.Object) piePlot3D21);
        org.jfree.data.general.PieDataset pieDataset27 = piePlot3D21.getDataset();
        boolean boolean28 = piePlot3D21.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(pieDataset27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        piePlotState34.setPieHRadius((double) (-1.0f));
        double double37 = piePlotState34.getPieHRadius();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer25);
        dateAxis21.setTickMarkInsideLength((float) 0L);
        boolean boolean29 = dateAxis21.isAutoTickUnitSelection();
        categoryPlot14.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis21, false);
        categoryPlot14.setDrawSharedDomainAxis(false);
        java.util.List list34 = categoryPlot14.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 10);
        double double8 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range6 = dateAxis2.getRange();
        org.jfree.data.Range range9 = org.jfree.data.Range.expand(range6, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(45.0d, range6);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.data.Range range14 = org.jfree.data.Range.combine(range6, (org.jfree.data.Range) dateRange12);
        boolean boolean17 = range6.intersects(1.0E-5d, (double) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font5 = dateAxis1.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets6.createInsetRectangle(rectangle2D27);
        dateAxis1.setDownArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        dateAxis31.setLabelAngle((double) (short) -1);
        java.awt.Shape shape34 = dateAxis31.getLeftArrow();
        java.util.Date date35 = dateAxis31.getMinimumDate();
        dateAxis1.setMaximumDate(date35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        double double20 = categoryPlot14.getAnchorValue();
        java.awt.Font font23 = null;
        java.awt.Paint paint24 = null;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, paint24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean29 = textBlock25.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean33 = dateAxis32.isAxisLineVisible();
        dateAxis32.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat36 = dateAxis32.getDateFormatOverride();
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis32.setTickLabelFont(font37);
        java.awt.Color color39 = java.awt.Color.red;
        textBlock25.addLine("", font37, (java.awt.Paint) color39);
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        double double42 = piePlot3D41.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("hi!", font37, (org.jfree.chart.plot.Plot) piePlot3D41, false);
        boolean boolean45 = jFreeChart44.isNotify();
        float float46 = jFreeChart44.getBackgroundImageAlpha();
        java.awt.Color color47 = java.awt.Color.BLACK;
        jFreeChart44.setBorderPaint((java.awt.Paint) color47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart44.setPadding(rectangleInsets49);
        categoryPlot14.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.event.ChartChangeListener chartChangeListener52 = null;
        try {
            jFreeChart44.addChangeListener(chartChangeListener52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(dateFormat36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.12d + "'", double42 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.5f + "'", float46 == 0.5f);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        double double7 = dateAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke10 = piePlot3D9.getLabelOutlineStroke();
        java.lang.Object obj11 = piePlot3D9.clone();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D9.setSectionPaint((java.lang.Comparable) 1.0d, paint13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color15.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        boolean boolean22 = piePlot3D9.equals((java.lang.Object) color15);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean26 = dateAxis25.isAxisLineVisible();
        dateAxis25.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        polarPlot30.addChangeListener(plotChangeListener31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = polarPlot30.getDrawingSupplier();
        piePlot3D9.setDrawingSupplier(drawingSupplier33);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        piePlot35.setIgnoreNullValues(false);
        java.awt.Paint paint39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot35.setSectionOutlinePaint((java.lang.Comparable) '#', paint39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean45 = textBlockAnchor43.equals((java.lang.Object) horizontalAlignment44);
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement49 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment44, verticalAlignment46, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement50 = null;
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot42, (org.jfree.chart.block.Arrangement) flowArrangement49, arrangement50);
        legendTitle51.setWidth(1.0d);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D58 = legendTitle51.arrange(graphics2D54, rectangleConstraint57);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D62 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D58, 100.0d, (double) (byte) -1, rectangleAnchor61);
        org.jfree.chart.plot.PiePlot3D piePlot3D63 = new org.jfree.chart.plot.PiePlot3D();
        double double64 = piePlot3D63.getDepthFactor();
        double double65 = piePlot3D63.getMaximumExplodePercent();
        boolean boolean66 = piePlot3D63.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = piePlot35.initialise(graphics2D41, rectangle2D62, (org.jfree.chart.plot.PiePlot) piePlot3D63, (java.lang.Integer) 100, plotRenderingInfo68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.AxisSpace axisSpace71 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace72 = dateAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) piePlot3D9, rectangle2D62, rectangleEdge70, axisSpace71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(size2D58);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.12d + "'", double64 == 0.12d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(piePlotState69);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        piePlotState34.setPieHRadius((double) (-1.0f));
        int int37 = piePlotState34.getPassesRequired();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        piePlotState34.setLinkArea(rectangle2D38);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot26 = jFreeChart23.getPlot();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(plot26);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getLegendItems();
        org.jfree.chart.LegendItem legendItem8 = null;
        legendItemCollection7.add(legendItem8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        dateAxis2.setLabelAngle((double) (short) -1);
        java.lang.String str5 = dateAxis2.getLabelToolTip();
        boolean boolean6 = color0.equals((java.lang.Object) str5);
        java.awt.color.ColorSpace colorSpace7 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(colorSpace7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint10 = dateAxis6.getTickMarkPaint();
        xYPlot0.setDomainGridlinePaint(paint10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot0.rendererChanged(rendererChangeEvent12);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer((int) (short) 100);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = null;
        try {
            xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint28 = jFreeChart24.getBorderPaint();
        jFreeChart24.setAntiAlias(false);
        org.jfree.chart.plot.Plot plot31 = jFreeChart24.getPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        try {
            jFreeChart24.handleClick(2, (int) ' ', chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(plot31);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator4);
        boolean boolean6 = piePlot3D0.getSectionOutlinesVisible();
        boolean boolean7 = piePlot3D0.isCircular();
        piePlot3D0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("PlotOrientation.VERTICAL", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        double double24 = piePlot3D20.getShadowXOffset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator25 = null;
        piePlot3D20.setToolTipGenerator(pieToolTipGenerator25);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle9.getMargin();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle9.getBounds();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot19.getFixedDomainAxisSpace();
        xYPlot19.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot19.getDomainAxisEdge();
        double double24 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D18, rectangleEdge23);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setLabelAngle((double) (short) -1);
        double double4 = dateAxis1.getLabelAngle();
        dateAxis1.setVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.Object obj17 = categoryAxis4.clone();
        java.awt.Font font20 = null;
        java.awt.Paint paint21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, paint21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean26 = textBlock22.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean30 = dateAxis29.isAxisLineVisible();
        dateAxis29.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat33 = dateAxis29.getDateFormatOverride();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis29.setTickLabelFont(font34);
        java.awt.Color color36 = java.awt.Color.red;
        textBlock22.addLine("", font34, (java.awt.Paint) color36);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) piePlot3D38, false);
        boolean boolean42 = jFreeChart41.isNotify();
        float float43 = jFreeChart41.getBackgroundImageAlpha();
        java.awt.Color color44 = java.awt.Color.PINK;
        jFreeChart41.setBorderPaint((java.awt.Paint) color44);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis4, jFreeChart41, chartChangeEventType46);
        int int48 = categoryPlot0.getDomainAxisIndex(categoryAxis4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot0.setRenderer(categoryItemRenderer49);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(dateFormat33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot6.getFixedDomainAxisSpace();
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot6.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation10);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setRangeAxes(valueAxisArray12);
        xYPlot0.setWeight(1);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(valueAxisArray12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot18.getFixedDomainAxisSpace();
        xYPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot18.getDomainAxisLocation();
        int int23 = xYPlot18.getRangeAxisCount();
        java.awt.geom.Point2D point2D24 = xYPlot18.getQuadrantOrigin();
        categoryPlot14.zoomRangeAxes((double) 1, (double) 10.0f, plotRenderingInfo17, point2D24);
        java.awt.Color color28 = java.awt.Color.getColor("", 0);
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.plot.Marker marker21 = null;
        try {
            categoryPlot14.addRangeMarker(marker21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        double double3 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot3D0.getSectionPaint((java.lang.Comparable) (short) 10);
        java.awt.Shape shape6 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.lang.String str9 = chartEntity8.getToolTipText();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str9.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets12.trimHeight((double) (byte) -1);
        double double16 = rectangleInsets12.trimWidth(0.0d);
        double double18 = rectangleInsets12.trimWidth(52.0d);
        legendTitle9.setPadding(rectangleInsets12);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-9.0d) + "'", double14 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-16.0d) + "'", double16 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 36.0d + "'", double18 == 36.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart23.createBufferedImage((int) (short) 1, (int) (short) 1, chartRenderingInfo27);
        try {
            org.jfree.chart.plot.XYPlot xYPlot29 = jFreeChart23.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot3D cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(bufferedImage28);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        boolean boolean35 = piePlot3D28.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setIgnoreNullValues(false);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot9.setSectionOutlinePaint((java.lang.Comparable) '#', paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) horizontalAlignment18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment20, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) flowArrangement23, arrangement24);
        legendTitle25.setWidth(1.0d);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D32 = legendTitle25.arrange(graphics2D28, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 100.0d, (double) (byte) -1, rectangleAnchor35);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        double double38 = piePlot3D37.getDepthFactor();
        double double39 = piePlot3D37.getMaximumExplodePercent();
        boolean boolean40 = piePlot3D37.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = piePlot9.initialise(graphics2D15, rectangle2D36, (org.jfree.chart.plot.PiePlot) piePlot3D37, (java.lang.Integer) 100, plotRenderingInfo42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D36, plotRenderingInfo44);
        xYPlot0.clearRangeAxes();
        java.awt.Color color50 = java.awt.Color.getColor("", 0);
        java.awt.Color color51 = java.awt.Color.getColor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", color50);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color51);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.12d + "'", double38 == 0.12d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray14);
        multiplePiePlot1.setDataset(categoryDataset15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.lang.Object obj10 = polarPlot7.clone();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        polarPlot7.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '#', (int) (short) 100, 100);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot10.getFixedDomainAxisSpace();
        xYPlot10.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation();
        int int15 = xYPlot10.getRangeAxisCount();
        java.awt.geom.Point2D point2D16 = xYPlot10.getQuadrantOrigin();
        xYPlot10.clearDomainAxes();
        java.awt.Paint paint18 = xYPlot10.getDomainCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Other", font7, (org.jfree.chart.plot.Plot) xYPlot10, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot10.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot14.getRenderer(10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        boolean boolean16 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot14.getDomainAxis((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot14.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        piePlotState34.setPieHRadius((double) (-1.0f));
        java.awt.geom.Rectangle2D rectangle2D37 = piePlotState34.getPieArea();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertNull(rectangle2D37);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((-16.0d));
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) 10, 0.025d, 52.0d, (double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        org.jfree.chart.event.TitleChangeListener titleChangeListener12 = null;
        legendTitle9.addChangeListener(titleChangeListener12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle9.getLegendItemGraphicEdge();
        legendTitle9.setNotify(false);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setLabelAngle((double) (short) -1);
        double double4 = dateAxis1.getLabelAngle();
        java.awt.Font font5 = dateAxis1.getTickLabelFont();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        blockContainer11.clear();
        java.util.List list13 = blockContainer11.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockContainer11.getMargin();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) horizontalAlignment3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment5, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement8, arrangement9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle10.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer12 = legendTitle10.getItemContainer();
        blockContainer12.clear();
        java.util.List list14 = blockContainer12.getBlocks();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '#', (double) (byte) 0);
        org.jfree.chart.util.Size2D size2D19 = columnArrangement0.arrange(blockContainer12, graphics2D15, rectangleConstraint18);
        double double20 = size2D19.getHeight();
        double double21 = size2D19.height;
        double double22 = size2D19.getHeight();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(blockContainer12);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot14.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(sortOrder20);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        piePlotState34.setPieHRadius((double) (-1.0f));
        java.awt.geom.Rectangle2D rectangle2D37 = piePlotState34.getExplodedPieArea();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertNull(rectangle2D37);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        polarPlot7.zoomDomainAxes((double) 0.5f, 32.0d, plotRenderingInfo16, point2D17);
        boolean boolean19 = polarPlot7.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke3 = piePlot3D2.getLabelOutlineStroke();
        java.lang.Object obj4 = piePlot3D2.clone();
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D2.setSectionPaint((java.lang.Comparable) 1.0d, paint6);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint9 = piePlot3D8.getLabelOutlinePaint();
        piePlot3D2.setLabelBackgroundPaint(paint9);
        java.awt.Stroke stroke11 = piePlot3D2.getOutlineStroke();
        java.awt.Color color12 = java.awt.Color.orange;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        double double14 = piePlot3D13.getDepthFactor();
        double double15 = piePlot3D13.getMaximumExplodePercent();
        double double16 = piePlot3D13.getMaximumExplodePercent();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D13.setLabelLinkStroke(stroke17);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(45.0d, (java.awt.Paint) color1, stroke11, (java.awt.Paint) color12, stroke17, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.12d + "'", double14 == 0.12d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        float float2 = textFragment1.getBaselineOffset();
        boolean boolean4 = textFragment1.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.lang.Object obj15 = categoryAxis2.clone();
        java.awt.Font font18 = null;
        java.awt.Paint paint19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, paint19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean24 = textBlock20.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean28 = dateAxis27.isAxisLineVisible();
        dateAxis27.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat31 = dateAxis27.getDateFormatOverride();
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis27.setTickLabelFont(font32);
        java.awt.Color color34 = java.awt.Color.red;
        textBlock20.addLine("", font32, (java.awt.Paint) color34);
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        double double37 = piePlot3D36.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("hi!", font32, (org.jfree.chart.plot.Plot) piePlot3D36, false);
        boolean boolean40 = jFreeChart39.isNotify();
        float float41 = jFreeChart39.getBackgroundImageAlpha();
        java.awt.Color color42 = java.awt.Color.PINK;
        jFreeChart39.setBorderPaint((java.awt.Paint) color42);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis2, jFreeChart39, chartChangeEventType44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = null;
        java.awt.image.BufferedImage bufferedImage51 = jFreeChart39.createBufferedImage((int) (short) 1, (int) (short) 10, (double) 'a', (-9.223372036854776E18d), chartRenderingInfo50);
        jFreeChart39.setTextAntiAlias(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(dateFormat31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.12d + "'", double37 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.5f + "'", float41 == 0.5f);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertNotNull(bufferedImage51);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        double double35 = piePlotState34.getLatestAngle();
        piePlotState34.setPieHRadius((double) (short) 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 90.0d + "'", double35 == 90.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addRangeMarker(0, marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        java.awt.Paint paint8 = dateAxis2.getLabelPaint();
        boolean boolean9 = dateAxis2.isVisible();
        dateAxis2.setLabelURL("{0}");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setDownArrow(shape10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        java.text.DateFormat dateFormat18 = null;
        dateAxis13.setDateFormatOverride(dateFormat18);
        dateAxis13.setLabelToolTip("hi!");
        dateAxis13.setUpperMargin((double) '4');
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition24 = dateAxis13.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition24);
        java.awt.Shape shape26 = null;
        try {
            dateAxis1.setRightArrow(shape26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(dateTickMarkPosition24);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot18.getFixedDomainAxisSpace();
        xYPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot18.getDomainAxisLocation();
        int int23 = xYPlot18.getRangeAxisCount();
        java.awt.geom.Point2D point2D24 = xYPlot18.getQuadrantOrigin();
        categoryPlot14.zoomRangeAxes((double) 1, (double) 10.0f, plotRenderingInfo17, point2D24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean31 = dateAxis30.isAxisLineVisible();
        dateAxis30.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat34 = dateAxis30.getDateFormatOverride();
        dateAxis30.setLabelToolTip("");
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis30.setMaximumDate(date37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer39);
        java.lang.Object obj41 = categoryAxis28.clone();
        java.awt.Font font44 = null;
        java.awt.Paint paint45 = null;
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("", font44, paint45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean50 = textBlock46.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean54 = dateAxis53.isAxisLineVisible();
        dateAxis53.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat57 = dateAxis53.getDateFormatOverride();
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis53.setTickLabelFont(font58);
        java.awt.Color color60 = java.awt.Color.red;
        textBlock46.addLine("", font58, (java.awt.Paint) color60);
        org.jfree.chart.plot.PiePlot3D piePlot3D62 = new org.jfree.chart.plot.PiePlot3D();
        double double63 = piePlot3D62.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("hi!", font58, (org.jfree.chart.plot.Plot) piePlot3D62, false);
        boolean boolean66 = jFreeChart65.isNotify();
        float float67 = jFreeChart65.getBackgroundImageAlpha();
        java.awt.Color color68 = java.awt.Color.PINK;
        jFreeChart65.setBorderPaint((java.awt.Paint) color68);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType70 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent71 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis28, jFreeChart65, chartChangeEventType70);
        java.util.List list72 = categoryPlot14.getCategoriesForAxis(categoryAxis28);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(dateFormat34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNull(dateFormat57);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.12d + "'", double63 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 0.5f + "'", float67 == 0.5f);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(chartChangeEventType70);
        org.junit.Assert.assertNotNull(list72);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color1);
        double double3 = numberAxis0.getFixedDimension();
        java.awt.Paint paint4 = numberAxis0.getLabelPaint();
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.java2DToValue((double) (short) -1, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getRange();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        piePlot14.setIgnoreNullValues(false);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot14.setSectionOutlinePaint((java.lang.Comparable) '#', paint18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean24 = textBlockAnchor22.equals((java.lang.Object) horizontalAlignment23);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement28 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment25, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot21, (org.jfree.chart.block.Arrangement) flowArrangement28, arrangement29);
        legendTitle30.setWidth(1.0d);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D37 = legendTitle30.arrange(graphics2D33, rectangleConstraint36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 100.0d, (double) (byte) -1, rectangleAnchor40);
        org.jfree.chart.plot.PiePlot3D piePlot3D42 = new org.jfree.chart.plot.PiePlot3D();
        double double43 = piePlot3D42.getDepthFactor();
        double double44 = piePlot3D42.getMaximumExplodePercent();
        boolean boolean45 = piePlot3D42.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.chart.plot.PiePlotState piePlotState48 = piePlot14.initialise(graphics2D20, rectangle2D41, (org.jfree.chart.plot.PiePlot) piePlot3D42, (java.lang.Integer) 100, plotRenderingInfo47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = numberAxis7.lengthToJava2D((double) 10, rectangle2D41, rectangleEdge49);
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace52 = xYPlot51.getFixedDomainAxisSpace();
        xYPlot51.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot51.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot51.getDomainAxisEdge();
        double double57 = dateAxis1.java2DToValue(0.0d, rectangle2D41, rectangleEdge56);
        dateAxis1.setLabelURL("HorizontalAlignment.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.12d + "'", double43 == 0.12d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(piePlotState48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNull(axisSpace52);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + (-9.223372036854776E18d) + "'", double57 == (-9.223372036854776E18d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        java.awt.Stroke stroke7 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelToolTip("");
        dateAxis1.setAutoTickUnitSelection(false);
        boolean boolean10 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator4);
        boolean boolean6 = piePlot3D0.getSectionOutlinesVisible();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer15);
        dateAxis11.setTickMarkInsideLength((float) 0L);
        boolean boolean19 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer20);
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean27 = textBlockAnchor25.equals((java.lang.Object) horizontalAlignment26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment26, verticalAlignment28, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot24, (org.jfree.chart.block.Arrangement) flowArrangement31, arrangement32);
        legendTitle33.setWidth(1.0d);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D40 = legendTitle33.arrange(graphics2D36, rectangleConstraint39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D44 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D40, 100.0d, (double) (byte) -1, rectangleAnchor43);
        java.awt.Point point45 = polarPlot21.translateValueThetaRadiusToJava2D((double) (short) -1, (double) '4', rectangle2D44);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace48 = xYPlot47.getFixedDomainAxisSpace();
        xYPlot47.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot47.getDomainAxisLocation();
        int int52 = xYPlot47.getRangeAxisCount();
        java.awt.geom.Point2D point2D53 = xYPlot47.getQuadrantOrigin();
        xYPlot46.setQuadrantOrigin(point2D53);
        java.awt.geom.Point2D point2D55 = xYPlot46.getQuadrantOrigin();
        java.awt.geom.Point2D point2D56 = xYPlot46.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState57 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        try {
            piePlot3D0.draw(graphics2D7, rectangle2D44, point2D56, plotState57, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(point45);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNotNull(point2D56);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range40 = dateAxis36.getRange();
        dateAxis36.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets43.trimHeight((double) (byte) -1);
        double double47 = rectangleInsets43.trimWidth(0.0d);
        dateAxis36.setTickLabelInsets(rectangleInsets43);
        double double49 = rectangleInsets43.getRight();
        categoryPlot14.setAxisOffset(rectangleInsets43);
        org.jfree.chart.plot.Marker marker51 = null;
        org.jfree.chart.util.Layer layer52 = null;
        try {
            boolean boolean53 = categoryPlot14.removeDomainMarker(marker51, layer52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-9.0d) + "'", double45 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + (-16.0d) + "'", double47 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font17 = dateAxis13.getTickLabelFont();
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("ClassContext", font17, paint18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font17);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double24 = rectangleInsets22.trimHeight((double) (byte) -1);
        double double25 = rectangleInsets22.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean30 = textBlockAnchor28.equals((java.lang.Object) horizontalAlignment29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment31, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot27, (org.jfree.chart.block.Arrangement) flowArrangement34, arrangement35);
        legendTitle36.setWidth(1.0d);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D43 = legendTitle36.arrange(graphics2D39, rectangleConstraint42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, 100.0d, (double) (byte) -1, rectangleAnchor46);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets26.createInsetRectangle(rectangle2D47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets22.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType49, lengthAdjustmentType50);
        java.lang.Object obj53 = textTitle20.draw(graphics2D21, rectangle2D51, (java.lang.Object) 45.0d);
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace55 = xYPlot54.getFixedDomainAxisSpace();
        xYPlot54.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation58 = xYPlot54.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot54.getDomainAxisEdge();
        double double60 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor7, (int) '#', (int) '4', rectangle2D51, rectangleEdge59);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-9.0d) + "'", double24 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertNull(axisSpace55);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = polarPlot7.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean18 = dateAxis17.isAxisLineVisible();
        dateAxis17.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat21 = dateAxis17.getDateFormatOverride();
        dateAxis17.setLabelToolTip("");
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis17.setMaximumDate(date24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer26);
        java.lang.Object obj28 = categoryAxis15.clone();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean32 = dateAxis31.isAxisLineVisible();
        dateAxis31.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font35 = dateAxis31.getTickLabelFont();
        categoryAxis15.setTickLabelFont((java.lang.Comparable) (-9.0d), font35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.AxisState axisState38 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double41 = rectangleInsets39.trimHeight((double) (byte) -1);
        double double42 = rectangleInsets39.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean47 = textBlockAnchor45.equals((java.lang.Object) horizontalAlignment46);
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment46, verticalAlignment48, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot44, (org.jfree.chart.block.Arrangement) flowArrangement51, arrangement52);
        legendTitle53.setWidth(1.0d);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D60 = legendTitle53.arrange(graphics2D56, rectangleConstraint59);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D64 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D60, 100.0d, (double) (byte) -1, rectangleAnchor63);
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets43.createInsetRectangle(rectangle2D64);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets39.createAdjustedRectangle(rectangle2D64, lengthAdjustmentType66, lengthAdjustmentType67);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.util.List list70 = categoryAxis15.refreshTicks(graphics2D37, axisState38, rectangle2D68, rectangleEdge69);
        java.awt.Point point71 = polarPlot7.translateValueThetaRadiusToJava2D((double) 0, 0.025d, rectangle2D68);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(dateFormat21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-9.0d) + "'", double41 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(size2D60);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertNotNull(list70);
        org.junit.Assert.assertNotNull(point71);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Polar Plot", graphics2D1, (float) (byte) 10, (float) 2, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            boolean boolean5 = categoryPlot0.removeRangeMarker(15, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(list1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        double double3 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot3D0.getSectionPaint((java.lang.Comparable) (short) 10);
        piePlot3D0.setInteriorGap(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        dateAxis18.setLabelAngle((double) (short) -1);
        java.awt.Shape shape21 = dateAxis18.getLeftArrow();
        java.util.Date date22 = dateAxis18.getMinimumDate();
        categoryPlot14.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        categoryPlot14.mapDatasetToRangeAxis((int) (byte) 0, (int) (byte) 100);
        double double24 = categoryPlot14.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        jFreeChart23.removeLegend();
        java.lang.Object obj27 = jFreeChart23.getTextAntiAlias();
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        jFreeChart23.setBorderStroke(stroke28);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        xYPlot0.rendererChanged(rendererChangeEvent3);
        xYPlot0.clearAnnotations();
        java.awt.Paint paint7 = null;
        try {
            xYPlot0.setQuadrantPaint(10, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        boolean boolean2 = numberAxis0.isInverted();
        numberAxis0.configure();
        numberAxis0.setAutoRangeStickyZero(false);
        numberAxis0.setFixedDimension((double) (-1.0f));
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.util.List list17 = categoryPlot16.getCategories();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot16.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot19.getFixedDomainAxisSpace();
        xYPlot19.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot19.getDomainAxisLocation();
        int int24 = xYPlot19.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke26 = piePlot3D25.getLabelOutlineStroke();
        piePlot3D25.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke30 = piePlot3D29.getLabelOutlineStroke();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D29.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke32);
        piePlot3D25.setBaseSectionOutlineStroke(stroke32);
        xYPlot19.setRangeGridlineStroke(stroke32);
        categoryPlot16.setRangeGridlineStroke(stroke32);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean40 = dateAxis39.isAxisLineVisible();
        dateAxis39.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font43 = dateAxis39.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor46 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean48 = textBlockAnchor46.equals((java.lang.Object) horizontalAlignment47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement52 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment47, verticalAlignment49, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement53 = null;
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot45, (org.jfree.chart.block.Arrangement) flowArrangement52, arrangement53);
        legendTitle54.setWidth(1.0d);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D61 = legendTitle54.arrange(graphics2D57, rectangleConstraint60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D65 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D61, 100.0d, (double) (byte) -1, rectangleAnchor64);
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets44.createInsetRectangle(rectangle2D65);
        dateAxis39.setDownArrow((java.awt.Shape) rectangle2D66);
        categoryPlot16.drawBackgroundImage(graphics2D37, rectangle2D66);
        piePlot3D0.setLegendItemShape((java.awt.Shape) rectangle2D66);
        piePlot3D0.setPieIndex(15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(textBlockAnchor46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(size2D61);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = java.awt.Color.orange;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint10 = categoryAxis6.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint11 = categoryAxis6.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean19 = dateAxis18.isAxisLineVisible();
        dateAxis18.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat22 = dateAxis18.getDateFormatOverride();
        dateAxis18.setLabelToolTip("");
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis18.setMaximumDate(date25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer27);
        java.util.List list29 = categoryPlot28.getCategories();
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot28.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace32 = xYPlot31.getFixedDomainAxisSpace();
        xYPlot31.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation();
        int int36 = xYPlot31.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke38 = piePlot3D37.getLabelOutlineStroke();
        piePlot3D37.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke42 = piePlot3D41.getLabelOutlineStroke();
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D41.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke44);
        piePlot3D37.setBaseSectionOutlineStroke(stroke44);
        xYPlot31.setRangeGridlineStroke(stroke44);
        categoryPlot28.setRangeGridlineStroke(stroke44);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean52 = dateAxis51.isAxisLineVisible();
        dateAxis51.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font55 = dateAxis51.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor58 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment59 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean60 = textBlockAnchor58.equals((java.lang.Object) horizontalAlignment59);
        org.jfree.chart.util.VerticalAlignment verticalAlignment61 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement64 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment59, verticalAlignment61, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement65 = null;
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot57, (org.jfree.chart.block.Arrangement) flowArrangement64, arrangement65);
        legendTitle66.setWidth(1.0d);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D73 = legendTitle66.arrange(graphics2D69, rectangleConstraint72);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor76 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D77 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D73, 100.0d, (double) (byte) -1, rectangleAnchor76);
        java.awt.geom.Rectangle2D rectangle2D78 = rectangleInsets56.createInsetRectangle(rectangle2D77);
        dateAxis51.setDownArrow((java.awt.Shape) rectangle2D78);
        categoryPlot28.drawBackgroundImage(graphics2D49, rectangle2D78);
        org.jfree.chart.plot.CategoryPlot categoryPlot81 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = categoryPlot81.getRangeAxisEdge((int) (byte) 1);
        double double84 = categoryAxis6.getCategoryMiddle((int) (byte) 100, 1, rectangle2D78, rectangleEdge83);
        try {
            xYPlot0.drawBackground(graphics2D4, rectangle2D78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(dateFormat22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(list29);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(textBlockAnchor58);
        org.junit.Assert.assertNotNull(horizontalAlignment59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(verticalAlignment61);
        org.junit.Assert.assertNotNull(size2D73);
        org.junit.Assert.assertNotNull(rectangleAnchor76);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + (-180.99999999999997d) + "'", double84 == (-180.99999999999997d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        dateAxis2.setTickMarkInsideLength((float) 0L);
        boolean boolean10 = dateAxis2.isAutoTickUnitSelection();
        java.awt.Paint paint11 = dateAxis2.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range7 = dateAxis3.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis9.java2DToValue((double) (short) -1, rectangle2D11, rectangleEdge12);
        org.jfree.data.Range range14 = numberAxis9.getRange();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        piePlot16.setIgnoreNullValues(false);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot16.setSectionOutlinePaint((java.lang.Comparable) '#', paint20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean26 = textBlockAnchor24.equals((java.lang.Object) horizontalAlignment25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment27, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23, (org.jfree.chart.block.Arrangement) flowArrangement30, arrangement31);
        legendTitle32.setWidth(1.0d);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D39 = legendTitle32.arrange(graphics2D35, rectangleConstraint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 100.0d, (double) (byte) -1, rectangleAnchor42);
        org.jfree.chart.plot.PiePlot3D piePlot3D44 = new org.jfree.chart.plot.PiePlot3D();
        double double45 = piePlot3D44.getDepthFactor();
        double double46 = piePlot3D44.getMaximumExplodePercent();
        boolean boolean47 = piePlot3D44.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot16.initialise(graphics2D22, rectangle2D43, (org.jfree.chart.plot.PiePlot) piePlot3D44, (java.lang.Integer) 100, plotRenderingInfo49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = numberAxis9.lengthToJava2D((double) 10, rectangle2D43, rectangleEdge51);
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace54 = xYPlot53.getFixedDomainAxisSpace();
        xYPlot53.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot53.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = xYPlot53.getDomainAxisEdge();
        double double59 = dateAxis3.java2DToValue(0.0d, rectangle2D43, rectangleEdge58);
        rectangleInsets0.trim(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.NEGATIVE_INFINITY + "'", double13 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.12d + "'", double45 == 0.12d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNull(axisSpace54);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-9.223372036854776E18d) + "'", double59 == (-9.223372036854776E18d));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        blockContainer11.clear();
        java.util.List list13 = blockContainer11.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double16 = rectangleInsets14.trimHeight((double) (byte) -1);
        double double18 = rectangleInsets14.trimWidth(0.0d);
        double double20 = rectangleInsets14.trimWidth(52.0d);
        blockContainer11.setMargin(rectangleInsets14);
        java.util.List list22 = blockContainer11.getBlocks();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-9.0d) + "'", double16 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-16.0d) + "'", double18 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean18 = dateAxis17.isAxisLineVisible();
        dateAxis17.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range21 = dateAxis17.getRange();
        org.jfree.data.Range range24 = org.jfree.data.Range.expand(range21, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(45.0d, range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint14.toRangeHeight(range21);
        org.jfree.data.Range range27 = rectangleConstraint14.getWidthRange();
        org.jfree.chart.util.Size2D size2D28 = legendTitle9.arrange(graphics2D11, rectangleConstraint14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint14.toFixedWidth(8.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLabelGenerator();
        try {
            piePlot3D0.setInteriorGap((double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (15.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot7.zoomRangeAxes((double) (short) 1, plotRenderingInfo14, point2D15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        polarPlot7.drawBackgroundImage(graphics2D17, rectangle2D18);
        java.lang.String str20 = polarPlot7.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Polar Plot" + "'", str20.equals("Polar Plot"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Polar Plot");
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getLegendItems();
        int int8 = legendItemCollection7.getItemCount();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot14.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot14.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.data.Range range8 = org.jfree.data.Range.expand(range5, 0.2d, 0.2d);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range5, (double) (byte) 1, true);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range11, 0.0d, false);
        org.jfree.data.Range range17 = org.jfree.data.Range.expand(range14, (double) 2, (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        int int3 = legendItemCollection2.getItemCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot14.getRangeAxisLocation();
        categoryPlot14.setAnchorValue(0.0d, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        textTitle10.setExpandToFitSpace(false);
        textTitle10.setWidth(1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        jFreeChart23.clearSubtitles();
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        double double28 = piePlot3D27.getDepthFactor();
        double double29 = piePlot3D27.getMaximumExplodePercent();
        double double30 = piePlot3D27.getMaximumExplodePercent();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setLabelLinkStroke(stroke31);
        jFreeChart23.setBorderStroke(stroke31);
        java.awt.Paint paint34 = jFreeChart23.getBackgroundPaint();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.12d + "'", double28 == 0.12d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double3 = piePlot3D0.getExplodePercent((java.lang.Comparable) (-1L));
        boolean boolean4 = piePlot3D0.getDarkerSides();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.text.TextLine textLine4 = textBlock3.getLastLine();
        org.jfree.chart.text.TextLine textLine5 = textBlock3.getLastLine();
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNull(textLine4);
        org.junit.Assert.assertNull(textLine5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        boolean boolean16 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getDomainMarkers((int) (byte) -1, layer20);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color2 = java.awt.Color.getColor("", 0);
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.mapDatasetToRangeAxis(1, (int) (byte) 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        piePlot3D8.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke13 = piePlot3D12.getLabelOutlineStroke();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D12.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke15);
        piePlot3D8.setBaseSectionOutlineStroke(stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot3D8.getSimpleLabelOffset();
        java.awt.Paint paint19 = piePlot3D8.getBaseSectionPaint();
        xYPlot0.setDomainTickBandPaint(paint19);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot14.getRangeAxisForDataset((int) (short) 1);
        boolean boolean19 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        java.util.List list7 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        boolean boolean2 = numberAxis0.isInverted();
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        double double24 = piePlot3D20.getShadowXOffset();
        double double26 = piePlot3D20.getExplodePercent((java.lang.Comparable) 2);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        piePlot27.setIgnoreNullValues(false);
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot27.setSectionOutlinePaint((java.lang.Comparable) '#', paint31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor35 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean37 = textBlockAnchor35.equals((java.lang.Object) horizontalAlignment36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement41 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment36, verticalAlignment38, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot34, (org.jfree.chart.block.Arrangement) flowArrangement41, arrangement42);
        legendTitle43.setWidth(1.0d);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D50 = legendTitle43.arrange(graphics2D46, rectangleConstraint49);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, 100.0d, (double) (byte) -1, rectangleAnchor53);
        org.jfree.chart.plot.PiePlot3D piePlot3D55 = new org.jfree.chart.plot.PiePlot3D();
        double double56 = piePlot3D55.getDepthFactor();
        double double57 = piePlot3D55.getMaximumExplodePercent();
        boolean boolean58 = piePlot3D55.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        org.jfree.chart.plot.PiePlotState piePlotState61 = piePlot27.initialise(graphics2D33, rectangle2D54, (org.jfree.chart.plot.PiePlot) piePlot3D55, (java.lang.Integer) 100, plotRenderingInfo60);
        boolean boolean62 = piePlot3D20.equals((java.lang.Object) piePlot3D55);
        piePlot3D55.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(textBlockAnchor35);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.12d + "'", double56 == 0.12d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(piePlotState61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        dateAxis13.setLabelToolTip("");
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis13.setMaximumDate(date20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        java.util.List list24 = categoryPlot23.getCategories();
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot23.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot26.getFixedDomainAxisSpace();
        xYPlot26.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot26.getDomainAxisLocation();
        int int31 = xYPlot26.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke33 = piePlot3D32.getLabelOutlineStroke();
        piePlot3D32.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke37 = piePlot3D36.getLabelOutlineStroke();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D36.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke39);
        piePlot3D32.setBaseSectionOutlineStroke(stroke39);
        xYPlot26.setRangeGridlineStroke(stroke39);
        categoryPlot23.setRangeGridlineStroke(stroke39);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean47 = dateAxis46.isAxisLineVisible();
        dateAxis46.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font50 = dateAxis46.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor53 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean55 = textBlockAnchor53.equals((java.lang.Object) horizontalAlignment54);
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement59 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment54, verticalAlignment56, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot52, (org.jfree.chart.block.Arrangement) flowArrangement59, arrangement60);
        legendTitle61.setWidth(1.0d);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D68 = legendTitle61.arrange(graphics2D64, rectangleConstraint67);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, 100.0d, (double) (byte) -1, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets51.createInsetRectangle(rectangle2D72);
        dateAxis46.setDownArrow((java.awt.Shape) rectangle2D73);
        categoryPlot23.drawBackgroundImage(graphics2D44, rectangle2D73);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = categoryPlot76.getRangeAxisEdge((int) (byte) 1);
        double double79 = categoryAxis1.getCategoryMiddle((int) (byte) 100, 1, rectangle2D73, rectangleEdge78);
        java.lang.String str80 = rectangleEdge78.toString();
        java.lang.String str81 = rectangleEdge78.toString();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(list24);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(textBlockAnchor53);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(size2D68);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + (-180.99999999999997d) + "'", double79 == (-180.99999999999997d));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "RectangleEdge.RIGHT" + "'", str80.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "RectangleEdge.RIGHT" + "'", str81.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot10.getFixedDomainAxisSpace();
        xYPlot10.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation();
        int int15 = xYPlot10.getRangeAxisCount();
        java.awt.geom.Point2D point2D16 = xYPlot10.getQuadrantOrigin();
        xYPlot10.clearDomainAxes();
        java.awt.Paint paint18 = xYPlot10.getDomainCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Other", font7, (org.jfree.chart.plot.Plot) xYPlot10, true);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean24 = dateAxis23.isAxisLineVisible();
        dateAxis23.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, polarItemRenderer27);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        polarPlot28.addChangeListener(plotChangeListener29);
        polarPlot28.addCornerTextItem("");
        polarPlot28.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        polarPlot28.zoomDomainAxes((double) 0.5f, 32.0d, plotRenderingInfo37, point2D38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = polarPlot28.getAxis();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        polarPlot28.datasetChanged(datasetChangeEvent41);
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke44 = piePlot3D43.getLabelOutlineStroke();
        piePlot3D43.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D47 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke48 = piePlot3D47.getLabelOutlineStroke();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D47.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke50);
        piePlot3D43.setBaseSectionOutlineStroke(stroke50);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = piePlot3D43.getSimpleLabelOffset();
        polarPlot28.setInsets(rectangleInsets53);
        jFreeChart20.setPadding(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(valueAxis40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets53);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge();
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.Marker marker6 = null;
        try {
            boolean boolean7 = xYPlot0.removeDomainMarker(marker6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle9.getMargin();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle9.getBounds();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        piePlot20.setIgnoreNullValues(false);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) '#', paint24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean30 = textBlockAnchor28.equals((java.lang.Object) horizontalAlignment29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment31, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot27, (org.jfree.chart.block.Arrangement) flowArrangement34, arrangement35);
        legendTitle36.setWidth(1.0d);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D43 = legendTitle36.arrange(graphics2D39, rectangleConstraint42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, 100.0d, (double) (byte) -1, rectangleAnchor46);
        org.jfree.chart.plot.PiePlot3D piePlot3D48 = new org.jfree.chart.plot.PiePlot3D();
        double double49 = piePlot3D48.getDepthFactor();
        double double50 = piePlot3D48.getMaximumExplodePercent();
        boolean boolean51 = piePlot3D48.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.chart.plot.PiePlotState piePlotState54 = piePlot20.initialise(graphics2D26, rectangle2D47, (org.jfree.chart.plot.PiePlot) piePlot3D48, (java.lang.Integer) 100, plotRenderingInfo53);
        org.jfree.chart.plot.PiePlot piePlot55 = new org.jfree.chart.plot.PiePlot();
        piePlot55.setIgnoreNullValues(false);
        java.awt.Paint paint59 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot55.setSectionOutlinePaint((java.lang.Comparable) '#', paint59);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor63 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment64 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean65 = textBlockAnchor63.equals((java.lang.Object) horizontalAlignment64);
        org.jfree.chart.util.VerticalAlignment verticalAlignment66 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement69 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment64, verticalAlignment66, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement70 = null;
        org.jfree.chart.title.LegendTitle legendTitle71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot62, (org.jfree.chart.block.Arrangement) flowArrangement69, arrangement70);
        legendTitle71.setWidth(1.0d);
        java.awt.Graphics2D graphics2D74 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D78 = legendTitle71.arrange(graphics2D74, rectangleConstraint77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D82 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D78, 100.0d, (double) (byte) -1, rectangleAnchor81);
        org.jfree.chart.plot.PiePlot3D piePlot3D83 = new org.jfree.chart.plot.PiePlot3D();
        double double84 = piePlot3D83.getDepthFactor();
        double double85 = piePlot3D83.getMaximumExplodePercent();
        boolean boolean86 = piePlot3D83.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        org.jfree.chart.plot.PiePlotState piePlotState89 = piePlot55.initialise(graphics2D61, rectangle2D82, (org.jfree.chart.plot.PiePlot) piePlot3D83, (java.lang.Integer) 100, plotRenderingInfo88);
        double double90 = piePlotState89.getPieCenterX();
        piePlotState89.setPieCenterX((double) ' ');
        piePlotState89.setTotal((double) 100.0f);
        try {
            java.lang.Object obj95 = legendTitle9.draw(graphics2D19, rectangle2D47, (java.lang.Object) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.12d + "'", double49 == 0.12d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(piePlotState54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(textBlockAnchor63);
        org.junit.Assert.assertNotNull(horizontalAlignment64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(verticalAlignment66);
        org.junit.Assert.assertNotNull(size2D78);
        org.junit.Assert.assertNotNull(rectangleAnchor81);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.12d + "'", double84 == 0.12d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(piePlotState89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) -1, 0.4d, 52.0d, (double) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation(0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setLowerBound(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        piePlotState34.setPieHRadius((double) (-1.0f));
        double double37 = piePlotState34.getPieWRadius();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint5 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean8 = dateAxis7.isAxisLineVisible();
        dateAxis7.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range11 = dateAxis7.getRange();
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range11, 0.2d, 0.2d);
        dateAxis1.setRange(range11);
        double double17 = range11.constrain((double) 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer25);
        dateAxis21.setTickMarkInsideLength((float) 0L);
        boolean boolean29 = dateAxis21.isAutoTickUnitSelection();
        categoryPlot14.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis21, false);
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        try {
            categoryPlot14.setDomainAxisLocation((int) (short) 0, axisLocation35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("ClassContext", font8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot11.getFixedDomainAxisSpace();
        xYPlot11.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot11.getDomainAxisLocation();
        int int16 = xYPlot11.getRangeAxisCount();
        java.awt.geom.Point2D point2D17 = xYPlot11.getQuadrantOrigin();
        xYPlot11.clearDomainAxes();
        java.awt.Paint paint19 = xYPlot11.getDomainCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("Other", font8, (org.jfree.chart.plot.Plot) xYPlot11, true);
        java.awt.Color color25 = java.awt.Color.getColor("", 0);
        java.awt.Color color26 = java.awt.Color.getColor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", color25);
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("Other", font8, (java.awt.Paint) color25);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getRangeAxisEdge((int) (byte) 1);
        boolean boolean31 = textFragment27.equals((java.lang.Object) rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = null;
        try {
            piePlot0.setLabelDistributor(abstractPieLabelDistributor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle9.setHorizontalAlignment(horizontalAlignment10);
        double double12 = legendTitle9.getContentXOffset();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.lang.Object obj10 = polarPlot7.clone();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        java.awt.Font font13 = polarPlot7.getNoDataMessageFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = polarPlot7.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font25 = dateAxis21.getTickLabelFont();
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("ClassContext", font25, paint26);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font25);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double32 = rectangleInsets30.trimHeight((double) (byte) -1);
        double double33 = rectangleInsets30.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor36 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean38 = textBlockAnchor36.equals((java.lang.Object) horizontalAlignment37);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment39, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot35, (org.jfree.chart.block.Arrangement) flowArrangement42, arrangement43);
        legendTitle44.setWidth(1.0d);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D51 = legendTitle44.arrange(graphics2D47, rectangleConstraint50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D51, 100.0d, (double) (byte) -1, rectangleAnchor54);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets34.createInsetRectangle(rectangle2D55);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets30.createAdjustedRectangle(rectangle2D55, lengthAdjustmentType57, lengthAdjustmentType58);
        java.lang.Object obj61 = textTitle28.draw(graphics2D29, rectangle2D59, (java.lang.Object) 45.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D63 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D59, rectangleAnchor62);
        polarPlot7.zoomDomainAxes(0.0d, (double) 0L, plotRenderingInfo17, point2D63);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(polarItemRenderer14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-9.0d) + "'", double32 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(textBlockAnchor36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(size2D51);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNull(obj61);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D63);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.Plot plot14 = polarPlot7.getRootPlot();
        java.lang.Object obj15 = polarPlot7.clone();
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke17 = piePlot3D16.getLabelOutlineStroke();
        piePlot3D16.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke21 = piePlot3D20.getLabelOutlineStroke();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D20.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke23);
        piePlot3D16.setBaseSectionOutlineStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = piePlot3D16.getSimpleLabelOffset();
        boolean boolean27 = piePlot3D16.getSimpleLabels();
        java.awt.Font font28 = piePlot3D16.getLabelFont();
        polarPlot7.setAngleLabelFont(font28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (double) (byte) -1, (double) 4, (double) (-14745631));
        double double6 = rectangleInsets4.calculateBottomOutset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        polarPlot9.addChangeListener(plotChangeListener10);
        polarPlot9.setRadiusGridlinesVisible(true);
        java.awt.Paint paint14 = polarPlot9.getOutlinePaint();
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL", font1, paint14);
        java.awt.Graphics2D graphics2D16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = textBlock15.calculateDimensions(graphics2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.lang.Object obj5 = null;
        boolean boolean6 = textBlock3.equals(obj5);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraint[LengthConstraintType.FIXED: width=1.0E-5, height=100.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setLabelLinkMargin((double) 0.0f);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        piePlotState34.setLatestAngle(1.0E-8d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Stroke stroke3 = piePlot3D0.getLabelLinkStroke();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double6 = rectangleInsets5.getBottom();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = xYPlot7.getFixedDomainAxisSpace();
        xYPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot7.getDomainAxisLocation();
        double double12 = xYPlot7.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot7.rendererChanged(rendererChangeEvent13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        piePlot16.setIgnoreNullValues(false);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot16.setSectionOutlinePaint((java.lang.Comparable) '#', paint20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean26 = textBlockAnchor24.equals((java.lang.Object) horizontalAlignment25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment27, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23, (org.jfree.chart.block.Arrangement) flowArrangement30, arrangement31);
        legendTitle32.setWidth(1.0d);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D39 = legendTitle32.arrange(graphics2D35, rectangleConstraint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 100.0d, (double) (byte) -1, rectangleAnchor42);
        org.jfree.chart.plot.PiePlot3D piePlot3D44 = new org.jfree.chart.plot.PiePlot3D();
        double double45 = piePlot3D44.getDepthFactor();
        double double46 = piePlot3D44.getMaximumExplodePercent();
        boolean boolean47 = piePlot3D44.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot16.initialise(graphics2D22, rectangle2D43, (org.jfree.chart.plot.PiePlot) piePlot3D44, (java.lang.Integer) 100, plotRenderingInfo49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        xYPlot7.drawAnnotations(graphics2D15, rectangle2D43, plotRenderingInfo51);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets5.createOutsetRectangle(rectangle2D43);
        try {
            piePlot3D0.drawOutline(graphics2D4, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.12d + "'", double45 == 0.12d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint6 = dateAxis2.getTickMarkPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) dateAxis2);
        java.text.DateFormat dateFormat8 = dateAxis2.getDateFormatOverride();
        dateAxis2.resizeRange(0.0d, 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(dateFormat8);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean7 = textBlock3.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) horizontalAlignment10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment12, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot8, (org.jfree.chart.block.Arrangement) flowArrangement15, arrangement16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle17.setHorizontalAlignment(horizontalAlignment18);
        java.lang.String str20 = horizontalAlignment18.toString();
        textBlock3.setLineAlignment(horizontalAlignment18);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock3.draw(graphics2D22, (float) 1, (float) (-14745631), textBlockAnchor25, (float) (byte) -1, 1.0f, (double) 1.0f);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str20.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertNotNull(textBlockAnchor25);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((-16.0d));
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.lang.String str4 = unitType3.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.ABSOLUTE" + "'", str4.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint6 = dateAxis2.getTickMarkPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) dateAxis2);
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        projectInfo8.setVersion("hi!");
        projectInfo8.setLicenceText("PlotOrientation.VERTICAL");
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        projectInfo13.setVersion("hi!");
        projectInfo13.setLicenceText("PlotOrientation.VERTICAL");
        projectInfo8.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertNotNull(projectInfo13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint5 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean8 = dateAxis7.isAxisLineVisible();
        dateAxis7.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range11 = dateAxis7.getRange();
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range11, 0.2d, 0.2d);
        dateAxis1.setRange(range11);
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean20 = textBlockAnchor18.equals((java.lang.Object) horizontalAlignment19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment21, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17, (org.jfree.chart.block.Arrangement) flowArrangement24, arrangement25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle26.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer28 = legendTitle26.getItemContainer();
        blockContainer28.clear();
        java.util.List list30 = blockContainer28.getBlocks();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) '#', (double) (byte) 0);
        org.jfree.chart.util.Size2D size2D35 = columnArrangement16.arrange(blockContainer28, graphics2D31, rectangleConstraint34);
        double double36 = size2D35.getHeight();
        double double37 = size2D35.height;
        double double38 = size2D35.width;
        boolean boolean39 = range11.equals((java.lang.Object) double38);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(blockContainer28);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.text.TextLine textLine4 = textBlock3.getLastLine();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.awt.Shape shape12 = textBlock3.calculateBounds(graphics2D5, (float) (byte) 10, (float) (short) 10, textBlockAnchor8, (float) (short) 0, (float) 15, (double) (byte) -1);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNull(textLine4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = java.awt.Color.getColor("HorizontalAlignment.CENTER", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.Object obj17 = categoryAxis4.clone();
        java.awt.Font font20 = null;
        java.awt.Paint paint21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, paint21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean26 = textBlock22.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean30 = dateAxis29.isAxisLineVisible();
        dateAxis29.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat33 = dateAxis29.getDateFormatOverride();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis29.setTickLabelFont(font34);
        java.awt.Color color36 = java.awt.Color.red;
        textBlock22.addLine("", font34, (java.awt.Paint) color36);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) piePlot3D38, false);
        boolean boolean42 = jFreeChart41.isNotify();
        float float43 = jFreeChart41.getBackgroundImageAlpha();
        java.awt.Color color44 = java.awt.Color.PINK;
        jFreeChart41.setBorderPaint((java.awt.Paint) color44);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis4, jFreeChart41, chartChangeEventType46);
        int int48 = categoryPlot0.getDomainAxisIndex(categoryAxis4);
        java.awt.Font font49 = categoryAxis4.getTickLabelFont();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(dateFormat33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(font49);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        boolean boolean3 = piePlot3D0.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge((int) (byte) 1);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(collection4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        boolean boolean16 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        int int19 = categoryPlot14.getWeight();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = piePlot3D0.getOutlineStroke();
        piePlot3D0.setLabelLinksVisible(false);
        boolean boolean12 = piePlot3D0.isCircular();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font5 = dateAxis1.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets6.createInsetRectangle(rectangle2D27);
        dateAxis1.setDownArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D28, rectangleEdge30);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) double31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Multiple Pie Plot");
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 100.0f, (float) 1L, textAnchor4, 0.0d, (float) (short) 0, (float) 10L);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        double double25 = piePlot3D21.getShadowXOffset();
        boolean boolean26 = textBlockAnchor0.equals((java.lang.Object) piePlot3D21);
        org.jfree.data.general.PieDataset pieDataset27 = piePlot3D21.getDataset();
        piePlot3D21.setMaximumLabelWidth((double) 0.5f);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(pieDataset27);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat18 = dateAxis14.getDateFormatOverride();
        dateAxis14.setLabelToolTip("");
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis14.setMaximumDate(date21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer23);
        java.util.List list25 = categoryPlot24.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot24.getRenderer((int) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace31 = xYPlot30.getFixedDomainAxisSpace();
        xYPlot30.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot30.getDomainAxisLocation();
        int int35 = xYPlot30.getRangeAxisCount();
        java.awt.geom.Point2D point2D36 = xYPlot30.getQuadrantOrigin();
        categoryPlot24.zoomRangeAxes((-16.0d), plotRenderingInfo29, point2D36);
        xYPlot0.zoomRangeAxes((double) (byte) 10, plotRenderingInfo9, point2D36, false);
        java.awt.Color color40 = java.awt.Color.DARK_GRAY;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color40);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(dateFormat18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        java.awt.Paint paint11 = polarPlot7.getAngleLabelPaint();
        polarPlot7.setAngleLabelsVisible(false);
        double double14 = polarPlot7.getMaxRadius();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 16.0d + "'", double14 == 16.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke3 = piePlot3D2.getLabelOutlineStroke();
        piePlot3D0.setLabelOutlineStroke(stroke3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean11 = dateAxis10.isAxisLineVisible();
        dateAxis10.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer14);
        dateAxis10.setTickMarkInsideLength((float) 0L);
        boolean boolean18 = dateAxis10.isAutoTickUnitSelection();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer19);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean26 = textBlockAnchor24.equals((java.lang.Object) horizontalAlignment25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment27, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23, (org.jfree.chart.block.Arrangement) flowArrangement30, arrangement31);
        legendTitle32.setWidth(1.0d);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D39 = legendTitle32.arrange(graphics2D35, rectangleConstraint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 100.0d, (double) (byte) -1, rectangleAnchor42);
        java.awt.Point point44 = polarPlot20.translateValueThetaRadiusToJava2D((double) (short) -1, (double) '4', rectangle2D43);
        org.jfree.chart.plot.PlotState plotState45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        try {
            piePlot3D0.draw(graphics2D5, rectangle2D6, (java.awt.geom.Point2D) point44, plotState45, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(point44);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setDownArrow(shape10);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape10, "hi!", "");
        chartEntity14.setURLText("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL");
        java.lang.String str17 = chartEntity14.getShapeCoords();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str17.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean5 = textBlockAnchor3.equals((java.lang.Object) horizontalAlignment4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment6, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement9, arrangement10);
        legendTitle11.setWidth(1.0d);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D18 = legendTitle11.arrange(graphics2D14, rectangleConstraint17);
        boolean boolean19 = ringPlot1.equals((java.lang.Object) graphics2D14);
        java.awt.Paint paint20 = null;
        try {
            ringPlot1.setSeparatorPaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '#', (double) (byte) 0);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        boolean boolean16 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot14.getDomainAxis((int) ' ');
        int int19 = categoryPlot14.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        java.util.List list7 = xYPlot0.getAnnotations();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        java.awt.Paint paint35 = categoryPlot14.getDomainGridlinePaint();
        java.awt.Stroke stroke36 = categoryPlot14.getRangeGridlineStroke();
        categoryPlot14.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.data.Range range8 = org.jfree.data.Range.expand(range5, 0.2d, 0.2d);
        double double9 = range8.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.2d) + "'", double9 == (-0.2d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        try {
            org.jfree.chart.LegendItem legendItem2 = legendItemCollection0.get((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getRange();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setIgnoreNullValues(false);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) '#', paint11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean17 = textBlockAnchor15.equals((java.lang.Object) horizontalAlignment16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment18, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14, (org.jfree.chart.block.Arrangement) flowArrangement21, arrangement22);
        legendTitle23.setWidth(1.0d);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D30 = legendTitle23.arrange(graphics2D26, rectangleConstraint29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, 100.0d, (double) (byte) -1, rectangleAnchor33);
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D();
        double double36 = piePlot3D35.getDepthFactor();
        double double37 = piePlot3D35.getMaximumExplodePercent();
        boolean boolean38 = piePlot3D35.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.PiePlotState piePlotState41 = piePlot7.initialise(graphics2D13, rectangle2D34, (org.jfree.chart.plot.PiePlot) piePlot3D35, (java.lang.Integer) 100, plotRenderingInfo40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis0.lengthToJava2D((double) 10, rectangle2D34, rectangleEdge42);
        double double44 = numberAxis0.getUpperBound();
        org.jfree.data.Range range45 = numberAxis0.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.12d + "'", double36 == 0.12d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(piePlotState41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent21);
        categoryPlot14.setWeight(100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge((int) (byte) 1);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis(100);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean11 = dateAxis10.isAxisLineVisible();
        dateAxis10.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        polarPlot15.addChangeListener(plotChangeListener16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = polarPlot15.getDrawingSupplier();
        java.awt.Paint paint19 = polarPlot15.getAngleLabelPaint();
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 0.5f, (double) 100L, (double) (-14745631), paint19);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((-16.0d), (double) 255, (double) (byte) 0, (double) 2.0f, paint19);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("HorizontalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray14);
        multiplePiePlot1.setDataset(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) 100.0f);
        try {
            org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot11.getFixedDomainAxisSpace();
        xYPlot11.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot11.getDomainAxisLocation();
        int int16 = xYPlot11.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray18 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer17 };
        xYPlot11.setRenderers(xYItemRendererArray18);
        legendTitle9.setSources((org.jfree.chart.LegendItemSource[]) xYItemRendererArray18);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray18);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth(1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        dateAxis2.setTickMarkInsideLength((float) 0L);
        dateAxis2.setLowerBound(1.0d);
        boolean boolean12 = dateAxis2.isAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range18 = dateAxis14.getRange();
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range18, 0.2d, 0.2d);
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range18, (double) (byte) 1, true);
        org.jfree.data.Range range27 = org.jfree.data.Range.shift(range24, 0.0d, false);
        dateAxis2.setRangeWithMargins(range27, false, true);
        double double31 = range27.getCentralValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.5d + "'", double31 == 1.5d);
    }
}

