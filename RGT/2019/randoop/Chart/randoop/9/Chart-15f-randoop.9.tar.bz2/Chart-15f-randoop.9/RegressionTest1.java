import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        org.jfree.chart.event.TitleChangeListener titleChangeListener12 = null;
        legendTitle9.addChangeListener(titleChangeListener12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets15.trimHeight((double) (byte) -1);
        double double18 = rectangleInsets15.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean23 = textBlockAnchor21.equals((java.lang.Object) horizontalAlignment22);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment22, verticalAlignment24, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20, (org.jfree.chart.block.Arrangement) flowArrangement27, arrangement28);
        legendTitle29.setWidth(1.0d);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D36 = legendTitle29.arrange(graphics2D32, rectangleConstraint35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D36, 100.0d, (double) (byte) -1, rectangleAnchor39);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets19.createInsetRectangle(rectangle2D40);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets15.createAdjustedRectangle(rectangle2D40, lengthAdjustmentType42, lengthAdjustmentType43);
        try {
            legendTitle9.draw(graphics2D14, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.0d) + "'", double17 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 100, (int) (byte) 1, (int) (byte) 10);
        int int4 = chartColor3.getRed();
        float[] floatArray11 = new float[] { '#', 0, (byte) 1, 10.0f, (short) 0, 15 };
        float[] floatArray12 = chartColor3.getComponents(floatArray11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        polarPlot7.setOutlineVisible(false);
        boolean boolean10 = polarPlot7.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat9 = dateAxis5.getDateFormatOverride();
        dateAxis5.setLabelToolTip("");
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMaximumDate(date12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        dateAxis5.resizeRange(0.025d, (double) 0.0f);
        boolean boolean20 = dateAxis5.isHiddenValue((long) (short) 1);
        boolean boolean21 = xYPlot0.equals((java.lang.Object) boolean20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean25 = dateAxis24.isAxisLineVisible();
        dateAxis24.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, polarItemRenderer28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        polarPlot29.addChangeListener(plotChangeListener30);
        java.awt.Paint paint32 = polarPlot29.getRadiusGridlinePaint();
        boolean boolean33 = polarPlot29.isAngleLabelsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = polarPlot29.getLegendItems();
        java.awt.Color color35 = java.awt.Color.red;
        boolean boolean36 = legendItemCollection34.equals((java.lang.Object) color35);
        xYPlot0.setFixedLegendItems(legendItemCollection34);
        java.awt.Stroke stroke38 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot7.zoomRangeAxes((double) (short) 1, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = polarPlot7.getAxis();
        java.awt.Paint paint18 = polarPlot7.getAngleGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot0.getRenderer();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        blockContainer11.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockContainer11.getMargin();
        java.lang.Object obj14 = blockContainer11.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.title.Title title11 = titleChangeEvent10.getTitle();
        title11.setHeight(1.0E-8d);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(title11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        dateAxis13.setLabelToolTip("");
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis13.setMaximumDate(date20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        java.util.List list24 = categoryPlot23.getCategories();
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot23.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot26.getFixedDomainAxisSpace();
        xYPlot26.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot26.getDomainAxisLocation();
        int int31 = xYPlot26.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke33 = piePlot3D32.getLabelOutlineStroke();
        piePlot3D32.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke37 = piePlot3D36.getLabelOutlineStroke();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D36.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke39);
        piePlot3D32.setBaseSectionOutlineStroke(stroke39);
        xYPlot26.setRangeGridlineStroke(stroke39);
        categoryPlot23.setRangeGridlineStroke(stroke39);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean47 = dateAxis46.isAxisLineVisible();
        dateAxis46.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font50 = dateAxis46.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor53 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean55 = textBlockAnchor53.equals((java.lang.Object) horizontalAlignment54);
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement59 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment54, verticalAlignment56, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot52, (org.jfree.chart.block.Arrangement) flowArrangement59, arrangement60);
        legendTitle61.setWidth(1.0d);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D68 = legendTitle61.arrange(graphics2D64, rectangleConstraint67);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, 100.0d, (double) (byte) -1, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets51.createInsetRectangle(rectangle2D72);
        dateAxis46.setDownArrow((java.awt.Shape) rectangle2D73);
        categoryPlot23.drawBackgroundImage(graphics2D44, rectangle2D73);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = categoryPlot76.getRangeAxisEdge((int) (byte) 1);
        double double79 = categoryAxis1.getCategoryMiddle((int) (byte) 100, 1, rectangle2D73, rectangleEdge78);
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean83 = dateAxis82.isAxisLineVisible();
        dateAxis82.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font86 = dateAxis82.getTickLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 255, font86);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(list24);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(textBlockAnchor53);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(size2D68);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + (-180.99999999999997d) + "'", double79 == (-180.99999999999997d));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(font86);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        org.jfree.chart.event.TitleChangeListener titleChangeListener12 = null;
        legendTitle9.addChangeListener(titleChangeListener12);
        boolean boolean15 = legendTitle9.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelOutlinePaint();
        double double2 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        piePlot3D0.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke5 = piePlot3D4.getLabelOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D4.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke7);
        piePlot3D0.setBaseSectionOutlineStroke(stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean11 = piePlot3D0.getSimpleLabels();
        java.awt.Font font12 = piePlot3D0.getLabelFont();
        piePlot3D0.setSimpleLabels(true);
        double double15 = piePlot3D0.getShadowYOffset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        java.lang.String str8 = dateAxis1.getLabel();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis12.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint16 = categoryAxis12.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint17 = categoryAxis12.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean25 = dateAxis24.isAxisLineVisible();
        dateAxis24.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat28 = dateAxis24.getDateFormatOverride();
        dateAxis24.setLabelToolTip("");
        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis24.setMaximumDate(date31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer33);
        java.util.List list35 = categoryPlot34.getCategories();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot34.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace38 = xYPlot37.getFixedDomainAxisSpace();
        xYPlot37.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot37.getDomainAxisLocation();
        int int42 = xYPlot37.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke44 = piePlot3D43.getLabelOutlineStroke();
        piePlot3D43.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D47 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke48 = piePlot3D47.getLabelOutlineStroke();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D47.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke50);
        piePlot3D43.setBaseSectionOutlineStroke(stroke50);
        xYPlot37.setRangeGridlineStroke(stroke50);
        categoryPlot34.setRangeGridlineStroke(stroke50);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean58 = dateAxis57.isAxisLineVisible();
        dateAxis57.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font61 = dateAxis57.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot63 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor64 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment65 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean66 = textBlockAnchor64.equals((java.lang.Object) horizontalAlignment65);
        org.jfree.chart.util.VerticalAlignment verticalAlignment67 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement70 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment65, verticalAlignment67, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot63, (org.jfree.chart.block.Arrangement) flowArrangement70, arrangement71);
        legendTitle72.setWidth(1.0d);
        java.awt.Graphics2D graphics2D75 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint78 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D79 = legendTitle72.arrange(graphics2D75, rectangleConstraint78);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D83 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D79, 100.0d, (double) (byte) -1, rectangleAnchor82);
        java.awt.geom.Rectangle2D rectangle2D84 = rectangleInsets62.createInsetRectangle(rectangle2D83);
        dateAxis57.setDownArrow((java.awt.Shape) rectangle2D84);
        categoryPlot34.drawBackgroundImage(graphics2D55, rectangle2D84);
        org.jfree.chart.plot.CategoryPlot categoryPlot87 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = categoryPlot87.getRangeAxisEdge((int) (byte) 1);
        double double90 = categoryAxis12.getCategoryMiddle((int) (byte) 100, 1, rectangle2D84, rectangleEdge89);
        org.jfree.chart.plot.XYPlot xYPlot91 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace92 = xYPlot91.getFixedDomainAxisSpace();
        xYPlot91.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = xYPlot91.getDomainAxisEdge();
        try {
            java.util.List list96 = dateAxis1.refreshTicks(graphics2D9, axisState10, rectangle2D84, rectangleEdge95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(dateFormat28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(list35);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNull(axisSpace38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(textBlockAnchor64);
        org.junit.Assert.assertNotNull(horizontalAlignment65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(verticalAlignment67);
        org.junit.Assert.assertNotNull(size2D79);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + (-180.99999999999997d) + "'", double90 == (-180.99999999999997d));
        org.junit.Assert.assertNull(axisSpace92);
        org.junit.Assert.assertNotNull(rectangleEdge95);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke7 = piePlot3D6.getLabelOutlineStroke();
        piePlot3D6.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke11 = piePlot3D10.getLabelOutlineStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D10.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke13);
        piePlot3D6.setBaseSectionOutlineStroke(stroke13);
        xYPlot0.setRangeGridlineStroke(stroke13);
        int int17 = xYPlot0.getBackgroundImageAlignment();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart23.createBufferedImage((int) (short) 1, (int) (short) 1, chartRenderingInfo27);
        org.jfree.chart.plot.Plot plot29 = jFreeChart23.getPlot();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(bufferedImage28);
        org.junit.Assert.assertNotNull(plot29);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range40 = dateAxis36.getRange();
        dateAxis36.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets43.trimHeight((double) (byte) -1);
        double double47 = rectangleInsets43.trimWidth(0.0d);
        dateAxis36.setTickLabelInsets(rectangleInsets43);
        double double49 = rectangleInsets43.getRight();
        categoryPlot14.setAxisOffset(rectangleInsets43);
        org.jfree.chart.axis.AxisSpace axisSpace51 = categoryPlot14.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-9.0d) + "'", double45 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + (-16.0d) + "'", double47 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNull(axisSpace51);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot14.getDomainAxisLocation();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean3 = dateRange0.intersects(1.0E-5d, (double) (short) -1);
        double double4 = dateRange0.getLowerBound();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot3D0.getInsets();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        java.lang.Object obj8 = null;
        boolean boolean9 = polarPlot7.equals(obj8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean13 = textBlockAnchor11.equals((java.lang.Object) horizontalAlignment12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment14, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot10, (org.jfree.chart.block.Arrangement) flowArrangement17, arrangement18);
        legendTitle19.setWidth(1.0d);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D26 = legendTitle19.arrange(graphics2D22, rectangleConstraint25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, 100.0d, (double) (byte) -1, rectangleAnchor29);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets9.createInsetRectangle(rectangle2D30);
        dateAxis4.setDownArrow((java.awt.Shape) rectangle2D31);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot34.getFixedDomainAxisSpace();
        xYPlot34.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot34.getDomainAxisLocation();
        int int39 = xYPlot34.getRangeAxisCount();
        java.awt.geom.Point2D point2D40 = xYPlot34.getQuadrantOrigin();
        xYPlot33.setQuadrantOrigin(point2D40);
        java.awt.geom.Point2D point2D42 = xYPlot33.getQuadrantOrigin();
        java.awt.geom.Point2D point2D43 = xYPlot33.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D31, point2D43, plotState44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(point2D40);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray24);
        multiplePiePlot11.setDataset(categoryDataset25);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset25, (double) 100.0f);
        boolean boolean29 = flowArrangement7.equals((java.lang.Object) range28);
        flowArrangement7.clear();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke3 = piePlot3D2.getLabelOutlineStroke();
        piePlot3D0.setLabelOutlineStroke(stroke3);
        piePlot3D0.setStartAngle(0.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleEdge.RIGHT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.Plot plot14 = polarPlot7.getRootPlot();
        java.awt.Stroke stroke15 = polarPlot7.getAngleGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0L, (double) 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator4);
        boolean boolean6 = piePlot3D0.getSectionOutlinesVisible();
        piePlot3D0.setCircular(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis6.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource7);
        double double9 = dateAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D0.getLabelGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = xYPlot0.equals((java.lang.Object) stroke9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        dateAxis15.setLabelAngle((double) (short) -1);
        double double18 = dateAxis15.getLabelAngle();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15);
        dateAxis15.setUpperBound(0.0d);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        polarPlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = polarPlot19.getDrawingSupplier();
        java.awt.Color color23 = java.awt.Color.PINK;
        polarPlot19.setNoDataMessagePaint((java.awt.Paint) color23);
        textTitle10.setPaint((java.awt.Paint) color23);
        textTitle10.setID("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean30 = textBlockAnchor28.equals((java.lang.Object) horizontalAlignment29);
        textTitle10.setHorizontalAlignment(horizontalAlignment29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int33 = color32.getBlue();
        textTitle10.setBackgroundPaint((java.awt.Paint) color32);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint38.toFixedWidth(1.0E-5d);
        try {
            org.jfree.chart.util.Size2D size2D41 = textTitle10.arrange(graphics2D35, rectangleConstraint40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        java.awt.Font font11 = legendTitle9.getItemFont();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray12);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13);
        boolean boolean17 = range14.intersects(1.0E-8d, (double) 2.0f);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle9.getMargin();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle9.getBounds();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font25 = dateAxis21.getTickLabelFont();
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("ClassContext", font25, paint26);
        legendTitle9.setItemFont(font25);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        java.lang.String str3 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        boolean boolean16 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot14.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(drawingSupplier19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = piePlot3D0.getOutlineStroke();
        piePlot3D0.setLabelLinksVisible(false);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3D0);
        java.awt.Stroke stroke13 = jFreeChart12.getBorderStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        piePlot3D0.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke5 = piePlot3D4.getLabelOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D4.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke7);
        piePlot3D0.setBaseSectionOutlineStroke(stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean11 = piePlot3D0.getSimpleLabels();
        java.awt.Font font12 = piePlot3D0.getLabelFont();
        double double14 = piePlot3D0.getExplodePercent((java.lang.Comparable) 32.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment12, (double) (byte) 10, (double) 100);
        boolean boolean16 = textTitle10.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getDomainAxisEdge();
        textTitle10.setPosition(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke7 = piePlot3D6.getLabelOutlineStroke();
        piePlot3D6.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke11 = piePlot3D10.getLabelOutlineStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D10.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke13);
        piePlot3D6.setBaseSectionOutlineStroke(stroke13);
        xYPlot0.setRangeGridlineStroke(stroke13);
        int int17 = xYPlot0.getBackgroundImageAlignment();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke20 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelToolTip("");
        boolean boolean8 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 0.5f };
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat7 = dateAxis3.getDateFormatOverride();
        dateAxis3.setLabelToolTip("");
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis3.setMaximumDate(date10);
        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] { date10, 2 };
        double[][] doubleArray14 = new double[][] {};
        try {
            org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray13, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(comparableArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        piePlotState34.setPieHRadius((double) 10.0f);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        dateAxis2.setTickMarkInsideLength((float) 0L);
        double double10 = dateAxis2.getAutoRangeMinimumSize();
        dateAxis2.setFixedAutoRange(0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getOuterSeparatorExtension();
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot1.getDataset();
        ringPlot1.setSectionDepth((double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double4 = rectangleInsets0.trimWidth(0.0d);
        double double6 = rectangleInsets0.trimWidth(52.0d);
        double double8 = rectangleInsets0.calculateLeftInset((double) 100.0f);
        double double10 = rectangleInsets0.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-16.0d) + "'", double4 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 36.0d + "'", double6 == 36.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-16.0d) + "'", double10 == (-16.0d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean38 = dateAxis37.isAxisLineVisible();
        dateAxis37.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font41 = dateAxis37.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean46 = textBlockAnchor44.equals((java.lang.Object) horizontalAlignment45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment45, verticalAlignment47, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot43, (org.jfree.chart.block.Arrangement) flowArrangement50, arrangement51);
        legendTitle52.setWidth(1.0d);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D59 = legendTitle52.arrange(graphics2D55, rectangleConstraint58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 100.0d, (double) (byte) -1, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets42.createInsetRectangle(rectangle2D63);
        dateAxis37.setDownArrow((java.awt.Shape) rectangle2D64);
        categoryPlot14.drawBackgroundImage(graphics2D35, rectangle2D64);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double68 = rectangleInsets67.getBottom();
        categoryPlot14.setInsets(rectangleInsets67, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 4.0d + "'", double68 == 4.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range40 = dateAxis36.getRange();
        dateAxis36.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets43.trimHeight((double) (byte) -1);
        double double47 = rectangleInsets43.trimWidth(0.0d);
        dateAxis36.setTickLabelInsets(rectangleInsets43);
        double double49 = rectangleInsets43.getRight();
        categoryPlot14.setAxisOffset(rectangleInsets43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot14.getRenderer();
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = null;
        org.jfree.chart.util.Layer layer54 = null;
        try {
            categoryPlot14.addDomainMarker((int) (byte) 0, categoryMarker53, layer54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-9.0d) + "'", double45 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + (-16.0d) + "'", double47 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNull(categoryItemRenderer51);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        java.lang.String str3 = projectInfo0.getInfo();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean9 = dateAxis8.isAxisLineVisible();
        dateAxis8.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat12 = dateAxis8.getDateFormatOverride();
        dateAxis8.setLabelToolTip("");
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis8.setMaximumDate(date15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer17);
        java.lang.Object obj19 = categoryAxis6.clone();
        java.awt.Font font22 = null;
        java.awt.Paint paint23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, paint23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean28 = textBlock24.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean32 = dateAxis31.isAxisLineVisible();
        dateAxis31.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat35 = dateAxis31.getDateFormatOverride();
        java.awt.Font font36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis31.setTickLabelFont(font36);
        java.awt.Color color38 = java.awt.Color.red;
        textBlock24.addLine("", font36, (java.awt.Paint) color38);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        double double41 = piePlot3D40.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("hi!", font36, (org.jfree.chart.plot.Plot) piePlot3D40, false);
        boolean boolean44 = jFreeChart43.isNotify();
        float float45 = jFreeChart43.getBackgroundImageAlpha();
        java.awt.Color color46 = java.awt.Color.PINK;
        jFreeChart43.setBorderPaint((java.awt.Paint) color46);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType48 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis6, jFreeChart43, chartChangeEventType48);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        java.awt.image.BufferedImage bufferedImage55 = jFreeChart43.createBufferedImage((int) (short) 1, (int) (short) 10, (double) 'a', (-9.223372036854776E18d), chartRenderingInfo54);
        projectInfo0.setLogo((java.awt.Image) bufferedImage55);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(dateFormat12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(dateFormat35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.12d + "'", double41 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.5f + "'", float45 == 0.5f);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(chartChangeEventType48);
        org.junit.Assert.assertNotNull(bufferedImage55);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean38 = dateAxis37.isAxisLineVisible();
        dateAxis37.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font41 = dateAxis37.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean46 = textBlockAnchor44.equals((java.lang.Object) horizontalAlignment45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment45, verticalAlignment47, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot43, (org.jfree.chart.block.Arrangement) flowArrangement50, arrangement51);
        legendTitle52.setWidth(1.0d);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D59 = legendTitle52.arrange(graphics2D55, rectangleConstraint58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 100.0d, (double) (byte) -1, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets42.createInsetRectangle(rectangle2D63);
        dateAxis37.setDownArrow((java.awt.Shape) rectangle2D64);
        categoryPlot14.drawBackgroundImage(graphics2D35, rectangle2D64);
        org.jfree.chart.axis.ValueAxis valueAxis68 = categoryPlot14.getRangeAxis((int) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset69 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean74 = dateAxis73.isAxisLineVisible();
        dateAxis73.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat77 = dateAxis73.getDateFormatOverride();
        dateAxis73.setLabelToolTip("");
        java.util.Date date80 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis73.setMaximumDate(date80);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis71, (org.jfree.chart.axis.ValueAxis) dateAxis73, categoryItemRenderer82);
        java.util.List list84 = categoryPlot83.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation85 = categoryPlot83.getRangeAxisLocation();
        categoryPlot14.setRangeAxisLocation(axisLocation85);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNull(valueAxis68);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNull(dateFormat77);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNull(list84);
        org.junit.Assert.assertNotNull(axisLocation85);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = piePlot3D0.getOutlineStroke();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean16 = dateAxis15.isAxisLineVisible();
        dateAxis15.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range19 = dateAxis15.getRange();
        org.jfree.data.Range range22 = org.jfree.data.Range.expand(range19, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(45.0d, range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint12.toRangeHeight(range19);
        org.jfree.data.Range range25 = rectangleConstraint12.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint12.toFixedWidth(0.0d);
        boolean boolean28 = piePlot3D0.equals((java.lang.Object) 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot3D0.getSimpleLabelOffset();
        piePlot3D0.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        double double35 = piePlotState34.getPieCenterX();
        piePlotState34.setPieCenterX((double) ' ');
        piePlotState34.setTotal((double) 100.0f);
        java.awt.geom.Rectangle2D rectangle2D40 = piePlotState34.getPieArea();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D40);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean8 = dateAxis7.isAxisLineVisible();
        dateAxis7.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat11 = dateAxis7.getDateFormatOverride();
        dateAxis7.setLabelToolTip("");
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis7.setMaximumDate(date14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer16);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color0, paint1 };
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Stroke[] strokeArray6 = new java.awt.Stroke[] { stroke5 };
        java.awt.Stroke stroke7 = null;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke7 };
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray11 = new java.awt.Shape[] { shape9, shape10 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, paintArray4, strokeArray6, strokeArray8, shapeArray11);
        java.awt.Shape shape13 = defaultDrawingSupplier12.getNextShape();
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke15 = piePlot3D14.getLabelOutlineStroke();
        piePlot3D14.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke19 = piePlot3D18.getLabelOutlineStroke();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D18.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke21);
        piePlot3D14.setBaseSectionOutlineStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot3D14.getSimpleLabelOffset();
        java.awt.Paint paint25 = piePlot3D14.getBaseSectionPaint();
        boolean boolean26 = defaultDrawingSupplier12.equals((java.lang.Object) piePlot3D14);
        java.awt.Stroke stroke27 = defaultDrawingSupplier12.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shapeArray11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(stroke27);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = dateAxis1.hasListener(eventListener10);
        double double12 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets8.trimHeight((double) (byte) -1);
        double double12 = rectangleInsets8.trimWidth(0.0d);
        dateAxis1.setTickLabelInsets(rectangleInsets8);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint19 = categoryAxis15.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.Paint paint20 = categoryAxis15.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean28 = dateAxis27.isAxisLineVisible();
        dateAxis27.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat31 = dateAxis27.getDateFormatOverride();
        dateAxis27.setLabelToolTip("");
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis27.setMaximumDate(date34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer36);
        java.util.List list38 = categoryPlot37.getCategories();
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot37.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot40.getFixedDomainAxisSpace();
        xYPlot40.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot40.getDomainAxisLocation();
        int int45 = xYPlot40.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke47 = piePlot3D46.getLabelOutlineStroke();
        piePlot3D46.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D50 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke51 = piePlot3D50.getLabelOutlineStroke();
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D50.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke53);
        piePlot3D46.setBaseSectionOutlineStroke(stroke53);
        xYPlot40.setRangeGridlineStroke(stroke53);
        categoryPlot37.setRangeGridlineStroke(stroke53);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean61 = dateAxis60.isAxisLineVisible();
        dateAxis60.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font64 = dateAxis60.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot66 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor67 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment68 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean69 = textBlockAnchor67.equals((java.lang.Object) horizontalAlignment68);
        org.jfree.chart.util.VerticalAlignment verticalAlignment70 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement73 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment68, verticalAlignment70, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement74 = null;
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot66, (org.jfree.chart.block.Arrangement) flowArrangement73, arrangement74);
        legendTitle75.setWidth(1.0d);
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint81 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D82 = legendTitle75.arrange(graphics2D78, rectangleConstraint81);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D86 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D82, 100.0d, (double) (byte) -1, rectangleAnchor85);
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets65.createInsetRectangle(rectangle2D86);
        dateAxis60.setDownArrow((java.awt.Shape) rectangle2D87);
        categoryPlot37.drawBackgroundImage(graphics2D58, rectangle2D87);
        org.jfree.chart.plot.CategoryPlot categoryPlot90 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = categoryPlot90.getRangeAxisEdge((int) (byte) 1);
        double double93 = categoryAxis15.getCategoryMiddle((int) (byte) 100, 1, rectangle2D87, rectangleEdge92);
        java.awt.geom.Rectangle2D rectangle2D96 = rectangleInsets8.createInsetRectangle(rectangle2D87, false, true);
        double double98 = rectangleInsets8.calculateBottomOutset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.0d) + "'", double10 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-16.0d) + "'", double12 == (-16.0d));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(dateFormat31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(list38);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(textBlockAnchor67);
        org.junit.Assert.assertNotNull(horizontalAlignment68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(verticalAlignment70);
        org.junit.Assert.assertNotNull(size2D82);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNotNull(rectangle2D86);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertNotNull(rectangleEdge92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + (-180.99999999999997d) + "'", double93 == (-180.99999999999997d));
        org.junit.Assert.assertNotNull(rectangle2D96);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 4.0d + "'", double98 == 4.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        int int7 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0L, (-17.0d), 10.0d, (double) 0.5f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateRightOutset((-17.0d));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setLabelAngle((double) (short) -1);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        dateAxis1.setInverted(true);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, (double) '4');
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double19 = rectangleInsets17.trimHeight((double) (byte) -1);
        double double20 = rectangleInsets17.getTop();
        double double22 = rectangleInsets17.calculateBottomInset((double) (byte) 100);
        categoryPlot14.setAxisOffset(rectangleInsets17);
        java.lang.Object obj24 = categoryPlot14.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-9.0d) + "'", double19 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        java.awt.geom.Point2D point2D9 = xYPlot0.getQuadrantOrigin();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        java.text.DateFormat dateFormat18 = null;
        dateAxis13.setDateFormatOverride(dateFormat18);
        dateAxis13.setAutoRangeMinimumSize((double) (byte) 100);
        java.util.Date date22 = dateAxis13.getMaximumDate();
        dateAxis13.setAutoRange(true);
        xYPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis13, true);
        dateAxis13.setTickMarkOutsideLength(0.0f);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        int int3 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        double double3 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot3D0.getSectionPaint((java.lang.Comparable) (short) 10);
        java.awt.Shape shape6 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.lang.String str9 = chartEntity8.toString();
        chartEntity8.setToolTipText("ClassContext");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartEntity: tooltip = (C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str9.equals("ChartEntity: tooltip = (C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot7.zoomRangeAxes((double) (short) 1, plotRenderingInfo14, point2D15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        polarPlot7.drawBackgroundImage(graphics2D17, rectangle2D18);
        int int20 = polarPlot7.getSeriesCount();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        polarPlot7.setDataset(xYDataset21);
        polarPlot7.addCornerTextItem("Multiple Pie Plot");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        categoryPlot14.mapDatasetToRangeAxis((int) (byte) 0, (int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot14.getDomainAxisForDataset((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean32 = dateAxis31.isAxisLineVisible();
        dateAxis31.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font35 = dateAxis31.getTickLabelFont();
        java.awt.Paint paint36 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("ClassContext", font35, paint36);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font35);
        java.awt.Paint paint39 = null;
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, paint39);
        categoryAxis25.setTickLabelFont((java.lang.Comparable) false, font35);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(categoryAxis25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(textBlock40);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        categoryPlot14.mapDatasetToRangeAxis((int) (byte) 0, (int) (byte) 100);
        java.lang.Object obj24 = categoryPlot14.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range6 = dateAxis2.getRange();
        org.jfree.data.Range range9 = org.jfree.data.Range.expand(range6, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(45.0d, range6);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.data.Range range14 = org.jfree.data.Range.combine(range6, (org.jfree.data.Range) dateRange12);
        java.lang.String str15 = dateRange12.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str15.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PlotOrientation.VERTICAL", graphics2D1, (float) (-1), (float) (byte) 1, (double) 8, (float) (byte) 1, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray14);
        multiplePiePlot1.setDataset(categoryDataset15);
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent21);
        boolean boolean23 = categoryPlot14.isDomainGridlinesVisible();
        java.awt.Stroke stroke24 = categoryPlot14.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean18 = dateAxis17.isAxisLineVisible();
        dateAxis17.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range21 = dateAxis17.getRange();
        org.jfree.data.Range range24 = org.jfree.data.Range.expand(range21, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(45.0d, range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint14.toRangeHeight(range21);
        org.jfree.data.Range range27 = rectangleConstraint14.getWidthRange();
        org.jfree.chart.util.Size2D size2D28 = legendTitle9.arrange(graphics2D11, rectangleConstraint14);
        org.jfree.data.Range range29 = rectangleConstraint14.getWidthRange();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNull(range29);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        jFreeChart23.clearSubtitles();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean31 = dateAxis30.isAxisLineVisible();
        dateAxis30.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font34 = dateAxis30.getTickLabelFont();
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ClassContext", font34, paint35);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font34);
        java.lang.Object obj38 = textTitle37.clone();
        jFreeChart23.removeSubtitle((org.jfree.chart.title.Title) textTitle37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        try {
            java.awt.image.BufferedImage bufferedImage44 = jFreeChart23.createBufferedImage(0, (int) (short) 1, 500, chartRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 500");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        polarPlot7.setOutlineVisible(false);
        java.awt.Color color10 = java.awt.Color.red;
        polarPlot7.setRadiusGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        dateAxis13.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis13.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(tickUnitSource17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Size2D[width=0.0, height=0.0]", "RectangleEdge.RIGHT", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "Other", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle9.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean19 = dateAxis18.isAxisLineVisible();
        dateAxis18.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat22 = dateAxis18.getDateFormatOverride();
        dateAxis18.setLabelToolTip("");
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis18.setMaximumDate(date25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer27);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = numberAxis29.getStandardTickUnits();
        boolean boolean31 = numberAxis29.isInverted();
        numberAxis29.configure();
        int int33 = categoryPlot28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font40 = dateAxis36.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean45 = textBlockAnchor43.equals((java.lang.Object) horizontalAlignment44);
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement49 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment44, verticalAlignment46, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement50 = null;
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot42, (org.jfree.chart.block.Arrangement) flowArrangement49, arrangement50);
        legendTitle51.setWidth(1.0d);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D58 = legendTitle51.arrange(graphics2D54, rectangleConstraint57);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D62 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D58, 100.0d, (double) (byte) -1, rectangleAnchor61);
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets41.createInsetRectangle(rectangle2D62);
        dateAxis36.setDownArrow((java.awt.Shape) rectangle2D63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        boolean boolean67 = categoryPlot28.render(graphics2D34, rectangle2D63, (int) 'a', plotRenderingInfo66);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double70 = rectangleInsets68.trimHeight((double) (byte) -1);
        double double72 = rectangleInsets68.trimWidth(0.0d);
        try {
            java.lang.Object obj73 = legendTitle9.draw(graphics2D13, rectangle2D63, (java.lang.Object) double72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(dateFormat22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(size2D58);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-9.0d) + "'", double70 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + (-16.0d) + "'", double72 == (-16.0d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean8 = dateAxis7.isAxisLineVisible();
        dateAxis7.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat11 = dateAxis7.getDateFormatOverride();
        dateAxis7.setLabelToolTip("");
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis7.setMaximumDate(date14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer16);
        java.util.List list18 = categoryPlot17.getCategories();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot17.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot20.getFixedDomainAxisSpace();
        xYPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot20.getDomainAxisLocation();
        int int25 = xYPlot20.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke27 = piePlot3D26.getLabelOutlineStroke();
        piePlot3D26.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke31 = piePlot3D30.getLabelOutlineStroke();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D30.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke33);
        piePlot3D26.setBaseSectionOutlineStroke(stroke33);
        xYPlot20.setRangeGridlineStroke(stroke33);
        categoryPlot17.setRangeGridlineStroke(stroke33);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean41 = dateAxis40.isAxisLineVisible();
        dateAxis40.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font44 = dateAxis40.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor47 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean49 = textBlockAnchor47.equals((java.lang.Object) horizontalAlignment48);
        org.jfree.chart.util.VerticalAlignment verticalAlignment50 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement53 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment48, verticalAlignment50, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot46, (org.jfree.chart.block.Arrangement) flowArrangement53, arrangement54);
        legendTitle55.setWidth(1.0d);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D62 = legendTitle55.arrange(graphics2D58, rectangleConstraint61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D66 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D62, 100.0d, (double) (byte) -1, rectangleAnchor65);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets45.createInsetRectangle(rectangle2D66);
        dateAxis40.setDownArrow((java.awt.Shape) rectangle2D67);
        categoryPlot17.drawBackgroundImage(graphics2D38, rectangle2D67);
        boolean boolean70 = textFragment2.equals((java.lang.Object) categoryPlot17);
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.text.TextAnchor textAnchor74 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.plot.PiePlot piePlot75 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor76 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment77 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean78 = textBlockAnchor76.equals((java.lang.Object) horizontalAlignment77);
        org.jfree.chart.util.VerticalAlignment verticalAlignment79 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement82 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment77, verticalAlignment79, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement83 = null;
        org.jfree.chart.title.LegendTitle legendTitle84 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot75, (org.jfree.chart.block.Arrangement) flowArrangement82, arrangement83);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment85 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle84.setHorizontalAlignment(horizontalAlignment85);
        boolean boolean87 = textAnchor74.equals((java.lang.Object) horizontalAlignment85);
        try {
            textFragment2.draw(graphics2D71, (float) (byte) 10, (float) 10, textAnchor74, 2.0f, 0.0f, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(textBlockAnchor47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(verticalAlignment50);
        org.junit.Assert.assertNotNull(size2D62);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(textAnchor74);
        org.junit.Assert.assertNotNull(textBlockAnchor76);
        org.junit.Assert.assertNotNull(horizontalAlignment77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(verticalAlignment79);
        org.junit.Assert.assertNotNull(horizontalAlignment85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot14.getRangeAxisLocation();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) -1, marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle9.setLegendItemGraphicAnchor(rectangleAnchor11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle9.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean5 = textBlockAnchor3.equals((java.lang.Object) horizontalAlignment4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment6, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement9, arrangement10);
        legendTitle11.setWidth(1.0d);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D18 = legendTitle11.arrange(graphics2D14, rectangleConstraint17);
        boolean boolean19 = ringPlot1.equals((java.lang.Object) graphics2D14);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean23 = dateAxis22.isAxisLineVisible();
        dateAxis22.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, polarItemRenderer26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        polarPlot27.addChangeListener(plotChangeListener28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = polarPlot27.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        polarPlot27.setRenderer(polarItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        polarPlot27.zoomRangeAxes((double) (short) 1, plotRenderingInfo34, point2D35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        polarPlot27.drawBackgroundImage(graphics2D37, rectangle2D38);
        int int40 = polarPlot27.getSeriesCount();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        polarPlot27.setDataset(xYDataset41);
        boolean boolean43 = ringPlot1.equals((java.lang.Object) polarPlot27);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace45 = color44.getColorSpace();
        ringPlot1.setBaseSectionPaint((java.awt.Paint) color44);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(colorSpace45);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean7 = textBlock3.equals((java.lang.Object) (byte) 100);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        polarPlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = polarPlot16.getDrawingSupplier();
        java.awt.Color color20 = java.awt.Color.PINK;
        polarPlot16.setNoDataMessagePaint((java.awt.Paint) color20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean24 = dateAxis23.isAxisLineVisible();
        dateAxis23.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat27 = dateAxis23.getDateFormatOverride();
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis23.setTickLabelFont(font28);
        polarPlot16.setAngleLabelFont(font28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        textBlock3.addLine("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font28, (java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(dateFormat27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.Plot plot10 = null;
        polarPlot7.setParent(plot10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis13.setTickLabelFont(font18);
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int4 = color3.getBlue();
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = piePlot3D0.getOutlineStroke();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean16 = dateAxis15.isAxisLineVisible();
        dateAxis15.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range19 = dateAxis15.getRange();
        org.jfree.data.Range range22 = org.jfree.data.Range.expand(range19, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(45.0d, range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint12.toRangeHeight(range19);
        org.jfree.data.Range range25 = rectangleConstraint12.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint12.toFixedWidth(0.0d);
        boolean boolean28 = piePlot3D0.equals((java.lang.Object) 0.0d);
        java.awt.Paint paint29 = null;
        piePlot3D0.setLabelShadowPaint(paint29);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PlotOrientation.VERTICAL", graphics2D1, (float) (short) 10, (float) 'a', textAnchor4, 90.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.data.Range range8 = org.jfree.data.Range.expand(range5, 0.2d, 0.2d);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean11 = dateAxis10.isAxisLineVisible();
        dateAxis10.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range14 = dateAxis10.getRange();
        org.jfree.data.Range range15 = dateAxis10.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range5, range15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) horizontalAlignment3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment5, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement8, arrangement9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle10.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer12 = legendTitle10.getItemContainer();
        blockContainer12.clear();
        java.util.List list14 = blockContainer12.getBlocks();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '#', (double) (byte) 0);
        org.jfree.chart.util.Size2D size2D19 = columnArrangement0.arrange(blockContainer12, graphics2D15, rectangleConstraint18);
        double double20 = size2D19.getHeight();
        double double21 = size2D19.height;
        size2D19.width = Double.NEGATIVE_INFINITY;
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(blockContainer12);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        textTitle10.setURLText("hi!");
        java.lang.Object obj14 = null;
        boolean boolean15 = textTitle10.equals(obj14);
        java.awt.Graphics2D graphics2D16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = textTitle10.arrange(graphics2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        legendTitle9.setWidth(1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle9.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        jFreeChart23.clearSubtitles();
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        double double28 = piePlot3D27.getDepthFactor();
        double double29 = piePlot3D27.getMaximumExplodePercent();
        double double30 = piePlot3D27.getMaximumExplodePercent();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setLabelLinkStroke(stroke31);
        jFreeChart23.setBorderStroke(stroke31);
        org.jfree.chart.plot.Plot plot34 = jFreeChart23.getPlot();
        jFreeChart23.setBorderVisible(true);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.12d + "'", double28 == 0.12d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(plot34);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        double double24 = piePlot3D20.getShadowXOffset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator25 = piePlot3D20.getToolTipGenerator();
        piePlot3D20.setCircular(true, false);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator25);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = xYPlot0.equals((java.lang.Object) stroke9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = xYPlot0.removeRangeMarker((int) (short) -1, marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle9.setHorizontalAlignment(horizontalAlignment10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets12.trimHeight((double) (byte) -1);
        double double16 = rectangleInsets12.trimWidth(0.0d);
        legendTitle9.setPadding(rectangleInsets12);
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets12.getUnitType();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-9.0d) + "'", double14 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-16.0d) + "'", double16 == (-16.0d));
        org.junit.Assert.assertNotNull(unitType18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        polarPlot7.zoomDomainAxes((double) 0.5f, 32.0d, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot7.getAxis();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        polarPlot7.datasetChanged(datasetChangeEvent20);
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke23 = piePlot3D22.getLabelOutlineStroke();
        piePlot3D22.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke27 = piePlot3D26.getLabelOutlineStroke();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D26.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke29);
        piePlot3D22.setBaseSectionOutlineStroke(stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = piePlot3D22.getSimpleLabelOffset();
        polarPlot7.setInsets(rectangleInsets32);
        polarPlot7.removeCornerTextItem("RectangleConstraint[LengthConstraintType.FIXED: width=1.0E-5, height=100.0]");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        polarPlot7.setRenderer(polarItemRenderer36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.String str1 = piePlot3D0.getNoDataMessage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = null;
        try {
            piePlot3D0.setLabelDistributor(abstractPieLabelDistributor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Paint paint9 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D0.getSimpleLabelOffset();
        double double12 = rectangleInsets10.calculateTopInset((double) 10.0f);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.7999999999999998d + "'", double12 == 1.7999999999999998d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = xYPlot0.equals((java.lang.Object) stroke9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot0.setRenderer(xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = numberAxis15.getStandardTickUnits();
        boolean boolean17 = numberAxis15.isInverted();
        numberAxis15.configure();
        numberAxis15.setAutoRangeStickyZero(false);
        int int21 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double3 = rectangleInsets0.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) horizontalAlignment7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment9, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot5, (org.jfree.chart.block.Arrangement) flowArrangement12, arrangement13);
        legendTitle14.setWidth(1.0d);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D21 = legendTitle14.arrange(graphics2D17, rectangleConstraint20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, 100.0d, (double) (byte) -1, rectangleAnchor24);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets4.createInsetRectangle(rectangle2D25);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets0.createAdjustedRectangle(rectangle2D25, lengthAdjustmentType27, lengthAdjustmentType28);
        double double31 = rectangleInsets0.calculateRightOutset(1.7999999999999998d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        java.lang.Object obj6 = xYPlot0.clone();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator4);
        boolean boolean6 = piePlot3D0.getSectionOutlinesVisible();
        boolean boolean7 = piePlot3D0.isCircular();
        double double8 = piePlot3D0.getStartAngle();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        java.awt.geom.Point2D point2D9 = xYPlot0.getQuadrantOrigin();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        java.text.DateFormat dateFormat18 = null;
        dateAxis13.setDateFormatOverride(dateFormat18);
        dateAxis13.setAutoRangeMinimumSize((double) (byte) 100);
        java.util.Date date22 = dateAxis13.getMaximumDate();
        dateAxis13.setAutoRange(true);
        xYPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis13, true);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace27, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot0.getRenderer();
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(xYItemRenderer30);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelOutlinePaint();
        piePlot3D0.setIgnoreNullValues(true);
        boolean boolean4 = piePlot3D0.getDarkerSides();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint28 = jFreeChart24.getBorderPaint();
        jFreeChart24.setAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart24.createBufferedImage(500, 8, Double.NEGATIVE_INFINITY, (double) 15, chartRenderingInfo35);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(bufferedImage36);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 10L, plotRenderingInfo10, point2D11);
        boolean boolean13 = xYPlot0.isDomainCrosshairLockedOnData();
        java.lang.String str14 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "XY Plot" + "'", str14.equals("XY Plot"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getTransparency();
        java.awt.Color color2 = color0.darker();
        float[] floatArray7 = new float[] { 0, (-1L), (short) 100, 100L };
        float[] floatArray8 = color2.getComponents(floatArray7);
        int int9 = color2.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 178 + "'", int9 == 178);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) horizontalAlignment1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) 1L);
        flowArrangement6.clear();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.lang.Object obj10 = polarPlot7.clone();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        java.awt.Font font13 = polarPlot7.getNoDataMessageFont();
        float float14 = polarPlot7.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint6 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        polarPlot7.setRenderer(polarItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = polarPlot7.getOutlinePaint();
        java.lang.Object obj11 = polarPlot7.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        polarPlot7.setDataset(xYDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot16.getFixedDomainAxisSpace();
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot16.getDomainAxisLocation();
        int int21 = xYPlot16.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot16.setRenderers(xYItemRendererArray23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean31 = dateAxis30.isAxisLineVisible();
        dateAxis30.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font34 = dateAxis30.getTickLabelFont();
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ClassContext", font34, paint35);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font34);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double41 = rectangleInsets39.trimHeight((double) (byte) -1);
        double double42 = rectangleInsets39.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean47 = textBlockAnchor45.equals((java.lang.Object) horizontalAlignment46);
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment46, verticalAlignment48, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot44, (org.jfree.chart.block.Arrangement) flowArrangement51, arrangement52);
        legendTitle53.setWidth(1.0d);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D60 = legendTitle53.arrange(graphics2D56, rectangleConstraint59);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D64 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D60, 100.0d, (double) (byte) -1, rectangleAnchor63);
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets43.createInsetRectangle(rectangle2D64);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets39.createAdjustedRectangle(rectangle2D64, lengthAdjustmentType66, lengthAdjustmentType67);
        java.lang.Object obj70 = textTitle37.draw(graphics2D38, rectangle2D68, (java.lang.Object) 45.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D68, rectangleAnchor71);
        xYPlot16.zoomDomainAxes(1.0E-5d, plotRenderingInfo26, point2D72, false);
        try {
            polarPlot7.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D72, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-9.0d) + "'", double41 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(size2D60);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNull(obj70);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(point2D72);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Color color3 = java.awt.Color.BLACK;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color4);
        java.lang.Comparable comparable6 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder7 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "Other" + "'", comparable6.equals("Other"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(layer2);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        double double2 = numberAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 10L, plotRenderingInfo10, point2D11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        int int14 = xYPlot0.getIndexOf(xYItemRenderer13);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((-9.0d), (-17.0d));
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-9.0d) + "'", double3 == (-9.0d));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis0.setMarkerBand(markerAxisBand1);
        java.lang.String str3 = numberAxis0.getLabelURL();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        double double25 = piePlot3D21.getShadowXOffset();
        boolean boolean26 = textBlockAnchor0.equals((java.lang.Object) piePlot3D21);
        piePlot3D21.setCircular(true, true);
        java.awt.Font font32 = null;
        java.awt.Paint paint33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, paint33);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean38 = textBlock34.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean42 = dateAxis41.isAxisLineVisible();
        dateAxis41.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat45 = dateAxis41.getDateFormatOverride();
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis41.setTickLabelFont(font46);
        java.awt.Color color48 = java.awt.Color.red;
        textBlock34.addLine("", font46, (java.awt.Paint) color48);
        org.jfree.chart.plot.PiePlot3D piePlot3D50 = new org.jfree.chart.plot.PiePlot3D();
        double double51 = piePlot3D50.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("hi!", font46, (org.jfree.chart.plot.Plot) piePlot3D50, false);
        boolean boolean54 = jFreeChart53.isNotify();
        float float55 = jFreeChart53.getBackgroundImageAlpha();
        jFreeChart53.removeLegend();
        int int57 = jFreeChart53.getBackgroundImageAlignment();
        piePlot3D21.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart53);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(dateFormat45);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.12d + "'", double51 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.5f + "'", float55 == 0.5f);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 15 + "'", int57 == 15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat9 = dateAxis5.getDateFormatOverride();
        dateAxis5.setLabelToolTip("");
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMaximumDate(date12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        dateAxis5.resizeRange(0.025d, (double) 0.0f);
        boolean boolean20 = dateAxis5.isHiddenValue((long) (short) 1);
        boolean boolean21 = xYPlot0.equals((java.lang.Object) boolean20);
        boolean boolean22 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace23);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot7.zoomRangeAxes((double) (short) 1, plotRenderingInfo14, point2D15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        polarPlot7.drawBackgroundImage(graphics2D17, rectangle2D18);
        int int20 = polarPlot7.getSeriesCount();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean24 = dateAxis23.isAxisLineVisible();
        dateAxis23.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, polarItemRenderer27);
        dateAxis23.setTickMarkInsideLength((float) 0L);
        double double31 = dateAxis23.getAutoRangeMinimumSize();
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 32.0d + "'", double31 == 32.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer25);
        dateAxis21.setTickMarkInsideLength((float) 0L);
        boolean boolean29 = dateAxis21.isAutoTickUnitSelection();
        categoryPlot14.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis21, false);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat40 = dateAxis36.getDateFormatOverride();
        dateAxis36.setLabelToolTip("");
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis36.setMaximumDate(date43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer45);
        java.util.List list47 = categoryPlot46.getCategories();
        org.jfree.chart.util.SortOrder sortOrder48 = categoryPlot46.getColumnRenderingOrder();
        categoryPlot14.setRowRenderingOrder(sortOrder48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot14.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(dateFormat40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(list47);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        polarPlot7.zoomRangeAxes(0.0d, (double) 0, plotRenderingInfo13, point2D14);
        double double16 = polarPlot7.getMaxRadius();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 16.0d + "'", double16 == 16.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        double double20 = categoryPlot14.getAnchorValue();
        java.awt.Font font23 = null;
        java.awt.Paint paint24 = null;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, paint24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean29 = textBlock25.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean33 = dateAxis32.isAxisLineVisible();
        dateAxis32.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat36 = dateAxis32.getDateFormatOverride();
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis32.setTickLabelFont(font37);
        java.awt.Color color39 = java.awt.Color.red;
        textBlock25.addLine("", font37, (java.awt.Paint) color39);
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        double double42 = piePlot3D41.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("hi!", font37, (org.jfree.chart.plot.Plot) piePlot3D41, false);
        boolean boolean45 = jFreeChart44.isNotify();
        float float46 = jFreeChart44.getBackgroundImageAlpha();
        java.awt.Color color47 = java.awt.Color.BLACK;
        jFreeChart44.setBorderPaint((java.awt.Paint) color47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart44.setPadding(rectangleInsets49);
        categoryPlot14.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot14.getRangeAxisEdge(255);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(dateFormat36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.12d + "'", double42 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.5f + "'", float46 == 0.5f);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range40 = dateAxis36.getRange();
        dateAxis36.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets43.trimHeight((double) (byte) -1);
        double double47 = rectangleInsets43.trimWidth(0.0d);
        dateAxis36.setTickLabelInsets(rectangleInsets43);
        double double49 = rectangleInsets43.getRight();
        categoryPlot14.setAxisOffset(rectangleInsets43);
        int int51 = categoryPlot14.getWeight();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        numberAxis53.setTickMarkPaint((java.awt.Paint) color54);
        double double56 = numberAxis53.getFixedDimension();
        java.awt.Paint paint57 = numberAxis53.getLabelPaint();
        categoryPlot14.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis53, false);
        categoryPlot14.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-9.0d) + "'", double45 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + (-16.0d) + "'", double47 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("hi!");
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        boolean boolean5 = projectInfo0.equals((java.lang.Object) rectangleInsets4);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getRange();
        double double6 = range5.getCentralValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!");
        textLine1.removeFragment(textFragment3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        textLine1.draw(graphics2D5, (float) 0L, (float) 100, textAnchor8, (float) (short) 10, 0.5f, 0.0d);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        java.lang.String str10 = piePlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        categoryPlot14.setOutlineVisible(true);
        categoryPlot14.clearRangeMarkers(2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot14.zoomRangeAxes((double) 10.0f, plotRenderingInfo40, point2D41, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        blockContainer11.clear();
        double double13 = blockContainer11.getContentXOffset();
        java.lang.String str14 = blockContainer11.getID();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat9 = dateAxis5.getDateFormatOverride();
        dateAxis5.setLabelToolTip("");
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMaximumDate(date12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        dateAxis5.resizeRange(0.025d, (double) 0.0f);
        boolean boolean20 = dateAxis5.isHiddenValue((long) (short) 1);
        boolean boolean21 = xYPlot0.equals((java.lang.Object) boolean20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot0.getRangeMarkers(layer22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot0.setDataset(xYDataset24);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot0.getRangeMarkers(layer26);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        dateAxis1.setUpperMargin((double) '4');
        float float12 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat9 = dateAxis5.getDateFormatOverride();
        dateAxis5.setLabelToolTip("");
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMaximumDate(date12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        java.lang.Object obj16 = categoryAxis3.clone();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean20 = dateAxis19.isAxisLineVisible();
        dateAxis19.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font23 = dateAxis19.getTickLabelFont();
        categoryAxis3.setTickLabelFont((java.lang.Comparable) (-9.0d), font23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot26.getFixedDomainAxisSpace();
        xYPlot26.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot26.getDomainAxisLocation();
        int int31 = xYPlot26.getRangeAxisCount();
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        xYPlot25.setQuadrantOrigin(point2D32);
        org.jfree.chart.plot.Plot plot34 = xYPlot25.getParent();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", font23, (org.jfree.chart.plot.Plot) xYPlot25, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNull(plot34);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("ClassContext", font9, paint10);
        paintMap0.put((java.lang.Comparable) '#', paint10);
        java.awt.Color color15 = java.awt.Color.BLACK;
        java.awt.Color color16 = java.awt.Color.getColor("", color15);
        paintMap0.put((java.lang.Comparable) '#', (java.awt.Paint) color15);
        paintMap0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.String str1 = standardPieSectionLabelGenerator0.getLabelFormat();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        textTitle10.setExpandToFitSpace(false);
        java.awt.Font font14 = textTitle10.getFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range25 = dateAxis21.getRange();
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(45.0d, range25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint18.toRangeHeight(range25);
        try {
            org.jfree.chart.util.Size2D size2D31 = textTitle10.arrange(graphics2D15, rectangleConstraint30);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer25);
        dateAxis21.setTickMarkInsideLength((float) 0L);
        boolean boolean29 = dateAxis21.isAutoTickUnitSelection();
        categoryPlot14.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis21, false);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat40 = dateAxis36.getDateFormatOverride();
        dateAxis36.setLabelToolTip("");
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis36.setMaximumDate(date43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer45);
        java.util.List list47 = categoryPlot46.getCategories();
        org.jfree.chart.util.SortOrder sortOrder48 = categoryPlot46.getColumnRenderingOrder();
        categoryPlot14.setRowRenderingOrder(sortOrder48);
        boolean boolean50 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean57 = dateAxis56.isAxisLineVisible();
        dateAxis56.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) dateAxis56, polarItemRenderer60);
        org.jfree.chart.event.PlotChangeListener plotChangeListener62 = null;
        polarPlot61.addChangeListener(plotChangeListener62);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier64 = polarPlot61.getDrawingSupplier();
        java.awt.Color color65 = java.awt.Color.PINK;
        polarPlot61.setNoDataMessagePaint((java.awt.Paint) color65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace71 = xYPlot70.getFixedDomainAxisSpace();
        xYPlot70.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation74 = xYPlot70.getDomainAxisLocation();
        int int75 = xYPlot70.getRangeAxisCount();
        java.awt.geom.Point2D point2D76 = xYPlot70.getQuadrantOrigin();
        xYPlot69.setQuadrantOrigin(point2D76);
        polarPlot61.zoomDomainAxes(0.0d, plotRenderingInfo68, point2D76);
        categoryPlot14.zoomRangeAxes(0.12d, plotRenderingInfo53, point2D76, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(dateFormat40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(list47);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(categoryAnchor51);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(drawingSupplier64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNull(axisSpace71);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(point2D76);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartEntity: tooltip = (C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean11 = textBlock7.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat18 = dateAxis14.getDateFormatOverride();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis14.setTickLabelFont(font19);
        java.awt.Color color21 = java.awt.Color.red;
        textBlock7.addLine("", font19, (java.awt.Paint) color21);
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        double double24 = piePlot3D23.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("hi!", font19, (org.jfree.chart.plot.Plot) piePlot3D23, false);
        boolean boolean27 = jFreeChart26.isNotify();
        int int28 = jFreeChart26.getBackgroundImageAlignment();
        boolean boolean29 = textFragment2.equals((java.lang.Object) int28);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(dateFormat18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.12d + "'", double24 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        categoryPlot14.mapDatasetToRangeAxis((int) (byte) 0, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot14.getDataset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot14.setRenderer(categoryItemRenderer25, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(categoryDataset24);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint10 = dateAxis6.getTickMarkPaint();
        xYPlot0.setDomainGridlinePaint(paint10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot0.rendererChanged(rendererChangeEvent12);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean21 = dateAxis20.isAxisLineVisible();
        dateAxis20.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, polarItemRenderer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        polarPlot25.addChangeListener(plotChangeListener26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = polarPlot25.getDrawingSupplier();
        java.awt.Color color29 = java.awt.Color.PINK;
        polarPlot25.setNoDataMessagePaint((java.awt.Paint) color29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot34.getFixedDomainAxisSpace();
        xYPlot34.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot34.getDomainAxisLocation();
        int int39 = xYPlot34.getRangeAxisCount();
        java.awt.geom.Point2D point2D40 = xYPlot34.getQuadrantOrigin();
        xYPlot33.setQuadrantOrigin(point2D40);
        polarPlot25.zoomDomainAxes(0.0d, plotRenderingInfo32, point2D40);
        xYPlot0.zoomRangeAxes((-9.0d), 36.0d, plotRenderingInfo17, point2D40);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation44 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(point2D40);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        dateAxis4.setLabelAngle((double) (short) -1);
        boolean boolean7 = dateAxis4.isInverted();
        boolean boolean8 = multiplePiePlot1.equals((java.lang.Object) boolean7);
        java.awt.Paint paint9 = multiplePiePlot1.getAggregatedItemsPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getRange();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setIgnoreNullValues(false);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) '#', paint11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean17 = textBlockAnchor15.equals((java.lang.Object) horizontalAlignment16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment18, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14, (org.jfree.chart.block.Arrangement) flowArrangement21, arrangement22);
        legendTitle23.setWidth(1.0d);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D30 = legendTitle23.arrange(graphics2D26, rectangleConstraint29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, 100.0d, (double) (byte) -1, rectangleAnchor33);
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D();
        double double36 = piePlot3D35.getDepthFactor();
        double double37 = piePlot3D35.getMaximumExplodePercent();
        boolean boolean38 = piePlot3D35.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.PiePlotState piePlotState41 = piePlot7.initialise(graphics2D13, rectangle2D34, (org.jfree.chart.plot.PiePlot) piePlot3D35, (java.lang.Integer) 100, plotRenderingInfo40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis0.lengthToJava2D((double) 10, rectangle2D34, rectangleEdge42);
        boolean boolean44 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.12d + "'", double36 == 0.12d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(piePlotState41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        jFreeChart23.clearSubtitles();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setDownArrow(shape10);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape10, "hi!", "");
        chartEntity14.setURLText("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPlotOrientation.VERTICAL");
        java.lang.Object obj17 = chartEntity14.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 10, (double) 100);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, 1.0E-8d);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean12 = textBlockAnchor10.equals((java.lang.Object) horizontalAlignment11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment13, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9, (org.jfree.chart.block.Arrangement) flowArrangement16, arrangement17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle18.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer20 = legendTitle18.getItemContainer();
        blockContainer20.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockContainer20.getMargin();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint26.toFixedWidth(1.0E-5d);
        java.lang.String str29 = rectangleConstraint28.toString();
        org.jfree.chart.util.Size2D size2D30 = columnArrangement8.arrange(blockContainer20, graphics2D23, rectangleConstraint28);
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        blockContainer31.setMargin((double) (byte) 100, (double) (-1.0f), (double) 10L, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(blockContainer20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0E-5, height=100.0]" + "'", str29.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0E-5, height=100.0]"));
        org.junit.Assert.assertNotNull(size2D30);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[] doubleArray3 = new double[] { 8.0d };
        double[] doubleArray5 = new double[] { 8.0d };
        double[] doubleArray7 = new double[] { 8.0d };
        double[] doubleArray9 = new double[] { 8.0d };
        double[] doubleArray11 = new double[] { 8.0d };
        double[][] doubleArray12 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Other", "UnitType.ABSOLUTE", doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray14);
        multiplePiePlot1.setDataset(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) 100.0f);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat9 = dateAxis5.getDateFormatOverride();
        dateAxis5.setLabelToolTip("");
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMaximumDate(date12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        dateAxis5.resizeRange(0.025d, (double) 0.0f);
        boolean boolean20 = dateAxis5.isHiddenValue((long) (short) 1);
        boolean boolean21 = xYPlot0.equals((java.lang.Object) boolean20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot0.getRangeMarkers(layer22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        int int25 = xYPlot0.getIndexOf(xYItemRenderer24);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        jFreeChart23.clearSubtitles();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean31 = dateAxis30.isAxisLineVisible();
        dateAxis30.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font34 = dateAxis30.getTickLabelFont();
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ClassContext", font34, paint35);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font34);
        java.lang.Object obj38 = textTitle37.clone();
        jFreeChart23.removeSubtitle((org.jfree.chart.title.Title) textTitle37);
        try {
            org.jfree.chart.plot.XYPlot xYPlot40 = jFreeChart23.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot3D cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint28 = jFreeChart24.getBorderPaint();
        jFreeChart24.setBackgroundImageAlignment((-1));
        org.jfree.chart.plot.Plot plot31 = jFreeChart24.getPlot();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(plot31);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.Object obj17 = categoryAxis4.clone();
        java.awt.Font font20 = null;
        java.awt.Paint paint21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, paint21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean26 = textBlock22.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean30 = dateAxis29.isAxisLineVisible();
        dateAxis29.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat33 = dateAxis29.getDateFormatOverride();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis29.setTickLabelFont(font34);
        java.awt.Color color36 = java.awt.Color.red;
        textBlock22.addLine("", font34, (java.awt.Paint) color36);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) piePlot3D38, false);
        boolean boolean42 = jFreeChart41.isNotify();
        float float43 = jFreeChart41.getBackgroundImageAlpha();
        java.awt.Color color44 = java.awt.Color.PINK;
        jFreeChart41.setBorderPaint((java.awt.Paint) color44);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis4, jFreeChart41, chartChangeEventType46);
        int int48 = categoryPlot0.getDomainAxisIndex(categoryAxis4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot0.setRenderer((int) '#', categoryItemRenderer50, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.Marker marker55 = null;
        org.jfree.chart.util.Layer layer56 = null;
        try {
            boolean boolean57 = categoryPlot0.removeDomainMarker((int) (byte) 100, marker55, layer56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(dateFormat33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation53);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace7, false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.Plot plot14 = polarPlot7.getRootPlot();
        java.lang.Object obj15 = polarPlot7.clone();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        piePlot16.setIgnoreNullValues(false);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot16.setSectionOutlinePaint((java.lang.Comparable) '#', paint20);
        polarPlot7.setNoDataMessagePaint(paint20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean5 = textBlockAnchor3.equals((java.lang.Object) horizontalAlignment4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment6, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement9, arrangement10);
        legendTitle11.setWidth(1.0d);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D18 = legendTitle11.arrange(graphics2D14, rectangleConstraint17);
        boolean boolean19 = ringPlot1.equals((java.lang.Object) graphics2D14);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean23 = dateAxis22.isAxisLineVisible();
        dateAxis22.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, polarItemRenderer26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        polarPlot27.addChangeListener(plotChangeListener28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = polarPlot27.getDrawingSupplier();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        polarPlot27.setRenderer(polarItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        polarPlot27.zoomRangeAxes((double) (short) 1, plotRenderingInfo34, point2D35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        polarPlot27.drawBackgroundImage(graphics2D37, rectangle2D38);
        int int40 = polarPlot27.getSeriesCount();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        polarPlot27.setDataset(xYDataset41);
        boolean boolean43 = ringPlot1.equals((java.lang.Object) polarPlot27);
        ringPlot1.setCircular(false);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace23);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 10);
        java.awt.Shape shape8 = dateAxis1.getRightArrow();
        boolean boolean9 = dateAxis1.isInverted();
        double double10 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot14.setDataset((int) (byte) 0, categoryDataset17);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = categoryPlot14.removeDomainMarker(marker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color1);
        double double3 = numberAxis0.getFixedDimension();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        float float5 = numberAxis0.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(numberTickUnit6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer25);
        dateAxis21.setTickMarkInsideLength((float) 0L);
        boolean boolean29 = dateAxis21.isAutoTickUnitSelection();
        categoryPlot14.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis21, false);
        categoryPlot14.setDrawSharedDomainAxis(false);
        categoryPlot14.mapDatasetToDomainAxis(0, 0);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot14.getRangeAxisForDataset((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(valueAxis38);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        dateAxis2.setLabelAngle((double) (short) -1);
        double double5 = dateAxis2.getLabelAngle();
        java.awt.Font font6 = dateAxis2.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!", font6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 15);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        int int20 = categoryPlot14.getDomainAxisCount();
        categoryPlot14.mapDatasetToRangeAxis((int) (byte) 0, (int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot14.getDomainAxisForDataset((int) '#');
        java.awt.Stroke stroke26 = categoryPlot14.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(categoryAxis25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot1.getFixedDomainAxisSpace();
        xYPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot1.getDomainAxisLocation();
        int int6 = xYPlot1.getRangeAxisCount();
        java.awt.geom.Point2D point2D7 = xYPlot1.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D7);
        java.awt.geom.Point2D point2D9 = xYPlot0.getQuadrantOrigin();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNotNull(point2D10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        double double4 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean38 = dateAxis37.isAxisLineVisible();
        dateAxis37.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font41 = dateAxis37.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean46 = textBlockAnchor44.equals((java.lang.Object) horizontalAlignment45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment45, verticalAlignment47, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot43, (org.jfree.chart.block.Arrangement) flowArrangement50, arrangement51);
        legendTitle52.setWidth(1.0d);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D59 = legendTitle52.arrange(graphics2D55, rectangleConstraint58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 100.0d, (double) (byte) -1, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets42.createInsetRectangle(rectangle2D63);
        dateAxis37.setDownArrow((java.awt.Shape) rectangle2D64);
        categoryPlot14.drawBackgroundImage(graphics2D35, rectangle2D64);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot14.getRangeAxisEdge(10);
        org.jfree.chart.plot.Marker marker69 = null;
        try {
            boolean boolean70 = categoryPlot14.removeDomainMarker(marker69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.lang.Object obj2 = piePlot3D0.clone();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1.0d, paint4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        piePlot3D0.setLabelBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = piePlot3D0.getOutlineStroke();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = null;
        try {
            piePlot3D0.setLabelDistributor(abstractPieLabelDistributor10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean24 = dateAxis23.isAxisLineVisible();
        dateAxis23.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font27 = dateAxis23.getTickLabelFont();
        java.awt.Paint paint28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("ClassContext", font27, paint28);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font27);
        java.lang.Object obj31 = textTitle30.clone();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean35 = dateAxis34.isAxisLineVisible();
        dateAxis34.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis34, polarItemRenderer38);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        polarPlot39.addChangeListener(plotChangeListener40);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier42 = polarPlot39.getDrawingSupplier();
        java.awt.Color color43 = java.awt.Color.PINK;
        polarPlot39.setNoDataMessagePaint((java.awt.Paint) color43);
        textTitle30.setPaint((java.awt.Paint) color43);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle30.setPaint((java.awt.Paint) color46);
        org.jfree.chart.text.TextMeasurer textMeasurer49 = null;
        org.jfree.chart.text.TextBlock textBlock50 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color46, (float) 10L, textMeasurer49);
        java.awt.Font font52 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_GREEN;
        textBlock50.addLine("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font52, (java.awt.Paint) color53);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(drawingSupplier42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(textBlock50);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        double double35 = piePlotState34.getLatestAngle();
        piePlotState34.setTotal(0.025d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 90.0d + "'", double35 == 90.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        java.awt.Paint paint8 = xYPlot0.getDomainCrosshairPaint();
        java.lang.String str9 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "XY Plot" + "'", str9.equals("XY Plot"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        xYPlot0.rendererChanged(rendererChangeEvent3);
        xYPlot0.clearAnnotations();
        boolean boolean6 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean12 = textBlockAnchor10.equals((java.lang.Object) horizontalAlignment11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment13, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9, (org.jfree.chart.block.Arrangement) flowArrangement16, arrangement17);
        legendTitle18.setWidth(1.0d);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D25 = legendTitle18.arrange(graphics2D21, rectangleConstraint24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, 100.0d, (double) (byte) -1, rectangleAnchor28);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets8.createInsetRectangle(rectangle2D29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        xYPlot0.drawAnnotations(graphics2D7, rectangle2D30, plotRenderingInfo31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, 0.12d, 32.0d, (-1.0d));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean9 = textBlockAnchor7.equals((java.lang.Object) horizontalAlignment8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment10, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6, (org.jfree.chart.block.Arrangement) flowArrangement13, arrangement14);
        legendTitle15.setWidth(1.0d);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D22 = legendTitle15.arrange(graphics2D18, rectangleConstraint21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, 100.0d, (double) (byte) -1, rectangleAnchor25);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets5.createInsetRectangle(rectangle2D26);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets4.createInsetRectangle(rectangle2D26, false, false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range16 = dateAxis12.getRange();
        org.jfree.data.Range range19 = org.jfree.data.Range.expand(range16, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(45.0d, range16);
        boolean boolean21 = dateAxis1.equals((java.lang.Object) 45.0d);
        java.awt.Stroke stroke22 = dateAxis1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Color color2 = java.awt.Color.orange;
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color2);
        java.lang.Comparable comparable4 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelToolTip("");
        dateAxis1.setAutoTickUnitSelection(false);
        float float10 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint17 = dateAxis13.getTickMarkPaint();
        boolean boolean18 = basicProjectInfo11.equals((java.lang.Object) dateAxis13);
        dateAxis13.resizeRange((double) (byte) 10, (double) 15);
        java.util.Date date22 = dateAxis13.getMaximumDate();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        piePlot23.setIgnoreNullValues(false);
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot23.setSectionOutlinePaint((java.lang.Comparable) '#', paint27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean33 = textBlockAnchor31.equals((java.lang.Object) horizontalAlignment32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment32, verticalAlignment34, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot30, (org.jfree.chart.block.Arrangement) flowArrangement37, arrangement38);
        legendTitle39.setWidth(1.0d);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D46 = legendTitle39.arrange(graphics2D42, rectangleConstraint45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, 100.0d, (double) (byte) -1, rectangleAnchor49);
        org.jfree.chart.plot.PiePlot3D piePlot3D51 = new org.jfree.chart.plot.PiePlot3D();
        double double52 = piePlot3D51.getDepthFactor();
        double double53 = piePlot3D51.getMaximumExplodePercent();
        boolean boolean54 = piePlot3D51.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.PiePlotState piePlotState57 = piePlot23.initialise(graphics2D29, rectangle2D50, (org.jfree.chart.plot.PiePlot) piePlot3D51, (java.lang.Integer) 100, plotRenderingInfo56);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean63 = dateAxis62.isAxisLineVisible();
        dateAxis62.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat66 = dateAxis62.getDateFormatOverride();
        dateAxis62.setLabelToolTip("");
        java.util.Date date69 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis62.setMaximumDate(date69);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis60, (org.jfree.chart.axis.ValueAxis) dateAxis62, categoryItemRenderer71);
        java.util.List list73 = categoryPlot72.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = categoryPlot72.getRenderer((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean80 = dateAxis79.isAxisLineVisible();
        dateAxis79.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer83 = null;
        org.jfree.chart.plot.PolarPlot polarPlot84 = new org.jfree.chart.plot.PolarPlot(xYDataset77, (org.jfree.chart.axis.ValueAxis) dateAxis79, polarItemRenderer83);
        dateAxis79.setTickMarkInsideLength((float) 0L);
        boolean boolean87 = dateAxis79.isAutoTickUnitSelection();
        categoryPlot72.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis79, false);
        categoryPlot72.setDrawSharedDomainAxis(false);
        categoryPlot72.mapDatasetToDomainAxis((int) '4', (int) (byte) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge96 = categoryPlot72.getRangeAxisEdge((int) (short) 1);
        double double97 = dateAxis1.dateToJava2D(date22, rectangle2D50, rectangleEdge96);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.12d + "'", double52 == 0.12d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(piePlotState57);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(dateFormat66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNull(list73);
        org.junit.Assert.assertNull(categoryItemRenderer75);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(rectangleEdge96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + (-1.0d) + "'", double97 == (-1.0d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Polar Plot");
        categoryAxis3D1.setCategoryMargin(0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = java.awt.Color.magenta;
        java.awt.Color color4 = java.awt.Color.getColor("ClassContext", 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        float[] floatArray7 = null;
        float[] floatArray8 = color4.getColorComponents(colorSpace6, floatArray7);
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        float[] floatArray18 = new float[] { (byte) 10, 255, 255, 0L, 10.0f, 15 };
        float[] floatArray19 = color9.getColorComponents(colorSpace11, floatArray18);
        float[] floatArray20 = color1.getComponents(colorSpace6, floatArray19);
        float[] floatArray21 = color0.getColorComponents(floatArray20);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("PlotOrientation.VERTICAL", font16);
        java.lang.String str21 = textTitle20.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle20.getMargin();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.lang.String str28 = chartProgressEvent27.toString();
        org.jfree.chart.JFreeChart jFreeChart29 = chartProgressEvent27.getChart();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean34 = dateAxis33.isAxisLineVisible();
        dateAxis33.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font37 = dateAxis33.getTickLabelFont();
        java.awt.Paint paint38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("ClassContext", font37, paint38);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font37);
        java.lang.Object obj41 = textTitle40.clone();
        textTitle40.setExpandToFitSpace(false);
        java.awt.Font font44 = textTitle40.getFont();
        jFreeChart29.setTitle(textTitle40);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1]" + "'", str28.equals("org.jfree.chart.event.ChartProgressEvent[source=-1]"));
        org.junit.Assert.assertNotNull(jFreeChart29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double3 = piePlot3D0.getExplodePercent((java.lang.Comparable) (-1L));
        java.awt.Stroke stroke4 = piePlot3D0.getOutlineStroke();
        try {
            piePlot3D0.setInteriorGap((double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range40 = dateAxis36.getRange();
        dateAxis36.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets43.trimHeight((double) (byte) -1);
        double double47 = rectangleInsets43.trimWidth(0.0d);
        dateAxis36.setTickLabelInsets(rectangleInsets43);
        double double49 = rectangleInsets43.getRight();
        categoryPlot14.setAxisOffset(rectangleInsets43);
        int int51 = categoryPlot14.getWeight();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent52 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray55 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer54 };
        categoryPlot14.setRenderers(categoryItemRendererArray55);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-9.0d) + "'", double45 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + (-16.0d) + "'", double47 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray55);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        dateAxis13.setLabelToolTip("");
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis13.setMaximumDate(date20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        java.lang.Object obj24 = categoryAxis11.clone();
        java.awt.Font font27 = null;
        java.awt.Paint paint28 = null;
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, paint28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean33 = textBlock29.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean37 = dateAxis36.isAxisLineVisible();
        dateAxis36.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat40 = dateAxis36.getDateFormatOverride();
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis36.setTickLabelFont(font41);
        java.awt.Color color43 = java.awt.Color.red;
        textBlock29.addLine("", font41, (java.awt.Paint) color43);
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D();
        double double46 = piePlot3D45.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("hi!", font41, (org.jfree.chart.plot.Plot) piePlot3D45, false);
        boolean boolean49 = jFreeChart48.isNotify();
        float float50 = jFreeChart48.getBackgroundImageAlpha();
        java.awt.Color color51 = java.awt.Color.PINK;
        jFreeChart48.setBorderPaint((java.awt.Paint) color51);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType53 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis11, jFreeChart48, chartChangeEventType53);
        int int55 = categoryPlot7.getDomainAxisIndex(categoryAxis11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        categoryPlot7.setRenderer((int) '#', categoryItemRenderer57, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = categoryPlot7.getOrientation();
        xYPlot0.setOrientation(plotOrientation60);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(textBlock29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(dateFormat40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.12d + "'", double46 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.5f + "'", float50 == 0.5f);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(chartChangeEventType53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation60);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        java.util.TimeZone timeZone10 = dateAxis1.getTimeZone();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat17 = dateAxis13.getDateFormatOverride();
        java.text.DateFormat dateFormat18 = null;
        dateAxis13.setDateFormatOverride(dateFormat18);
        dateAxis13.setAutoRangeMinimumSize((double) (byte) 100);
        java.util.Date date22 = dateAxis13.getMaximumDate();
        try {
            dateAxis1.setRange(date11, date22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ClassContext", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setLabelAngle((double) (short) -1);
        boolean boolean39 = dateAxis36.isInverted();
        java.awt.Shape shape40 = dateAxis36.getDownArrow();
        piePlot0.setLegendItemShape(shape40);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape40);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot14.getRenderer((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean22 = dateAxis21.isAxisLineVisible();
        dateAxis21.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer25);
        dateAxis21.setTickMarkInsideLength((float) 0L);
        boolean boolean29 = dateAxis21.isAutoTickUnitSelection();
        categoryPlot14.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis21, false);
        categoryPlot14.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        polarPlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = polarPlot19.getDrawingSupplier();
        java.awt.Color color23 = java.awt.Color.PINK;
        polarPlot19.setNoDataMessagePaint((java.awt.Paint) color23);
        textTitle10.setPaint((java.awt.Paint) color23);
        textTitle10.setID("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        java.lang.Object obj28 = null;
        boolean boolean29 = textTitle10.equals(obj28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = polarPlot7.getRadiusGridlinePaint();
        boolean boolean11 = polarPlot7.isAngleLabelsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = polarPlot7.getLegendItems();
        int int13 = polarPlot7.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.Plot plot14 = polarPlot7.getRootPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        polarPlot7.setRenderer(polarItemRenderer15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = polarPlot7.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(plotOrientation17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart23.getLegend();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNull(legendTitle26);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset13, false);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset13);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        java.awt.Paint paint8 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYPlot0.setBackgroundPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.awt.Font font2 = textFragment1.getFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getLegendItems();
        xYPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        java.lang.String str3 = waferMapPlot0.getNoDataMessage();
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot0.setDataset(waferMapDataset4);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        polarPlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = polarPlot19.getDrawingSupplier();
        java.awt.Color color23 = java.awt.Color.PINK;
        polarPlot19.setNoDataMessagePaint((java.awt.Paint) color23);
        textTitle10.setPaint((java.awt.Paint) color23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle10.setPaint((java.awt.Paint) color26);
        java.awt.Font font28 = textTitle10.getFont();
        textTitle10.setMargin((double) (-1.0f), 100.0d, (double) (short) 10, (double) 8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        polarPlot7.addCornerTextItem("");
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        polarPlot7.zoomDomainAxes((double) 0.5f, 32.0d, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot7.getAxis();
        java.lang.String str20 = valueAxis19.getLabel();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = numberAxis21.getStandardTickUnits();
        valueAxis19.setStandardTickUnits(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(tickUnitSource22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot1.getBaseSectionPaint();
        java.awt.Stroke stroke4 = ringPlot1.getSeparatorStroke();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = java.awt.Color.orange;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelToolTip("");
        dateAxis1.setAutoTickUnitSelection(false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean16 = dateAxis15.isAxisLineVisible();
        dateAxis15.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font19 = dateAxis15.getTickLabelFont();
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("ClassContext", font19, paint20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font19);
        java.lang.Object obj23 = textTitle22.clone();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean27 = dateAxis26.isAxisLineVisible();
        dateAxis26.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        polarPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = polarPlot31.getDrawingSupplier();
        java.awt.Color color35 = java.awt.Color.PINK;
        polarPlot31.setNoDataMessagePaint((java.awt.Paint) color35);
        textTitle22.setPaint((java.awt.Paint) color35);
        textTitle22.setID("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        xYPlot40.datasetChanged(datasetChangeEvent41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement48 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment45, (double) (byte) 10, (double) 100);
        org.jfree.chart.block.Block block49 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor52 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment53 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean54 = textBlockAnchor52.equals((java.lang.Object) horizontalAlignment53);
        org.jfree.chart.util.VerticalAlignment verticalAlignment55 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement58 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment53, verticalAlignment55, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement59 = null;
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot51, (org.jfree.chart.block.Arrangement) flowArrangement58, arrangement59);
        legendTitle60.setWidth(1.0d);
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D67 = legendTitle60.arrange(graphics2D63, rectangleConstraint66);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D71 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D67, 100.0d, (double) (byte) -1, rectangleAnchor70);
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets50.createInsetRectangle(rectangle2D71);
        columnArrangement48.add(block49, (java.lang.Object) rectangle2D72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        xYPlot40.drawAnnotations(graphics2D43, rectangle2D72, plotRenderingInfo74);
        textTitle22.setBounds(rectangle2D72);
        dateAxis1.setUpArrow((java.awt.Shape) rectangle2D72);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(textBlockAnchor52);
        org.junit.Assert.assertNotNull(horizontalAlignment53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(verticalAlignment55);
        org.junit.Assert.assertNotNull(size2D67);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(rectangle2D72);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean18 = dateAxis17.isAxisLineVisible();
        dateAxis17.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range21 = dateAxis17.getRange();
        org.jfree.data.Range range24 = org.jfree.data.Range.expand(range21, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(45.0d, range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint14.toRangeHeight(range21);
        org.jfree.data.Range range27 = rectangleConstraint14.getWidthRange();
        org.jfree.chart.util.Size2D size2D28 = legendTitle9.arrange(graphics2D11, rectangleConstraint14);
        double double29 = size2D28.getHeight();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        boolean boolean25 = jFreeChart24.isNotify();
        int int26 = jFreeChart24.getBackgroundImageAlignment();
        jFreeChart24.clearSubtitles();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        double double31 = piePlot3D28.getMaximumExplodePercent();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D28.setLabelLinkStroke(stroke32);
        jFreeChart24.setBorderStroke(stroke32);
        org.jfree.chart.plot.Plot plot35 = jFreeChart24.getPlot();
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean39 = textBlockAnchor37.equals((java.lang.Object) horizontalAlignment38);
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement43 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment38, verticalAlignment40, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot36, (org.jfree.chart.block.Arrangement) flowArrangement43, arrangement44);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent46 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle45);
        org.jfree.chart.title.Title title47 = titleChangeEvent46.getTitle();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType48 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        titleChangeEvent46.setType(chartChangeEventType48);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart24, chartChangeEventType48);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(plot35);
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertNotNull(title47);
        org.junit.Assert.assertNotNull(chartChangeEventType48);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle9.setHorizontalAlignment(horizontalAlignment10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean14 = dateAxis13.isAxisLineVisible();
        dateAxis13.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint17 = dateAxis13.getTickMarkPaint();
        boolean boolean18 = legendTitle9.equals((java.lang.Object) dateAxis13);
        dateAxis13.setRangeAboutValue((double) (short) 0, 52.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getLegendItems();
        java.awt.Paint paint8 = xYPlot0.getDomainGridlinePaint();
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double6 = rectangleInsets4.trimHeight((double) (byte) -1);
        double double7 = rectangleInsets4.getTop();
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint9 = piePlot3D8.getLabelLinkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat18 = dateAxis14.getDateFormatOverride();
        dateAxis14.setLabelToolTip("");
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis14.setMaximumDate(date21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer23);
        java.util.List list25 = categoryPlot24.getCategories();
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot24.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot27.getFixedDomainAxisSpace();
        xYPlot27.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot27.getDomainAxisLocation();
        int int32 = xYPlot27.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke34 = piePlot3D33.getLabelOutlineStroke();
        piePlot3D33.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke38 = piePlot3D37.getLabelOutlineStroke();
        java.awt.Stroke stroke40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D37.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke40);
        piePlot3D33.setBaseSectionOutlineStroke(stroke40);
        xYPlot27.setRangeGridlineStroke(stroke40);
        categoryPlot24.setRangeGridlineStroke(stroke40);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean48 = dateAxis47.isAxisLineVisible();
        dateAxis47.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font51 = dateAxis47.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor54 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean56 = textBlockAnchor54.equals((java.lang.Object) horizontalAlignment55);
        org.jfree.chart.util.VerticalAlignment verticalAlignment57 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement60 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment55, verticalAlignment57, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot53, (org.jfree.chart.block.Arrangement) flowArrangement60, arrangement61);
        legendTitle62.setWidth(1.0d);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D69 = legendTitle62.arrange(graphics2D65, rectangleConstraint68);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D73 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D69, 100.0d, (double) (byte) -1, rectangleAnchor72);
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets52.createInsetRectangle(rectangle2D73);
        dateAxis47.setDownArrow((java.awt.Shape) rectangle2D74);
        categoryPlot24.drawBackgroundImage(graphics2D45, rectangle2D74);
        piePlot3D8.setLegendItemShape((java.awt.Shape) rectangle2D74);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = rectangleInsets4.createAdjustedRectangle(rectangle2D74, lengthAdjustmentType78, lengthAdjustmentType79);
        try {
            piePlot0.drawBackground(graphics2D3, rectangle2D80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-9.0d) + "'", double6 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(dateFormat18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(textBlockAnchor54);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(verticalAlignment57);
        org.junit.Assert.assertNotNull(size2D69);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        java.util.List list7 = xYPlot0.getAnnotations();
        java.util.Collection collection8 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list7);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot6.getFixedDomainAxisSpace();
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot6.getDomainAxisLocation();
        int int11 = xYPlot6.getRangeAxisCount();
        java.awt.geom.Point2D point2D12 = xYPlot6.getQuadrantOrigin();
        xYPlot5.setQuadrantOrigin(point2D12);
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo4, point2D12, false);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        jFreeChart23.clearSubtitles();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean31 = dateAxis30.isAxisLineVisible();
        dateAxis30.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font34 = dateAxis30.getTickLabelFont();
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ClassContext", font34, paint35);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font34);
        java.lang.Object obj38 = textTitle37.clone();
        jFreeChart23.removeSubtitle((org.jfree.chart.title.Title) textTitle37);
        java.awt.Font font40 = null;
        try {
            textTitle37.setFont(font40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYPlot0.getLegendItems();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            boolean boolean9 = xYPlot0.removeRangeMarker(marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = polarPlot7.getRadiusGridlinePaint();
        boolean boolean11 = polarPlot7.isAngleLabelsVisible();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot13.getFixedDomainAxisSpace();
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation();
        int int18 = xYPlot13.getRangeAxisCount();
        java.awt.geom.Point2D point2D19 = xYPlot13.getQuadrantOrigin();
        xYPlot12.setQuadrantOrigin(point2D19);
        java.awt.geom.Point2D point2D21 = xYPlot12.getQuadrantOrigin();
        java.awt.geom.Point2D point2D22 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean26 = dateAxis25.isAxisLineVisible();
        dateAxis25.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat29 = dateAxis25.getDateFormatOverride();
        java.text.DateFormat dateFormat30 = null;
        dateAxis25.setDateFormatOverride(dateFormat30);
        dateAxis25.setAutoRangeMinimumSize((double) (byte) 100);
        java.util.Date date34 = dateAxis25.getMaximumDate();
        dateAxis25.setAutoRange(true);
        xYPlot12.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis25, true);
        java.awt.Color color39 = java.awt.Color.PINK;
        xYPlot12.setDomainCrosshairPaint((java.awt.Paint) color39);
        polarPlot7.setRadiusGridlinePaint((java.awt.Paint) color39);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(dateFormat29);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getTransparency();
        java.awt.Color color5 = color3.darker();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setIgnoreNullValues(false);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot9.setSectionOutlinePaint((java.lang.Comparable) '#', paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) horizontalAlignment18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment20, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) flowArrangement23, arrangement24);
        legendTitle25.setWidth(1.0d);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D32 = legendTitle25.arrange(graphics2D28, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 100.0d, (double) (byte) -1, rectangleAnchor35);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        double double38 = piePlot3D37.getDepthFactor();
        double double39 = piePlot3D37.getMaximumExplodePercent();
        boolean boolean40 = piePlot3D37.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = piePlot9.initialise(graphics2D15, rectangle2D36, (org.jfree.chart.plot.PiePlot) piePlot3D37, (java.lang.Integer) 100, plotRenderingInfo42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D36, plotRenderingInfo44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace52 = xYPlot51.getFixedDomainAxisSpace();
        xYPlot51.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot51.getDomainAxisLocation();
        int int56 = xYPlot51.getRangeAxisCount();
        java.awt.geom.Point2D point2D57 = xYPlot51.getQuadrantOrigin();
        xYPlot50.setQuadrantOrigin(point2D57);
        java.awt.geom.Point2D point2D59 = xYPlot50.getQuadrantOrigin();
        java.awt.geom.Point2D point2D60 = xYPlot50.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 100, (double) 128, plotRenderingInfo49, point2D60);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.12d + "'", double38 == 0.12d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(axisSpace52);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(point2D57);
        org.junit.Assert.assertNotNull(point2D59);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setIgnoreNullValues(false);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) '#', paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement14, arrangement15);
        legendTitle16.setWidth(1.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D23 = legendTitle16.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 100.0d, (double) (byte) -1, rectangleAnchor26);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        double double29 = piePlot3D28.getDepthFactor();
        double double30 = piePlot3D28.getMaximumExplodePercent();
        boolean boolean31 = piePlot3D28.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot0.initialise(graphics2D6, rectangle2D27, (org.jfree.chart.plot.PiePlot) piePlot3D28, (java.lang.Integer) 100, plotRenderingInfo33);
        double double35 = piePlot3D28.getDepthFactor();
        java.lang.Object obj36 = piePlot3D28.clone();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.String str38 = standardPieSectionLabelGenerator37.getLabelFormat();
        piePlot3D28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator37);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape41 = defaultDrawingSupplier40.getNextShape();
        piePlot3D28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier40);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        dateAxis44.setLabelAngle((double) (short) -1);
        boolean boolean47 = dateAxis44.isInverted();
        java.awt.Shape shape48 = dateAxis44.getDownArrow();
        java.awt.Paint paint49 = dateAxis44.getAxisLinePaint();
        piePlot3D28.setLabelPaint(paint49);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.12d + "'", double29 == 0.12d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.12d + "'", double35 == 0.12d);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{0}" + "'", str38.equals("{0}"));
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range9 = dateAxis5.getRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(45.0d, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint2.toRangeHeight(range9);
        java.awt.Font font17 = null;
        java.awt.Paint paint18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, paint18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean23 = textBlock19.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean27 = dateAxis26.isAxisLineVisible();
        dateAxis26.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat30 = dateAxis26.getDateFormatOverride();
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis26.setTickLabelFont(font31);
        java.awt.Color color33 = java.awt.Color.red;
        textBlock19.addLine("", font31, (java.awt.Paint) color33);
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D();
        double double36 = piePlot3D35.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("hi!", font31, (org.jfree.chart.plot.Plot) piePlot3D35, false);
        boolean boolean39 = jFreeChart38.isNotify();
        float float40 = jFreeChart38.getBackgroundImageAlpha();
        jFreeChart38.removeLegend();
        int int42 = jFreeChart38.getBackgroundImageAlignment();
        jFreeChart38.setBackgroundImageAlignment(4);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent47 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) rectangleConstraint14, jFreeChart38, (-1), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(dateFormat30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.12d + "'", double36 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.5f + "'", float40 == 0.5f);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("hi!");
        projectInfo0.setLicenceText("PlotOrientation.VERTICAL");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        projectInfo5.setVersion("hi!");
        projectInfo5.setLicenceText("PlotOrientation.VERTICAL");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        projectInfo0.addOptionalLibrary("HorizontalAlignment.CENTER");
        org.jfree.chart.ui.Library[] libraryArray13 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(libraryArray13);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setIgnoreNullValues(false);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot9.setSectionOutlinePaint((java.lang.Comparable) '#', paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) horizontalAlignment18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment20, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) flowArrangement23, arrangement24);
        legendTitle25.setWidth(1.0d);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D32 = legendTitle25.arrange(graphics2D28, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 100.0d, (double) (byte) -1, rectangleAnchor35);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        double double38 = piePlot3D37.getDepthFactor();
        double double39 = piePlot3D37.getMaximumExplodePercent();
        boolean boolean40 = piePlot3D37.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = piePlot9.initialise(graphics2D15, rectangle2D36, (org.jfree.chart.plot.PiePlot) piePlot3D37, (java.lang.Integer) 100, plotRenderingInfo42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D36, plotRenderingInfo44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace47 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.12d + "'", double38 == 0.12d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(axisSpace47);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setIgnoreNullValues(false);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot9.setSectionOutlinePaint((java.lang.Comparable) '#', paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) horizontalAlignment18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment20, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) flowArrangement23, arrangement24);
        legendTitle25.setWidth(1.0d);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D32 = legendTitle25.arrange(graphics2D28, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 100.0d, (double) (byte) -1, rectangleAnchor35);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        double double38 = piePlot3D37.getDepthFactor();
        double double39 = piePlot3D37.getMaximumExplodePercent();
        boolean boolean40 = piePlot3D37.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = piePlot9.initialise(graphics2D15, rectangle2D36, (org.jfree.chart.plot.PiePlot) piePlot3D37, (java.lang.Integer) 100, plotRenderingInfo42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D36, plotRenderingInfo44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace47 = xYPlot0.getFixedDomainAxisSpace();
        int int48 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.Marker marker49 = null;
        try {
            xYPlot0.addDomainMarker(marker49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.12d + "'", double38 == 0.12d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(axisSpace47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.Object obj17 = categoryAxis4.clone();
        java.awt.Font font20 = null;
        java.awt.Paint paint21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, paint21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean26 = textBlock22.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean30 = dateAxis29.isAxisLineVisible();
        dateAxis29.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat33 = dateAxis29.getDateFormatOverride();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis29.setTickLabelFont(font34);
        java.awt.Color color36 = java.awt.Color.red;
        textBlock22.addLine("", font34, (java.awt.Paint) color36);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        double double39 = piePlot3D38.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) piePlot3D38, false);
        boolean boolean42 = jFreeChart41.isNotify();
        float float43 = jFreeChart41.getBackgroundImageAlpha();
        java.awt.Color color44 = java.awt.Color.PINK;
        jFreeChart41.setBorderPaint((java.awt.Paint) color44);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis4, jFreeChart41, chartChangeEventType46);
        int int48 = categoryPlot0.getDomainAxisIndex(categoryAxis4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot0.setRenderer((int) '#', categoryItemRenderer50, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.plot.PolarPlot polarPlot56 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean64 = dateAxis63.isAxisLineVisible();
        dateAxis63.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat67 = dateAxis63.getDateFormatOverride();
        dateAxis63.setLabelToolTip("");
        java.util.Date date70 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis63.setMaximumDate(date70);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis61, (org.jfree.chart.axis.ValueAxis) dateAxis63, categoryItemRenderer72);
        java.util.List list74 = categoryPlot73.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = categoryPlot73.getRenderer((int) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace80 = xYPlot79.getFixedDomainAxisSpace();
        xYPlot79.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation83 = xYPlot79.getDomainAxisLocation();
        int int84 = xYPlot79.getRangeAxisCount();
        java.awt.geom.Point2D point2D85 = xYPlot79.getQuadrantOrigin();
        categoryPlot73.zoomRangeAxes((-16.0d), plotRenderingInfo78, point2D85);
        polarPlot56.zoomDomainAxes((double) (short) -1, plotRenderingInfo58, point2D85);
        categoryPlot0.zoomRangeAxes((double) 'a', plotRenderingInfo55, point2D85, true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(dateFormat33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.12d + "'", double39 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNull(dateFormat67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNull(list74);
        org.junit.Assert.assertNull(categoryItemRenderer76);
        org.junit.Assert.assertNull(axisSpace80);
        org.junit.Assert.assertNotNull(axisLocation83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(point2D85);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke10 = piePlot3D9.getLabelOutlineStroke();
        piePlot3D9.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke14 = piePlot3D13.getLabelOutlineStroke();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D13.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke16);
        piePlot3D9.setBaseSectionOutlineStroke(stroke16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = piePlot3D9.getSimpleLabelOffset();
        java.awt.Paint paint20 = piePlot3D9.getBaseSectionPaint();
        xYPlot0.setRangeCrosshairPaint(paint20);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setTickLabelFont(font6);
        dateAxis1.setAxisLineVisible(true);
        double double10 = dateAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean9 = textBlock5.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat16 = dateAxis12.getDateFormatOverride();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        java.awt.Color color19 = java.awt.Color.red;
        textBlock5.addLine("", font17, (java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        double double22 = piePlot3D21.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) piePlot3D21, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart24, (int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint28 = jFreeChart24.getBorderPaint();
        jFreeChart24.setAntiAlias(false);
        jFreeChart24.setBackgroundImageAlignment((int) (short) 10);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.12d + "'", double22 == 0.12d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        java.awt.Color color26 = java.awt.Color.BLACK;
        jFreeChart23.setBorderPaint((java.awt.Paint) color26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart23.setPadding(rectangleInsets28);
        org.jfree.chart.title.TextTitle textTitle30 = null;
        jFreeChart23.setTitle(textTitle30);
        org.jfree.chart.event.ChartProgressListener chartProgressListener32 = null;
        jFreeChart23.addProgressListener(chartProgressListener32);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double4 = rectangleInsets0.calculateLeftInset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        boolean boolean2 = color0.equals((java.lang.Object) 0.4d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        int int22 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke24 = piePlot3D23.getLabelOutlineStroke();
        piePlot3D23.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke28 = piePlot3D27.getLabelOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke30);
        piePlot3D23.setBaseSectionOutlineStroke(stroke30);
        xYPlot17.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeGridlineStroke(stroke30);
        categoryPlot14.clearRangeMarkers(0);
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        try {
            boolean boolean40 = categoryPlot14.removeDomainMarker((-14745631), marker38, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        polarPlot9.addChangeListener(plotChangeListener10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = polarPlot9.getDrawingSupplier();
        java.awt.Color color13 = java.awt.Color.PINK;
        polarPlot9.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot9, false);
        java.awt.Paint paint17 = jFreeChart16.getBorderPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart16.getPadding();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getBottom();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace23 = xYPlot22.getFixedDomainAxisSpace();
        xYPlot22.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot22.getDomainAxisLocation();
        double double27 = xYPlot22.getRangeCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYPlot22.rendererChanged(rendererChangeEvent28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        piePlot31.setIgnoreNullValues(false);
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot31.setSectionOutlinePaint((java.lang.Comparable) '#', paint35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean41 = textBlockAnchor39.equals((java.lang.Object) horizontalAlignment40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment40, verticalAlignment42, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot38, (org.jfree.chart.block.Arrangement) flowArrangement45, arrangement46);
        legendTitle47.setWidth(1.0d);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D54 = legendTitle47.arrange(graphics2D50, rectangleConstraint53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D54, 100.0d, (double) (byte) -1, rectangleAnchor57);
        org.jfree.chart.plot.PiePlot3D piePlot3D59 = new org.jfree.chart.plot.PiePlot3D();
        double double60 = piePlot3D59.getDepthFactor();
        double double61 = piePlot3D59.getMaximumExplodePercent();
        boolean boolean62 = piePlot3D59.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.plot.PiePlotState piePlotState65 = piePlot31.initialise(graphics2D37, rectangle2D58, (org.jfree.chart.plot.PiePlot) piePlot3D59, (java.lang.Integer) 100, plotRenderingInfo64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        xYPlot22.drawAnnotations(graphics2D30, rectangle2D58, plotRenderingInfo66);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets20.createOutsetRectangle(rectangle2D58);
        try {
            jFreeChart16.draw(graphics2D19, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(size2D54);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.12d + "'", double60 == 0.12d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(piePlotState65);
        org.junit.Assert.assertNotNull(rectangle2D68);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean5 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat8 = dateAxis4.getDateFormatOverride();
        dateAxis4.setLabelToolTip("");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot18.getFixedDomainAxisSpace();
        xYPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot18.getDomainAxisLocation();
        int int23 = xYPlot18.getRangeAxisCount();
        java.awt.geom.Point2D point2D24 = xYPlot18.getQuadrantOrigin();
        categoryPlot14.zoomRangeAxes((double) 1, (double) 10.0f, plotRenderingInfo17, point2D24);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            categoryPlot14.addDomainMarker(categoryMarker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(dateFormat8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets8.trimHeight((double) (byte) -1);
        double double12 = rectangleInsets8.trimWidth(0.0d);
        dateAxis1.setTickLabelInsets(rectangleInsets8);
        double double14 = rectangleInsets8.getTop();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.0d) + "'", double10 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-16.0d) + "'", double12 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = titleChangeEvent10.getType();
        java.lang.String str12 = chartChangeEventType11.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str12.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Polar Plot");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        java.lang.String str4 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle9.setHorizontalAlignment(horizontalAlignment10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 1, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.util.Size2D size2D16 = legendTitle9.arrange(graphics2D12, rectangleConstraint15);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(size2D16);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = xYPlot0.equals((java.lang.Object) stroke9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        xYPlot0.setRangeCrosshairValue(0.4d);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer7);
        dateAxis3.setTickMarkInsideLength((float) 0L);
        boolean boolean11 = dateAxis3.isAutoTickUnitSelection();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer12);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) horizontalAlignment18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment20, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) flowArrangement23, arrangement24);
        legendTitle25.setWidth(1.0d);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D32 = legendTitle25.arrange(graphics2D28, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 100.0d, (double) (byte) -1, rectangleAnchor35);
        java.awt.Point point37 = polarPlot13.translateValueThetaRadiusToJava2D((double) (short) -1, (double) '4', rectangle2D36);
        org.jfree.data.xy.XYDataset xYDataset38 = polarPlot13.getDataset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(point37);
        org.junit.Assert.assertNull(xYDataset38);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        java.lang.Object obj11 = textTitle10.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean15 = dateAxis14.isAxisLineVisible();
        dateAxis14.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        polarPlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = polarPlot19.getDrawingSupplier();
        java.awt.Color color23 = java.awt.Color.PINK;
        polarPlot19.setNoDataMessagePaint((java.awt.Paint) color23);
        textTitle10.setPaint((java.awt.Paint) color23);
        boolean boolean26 = textTitle10.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat9 = dateAxis5.getDateFormatOverride();
        dateAxis5.setLabelToolTip("");
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMaximumDate(date12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        dateAxis5.resizeRange(0.025d, (double) 0.0f);
        boolean boolean20 = dateAxis5.isHiddenValue((long) (short) 1);
        boolean boolean21 = xYPlot0.equals((java.lang.Object) boolean20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean25 = dateAxis24.isAxisLineVisible();
        dateAxis24.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, polarItemRenderer28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        polarPlot29.addChangeListener(plotChangeListener30);
        java.awt.Paint paint32 = polarPlot29.getRadiusGridlinePaint();
        boolean boolean33 = polarPlot29.isAngleLabelsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = polarPlot29.getLegendItems();
        java.awt.Color color35 = java.awt.Color.red;
        boolean boolean36 = legendItemCollection34.equals((java.lang.Object) color35);
        xYPlot0.setFixedLegendItems(legendItemCollection34);
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        try {
            xYPlot0.addRangeMarker(marker38, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset13);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean6 = dateAxis5.isAxisLineVisible();
        dateAxis5.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("ClassContext", font9, paint10);
        paintMap0.put((java.lang.Comparable) '#', paint10);
        paintMap0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.geom.Point2D point2D6 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean24 = dateAxis23.isAxisLineVisible();
        dateAxis23.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font27 = dateAxis23.getTickLabelFont();
        java.awt.Paint paint28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("ClassContext", font27, paint28);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font27);
        java.lang.Object obj31 = textTitle30.clone();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean35 = dateAxis34.isAxisLineVisible();
        dateAxis34.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis34, polarItemRenderer38);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        polarPlot39.addChangeListener(plotChangeListener40);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier42 = polarPlot39.getDrawingSupplier();
        java.awt.Color color43 = java.awt.Color.PINK;
        polarPlot39.setNoDataMessagePaint((java.awt.Paint) color43);
        textTitle30.setPaint((java.awt.Paint) color43);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle30.setPaint((java.awt.Paint) color46);
        org.jfree.chart.text.TextMeasurer textMeasurer49 = null;
        org.jfree.chart.text.TextBlock textBlock50 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color46, (float) 10L, textMeasurer49);
        java.awt.Font font54 = null;
        java.awt.Paint paint55 = null;
        org.jfree.chart.text.TextBlock textBlock56 = org.jfree.chart.text.TextUtilities.createTextBlock("", font54, paint55);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean60 = textBlock56.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean64 = dateAxis63.isAxisLineVisible();
        dateAxis63.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat67 = dateAxis63.getDateFormatOverride();
        java.awt.Font font68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis63.setTickLabelFont(font68);
        java.awt.Color color70 = java.awt.Color.red;
        textBlock56.addLine("", font68, (java.awt.Paint) color70);
        org.jfree.chart.plot.PiePlot3D piePlot3D72 = new org.jfree.chart.plot.PiePlot3D();
        double double73 = piePlot3D72.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart75 = new org.jfree.chart.JFreeChart("hi!", font68, (org.jfree.chart.plot.Plot) piePlot3D72, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent78 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart75, (int) (short) 100, (int) (byte) 10);
        java.lang.String str79 = chartProgressEvent78.toString();
        org.jfree.chart.JFreeChart jFreeChart80 = chartProgressEvent78.getChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent81 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textBlock50, jFreeChart80);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(drawingSupplier42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(textBlock50);
        org.junit.Assert.assertNotNull(textBlock56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNull(dateFormat67);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.12d + "'", double73 == 0.12d);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1]" + "'", str79.equals("org.jfree.chart.event.ChartProgressEvent[source=-1]"));
        org.junit.Assert.assertNotNull(jFreeChart80);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        int int5 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke7 = piePlot3D6.getLabelOutlineStroke();
        piePlot3D6.zoom((double) 100L);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke11 = piePlot3D10.getLabelOutlineStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D10.setSectionOutlineStroke((java.lang.Comparable) 1L, stroke13);
        piePlot3D6.setBaseSectionOutlineStroke(stroke13);
        xYPlot0.setRangeGridlineStroke(stroke13);
        int int17 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray18);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(valueAxisArray18);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        polarPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = polarPlot7.getRadiusGridlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) polarPlot7);
        org.jfree.data.xy.XYDataset xYDataset12 = polarPlot7.getDataset();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = polarPlot7.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(plotOrientation13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) Double.NEGATIVE_INFINITY);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        java.awt.Paint paint2 = piePlot3D0.getShadowPaint();
        piePlot3D0.setLabelGap(0.5d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean9 = dateAxis8.isAxisLineVisible();
        dateAxis8.setAutoRangeMinimumSize((double) ' ');
        org.jfree.data.Range range12 = dateAxis8.getRange();
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, 0.2d, 0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(45.0d, range12);
        dateAxis1.setRange(range12);
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range12, (double) 255, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        boolean boolean8 = textBlock4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean12 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat15 = dateAxis11.getDateFormatOverride();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis11.setTickLabelFont(font16);
        java.awt.Color color18 = java.awt.Color.red;
        textBlock4.addLine("", font16, (java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        double double21 = piePlot3D20.getDepthFactor();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) piePlot3D20, false);
        boolean boolean24 = jFreeChart23.isNotify();
        int int25 = jFreeChart23.getBackgroundImageAlignment();
        jFreeChart23.clearSubtitles();
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        double double28 = piePlot3D27.getDepthFactor();
        double double29 = piePlot3D27.getMaximumExplodePercent();
        double double30 = piePlot3D27.getMaximumExplodePercent();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D27.setLabelLinkStroke(stroke31);
        jFreeChart23.setBorderStroke(stroke31);
        org.jfree.chart.plot.Plot plot34 = jFreeChart23.getPlot();
        boolean boolean35 = jFreeChart23.isNotify();
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.12d + "'", double21 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.12d + "'", double28 == 0.12d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(plot34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textLine1.draw(graphics2D3, 0.0f, (float) 1L, textAnchor6, (float) 100L, (float) 255, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean4 = dateAxis3.isAxisLineVisible();
        dateAxis3.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font7 = dateAxis3.getTickLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font7, paint8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font7);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean13 = dateAxis12.isAxisLineVisible();
        dateAxis12.setAutoRangeMinimumSize((double) ' ');
        java.awt.Font font16 = dateAxis12.getTickLabelFont();
        textTitle10.setFont(font16);
        textTitle10.setExpandToFitSpace(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getMaximumExplodePercent();
        boolean boolean3 = piePlot3D0.getDarkerSides();
        java.awt.Paint paint4 = null;
        try {
            piePlot3D0.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setVisible(true);
        dateAxis1.resizeRange((double) 500, (-9.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        dateAxis1.setLabelToolTip("hi!");
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = dateAxis1.hasListener(eventListener10);
        dateAxis1.setRange(0.12d, (double) '4');
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean20 = dateAxis19.isAxisLineVisible();
        dateAxis19.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat23 = dateAxis19.getDateFormatOverride();
        dateAxis19.setLabelToolTip("");
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis19.setMaximumDate(date26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        boolean boolean31 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot29.setRenderer(categoryItemRenderer32);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(dateFormat23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        piePlot0.setLabelGap(0.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getRange();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setIgnoreNullValues(false);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) '#', paint11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean17 = textBlockAnchor15.equals((java.lang.Object) horizontalAlignment16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment18, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14, (org.jfree.chart.block.Arrangement) flowArrangement21, arrangement22);
        legendTitle23.setWidth(1.0d);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (byte) 100);
        org.jfree.chart.util.Size2D size2D30 = legendTitle23.arrange(graphics2D26, rectangleConstraint29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, 100.0d, (double) (byte) -1, rectangleAnchor33);
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D();
        double double36 = piePlot3D35.getDepthFactor();
        double double37 = piePlot3D35.getMaximumExplodePercent();
        boolean boolean38 = piePlot3D35.getDarkerSides();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.PiePlotState piePlotState41 = piePlot7.initialise(graphics2D13, rectangle2D34, (org.jfree.chart.plot.PiePlot) piePlot3D35, (java.lang.Integer) 100, plotRenderingInfo40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis0.lengthToJava2D((double) 10, rectangle2D34, rectangleEdge42);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.12d + "'", double36 == 0.12d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(piePlotState41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand44);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1L);
        org.jfree.chart.block.Arrangement arrangement8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, arrangement8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        boolean boolean3 = piePlot3D0.getDarkerSides();
        java.awt.Paint paint4 = piePlot3D0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoRangeMinimumSize((double) ' ');
        java.awt.Paint paint6 = dateAxis2.getTickMarkPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) dateAxis2);
        dateAxis2.resizeRange((double) (byte) 10, (double) 15);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot11.getFixedDomainAxisSpace();
        xYPlot11.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot11.getDomainAxisLocation();
        int int16 = xYPlot11.getRangeAxisCount();
        xYPlot11.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke20 = piePlot3D19.getLabelOutlineStroke();
        boolean boolean21 = xYPlot11.equals((java.lang.Object) stroke20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        int int23 = xYPlot11.indexOf(xYDataset22);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        dateAxis26.setLabelAngle((double) (short) -1);
        double double29 = dateAxis26.getLabelAngle();
        xYPlot11.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean33 = dateAxis32.isAxisLineVisible();
        dateAxis32.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat36 = dateAxis32.getDateFormatOverride();
        dateAxis32.setLabelToolTip("");
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMaximumDate(date39);
        dateAxis26.setMaximumDate(date39);
        dateAxis2.setMaximumDate(date39);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.0d) + "'", double29 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(dateFormat36);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1, (short) 100, 100, 1.0f };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray8, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "ChartEntity: tooltip = hi!", numberArray14);
        multiplePiePlot1.setDataset(categoryDataset15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        java.awt.Color color20 = java.awt.Color.BLACK;
        java.awt.Color color21 = java.awt.Color.getColor("", color20);
        multiplePiePlot18.setAggregatedItemsPaint((java.awt.Paint) color21);
        java.lang.Comparable comparable23 = multiplePiePlot18.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder24 = multiplePiePlot18.getDataExtractOrder();
        multiplePiePlot1.setDataExtractOrder(tableOrder24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = multiplePiePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder24);
        org.junit.Assert.assertNotNull(legendItemCollection26);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = piePlot3D0.getLabelOutlineStroke();
        boolean boolean2 = piePlot3D0.getIgnoreZeroValues();
        boolean boolean3 = piePlot3D0.getDarkerSides();
        boolean boolean4 = piePlot3D0.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean7 = dateAxis6.isAxisLineVisible();
        dateAxis6.setAutoRangeMinimumSize((double) ' ');
        java.text.DateFormat dateFormat10 = dateAxis6.getDateFormatOverride();
        dateAxis6.setLabelToolTip("");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMaximumDate(date13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        dateAxis6.resizeRange(0.025d, (double) 0.0f);
        boolean boolean21 = dateAxis6.isHiddenValue((long) (short) 1);
        boolean boolean22 = xYPlot1.equals((java.lang.Object) boolean21);
        boolean boolean23 = xYPlot1.isRangeZoomable();
        java.lang.Class<?> wildcardClass24 = xYPlot1.getClass();
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ChartChangeEventType.NEW_DATASET", (java.lang.Class) wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(obj25);
    }
}

