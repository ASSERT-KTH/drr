import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Object obj8 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        org.jfree.chart.LegendItem legendItem25 = lineAndShapeRenderer10.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape26 = lineAndShapeRenderer10.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator28 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator29 = null;
        java.lang.String str30 = chartEntity27.getImageMapAreaTag(toolTipTagFragmentGenerator28, uRLTagFragmentGenerator29);
        java.lang.String str31 = chartEntity27.getURLText();
        boolean boolean32 = plotOrientation9.equals((java.lang.Object) chartEntity27);
        java.lang.String str33 = chartEntity27.getURLText();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createOutsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = lineAndShapeRenderer7.getBaseItemLabelPaint();
        barRenderer0.setSeriesPaint(0, paint20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        barRenderer0.setBase(18.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setBasePaint((java.awt.Paint) color24);
        java.awt.Stroke stroke27 = lineAndShapeRenderer13.lookupSeriesStroke((int) (short) 10);
        boolean boolean28 = lineAndShapeRenderer13.getBaseShapesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = lineAndShapeRenderer13.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = lineAndShapeRenderer13.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator30);
        barRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator30);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot0.getDomainMarkers(layer3);
        org.junit.Assert.assertNull(collection4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        java.awt.Stroke stroke4 = barRenderer0.getBaseStroke();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultCategoryDataset5.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot7.markerChanged(markerChangeEvent8);
        java.awt.Paint paint10 = categoryPlot7.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot7.getRangeAxisEdge();
        boolean boolean12 = defaultCategoryDataset5.hasListener((java.util.EventListener) categoryPlot7);
        defaultCategoryDataset5.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.Range range18 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, false);
        java.awt.Paint paint19 = barRenderer0.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendHeight((double) 'a');
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.lang.String str4 = unitType3.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.ABSOLUTE" + "'", str4.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double2 = rectangleInsets0.getTop();
        double double4 = rectangleInsets0.calculateTopOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer0.getBarPainter();
        barRenderer0.setSeriesVisibleInLegend(255, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator10, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup14 = defaultCategoryDataset13.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryPlot15.markerChanged(markerChangeEvent16);
        java.awt.Paint paint18 = categoryPlot15.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot15.getRangeAxisEdge();
        boolean boolean20 = defaultCategoryDataset13.hasListener((java.util.EventListener) categoryPlot15);
        defaultCategoryDataset13.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int25 = defaultCategoryDataset13.getColumnCount();
        org.jfree.data.Range range27 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(barPainter6);
        org.junit.Assert.assertNotNull(datasetGroup14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("-3,-3,3,3");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: -3,-3,3,3" + "'", str2.equals("org.jfree.data.UnknownKeyException: -3,-3,3,3"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot7.getDataset((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setUseFillPaint(true);
        boolean boolean13 = lineAndShapeRenderer10.getAutoPopulateSeriesFillPaint();
        boolean boolean14 = lineAndShapeRenderer10.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer15.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot35.markerChanged(markerChangeEvent36);
        int int38 = categoryPlot35.getCrosshairDatasetIndex();
        float float39 = categoryPlot35.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        categoryPlot35.setDomainAxisLocation((int) (byte) 1, axisLocation41);
        java.awt.Stroke stroke43 = categoryPlot35.getOutlineStroke();
        lineAndShapeRenderer15.setSeriesOutlineStroke(15, stroke43);
        boolean boolean45 = lineAndShapeRenderer15.getBaseShapesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray46 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer10, lineAndShapeRenderer15 };
        categoryPlot7.setRenderers(categoryItemRendererArray46);
        boolean boolean48 = categoryPlot7.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint2 = renderAttributes1.getDefaultLabelPaint();
        java.awt.Shape shape5 = renderAttributes1.getItemShape(255, 2);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendHeight((double) 'a');
        double double4 = rectangleInsets0.extendHeight((-1.0d));
        double double6 = rectangleInsets0.trimWidth((double) 192);
        double double8 = rectangleInsets0.calculateRightOutset((double) (-1L));
        double double9 = rectangleInsets0.getTop();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 190.0d + "'", double6 == 190.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setShadowVisible(true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        boolean boolean9 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Font font3 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color4);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color4.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer5.setUseFillPaint(true);
        boolean boolean8 = lineAndShapeRenderer5.getAutoPopulateSeriesFillPaint();
        java.awt.Font font12 = lineAndShapeRenderer5.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean13 = lineAndShapeRenderer5.getBaseItemLabelsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = lineAndShapeRenderer5.getLegendItems();
        java.util.Iterator iterator15 = legendItemCollection14.iterator();
        boolean boolean16 = categoryPlot0.equals((java.lang.Object) legendItemCollection14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(iterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        boolean boolean27 = legendItem23.isShapeVisible();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge(8);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker(1, marker9, layer10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemToolTipGenerator();
        boolean boolean5 = lineAndShapeRenderer0.getUseSeriesOffset();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        boolean boolean13 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        categoryAxis0.clearCategoryLabelToolTips();
        double double33 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer15.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        boolean boolean35 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = categoryPlot0.removeRangeMarker((int) (byte) 1, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        java.awt.Paint paint17 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        java.awt.Stroke stroke19 = null;
        try {
            lineAndShapeRenderer0.setSeriesStroke((-23167), stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 10.0f);
        double double4 = rectangleInsets0.trimWidth((double) (short) 10);
        double double6 = rectangleInsets0.calculateTopInset(0.0d);
        double double8 = rectangleInsets0.extendHeight((double) '#');
        double double9 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-6.0d) + "'", double4 == (-6.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 43.0d + "'", double8 == 43.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Paint paint44 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        lineAndShapeRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNull(paint44);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        java.awt.Font font23 = lineAndShapeRenderer0.lookupLegendTextFont(0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        int int3 = color2.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Shape shape17 = lineAndShapeRenderer0.lookupLegendShape(10);
        boolean boolean19 = lineAndShapeRenderer0.isSeriesVisible((int) (byte) 10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo7, point2D8, true);
        categoryPlot0.clearSelection();
        int int12 = categoryPlot0.getRendererCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str1 = color0.toString();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        int int8 = color0.getTransparency();
        float[] floatArray9 = null;
        float[] floatArray10 = color0.getRGBColorComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str1.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot0.setInsets(rectangleInsets3);
        boolean boolean5 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot0.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer9.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator13);
        java.lang.Boolean boolean16 = lineAndShapeRenderer9.getSeriesVisible((int) '#');
        try {
            categoryPlot0.setRenderer((-256), (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setUseFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape9 = lineAndShapeRenderer4.lookupSeriesShape(0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape9, (java.awt.Paint) color10);
        java.awt.Shape shape12 = legendItem11.getShape();
        boolean boolean13 = legendItem11.isShapeVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke9 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis15, marker16, rectangle2D17);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = categoryPlot6.removeDomainMarker(0, marker20, layer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Point2D point2D25 = null;
        org.jfree.chart.plot.PlotState plotState26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            categoryPlot6.draw(graphics2D23, rectangle2D24, point2D25, plotState26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        lineAndShapeRenderer0.setSeriesShapesFilled(255, false);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.data.Range range38 = lineAndShapeRenderer0.findRangeBounds(categoryDataset37);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(8, (java.lang.Boolean) false);
        org.jfree.chart.renderer.RenderAttributes renderAttributes42 = lineAndShapeRenderer0.getSelectedItemAttributes();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(renderAttributes42);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean8 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 100, (java.lang.Boolean) true);
        try {
            lineAndShapeRenderer0.setSeriesShapesFilled((-16777216), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        categoryPlot0.clearAnnotations();
        java.awt.Paint paint4 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker((int) (short) -1, marker6, layer7, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        categoryPlot10.notifyListeners(plotChangeEvent11);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot10.setNoDataMessageFont(font13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot10.setRangeAxisLocation((int) (short) 100, axisLocation16);
        categoryPlot0.setDomainAxisLocation(axisLocation16);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        java.awt.Paint paint17 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        lineAndShapeRenderer0.setSeriesShapesVisible(2, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = lineAndShapeRenderer0.getItemLabelGenerator((int) '4', 192, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator45 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator45);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Font font3 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setShadowVisible(false);
        double double10 = barRenderer7.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        barRenderer7.setGradientPaintTransformer(gradientPaintTransformer11);
        barRenderer7.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean17 = barRenderer7.isDrawBarOutline();
        boolean boolean18 = barRenderer7.getShadowsVisible();
        java.awt.Shape shape19 = barRenderer7.getBaseLegendShape();
        renderAttributes1.setSeriesShape((int) (byte) 1, shape19);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) false);
        boolean boolean15 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        lineAndShapeRenderer0.setAutoPopulateSeriesShape(true);
        java.awt.Shape shape19 = lineAndShapeRenderer0.lookupLegendShape(3);
        lineAndShapeRenderer0.setDefaultEntityRadius((-65536));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.gray;
        legendItem24.setFillPaint((java.awt.Paint) color25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str28 = color27.toString();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color27.getTransparency();
        float[] floatArray40 = new float[] { (short) -1, (short) 1, 10.0f, 2 };
        float[] floatArray41 = color27.getComponents(floatArray40);
        float[] floatArray42 = color25.getColorComponents(floatArray40);
        float[] floatArray43 = color0.getRGBComponents(floatArray40);
        int int44 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str28.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setWeight((int) (short) -1);
        categoryPlot13.setAnchorValue((double) (byte) 10, false);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        try {
            lineAndShapeRenderer0.setSeriesItemLabelGenerator((-1), categoryItemLabelGenerator21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        float float5 = categoryPlot1.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity6 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.util.ShadowGenerator shadowGenerator7 = categoryPlot1.getShadowGenerator();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(shadowGenerator7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        legendItem23.setToolTipText("");
        legendItem23.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint30 = lineAndShapeRenderer29.getBaseOutlinePaint();
        legendItem23.setLabelPaint(paint30);
        java.awt.Color color32 = java.awt.Color.DARK_GRAY;
        legendItem23.setLabelPaint((java.awt.Paint) color32);
        java.lang.String str34 = legendItem23.getToolTipText();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        chartChangeEvent1.setChart(jFreeChart2);
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        lineAndShapeRenderer0.setUseFillPaint(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator48 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator48);
        boolean boolean50 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color61 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer56.setSeriesFillPaint((int) '#', (java.awt.Paint) color61);
        boolean boolean63 = lineAndShapeRenderer56.getBaseSeriesVisible();
        java.awt.Color color67 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer56.setBasePaint((java.awt.Paint) color67);
        org.jfree.chart.LegendItem legendItem71 = lineAndShapeRenderer56.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape72 = lineAndShapeRenderer56.getBaseShape();
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color74 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape72, stroke73, (java.awt.Paint) color74);
        java.awt.Stroke stroke76 = legendItem75.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) ' ', stroke76, false);
        double double79 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNull(legendItem71);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 2.0d + "'", double79 == 2.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        lineAndShapeRenderer0.setSeriesShapesFilled(255, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = lineAndShapeRenderer0.getLegendItemURLGenerator();
        lineAndShapeRenderer0.setSeriesShapesFilled(3, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot0.getDataset((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        categoryPlot32.markerChanged(markerChangeEvent33);
        int int35 = categoryPlot32.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        categoryPlot36.markerChanged(markerChangeEvent37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation41 = axisLocation40.getOpposite();
        categoryPlot36.setDomainAxisLocation(10, axisLocation40, true);
        categoryPlot32.setDomainAxisLocation(axisLocation40, false);
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation40, false);
        java.awt.Paint paint48 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        double double7 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot2.getAxisOffset();
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) rectangleInsets10);
        int int13 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "rect");
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) false, (java.lang.Comparable) 190.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (false) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator45 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer52.setUseFillPaint(true);
        boolean boolean55 = lineAndShapeRenderer52.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer52);
        lineAndShapeRenderer52.setBaseLinesVisible(true);
        java.awt.Font font59 = lineAndShapeRenderer52.getBaseItemLabelFont();
        try {
            lineAndShapeRenderer0.setSeriesItemLabelFont((-256), font59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        java.awt.Stroke stroke24 = lineAndShapeRenderer10.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = lineAndShapeRenderer10.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        boolean boolean30 = itemLabelPosition28.equals((java.lang.Object) itemLabelAnchor29);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition28);
        java.awt.Shape shape33 = lineAndShapeRenderer0.lookupSeriesShape((int) '4');
        java.awt.Paint paint35 = lineAndShapeRenderer0.lookupSeriesPaint((-256));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        lineAndShapeRenderer3.setBaseLinesVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = lineAndShapeRenderer3.getSeriesItemLabelGenerator(15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = lineAndShapeRenderer3.getSeriesURLGenerator(1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categoryURLGenerator13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 100, font9);
        java.awt.Stroke stroke11 = lineAndShapeRenderer0.getBaseOutlineStroke();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (byte) 100, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition(15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator17, true);
        java.awt.Stroke stroke23 = lineAndShapeRenderer0.getItemStroke(8, 100, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setSeriesFillPaint((int) '#', (java.awt.Paint) color33);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setBasePaint((java.awt.Paint) color39);
        org.jfree.chart.LegendItem legendItem43 = lineAndShapeRenderer28.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape44 = lineAndShapeRenderer28.getBaseShape();
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color46 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape44, stroke45, (java.awt.Paint) color46);
        lineAndShapeRenderer0.setBaseShape(shape44, false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(legendItem43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) 3, true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        categoryPlot3.setDrawingSupplier(drawingSupplier9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        java.awt.Image image13 = categoryPlot3.getBackgroundImage();
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Paint paint4 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.lang.Object obj6 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot0.markerChanged(markerChangeEvent2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        java.awt.Image image6 = null;
        categoryPlot0.setBackgroundImage(image6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        java.lang.String str25 = legendItem23.getLabel();
        boolean boolean26 = legendItem23.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0}" + "'", str25.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        double double7 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot2.getAxisOffset();
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) rectangleInsets10);
        int int13 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "rect");
        try {
            java.lang.Object obj16 = keyedObjects2D0.getObject(100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (-6.0d), (double) (byte) 100, (double) (short) 10);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateRightOutset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets4.createOutsetRectangle(rectangle2D8, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem23.setFillPaint((java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.yellow;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        boolean boolean39 = lineAndShapeRenderer32.getBaseSeriesVisible();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setBasePaint((java.awt.Paint) color43);
        org.jfree.chart.LegendItem legendItem47 = lineAndShapeRenderer32.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape48 = lineAndShapeRenderer32.getBaseShape();
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color50 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape48, stroke49, (java.awt.Paint) color50);
        java.awt.Color color52 = java.awt.Color.gray;
        legendItem51.setFillPaint((java.awt.Paint) color52);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str55 = color54.toString();
        java.awt.image.ColorModel colorModel56 = null;
        java.awt.Rectangle rectangle57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.AffineTransform affineTransform59 = null;
        java.awt.RenderingHints renderingHints60 = null;
        java.awt.PaintContext paintContext61 = color54.createContext(colorModel56, rectangle57, rectangle2D58, affineTransform59, renderingHints60);
        int int62 = color54.getTransparency();
        float[] floatArray67 = new float[] { (short) -1, (short) 1, 10.0f, 2 };
        float[] floatArray68 = color54.getComponents(floatArray67);
        float[] floatArray69 = color52.getColorComponents(floatArray67);
        float[] floatArray70 = color27.getRGBComponents(floatArray67);
        float[] floatArray71 = color25.getRGBColorComponents(floatArray67);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(legendItem47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str55.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertNotNull(floatArray71);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint4 = lineAndShapeRenderer0.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setUseFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape9 = lineAndShapeRenderer4.lookupSeriesShape(0);
        java.awt.Shape shape10 = lineAndShapeRenderer4.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape10, "hi!", "GradientPaintTransformType.VERTICAL");
        java.awt.Color color15 = java.awt.Color.red;
        java.awt.Color color16 = java.awt.Color.getColor("ChartEntity: tooltip = null", color15);
        int int17 = color15.getRed();
        int int18 = color15.getGreen();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke20 = categoryPlot19.getRangeZeroBaselineStroke();
        java.awt.Paint paint21 = categoryPlot19.getRangeGridlinePaint();
        categoryPlot19.setDomainCrosshairRowKey((java.lang.Comparable) "GradientPaintTransformType.VERTICAL");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setSeriesFillPaint((int) '#', (java.awt.Paint) color33);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setBasePaint((java.awt.Paint) color39);
        org.jfree.chart.LegendItem legendItem43 = lineAndShapeRenderer28.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape44 = lineAndShapeRenderer28.getBaseShape();
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color46 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape44, stroke45, (java.awt.Paint) color46);
        categoryPlot19.setOutlinePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke49 = categoryPlot19.getRangeGridlineStroke();
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.lang.String str51 = color50.toString();
        try {
            org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem(attributedString0, "Category Plot", "{0}", "java.awt.Color[r=128,g=0,b=128]", shape10, (java.awt.Paint) color15, stroke49, (java.awt.Paint) color50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(legendItem43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "java.awt.Color[r=128,g=0,b=128]" + "'", str51.equals("java.awt.Color[r=128,g=0,b=128]"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot0.setDomainAxis(100, categoryAxis4, true);
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        java.util.List list8 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        boolean boolean8 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot0.markerChanged(markerChangeEvent9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Shape shape13 = renderAttributes1.getDefaultShape();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str18 = color17.toString();
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color17.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        int int25 = color17.getTransparency();
        try {
            renderAttributes1.setSeriesLabelPaint(4, (java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str18.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        java.awt.Stroke stroke19 = null;
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke19, false);
        boolean boolean22 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint3 = renderAttributes1.getSeriesOutlinePaint((int) (byte) 10);
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name SortOrder.ASCENDING, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState10 = null;
        try {
            boolean boolean11 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) (byte) -1, plotRenderingInfo9, categoryCrosshairState10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.lang.String str25 = legendItem24.getDescription();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem24.setFillPaint((java.awt.Paint) color26);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color26, (float) (short) 100, 3, (double) (short) 100);
        int int32 = defaultShadowGenerator31.getDistance();
        int int33 = defaultShadowGenerator31.getShadowSize();
        int int34 = defaultShadowGenerator31.calculateOffsetX();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        double double16 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace17);
        categoryPlot11.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot11.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot11.zoomDomainAxes((double) 1.0f, plotRenderingInfo27, point2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot11.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot11.setRangeMinorGridlineStroke(stroke32);
        renderAttributes1.setDefaultStroke(stroke32);
        java.awt.Paint paint37 = renderAttributes1.getItemPaint((int) (short) 1, (-1));
        try {
            java.lang.Boolean boolean39 = renderAttributes1.getSeriesLabelVisible(128);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        int int4 = lineAndShapeRenderer0.getColumnCount();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = lineAndShapeRenderer0.getLegendItems();
        java.awt.Shape shape7 = lineAndShapeRenderer0.getSeriesShape((int) (byte) 100);
        java.awt.Shape shape8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        lineAndShapeRenderer0.setBaseShape(shape8, true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        int int15 = categoryPlot12.getCrosshairDatasetIndex();
        float float16 = categoryPlot12.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot12.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation17);
        java.lang.String str19 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot0.panRangeAxes(0.05d, plotRenderingInfo21, point2D22);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setUseFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape9 = lineAndShapeRenderer4.lookupSeriesShape(0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape9, (java.awt.Paint) color10);
        java.awt.Paint paint12 = legendItem11.getFillPaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setSeriesFillPaint((int) '#', (java.awt.Paint) color16);
        boolean boolean18 = lineAndShapeRenderer11.getBaseSeriesVisible();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setBasePaint((java.awt.Paint) color22);
        java.awt.Stroke stroke25 = lineAndShapeRenderer11.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color31 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer26.setSeriesFillPaint((int) '#', (java.awt.Paint) color31);
        boolean boolean33 = lineAndShapeRenderer26.getBaseSeriesVisible();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer26.setBasePaint((java.awt.Paint) color37);
        java.awt.Stroke stroke40 = lineAndShapeRenderer26.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer26.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = lineAndShapeRenderer26.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer11.setBaseNegativeItemLabelPosition(itemLabelPosition44);
        boolean boolean46 = color8.equals((java.lang.Object) lineAndShapeRenderer11);
        int int47 = color8.getRGB();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-16646144) + "'", int47 == (-16646144));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (byte) 0, (-16646144), 192, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        java.lang.Boolean boolean12 = lineAndShapeRenderer0.getSeriesShapesFilled(100);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        double double16 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace17);
        categoryPlot11.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot11.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot11.zoomDomainAxes((double) 1.0f, plotRenderingInfo27, point2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot11.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot11.setRangeMinorGridlineStroke(stroke32);
        renderAttributes1.setDefaultStroke(stroke32);
        java.awt.Paint paint37 = renderAttributes1.getItemPaint((int) (short) 1, (-1));
        java.awt.Color color39 = java.awt.Color.white;
        try {
            renderAttributes1.setSeriesLabelPaint((-256), (java.awt.Paint) color39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 1, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        java.lang.String str5 = chartChangeEvent3.toString();
        java.lang.Object obj6 = chartChangeEvent3.getSource();
        org.junit.Assert.assertNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=1]" + "'", str5.equals("org.jfree.chart.event.ChartChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (short) 1 + "'", obj6.equals((short) 1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        categoryPlot0.setBackgroundImageAlignment((int) ' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (-65536));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setWeight((int) (short) -1);
        lineAndShapeRenderer9.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot12);
        java.lang.Comparable comparable16 = categoryPlot12.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot17 = categoryPlot12.getRootPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = categoryPlot12.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot12.setDomainAxisLocation((int) '#', axisLocation20, true);
        boolean boolean23 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            boolean boolean28 = categoryPlot12.removeRangeMarker((int) (byte) 10, marker25, layer26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15, true);
        java.awt.Paint paint18 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setNotify(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        lineAndShapeRenderer0.setUseFillPaint(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator48 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator48);
        boolean boolean50 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color61 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer56.setSeriesFillPaint((int) '#', (java.awt.Paint) color61);
        boolean boolean63 = lineAndShapeRenderer56.getBaseSeriesVisible();
        java.awt.Color color67 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer56.setBasePaint((java.awt.Paint) color67);
        org.jfree.chart.LegendItem legendItem71 = lineAndShapeRenderer56.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape72 = lineAndShapeRenderer56.getBaseShape();
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color74 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape72, stroke73, (java.awt.Paint) color74);
        java.awt.Stroke stroke76 = legendItem75.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) ' ', stroke76, false);
        java.awt.Color color80 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        try {
            lineAndShapeRenderer0.setSeriesItemLabelPaint((-65536), (java.awt.Paint) color80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNull(legendItem71);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(color80);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setWeight((int) (short) -1);
        lineAndShapeRenderer11.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        java.lang.Comparable comparable18 = categoryPlot14.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot19 = categoryPlot14.getRootPlot();
        java.awt.Paint paint20 = categoryPlot14.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot14.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier21, false);
        boolean boolean24 = categoryPlot0.isRangeGridlinesVisible();
        int int25 = categoryPlot0.getDatasetCount();
        boolean boolean26 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot27.markerChanged(markerChangeEvent28);
        int int30 = categoryPlot27.getCrosshairDatasetIndex();
        float float31 = categoryPlot27.getForegroundAlpha();
        double double32 = categoryPlot27.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace33);
        categoryPlot27.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot27.clearRangeMarkers();
        categoryPlot27.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot27.getRangeAxisEdge(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot27);
        categoryPlot0.notifyListeners(plotChangeEvent42);
        org.jfree.chart.plot.Plot plot44 = plotChangeEvent42.getPlot();
        org.jfree.chart.plot.Plot plot45 = plot44.getRootPlot();
        plot44.setForegroundAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(plot44);
        org.junit.Assert.assertNotNull(plot45);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke9 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis15, marker16, rectangle2D17);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) ' ', true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(datasetGroup4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = lineAndShapeRenderer0.getSelectedItemAttributes();
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.getColor("ChartEntity: tooltip = null", color5);
        java.awt.Color color7 = java.awt.Color.getColor("ChartEntity: tooltip = null", color5);
        lineAndShapeRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = lineAndShapeRenderer0.getURLGenerator((int) 'a', (int) (short) 10, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setShadowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        categoryPlot17.markerChanged(markerChangeEvent18);
        int int20 = categoryPlot17.getCrosshairDatasetIndex();
        float float21 = categoryPlot17.getForegroundAlpha();
        double double22 = categoryPlot17.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace23);
        categoryPlot17.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot17.clearRangeMarkers();
        categoryPlot17.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot17.getRangeAxisEdge(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer33.setUseFillPaint(true);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer33.setSeriesFillPaint((int) (short) 100, (java.awt.Paint) color37, true);
        categoryPlot17.setRangeCrosshairPaint((java.awt.Paint) color37);
        boolean boolean41 = barRenderer14.equals((java.lang.Object) color37);
        lineAndShapeRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color37, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.gray;
        legendItem24.setFillPaint((java.awt.Paint) color25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str28 = color27.toString();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color27.getTransparency();
        float[] floatArray40 = new float[] { (short) -1, (short) 1, 10.0f, 2 };
        float[] floatArray41 = color27.getComponents(floatArray40);
        float[] floatArray42 = color25.getColorComponents(floatArray40);
        float[] floatArray43 = color0.getComponents(floatArray40);
        float[] floatArray44 = null;
        float[] floatArray45 = color0.getRGBColorComponents(floatArray44);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str28.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        java.lang.String str9 = axisLocation8.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str9.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Font font3 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke4 = renderAttributes1.getDefaultStroke();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) 0, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot0.addDomainMarker(100, categoryMarker12, layer13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        int int5 = categoryPlot1.indexOf(categoryDataset4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        categoryPlot1.notifyListeners(plotChangeEvent6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot1.getLegendItems();
        legendItemCollection0.addAll(legendItemCollection8);
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection8.get((-256));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Shape shape14 = lineAndShapeRenderer0.lookupSeriesShape(1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("GradientPaintTransformType.VERTICAL");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        java.awt.Paint paint17 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        int int1 = booleanList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getFixedLegendItems();
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Color color1 = java.awt.Color.red;
        java.awt.Color color2 = java.awt.Color.getColor("ChartEntity: tooltip = null", color1);
        int int3 = color1.getAlpha();
        int int4 = color1.getTransparency();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setWeight((int) (short) -1);
        categoryPlot12.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setSeriesFillPaint((int) '#', (java.awt.Paint) color24);
        boolean boolean26 = lineAndShapeRenderer19.getBaseSeriesVisible();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setBasePaint((java.awt.Paint) color30);
        org.jfree.chart.LegendItem legendItem34 = lineAndShapeRenderer19.getLegendItem(2, (int) (byte) 1);
        categoryPlot12.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19, false);
        java.awt.Color color39 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot12.setNoDataMessagePaint((java.awt.Paint) color39);
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color39);
        categoryPlot3.setDomainAxis(3, categoryAxis10, false);
        categoryAxis10.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        categoryPlot49.markerChanged(markerChangeEvent50);
        java.awt.Paint paint52 = categoryPlot49.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot49.getRangeAxisEdge();
        try {
            double double54 = categoryAxis10.getCategoryMiddle(0, (int) 'a', rectangle2D48, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(legendItem34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean8 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        lineAndShapeRenderer0.setSeriesLinesVisible(1, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        float float3 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean8 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        int int10 = categoryPlot0.getRendererCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke14 = categoryPlot13.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        categoryPlot13.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = categoryPlot13.removeDomainMarker(marker18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation25 = axisLocation24.getOpposite();
        categoryPlot20.setDomainAxisLocation(10, axisLocation24, true);
        org.jfree.chart.axis.AxisLocation axisLocation28 = axisLocation24.getOpposite();
        categoryPlot13.setDomainAxisLocation(axisLocation28, false);
        try {
            categoryPlot0.setDomainAxisLocation((-65536), axisLocation28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.lang.String str25 = legendItem23.getToolTipText();
        legendItem23.setToolTipText("AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        java.lang.Comparable comparable6 = keyedObjects0.getKey(0);
        try {
            keyedObjects0.removeValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1.0d + "'", comparable6.equals(1.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        categoryPlot0.setInsets(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15, true);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = categoryPlot0.removeDomainMarker(marker18);
        try {
            org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot0.getDomainAxisForDataset((-16646144));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation((int) (short) 1);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (short) -1);
        categoryPlot16.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        lineAndShapeRenderer21.setBaseToolTipGenerator(categoryToolTipGenerator22, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = lineAndShapeRenderer21.getLegendItemLabelGenerator();
        int int26 = categoryPlot16.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        categoryPlot16.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        categoryPlot28.markerChanged(markerChangeEvent29);
        int int31 = categoryPlot28.getCrosshairDatasetIndex();
        float float32 = categoryPlot28.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot28.getRangeAxisLocation();
        categoryPlot16.setRangeAxisLocation(axisLocation33);
        categoryPlot0.setDomainAxisLocation(axisLocation33, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = lineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryPlot16);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, (float) (-1), (float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        int int25 = categoryPlot21.indexOf(categoryDataset24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        categoryPlot21.notifyListeners(plotChangeEvent26);
        org.jfree.data.general.DatasetGroup datasetGroup28 = categoryPlot21.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color34 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer29.setSeriesFillPaint((int) '#', (java.awt.Paint) color34);
        boolean boolean36 = lineAndShapeRenderer29.getBaseSeriesVisible();
        java.awt.Font font38 = null;
        lineAndShapeRenderer29.setSeriesItemLabelFont((int) (byte) 0, font38, false);
        java.awt.Stroke stroke44 = lineAndShapeRenderer29.getItemStroke(2, 0, false);
        java.awt.Stroke stroke48 = lineAndShapeRenderer29.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot21.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke51 = categoryPlot50.getRangeZeroBaselineStroke();
        java.awt.Paint paint52 = categoryPlot50.getRangeGridlinePaint();
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "SortOrder.ASCENDING", "GradientPaintTransformType.VERTICAL", "Category Plot", shape16, (java.awt.Paint) color20, stroke48, paint52);
        lineAndShapeRenderer5.setSeriesShape((int) (byte) 10, shape16, false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(datasetGroup28);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            boolean boolean5 = defaultCategoryDataset0.isSelected(0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer15.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("ChartEntity: tooltip = null");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        lineAndShapeRenderer0.setUseFillPaint(false);
        boolean boolean47 = lineAndShapeRenderer0.getUseSeriesOffset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        java.lang.String str8 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        try {
            int int10 = categoryPlot0.getRangeAxisIndex(valueAxis9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        org.jfree.chart.LegendItem legendItem30 = lineAndShapeRenderer15.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape31 = lineAndShapeRenderer15.getBaseShape();
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color33 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape31, stroke32, (java.awt.Paint) color33);
        java.lang.String str35 = legendItem34.getDescription();
        legendItem34.setToolTipText("");
        legendItem34.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint41 = lineAndShapeRenderer40.getBaseOutlinePaint();
        legendItem34.setLabelPaint(paint41);
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        legendItem34.setLabelPaint((java.awt.Paint) color43);
        java.awt.color.ColorSpace colorSpace45 = color43.getColorSpace();
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color43);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(legendItem30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(colorSpace45);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        lineAndShapeRenderer7.setBaseURLGenerator(categoryURLGenerator25);
        try {
            lineAndShapeRenderer7.setSeriesLinesVisible((-83), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint5 = lineAndShapeRenderer0.getBasePaint();
        java.awt.Stroke stroke9 = lineAndShapeRenderer0.getItemStroke(1, 100, false);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 1, true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo7, point2D8, true);
        categoryPlot0.clearSelection();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot0.getInsets();
        float float13 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setWeight((int) (short) -1);
        categoryPlot14.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem36 = lineAndShapeRenderer21.getLegendItem(2, (int) (byte) 1);
        categoryPlot14.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21, false);
        java.awt.Color color41 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot14.setNoDataMessagePaint((java.awt.Paint) color41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        int int47 = categoryPlot43.indexOf(categoryDataset46);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        categoryPlot49.markerChanged(markerChangeEvent50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation54 = axisLocation53.getOpposite();
        categoryPlot49.setDomainAxisLocation(10, axisLocation53, true);
        categoryPlot43.setRangeAxisLocation((int) (byte) 0, axisLocation53);
        categoryPlot14.setRangeAxisLocation(axisLocation53);
        categoryPlot0.setDomainAxisLocation(axisLocation53, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(legendItem36);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        boolean boolean2 = color0.equals((java.lang.Object) categoryAnchor1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        barRenderer0.setShadowVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape23 = lineAndShapeRenderer7.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = null;
        lineAndShapeRenderer7.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition25);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setSeriesFillPaint((int) '#', (java.awt.Paint) color33);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setBasePaint((java.awt.Paint) color39);
        java.awt.Stroke stroke42 = lineAndShapeRenderer28.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer28.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer28.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer7.setSeriesPositiveItemLabelPosition(0, itemLabelPosition46);
        java.awt.Stroke stroke48 = lineAndShapeRenderer7.getBaseOutlineStroke();
        java.awt.Stroke stroke50 = lineAndShapeRenderer7.getSeriesStroke(1);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer52.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot55.setWeight((int) (short) -1);
        lineAndShapeRenderer52.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot55);
        java.lang.Comparable comparable59 = categoryPlot55.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot60 = categoryPlot55.getRootPlot();
        java.awt.Paint paint61 = categoryPlot55.getDomainGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.plot.Marker marker63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D51, categoryPlot55, valueAxis62, marker63, rectangle2D64);
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color74 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setSeriesFillPaint((int) '#', (java.awt.Paint) color74);
        boolean boolean76 = lineAndShapeRenderer69.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation77 = null;
        boolean boolean78 = lineAndShapeRenderer69.removeAnnotation(categoryAnnotation77);
        java.awt.Paint paint80 = lineAndShapeRenderer69.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint81 = lineAndShapeRenderer69.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer82 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint83 = lineAndShapeRenderer82.getBaseOutlinePaint();
        lineAndShapeRenderer69.setBaseOutlinePaint(paint83, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot86 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot86.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke89 = categoryPlot86.getOutlineStroke();
        try {
            barRenderer0.drawRangeLine(graphics2D6, categoryPlot55, valueAxis66, rectangle2D67, (double) 10, paint83, stroke89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(stroke50);
        org.junit.Assert.assertNull(comparable59);
        org.junit.Assert.assertNotNull(plot60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(stroke89);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = lineAndShapeRenderer9.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer9.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer9.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition27);
        java.awt.Stroke stroke30 = lineAndShapeRenderer3.getSeriesStroke((int) (short) 0);
        lineAndShapeRenderer3.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNull(stroke30);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke13 = categoryPlot12.getRangeZeroBaselineStroke();
        lineAndShapeRenderer0.setBaseStroke(stroke13, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = lineAndShapeRenderer0.getItemLabelGenerator((int) '#', (-256), false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font34 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 8);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer42.setUseFillPaint(true);
        boolean boolean45 = lineAndShapeRenderer42.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer42);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot46.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            org.jfree.chart.axis.AxisState axisState49 = categoryAxis0.draw(graphics2D35, (double) (byte) 0, rectangle2D37, rectangle2D38, rectangleEdge47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint3 = null;
        lineAndShapeRenderer0.setBasePaint(paint3);
        java.awt.Paint paint6 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 1);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer18.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setWeight((int) (short) -1);
        lineAndShapeRenderer18.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot21);
        categoryPlot21.setCrosshairDatasetIndex(8);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str29 = categoryAxis28.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.setWeight((int) (short) -1);
        categoryPlot30.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color42 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer37.setSeriesFillPaint((int) '#', (java.awt.Paint) color42);
        boolean boolean44 = lineAndShapeRenderer37.getBaseSeriesVisible();
        java.awt.Color color48 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer37.setBasePaint((java.awt.Paint) color48);
        org.jfree.chart.LegendItem legendItem52 = lineAndShapeRenderer37.getLegendItem(2, (int) (byte) 1);
        categoryPlot30.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer37, false);
        java.awt.Color color57 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot30.setNoDataMessagePaint((java.awt.Paint) color57);
        categoryAxis28.setTickLabelPaint((java.awt.Paint) color57);
        categoryPlot21.setDomainAxis(3, categoryAxis28, false);
        categoryAxis28.setLabelURL("TextAnchor.BASELINE_CENTER");
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.util.Layer layer65 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D16, rectangle2D17, categoryAxis28, valueAxis64, layer65, plotRenderingInfo66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(legendItem52);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        java.lang.String str6 = axisLocation5.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str6.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        boolean boolean9 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        java.awt.Font font11 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.clearSeriesPaints(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryPlot15.markerChanged(markerChangeEvent16);
        java.awt.Paint paint18 = categoryPlot15.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot15.getRangeAxisEdge();
        boolean boolean20 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot15.getRowRenderingOrder();
        categoryPlot15.clearRangeMarkers();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot15.axisChanged(axisChangeEvent23);
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        java.awt.Paint paint26 = categoryPlot15.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot3.addRangeMarker(marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        java.awt.Color color10 = java.awt.Color.white;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.ABSOLUTE", (int) (short) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getBaseShape();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        categoryAxis0.setFixedDimension(2.0d);
        categoryAxis0.setTickMarkOutsideLength((float) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (short) -1);
        lineAndShapeRenderer7.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        java.lang.Comparable comparable14 = categoryPlot10.getDomainCrosshairRowKey();
        categoryPlot10.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot10.removeDomainMarker((int) (byte) -1, marker18, layer19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = categoryPlot10.getDatasetRenderingOrder();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        java.awt.Font font24 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 43.0d);
        org.junit.Assert.assertNull(comparable14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        boolean boolean12 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot4);
        boolean boolean13 = categoryAxis0.isVisible();
        categoryAxis0.setFixedDimension((double) 'a');
        float float16 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        legendItem23.setToolTipText("");
        legendItem23.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint30 = lineAndShapeRenderer29.getBaseOutlinePaint();
        legendItem23.setLabelPaint(paint30);
        java.awt.Color color32 = java.awt.Color.DARK_GRAY;
        legendItem23.setLabelPaint((java.awt.Paint) color32);
        java.awt.Shape shape34 = legendItem23.getLine();
        java.awt.Paint paint35 = legendItem23.getFillPaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int12 = defaultCategoryDataset0.getColumnCount();
        java.util.List list13 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.addValue((double) (-256), (java.lang.Comparable) 1, (java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        legendItem23.setToolTipText("");
        legendItem23.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint30 = lineAndShapeRenderer29.getBaseOutlinePaint();
        legendItem23.setLabelPaint(paint30);
        int int32 = legendItem23.getDatasetIndex();
        java.lang.String str33 = legendItem23.getDescription();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        boolean boolean34 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Font font38 = lineAndShapeRenderer0.getItemLabelFont((int) '4', 8, false);
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 8, jFreeChart39, chartChangeEventType40);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Shape shape13 = renderAttributes1.getDefaultShape();
        java.awt.Paint paint16 = renderAttributes1.getItemFillPaint((-23167), 100);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int2 = keyedObjects2D0.getRowCount();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.lang.Comparable comparable4 = null;
        try {
            keyedObjects2D0.addObject((java.lang.Object) abstractCategoryDataset3, comparable4, (java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean17 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        lineAndShapeRenderer0.setSeriesCreateEntities(2, (java.lang.Boolean) true, true);
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        barRenderer0.setBase(18.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getSeriesNegativeItemLabelPosition(2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        categoryPlot4.setDomainAxisLocation(10, axisLocation8, true);
        categoryPlot0.setDomainAxisLocation(axisLocation8, false);
        java.lang.String str14 = axisLocation8.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str14.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        java.awt.Stroke stroke25 = legendItem23.getLineStroke();
        java.awt.Shape shape26 = legendItem23.getLine();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        categoryAxis0.setFixedDimension(2.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Font font14 = null;
        lineAndShapeRenderer5.setSeriesItemLabelFont((int) (byte) 0, font14, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke18 = categoryPlot17.getRangeZeroBaselineStroke();
        lineAndShapeRenderer5.setBaseStroke(stroke18, true);
        boolean boolean21 = categoryAxis0.equals((java.lang.Object) true);
        java.awt.Font font23 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 2);
        boolean boolean24 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        boolean boolean12 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot4);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer18.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setWeight((int) (short) -1);
        lineAndShapeRenderer18.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot21);
        java.lang.Comparable comparable25 = categoryPlot21.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot26 = categoryPlot21.getRootPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = null;
        categoryPlot21.setDrawingSupplier(drawingSupplier27, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot21.getDomainAxisEdge();
        try {
            double double31 = categoryAxis0.getCategoryStart(10, (-65536), rectangle2D17, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(comparable25);
        org.junit.Assert.assertNotNull(plot26);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot20.setDomainAxisLocation((int) (byte) 1, axisLocation26);
        java.awt.Stroke stroke28 = categoryPlot20.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(15, stroke28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer38.setUseFillPaint(true);
        boolean boolean41 = lineAndShapeRenderer38.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape43 = lineAndShapeRenderer38.lookupSeriesShape(0);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape43, (java.awt.Paint) color44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot46.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        int int50 = categoryPlot46.indexOf(categoryDataset49);
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape43, (org.jfree.chart.plot.Plot) categoryPlot46, "ItemLabelAnchor.INSIDE4", "{0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent55 = null;
        categoryPlot54.markerChanged(markerChangeEvent55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation59 = axisLocation58.getOpposite();
        categoryPlot54.setDomainAxisLocation(10, axisLocation58, true);
        categoryPlot54.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke64 = categoryPlot54.getOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color74 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setSeriesFillPaint((int) '#', (java.awt.Paint) color74);
        boolean boolean76 = lineAndShapeRenderer69.getBaseSeriesVisible();
        java.awt.Color color80 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setBasePaint((java.awt.Paint) color80);
        org.jfree.chart.LegendItem legendItem84 = lineAndShapeRenderer69.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape85 = lineAndShapeRenderer69.getBaseShape();
        java.awt.Stroke stroke86 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color87 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape85, stroke86, (java.awt.Paint) color87);
        java.awt.Color color89 = java.awt.Color.gray;
        legendItem88.setFillPaint((java.awt.Paint) color89);
        org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "ChartEntity: tooltip = null", "GradientPaintTransformType.VERTICAL", "", shape43, stroke64, (java.awt.Paint) color89);
        lineAndShapeRenderer0.setBaseShape(shape43);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition94 = null;
        try {
            lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((-16777216), itemLabelPosition94, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNull(legendItem84);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(color89);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setWeight((int) (short) -1);
        lineAndShapeRenderer11.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        java.lang.Comparable comparable18 = categoryPlot14.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot19 = categoryPlot14.getRootPlot();
        java.awt.Paint paint20 = categoryPlot14.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot14.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier21, false);
        boolean boolean24 = categoryPlot0.isRangeGridlinesVisible();
        int int25 = categoryPlot0.getDatasetCount();
        boolean boolean26 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = null;
        categoryPlot27.notifyListeners(plotChangeEvent28);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot27.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot27.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean33 = sortOrder31.equals((java.lang.Object) axisLocation32);
        categoryPlot0.setRowRenderingOrder(sortOrder31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        lineAndShapeRenderer35.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color59 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer54.setSeriesFillPaint((int) '#', (java.awt.Paint) color59);
        boolean boolean61 = lineAndShapeRenderer54.getBaseSeriesVisible();
        java.awt.Color color65 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer54.setBasePaint((java.awt.Paint) color65);
        org.jfree.chart.LegendItem legendItem69 = lineAndShapeRenderer54.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape70 = lineAndShapeRenderer54.getBaseShape();
        java.awt.Stroke stroke71 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color72 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape70, stroke71, (java.awt.Paint) color72);
        java.awt.Stroke stroke74 = legendItem73.getOutlineStroke();
        lineAndShapeRenderer35.setBaseStroke(stroke74, false);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer35, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNull(legendItem69);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        double double16 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace17);
        categoryPlot11.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot11.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot11.zoomDomainAxes((double) 1.0f, plotRenderingInfo27, point2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot11.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot11.setRangeMinorGridlineStroke(stroke32);
        renderAttributes1.setDefaultStroke(stroke32);
        java.awt.Font font35 = renderAttributes1.getDefaultLabelFont();
        try {
            java.awt.Stroke stroke37 = renderAttributes1.getSeriesOutlineStroke((-16646144));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(font35);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot3.removeDomainMarker((int) (byte) -1, marker11, layer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem29 = lineAndShapeRenderer14.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape30 = lineAndShapeRenderer14.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke49 = lineAndShapeRenderer35.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer35.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = lineAndShapeRenderer35.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition(0, itemLabelPosition53);
        java.awt.Stroke stroke55 = lineAndShapeRenderer14.getBaseOutlineStroke();
        java.awt.Stroke stroke57 = lineAndShapeRenderer14.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = lineAndShapeRenderer14.getLegendItems();
        boolean boolean59 = lineAndShapeRenderer14.getAutoPopulateSeriesPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation62 = null;
        boolean boolean63 = lineAndShapeRenderer14.removeAnnotation(categoryAnnotation62);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator64 = lineAndShapeRenderer14.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(stroke57);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator64);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setMaximumBarWidth(0.0d);
        boolean boolean8 = barRenderer0.isDrawBarOutline();
        try {
            barRenderer0.setSeriesItemLabelsVisible((-23167), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setRangeCrosshairValue(2.0d, true);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        legendItem23.setLineVisible(false);
        java.awt.Shape shape27 = legendItem23.getLine();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis0.setUpperMargin((double) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        java.awt.Paint paint12 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot8.getRangeAxisEdge(8);
        boolean boolean15 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot8.getDatasetGroup();
        boolean boolean17 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot8);
        org.jfree.chart.plot.Plot plot18 = categoryAxis0.getPlot();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 15, "");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (-6.0d), (double) (byte) 100, (double) (short) 10);
        categoryAxis0.setLabelInsets(rectangleInsets26, false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(plot18);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint18 = lineAndShapeRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 10, false);
        boolean boolean23 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation((int) (short) 1);
        java.awt.Font font15 = null;
        try {
            categoryPlot0.setNoDataMessageFont(font15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        java.awt.Font font23 = lineAndShapeRenderer0.lookupLegendTextFont(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setWeight((int) (short) -1);
        categoryPlot25.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        boolean boolean39 = lineAndShapeRenderer32.getBaseSeriesVisible();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setBasePaint((java.awt.Paint) color43);
        org.jfree.chart.LegendItem legendItem47 = lineAndShapeRenderer32.getLegendItem(2, (int) (byte) 1);
        categoryPlot25.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer32, false);
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer32.setSeriesItemLabelFont((int) 'a', font51);
        lineAndShapeRenderer0.setLegendTextFont(15, font51);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator54 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator54);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(legendItem47);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        java.awt.Paint paint17 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = lineAndShapeRenderer0.getSeriesItemLabelGenerator((int) 'a');
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 0, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean4 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.jfree.data.KeyedObjects2D keyedObjects2D9 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        lineAndShapeRenderer10.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = lineAndShapeRenderer10.getLegendItemLabelGenerator();
        java.awt.Paint paint16 = lineAndShapeRenderer10.lookupSeriesFillPaint((int) (short) 1);
        java.awt.Paint paint18 = lineAndShapeRenderer10.lookupSeriesFillPaint((int) ' ');
        keyedObjects2D9.setObject((java.lang.Object) lineAndShapeRenderer10, (java.lang.Comparable) 10.0f, (java.lang.Comparable) (-1));
        boolean boolean22 = lineAndShapeRenderer10.getBaseSeriesVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer24.setSeriesFillPaint((int) '#', (java.awt.Paint) color29);
        boolean boolean31 = lineAndShapeRenderer24.getBaseSeriesVisible();
        java.awt.Color color35 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer24.setBasePaint((java.awt.Paint) color35);
        java.awt.Stroke stroke38 = lineAndShapeRenderer24.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer24.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer24.getSeriesNegativeItemLabelPosition((int) '4');
        double double43 = itemLabelPosition42.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor44 = itemLabelPosition42.getRotationAnchor();
        lineAndShapeRenderer10.setSeriesPositiveItemLabelPosition(0, itemLabelPosition42, false);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(100, itemLabelPosition42);
        java.lang.Boolean boolean49 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertNull(boolean49);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        java.lang.String str8 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        int int10 = categoryPlot0.getRendererCount();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot0.addRangeMarker(128, marker12, layer13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        categoryPlot1.notifyListeners(plotChangeEvent2);
        categoryPlot1.clearAnnotations();
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) categoryPlot1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setSeriesFillPaint((int) '#', (java.awt.Paint) color16);
        boolean boolean18 = lineAndShapeRenderer11.getBaseSeriesVisible();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setBasePaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem26 = lineAndShapeRenderer11.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape27 = lineAndShapeRenderer11.getBaseShape();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color29 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape27, stroke28, (java.awt.Paint) color29);
        java.lang.String str31 = legendItem30.getDescription();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem30.setFillPaint((java.awt.Paint) color32);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator37 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color32, (float) (short) 100, 3, (double) (short) 100);
        int int38 = defaultShadowGenerator37.getDistance();
        int int39 = defaultShadowGenerator37.getShadowSize();
        categoryPlot1.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator37);
        java.awt.Color color41 = defaultShadowGenerator37.getShadowColor();
        int int42 = defaultShadowGenerator37.getShadowSize();
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        legendItem23.setLineVisible(false);
        java.lang.String str27 = legendItem23.getDescription();
        int int28 = legendItem23.getSeriesIndex();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        categoryAxis0.setFixedDimension(2.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Font font14 = null;
        lineAndShapeRenderer5.setSeriesItemLabelFont((int) (byte) 0, font14, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke18 = categoryPlot17.getRangeZeroBaselineStroke();
        lineAndShapeRenderer5.setBaseStroke(stroke18, true);
        boolean boolean21 = categoryAxis0.equals((java.lang.Object) true);
        java.awt.Font font23 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 2);
        java.awt.Stroke stroke24 = categoryAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.panDomainAxes((double) 3, plotRenderingInfo17, point2D18);
        boolean boolean20 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            boolean boolean23 = categoryPlot0.removeRangeMarker(marker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer1.setSeriesFillPaint((int) '#', (java.awt.Paint) color6);
        java.awt.Paint paint11 = lineAndShapeRenderer1.getItemFillPaint(1, 15, false);
        renderAttributes0.setDefaultLabelPaint(paint11);
        java.awt.Paint paint15 = renderAttributes0.getItemPaint(0, (int) (short) -1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        double double4 = categoryAxis0.getUpperMargin();
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.getColor("ChartEntity: tooltip = null", color7);
        java.awt.Color color9 = java.awt.Color.getColor("ChartEntity: tooltip = null", color7);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot11.getRangeAxisEdge();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setUseFillPaint(true);
        boolean boolean14 = lineAndShapeRenderer11.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        int int20 = categoryPlot16.indexOf(categoryDataset19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot16.notifyListeners(plotChangeEvent21);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot16.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer24.setSeriesFillPaint((int) '#', (java.awt.Paint) color29);
        boolean boolean31 = lineAndShapeRenderer24.getBaseSeriesVisible();
        java.awt.Font font33 = null;
        lineAndShapeRenderer24.setSeriesItemLabelFont((int) (byte) 0, font33, false);
        java.awt.Stroke stroke39 = lineAndShapeRenderer24.getItemStroke(2, 0, false);
        java.awt.Stroke stroke43 = lineAndShapeRenderer24.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot16.setRangeCrosshairStroke(stroke43);
        lineAndShapeRenderer11.setSeriesOutlineStroke((int) (byte) 10, stroke43, false);
        renderAttributes1.setDefaultStroke(stroke43);
        java.lang.Boolean boolean48 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Shape shape49 = renderAttributes1.getDefaultShape();
        java.awt.Paint paint52 = renderAttributes1.getItemFillPaint((int) (byte) 1, 0);
        java.awt.Shape shape55 = renderAttributes1.getItemShape(15, (int) (short) 100);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(boolean48);
        org.junit.Assert.assertNull(shape49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(shape55);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge(8);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getWeight();
        java.awt.Paint paint4 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Paint paint14 = null;
        try {
            renderAttributes1.setSeriesFillPaint((int) (byte) -1, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Paint paint7 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Shape shape15 = lineAndShapeRenderer0.getItemShape((int) (short) 10, 0, true);
        lineAndShapeRenderer0.setBaseShapesFilled(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Color color1 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE12");
        org.junit.Assert.assertNull(color1);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight(99.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Paint paint5 = renderAttributes1.getItemFillPaint((int) (byte) -1, 0);
        java.awt.Shape shape8 = renderAttributes1.getItemShape((-65536), (-1));
        java.awt.Paint paint9 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint10 = renderAttributes1.getDefaultFillPaint();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot9.notifyListeners(plotChangeEvent10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot9.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint3 = renderAttributes1.getSeriesOutlinePaint((int) (byte) 10);
        boolean boolean4 = renderAttributes1.getAllowNull();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        renderAttributes1.setDefaultPaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setSeriesFillPaint((int) '#', (java.awt.Paint) color16);
        renderAttributes9.setSeriesFillPaint(10, (java.awt.Paint) color16);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot19.markerChanged(markerChangeEvent20);
        int int22 = categoryPlot19.getCrosshairDatasetIndex();
        float float23 = categoryPlot19.getForegroundAlpha();
        double double24 = categoryPlot19.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace25);
        categoryPlot19.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot19.clearRangeMarkers();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot19.zoomDomainAxes((double) 1.0f, plotRenderingInfo35, point2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot19.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot19.setRangeMinorGridlineStroke(stroke40);
        renderAttributes9.setDefaultStroke(stroke40);
        renderAttributes1.setSeriesStroke((int) (byte) 0, stroke40);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        int int5 = keyedObjects0.getItemCount();
        try {
            java.lang.Object obj7 = keyedObjects0.getObject((java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        java.lang.Object obj7 = null;
        boolean boolean8 = chartEntity6.equals(obj7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        double double7 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot2.getAxisOffset();
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) rectangleInsets10);
        int int13 = keyedObjects2D0.getRowIndex((java.lang.Comparable) true);
        int int14 = keyedObjects2D0.getColumnCount();
        int int15 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        int int5 = keyedObjects0.getItemCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        categoryPlot8.notifyListeners(plotChangeEvent9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot8.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot8.setRangeAxisLocation(15, axisLocation13);
        keyedObjects0.insertValue(0, (java.lang.Comparable) 0L, (java.lang.Object) axisLocation13);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint6 = barRenderer0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int2 = keyedObjects2D0.getRowCount();
        org.jfree.data.KeyedObjects keyedObjects3 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        java.awt.Paint paint7 = categoryPlot4.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getRangeAxisEdge();
        boolean boolean9 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        keyedObjects3.sortByKeys(sortOrder10);
        keyedObjects2D0.addObject((java.lang.Object) keyedObjects3, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 4.0d);
        try {
            keyedObjects2D0.removeColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.lang.Comparable comparable8 = categoryPlot0.getDomainCrosshairRowKey();
        java.util.List list9 = categoryPlot0.getAnnotations();
        categoryPlot0.setNoDataMessage("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.plot.Plot plot12 = categoryPlot0.getRootPlot();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        plot12.axisChanged(axisChangeEvent13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        lineAndShapeRenderer0.setSeriesShapesFilled(255, false);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.data.Range range38 = lineAndShapeRenderer0.findRangeBounds(categoryDataset37);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(8, (java.lang.Boolean) false);
        java.awt.Font font43 = lineAndShapeRenderer0.getSeriesItemLabelFont(128);
        java.awt.Stroke stroke44 = lineAndShapeRenderer0.getBaseStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNull(font43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.lang.Object obj4 = categoryPlot0.clone();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("GradientPaintTransformType.VERTICAL");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        categoryPlot3.markerChanged(markerChangeEvent4);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        float float7 = categoryPlot3.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity8 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot3);
        java.awt.Shape shape9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        plotEntity8.setArea(shape9);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) shape9);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        categoryPlot18.markerChanged(markerChangeEvent19);
        int int21 = categoryPlot18.getCrosshairDatasetIndex();
        float float22 = categoryPlot18.getForegroundAlpha();
        double double23 = categoryPlot18.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot18.setFixedRangeAxisSpace(axisSpace24);
        categoryPlot18.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot18.clearRangeMarkers();
        categoryPlot18.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot18.getRangeAxisEdge(10);
        try {
            double double33 = categoryAxis1.getCategorySeriesMiddle((-83), 0, 0, (-23167), (double) 4, rectangle2D17, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        int int10 = categoryPlot6.indexOf(categoryDataset9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        categoryPlot6.notifyListeners(plotChangeEvent11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer16.setUseFillPaint(true);
        boolean boolean19 = lineAndShapeRenderer16.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer23.setUseFillPaint(true);
        boolean boolean26 = lineAndShapeRenderer23.getAutoPopulateSeriesFillPaint();
        boolean boolean27 = lineAndShapeRenderer23.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setSeriesFillPaint((int) '#', (java.awt.Paint) color33);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setBasePaint((java.awt.Paint) color39);
        java.awt.Stroke stroke42 = lineAndShapeRenderer28.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer28.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer28.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryPlot48.markerChanged(markerChangeEvent49);
        int int51 = categoryPlot48.getCrosshairDatasetIndex();
        float float52 = categoryPlot48.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation54 = null;
        categoryPlot48.setDomainAxisLocation((int) (byte) 1, axisLocation54);
        java.awt.Stroke stroke56 = categoryPlot48.getOutlineStroke();
        lineAndShapeRenderer28.setSeriesOutlineStroke(15, stroke56);
        boolean boolean58 = lineAndShapeRenderer28.getBaseShapesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray59 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer23, lineAndShapeRenderer28 };
        categoryPlot20.setRenderers(categoryItemRendererArray59);
        categoryPlot6.setRenderers(categoryItemRendererArray59);
        categoryPlot0.setRenderers(categoryItemRendererArray59);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 1.0f + "'", float52 == 1.0f);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray59);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Paint paint4 = lineAndShapeRenderer0.getBaseOutlinePaint();
        boolean boolean5 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setSeriesFillPaint((int) '#', (java.awt.Paint) color11);
        boolean boolean13 = lineAndShapeRenderer6.getBaseSeriesVisible();
        java.awt.Color color17 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setBasePaint((java.awt.Paint) color17);
        java.awt.Stroke stroke20 = lineAndShapeRenderer6.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer6.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = itemLabelPosition24.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor26 = itemLabelPosition24.getItemLabelAnchor();
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition24, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = lineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertNotNull(itemLabelAnchor26);
        org.junit.Assert.assertNull(categoryPlot29);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot7.getRangeAxisEdge();
        categoryPlot7.setWeight((-16646144));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint5 = lineAndShapeRenderer0.getSeriesFillPaint((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemOutlineStroke(0, (int) (byte) 100, false);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer0.getLegendItem(10, (-16777216));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot7.getRangeAxisEdge();
        categoryPlot7.setCrosshairDatasetIndex((int) (short) 100);
        int int11 = categoryPlot7.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        try {
            boolean boolean4 = categoryPlot0.removeAnnotation(categoryAnnotation2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Stroke stroke14 = renderAttributes1.getSeriesStroke(3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        java.lang.Comparable comparable59 = categoryItemEntity58.getColumnKey();
        java.lang.String str60 = categoryItemEntity58.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + "Category Plot" + "'", comparable59.equals("Category Plot"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setBase(194.0d);
        java.awt.Paint paint8 = null;
        try {
            barRenderer0.setBaseFillPaint(paint8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int int3 = java.awt.Color.HSBtoRGB((float) ' ', (float) (-256), (float) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("GradientPaintTransformType.VERTICAL");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (byte) 10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.lang.String str25 = legendItem24.getDescription();
        legendItem24.setToolTipText("");
        legendItem24.setSeriesKey((java.lang.Comparable) 43.0d);
        boolean boolean30 = sortOrder0.equals((java.lang.Object) 43.0d);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, (double) 255, rectangle2D13, renderingSource14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace16, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setUseFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape9 = lineAndShapeRenderer4.lookupSeriesShape(0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape9, (java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        int int16 = categoryPlot12.indexOf(categoryDataset15);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot12, "ItemLabelAnchor.INSIDE4", "{0}");
        java.lang.String str20 = plotEntity19.getURLText();
        java.lang.Object obj21 = plotEntity19.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{0}" + "'", str20.equals("{0}"));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        java.awt.Font font3 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (short) 1, 0.05d, (double) (byte) 0);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.setSelected(100, (int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        int int8 = lineAndShapeRenderer0.getColumnCount();
        boolean boolean11 = lineAndShapeRenderer0.getItemVisible(15, (int) ' ');
        lineAndShapeRenderer0.setSeriesVisible(1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setBase(194.0d);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getSeriesItemLabelGenerator(4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultCategoryDataset10.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        java.awt.Paint paint15 = categoryPlot12.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        boolean boolean17 = defaultCategoryDataset10.hasListener((java.util.EventListener) categoryPlot12);
        defaultCategoryDataset10.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.Range range23 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, false);
        java.lang.Comparable comparable26 = null;
        try {
            defaultCategoryDataset10.addValue(0.0d, (java.lang.Comparable) false, comparable26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        boolean boolean45 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        int int46 = lineAndShapeRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        boolean boolean29 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setWeight(8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer3.getLegendItemURLGenerator();
        boolean boolean11 = lineAndShapeRenderer3.isSeriesItemLabelsVisible((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (10.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomDomainAxes((double) (-65536), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        lineAndShapeRenderer14.setBaseToolTipGenerator(categoryToolTipGenerator15, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = lineAndShapeRenderer14.getLegendItemLabelGenerator();
        java.awt.Paint paint20 = lineAndShapeRenderer14.lookupSeriesFillPaint((int) (short) 1);
        java.awt.Paint paint22 = lineAndShapeRenderer14.lookupSeriesFillPaint((int) ' ');
        categoryPlot3.setOutlinePaint(paint22);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.0d) + "'", double2 == (-8.0d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation((int) (short) 1);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) 0, false);
        categoryPlot0.setAnchorValue((double) 'a', false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        float float4 = categoryAxis0.getMinorTickMarkOutsideLength();
        org.jfree.chart.plot.Plot plot5 = categoryAxis0.getPlot();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setBase(194.0d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        lineAndShapeRenderer11.setSeriesPaint(100, (java.awt.Paint) color13);
        barRenderer0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color13, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boolean boolean19 = standardCategorySeriesLabelGenerator17.equals((java.lang.Object) "ItemLabelAnchor.OUTSIDE12");
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        int int22 = lineAndShapeRenderer19.getColumnCount();
        java.awt.Paint paint23 = lineAndShapeRenderer19.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint23, true);
        boolean boolean26 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Shape shape30 = lineAndShapeRenderer0.getItemShape((int) (short) -1, (int) '4', true);
        java.awt.Paint paint32 = lineAndShapeRenderer0.lookupSeriesPaint(8);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getRed();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setSeriesFillPaint((int) '#', (java.awt.Paint) color11);
        boolean boolean13 = lineAndShapeRenderer6.getBaseSeriesVisible();
        java.awt.Color color17 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setBasePaint((java.awt.Paint) color17);
        org.jfree.chart.LegendItem legendItem21 = lineAndShapeRenderer6.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape22 = lineAndShapeRenderer6.getBaseShape();
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color24 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape22, stroke23, (java.awt.Paint) color24);
        java.lang.String str26 = legendItem25.getDescription();
        legendItem25.setToolTipText("");
        legendItem25.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint32 = lineAndShapeRenderer31.getBaseOutlinePaint();
        legendItem25.setLabelPaint(paint32);
        java.awt.Color color34 = java.awt.Color.DARK_GRAY;
        legendItem25.setLabelPaint((java.awt.Paint) color34);
        java.awt.color.ColorSpace colorSpace36 = color34.getColorSpace();
        float[] floatArray43 = new float[] { 3, 1, (-1), 0.0f, 8, 255 };
        float[] floatArray44 = color0.getColorComponents(colorSpace36, floatArray43);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace36);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer0.getBarPainter();
        barRenderer0.setSeriesVisibleInLegend(255, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator10, false);
        double double13 = barRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(barPainter6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        categoryPlot3.setDrawingSupplier(drawingSupplier9, false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        try {
            categoryPlot3.setRangeAxisLocation((-256), axisLocation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean17 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        lineAndShapeRenderer0.setSeriesCreateEntities(2, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setUseFillPaint(true);
        boolean boolean9 = lineAndShapeRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape11 = lineAndShapeRenderer6.lookupSeriesShape(0);
        lineAndShapeRenderer5.setBaseLegendShape(shape11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5, false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        java.lang.Comparable comparable8 = null;
        try {
            int int9 = defaultCategoryDataset0.getRowIndex(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint2 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint3 = renderAttributes1.getDefaultOutlinePaint();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        java.awt.Stroke stroke21 = lineAndShapeRenderer7.lookupSeriesStroke((int) (short) 10);
        boolean boolean22 = lineAndShapeRenderer7.getDrawOutlines();
        java.awt.Paint paint24 = lineAndShapeRenderer7.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer26.setUseFillPaint(true);
        int int29 = lineAndShapeRenderer26.getColumnCount();
        java.awt.Paint paint30 = lineAndShapeRenderer26.getBaseOutlinePaint();
        lineAndShapeRenderer7.setSeriesItemLabelPaint((int) '4', paint30, true);
        renderAttributes1.setSeriesPaint((int) '4', paint30);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        boolean boolean16 = lineAndShapeRenderer0.getUseSeriesOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryPlot17);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        boolean boolean28 = legendItem23.isShapeVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup30 = defaultCategoryDataset29.getGroup();
        boolean boolean31 = legendItem23.equals((java.lang.Object) datasetGroup30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType33 = rectangleInsets32.getUnitType();
        double double35 = rectangleInsets32.calculateBottomOutset((double) (-1L));
        boolean boolean36 = datasetGroup30.equals((java.lang.Object) rectangleInsets32);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetGroup30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(unitType33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        double double19 = itemLabelPosition18.getAngle();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        lineAndShapeRenderer20.setBaseToolTipGenerator(categoryToolTipGenerator21, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer20.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        java.awt.Font font29 = null;
        lineAndShapeRenderer20.setSeriesItemLabelFont((int) (byte) 100, font29);
        java.awt.Stroke stroke31 = lineAndShapeRenderer20.getBaseOutlineStroke();
        boolean boolean32 = itemLabelPosition18.equals((java.lang.Object) lineAndShapeRenderer20);
        double double33 = itemLabelPosition18.getAngle();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (-6.0d), (double) (byte) 100, (double) (short) 10);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateRightOutset(0.0d);
        double double9 = rectangleInsets4.calculateTopOutset(1.0d);
        double double11 = rectangleInsets4.extendWidth((double) 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.0d + "'", double11 == 5.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str12 = categoryAxis11.getLabelToolTip();
        categoryAxis11.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis11.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis11.setUpperMargin((double) '4');
        java.awt.Stroke stroke19 = categoryAxis11.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke19, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.clearRangeMarkers((-256));
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        int int4 = lineAndShapeRenderer0.getDefaultEntityRadius();
        double double5 = lineAndShapeRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        int int10 = categoryPlot0.getRendererCount();
        java.util.List list11 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        double double4 = categoryAxis0.getUpperMargin();
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.getColor("ChartEntity: tooltip = null", color7);
        java.awt.Color color9 = java.awt.Color.getColor("ChartEntity: tooltip = null", color7);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color7);
        java.lang.String str11 = color7.toString();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str11.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        boolean boolean12 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot4);
        boolean boolean13 = categoryAxis0.isVisible();
        categoryAxis0.setFixedDimension((double) 'a');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = null;
        try {
            categoryAxis0.setTickLabelInsets(rectangleInsets17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        java.awt.Paint paint17 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        boolean boolean21 = lineAndShapeRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = categoryPlot0.getNoDataMessagePaint();
        java.lang.Comparable comparable10 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset4.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        java.awt.Paint paint9 = categoryPlot6.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge();
        boolean boolean11 = defaultCategoryDataset4.hasListener((java.util.EventListener) categoryPlot6);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState12 = defaultCategoryDataset4.getSelectionState();
        defaultCategoryDataset4.setValue((double) (-1L), (java.lang.Comparable) 0, (java.lang.Comparable) 2);
        org.jfree.data.Range range18 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState12);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=128]");
        lineAndShapeRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator13);
        java.awt.Paint paint18 = lineAndShapeRenderer0.getItemOutlinePaint((int) '4', 3, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        double double33 = categoryAxis0.getCategoryMargin();
        double double34 = categoryAxis0.getCategoryMargin();
        java.awt.Color color38 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color38);
        categoryAxis0.setLowerMargin((double) (-23167));
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        categoryPlot3.setOutlineVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer11.setShadowVisible(false);
        double double14 = barRenderer11.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer17.setSeriesFillPaint((int) '#', (java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer17.getBaseSeriesVisible();
        java.awt.Color color28 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer17.setBasePaint((java.awt.Paint) color28);
        java.awt.Stroke stroke31 = lineAndShapeRenderer17.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        boolean boolean39 = lineAndShapeRenderer32.getBaseSeriesVisible();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setBasePaint((java.awt.Paint) color43);
        java.awt.Stroke stroke46 = lineAndShapeRenderer32.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer32.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = lineAndShapeRenderer32.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer17.setBaseNegativeItemLabelPosition(itemLabelPosition50);
        barRenderer11.setNegativeItemLabelPositionFallback(itemLabelPosition50);
        int int53 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot3.removeDomainMarker((int) (byte) -1, marker11, layer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot3.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot3.getRangeAxisLocation();
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("PlotEntity: tooltip = null");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.ShadowGenerator shadowGenerator9 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        int int15 = categoryPlot11.indexOf(categoryDataset14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        categoryPlot11.notifyListeners(plotChangeEvent16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer21.setUseFillPaint(true);
        boolean boolean24 = lineAndShapeRenderer21.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryPlot25.getDataset((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer28.setUseFillPaint(true);
        boolean boolean31 = lineAndShapeRenderer28.getAutoPopulateSeriesFillPaint();
        boolean boolean32 = lineAndShapeRenderer28.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color38 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer33.setSeriesFillPaint((int) '#', (java.awt.Paint) color38);
        boolean boolean40 = lineAndShapeRenderer33.getBaseSeriesVisible();
        java.awt.Color color44 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer33.setBasePaint((java.awt.Paint) color44);
        java.awt.Stroke stroke47 = lineAndShapeRenderer33.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer33.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = lineAndShapeRenderer33.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent54 = null;
        categoryPlot53.markerChanged(markerChangeEvent54);
        int int56 = categoryPlot53.getCrosshairDatasetIndex();
        float float57 = categoryPlot53.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation59 = null;
        categoryPlot53.setDomainAxisLocation((int) (byte) 1, axisLocation59);
        java.awt.Stroke stroke61 = categoryPlot53.getOutlineStroke();
        lineAndShapeRenderer33.setSeriesOutlineStroke(15, stroke61);
        boolean boolean63 = lineAndShapeRenderer33.getBaseShapesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray64 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer28, lineAndShapeRenderer33 };
        categoryPlot25.setRenderers(categoryItemRendererArray64);
        categoryPlot11.setRenderers(categoryItemRendererArray64);
        categoryPlot0.setRenderers(categoryItemRendererArray64);
        org.jfree.chart.util.SortOrder sortOrder68 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.setBackgroundImageAlignment(10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 1.0f + "'", float57 == 1.0f);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray64);
        org.junit.Assert.assertNotNull(sortOrder68);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        boolean boolean9 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            boolean boolean14 = categoryPlot0.removeRangeMarker(0, marker11, layer12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        barRenderer0.setShadowXOffset((double) 1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer8.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer8.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        barRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition15, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        categoryPlot18.markerChanged(markerChangeEvent19);
        int int21 = categoryPlot18.getCrosshairDatasetIndex();
        float float22 = categoryPlot18.getForegroundAlpha();
        double double23 = categoryPlot18.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes25 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint26 = renderAttributes25.getDefaultOutlinePaint();
        categoryPlot18.setNoDataMessagePaint(paint26);
        java.awt.Paint paint28 = categoryPlot18.getDomainCrosshairPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer29.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.setWeight((int) (short) -1);
        lineAndShapeRenderer29.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot32);
        java.lang.Comparable comparable36 = categoryPlot32.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot37 = categoryPlot32.getRootPlot();
        java.awt.Paint paint38 = categoryPlot32.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier39 = categoryPlot32.getDrawingSupplier();
        categoryPlot18.setDrawingSupplier(drawingSupplier39, false);
        boolean boolean42 = categoryPlot18.isRangeGridlinesVisible();
        int int43 = categoryPlot18.getDatasetCount();
        boolean boolean44 = categoryPlot18.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        categoryPlot45.markerChanged(markerChangeEvent46);
        int int48 = categoryPlot45.getCrosshairDatasetIndex();
        float float49 = categoryPlot45.getForegroundAlpha();
        double double50 = categoryPlot45.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        categoryPlot45.setFixedRangeAxisSpace(axisSpace51);
        categoryPlot45.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot45.clearRangeMarkers();
        categoryPlot45.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = categoryPlot45.getRangeAxisEdge(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent60 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot45);
        categoryPlot18.notifyListeners(plotChangeEvent60);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType62 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        plotChangeEvent60.setType(chartChangeEventType62);
        boolean boolean64 = itemLabelPosition15.equals((java.lang.Object) chartChangeEventType62);
        java.lang.String str65 = chartChangeEventType62.toString();
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(comparable36);
        org.junit.Assert.assertNotNull(plot37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(drawingSupplier39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 1.0f + "'", float49 == 1.0f);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(chartChangeEventType62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str65.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 1, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        java.lang.Object obj5 = chartChangeEvent3.getSource();
        org.junit.Assert.assertNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (short) 1 + "'", obj5.equals((short) 1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setShadowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        int int7 = categoryPlot4.getCrosshairDatasetIndex();
        float float8 = categoryPlot4.getForegroundAlpha();
        double double9 = categoryPlot4.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace10);
        categoryPlot4.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot4.clearRangeMarkers();
        categoryPlot4.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot4.getRangeAxisEdge(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer20.setUseFillPaint(true);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer20.setSeriesFillPaint((int) (short) 100, (java.awt.Paint) color24, true);
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color24);
        boolean boolean28 = barRenderer1.equals((java.lang.Object) color24);
        java.awt.Color color29 = java.awt.Color.getColor("Category Plot", color24);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setUseOutlinePaint(true);
        lineAndShapeRenderer0.setSeriesShapesFilled(192, (java.lang.Boolean) true);
        boolean boolean20 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "java.awt.Color[r=128,g=0,b=128]", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        java.awt.Color color27 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color27);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = categoryPlot0.removeDomainMarker((-256), marker30, layer31, false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot3.getOrientation();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot3.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot3.getInsets();
        java.awt.Stroke stroke13 = categoryPlot3.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        org.jfree.chart.text.TextAnchor textAnchor18 = itemLabelPosition17.getRotationAnchor();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = lineAndShapeRenderer9.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer9.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer9.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke32 = categoryPlot29.getOutlineStroke();
        lineAndShapeRenderer3.setBaseStroke(stroke32, false);
        try {
            java.awt.Shape shape38 = lineAndShapeRenderer3.getItemShape((-256), (int) ' ', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.getSeriesStroke((int) (short) 10);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.addValue((double) 'a', (java.lang.Comparable) (-6.0d), (java.lang.Comparable) (-256));
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        boolean boolean16 = lineAndShapeRenderer0.getUseSeriesOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer18.setUseFillPaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer18.getPositiveItemLabelPosition(4, 0, false);
        try {
            lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((-65536), itemLabelPosition24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double4 = rectangleInsets2.calculateTopOutset((double) 10.0f);
        categoryAxis0.setTickLabelInsets(rectangleInsets2);
        categoryAxis0.setVisible(false);
        java.lang.String str8 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Paint paint44 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) '#', (java.lang.Boolean) true);
        lineAndShapeRenderer0.setSeriesVisible(4, (java.lang.Boolean) true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes52 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint53 = renderAttributes52.getDefaultOutlinePaint();
        java.awt.Shape shape54 = renderAttributes52.getDefaultShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint56 = lineAndShapeRenderer55.getBaseOutlinePaint();
        renderAttributes52.setDefaultPaint(paint56);
        lineAndShapeRenderer0.setBasePaint(paint56);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNull(shape54);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxisForDataset(8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Paint paint42 = lineAndShapeRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity11 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "CategoryAnchor.END", "GradientPaintTransformType.VERTICAL", categoryDataset8, (java.lang.Comparable) "AxisLocation.TOP_OR_LEFT", (java.lang.Comparable) 190.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem23.setFillPaint((java.awt.Paint) color25);
        legendItem23.setShapeVisible(false);
        legendItem23.setSeriesKey((java.lang.Comparable) (byte) -1);
        java.awt.Color color31 = java.awt.Color.darkGray;
        boolean boolean32 = legendItem23.equals((java.lang.Object) color31);
        java.awt.Paint paint33 = legendItem23.getLabelPaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(paint33);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot9.notifyListeners(plotChangeEvent10);
        categoryPlot9.clearAnnotations();
        java.awt.Paint paint13 = categoryPlot9.getNoDataMessagePaint();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot9);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot9.getOrientation();
        categoryPlot9.clearRangeAxes();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        boolean boolean12 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot4);
        boolean boolean13 = categoryAxis0.isVisible();
        categoryAxis0.setFixedDimension((double) 'a');
        categoryAxis0.setLabel("AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        int int5 = keyedObjects0.getItemCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        float float12 = categoryPlot8.getForegroundAlpha();
        double double13 = categoryPlot8.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint16 = renderAttributes15.getDefaultOutlinePaint();
        categoryPlot8.setNoDataMessagePaint(paint16);
        java.awt.Paint paint18 = categoryPlot8.getDomainCrosshairPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setWeight((int) (short) -1);
        lineAndShapeRenderer19.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot22);
        java.lang.Comparable comparable26 = categoryPlot22.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot27 = categoryPlot22.getRootPlot();
        java.awt.Paint paint28 = categoryPlot22.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = categoryPlot22.getDrawingSupplier();
        categoryPlot8.setDrawingSupplier(drawingSupplier29, false);
        boolean boolean32 = categoryPlot8.isRangeGridlinesVisible();
        int int33 = categoryPlot8.getDatasetCount();
        boolean boolean34 = categoryPlot8.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot35.markerChanged(markerChangeEvent36);
        int int38 = categoryPlot35.getCrosshairDatasetIndex();
        float float39 = categoryPlot35.getForegroundAlpha();
        double double40 = categoryPlot35.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot35.setFixedRangeAxisSpace(axisSpace41);
        categoryPlot35.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot35.clearRangeMarkers();
        categoryPlot35.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent50 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot35);
        categoryPlot8.notifyListeners(plotChangeEvent50);
        org.jfree.chart.plot.Plot plot52 = plotChangeEvent50.getPlot();
        try {
            keyedObjects0.insertValue((-256), (java.lang.Comparable) (-1.0d), (java.lang.Object) plotChangeEvent50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(comparable26);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(plot52);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        categoryAxis10.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis10.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis10.setUpperMargin((double) '4');
        java.awt.Stroke stroke18 = categoryAxis10.getTickMarkStroke();
        categoryPlot3.setDomainAxis(categoryAxis10);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot3.setFixedDomainAxisSpace(axisSpace20);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.KeyedObjects2D keyedObjects2D3 = new org.jfree.data.KeyedObjects2D();
        int int4 = keyedObjects2D3.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot5.markerChanged(markerChangeEvent6);
        int int8 = categoryPlot5.getCrosshairDatasetIndex();
        float float9 = categoryPlot5.getForegroundAlpha();
        double double10 = categoryPlot5.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot5.getAxisOffset();
        boolean boolean14 = keyedObjects2D3.equals((java.lang.Object) rectangleInsets13);
        double double15 = rectangleInsets13.getTop();
        categoryPlot0.setInsets(rectangleInsets13);
        boolean boolean17 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=1]", "org.jfree.chart.event.ChartChangeEvent[source=1]", "-3,-3,3,3", "", shape4, (java.awt.Paint) color5);
        java.lang.String str7 = color5.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=64,b=64]" + "'", str7.equals("java.awt.Color[r=255,g=64,b=64]"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.clearSeriesPaints(false);
        java.awt.Shape shape6 = null;
        lineAndShapeRenderer0.setLegendShape(1, shape6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.lang.String str25 = legendItem24.getDescription();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem24.setFillPaint((java.awt.Paint) color26);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color26, (float) (short) 100, 3, (double) (short) 100);
        int int32 = defaultShadowGenerator31.getDistance();
        java.awt.Color color33 = defaultShadowGenerator31.getShadowColor();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getColumnKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double4 = rectangleInsets2.calculateTopOutset((double) 10.0f);
        categoryAxis0.setTickLabelInsets(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets6);
        double double9 = rectangleInsets6.extendWidth((double) 10);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 26.0d + "'", double9 == 26.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-3,-3,3,3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        boolean boolean9 = categoryPlot3.isSubplot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot3.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setShadowVisible(false);
        categoryPlot0.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        java.awt.Paint paint18 = barRenderer13.getSeriesOutlinePaint((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot19.markerChanged(markerChangeEvent20);
        int int22 = categoryPlot19.getCrosshairDatasetIndex();
        float float23 = categoryPlot19.getForegroundAlpha();
        double double24 = categoryPlot19.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace25);
        categoryPlot19.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean30 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot19.getRenderer();
        boolean boolean32 = barRenderer13.equals((java.lang.Object) categoryPlot19);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot19.setDomainAxis((int) (short) 10, categoryAxis34);
        boolean boolean36 = categoryAxis34.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot3.removeDomainMarker((int) (byte) -1, marker11, layer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot3.getDatasetRenderingOrder();
        java.lang.String str15 = datasetRenderingOrder14.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryPlot16.markerChanged(markerChangeEvent17);
        int int19 = categoryPlot16.getCrosshairDatasetIndex();
        float float20 = categoryPlot16.getForegroundAlpha();
        double double21 = categoryPlot16.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes23 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint24 = renderAttributes23.getDefaultOutlinePaint();
        categoryPlot16.setNoDataMessagePaint(paint24);
        int int26 = categoryPlot16.getRendererCount();
        boolean boolean27 = datasetRenderingOrder14.equals((java.lang.Object) int26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer31.setUseFillPaint(true);
        boolean boolean34 = lineAndShapeRenderer31.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        boolean boolean36 = lineAndShapeRenderer31.getDrawOutlines();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_BLUE;
        lineAndShapeRenderer31.setBaseItemLabelPaint((java.awt.Paint) color37);
        boolean boolean39 = datasetRenderingOrder14.equals((java.lang.Object) color37);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str15.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        double double7 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot2.getAxisOffset();
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) rectangleInsets10);
        int int13 = keyedObjects2D0.getRowIndex((java.lang.Comparable) true);
        int int15 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int2 = keyedObjects2D0.getRowCount();
        org.jfree.data.KeyedObjects keyedObjects3 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        java.awt.Paint paint7 = categoryPlot4.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getRangeAxisEdge();
        boolean boolean9 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        keyedObjects3.sortByKeys(sortOrder10);
        keyedObjects2D0.addObject((java.lang.Object) keyedObjects3, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 4.0d);
        java.lang.Object obj15 = keyedObjects2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        boolean boolean8 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = categoryPlot0.getDataRange(valueAxis9);
        categoryPlot0.setAnchorValue(8.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        int int19 = categoryPlot15.indexOf(categoryDataset18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        categoryPlot15.notifyListeners(plotChangeEvent20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot15.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color28 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer23.setSeriesFillPaint((int) '#', (java.awt.Paint) color28);
        boolean boolean30 = lineAndShapeRenderer23.getBaseSeriesVisible();
        java.awt.Font font32 = null;
        lineAndShapeRenderer23.setSeriesItemLabelFont((int) (byte) 0, font32, false);
        java.awt.Stroke stroke38 = lineAndShapeRenderer23.getItemStroke(2, 0, false);
        java.awt.Stroke stroke42 = lineAndShapeRenderer23.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot15.setRangeCrosshairStroke(stroke42);
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot15.getDataset((int) (short) 1);
        java.awt.Paint paint46 = categoryPlot15.getOutlinePaint();
        categoryPlot0.setOutlinePaint(paint46);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            categoryPlot0.addRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis0.setUpperMargin((double) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        java.awt.Paint paint12 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot8.getRangeAxisEdge(8);
        boolean boolean15 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot8.getDatasetGroup();
        boolean boolean17 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot8);
        org.jfree.chart.plot.Plot plot18 = categoryAxis0.getPlot();
        boolean boolean19 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke22 = renderAttributes21.getDefaultOutlineStroke();
        java.awt.Paint paint25 = renderAttributes21.getItemFillPaint((int) (byte) -1, 0);
        boolean boolean26 = categoryAxis0.equals((java.lang.Object) renderAttributes21);
        float float27 = categoryAxis0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setUseFillPaint(true);
        boolean boolean9 = lineAndShapeRenderer6.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean11 = lineAndShapeRenderer6.getDrawOutlines();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        lineAndShapeRenderer6.setBaseItemLabelPaint((java.awt.Paint) color12);
        java.awt.Shape shape15 = lineAndShapeRenderer6.lookupSeriesShape(0);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape15, "{0}");
        renderAttributes1.setDefaultShape(shape15);
        try {
            java.lang.Boolean boolean20 = renderAttributes1.getSeriesLabelVisible((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        boolean boolean13 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Paint paint5 = renderAttributes1.getItemFillPaint((int) (byte) -1, 0);
        java.awt.Shape shape8 = renderAttributes1.getItemShape((-65536), (-1));
        java.awt.Shape shape9 = renderAttributes1.getDefaultShape();
        java.awt.Paint paint10 = renderAttributes1.getDefaultPaint();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        java.lang.String str10 = plotOrientation9.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotOrientation.VERTICAL" + "'", str10.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        boolean boolean8 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = categoryPlot0.getDataRange(valueAxis9);
        categoryPlot0.setAnchorValue(8.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(4, axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            boolean boolean15 = categoryPlot0.removeAnnotation(categoryAnnotation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        boolean boolean8 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = categoryPlot0.getDataRange(valueAxis9);
        categoryPlot0.setAnchorValue(8.0d, true);
        java.lang.String str14 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font34 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        lineAndShapeRenderer36.setBaseToolTipGenerator(categoryToolTipGenerator37, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = lineAndShapeRenderer36.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color49 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer44.setSeriesFillPaint((int) '#', (java.awt.Paint) color49);
        boolean boolean51 = lineAndShapeRenderer44.getBaseSeriesVisible();
        java.awt.Color color55 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer44.setBasePaint((java.awt.Paint) color55);
        java.awt.Stroke stroke58 = lineAndShapeRenderer44.lookupSeriesStroke((int) (short) 10);
        boolean boolean59 = lineAndShapeRenderer44.getDrawOutlines();
        java.awt.Paint paint61 = lineAndShapeRenderer44.lookupSeriesFillPaint((int) (short) 10);
        lineAndShapeRenderer36.setBaseFillPaint(paint61, false);
        categoryAxis0.setTickMarkPaint(paint61);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        categoryPlot1.notifyListeners(plotChangeEvent2);
        categoryPlot1.clearAnnotations();
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) categoryPlot1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setSeriesFillPaint((int) '#', (java.awt.Paint) color16);
        boolean boolean18 = lineAndShapeRenderer11.getBaseSeriesVisible();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setBasePaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem26 = lineAndShapeRenderer11.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape27 = lineAndShapeRenderer11.getBaseShape();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color29 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape27, stroke28, (java.awt.Paint) color29);
        java.lang.String str31 = legendItem30.getDescription();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem30.setFillPaint((java.awt.Paint) color32);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator37 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color32, (float) (short) 100, 3, (double) (short) 100);
        int int38 = defaultShadowGenerator37.getDistance();
        int int39 = defaultShadowGenerator37.getShadowSize();
        categoryPlot1.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator37);
        int int41 = defaultShadowGenerator37.calculateOffsetY();
        int int42 = defaultShadowGenerator37.getShadowSize();
        int int43 = defaultShadowGenerator37.calculateOffsetX();
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean8 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer0.getLegendItems();
        boolean boolean10 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setWeight((int) (short) -1);
        categoryPlot12.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setSeriesFillPaint((int) '#', (java.awt.Paint) color24);
        boolean boolean26 = lineAndShapeRenderer19.getBaseSeriesVisible();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setBasePaint((java.awt.Paint) color30);
        org.jfree.chart.LegendItem legendItem34 = lineAndShapeRenderer19.getLegendItem(2, (int) (byte) 1);
        categoryPlot12.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19, false);
        java.awt.Color color39 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot12.setNoDataMessagePaint((java.awt.Paint) color39);
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color39);
        categoryPlot3.setDomainAxis(3, categoryAxis10, false);
        categoryAxis10.configure();
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(legendItem34);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        java.awt.Stroke stroke25 = legendItem23.getLineStroke();
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(attributedString26);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        int int8 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, false);
        lineAndShapeRenderer0.setSeriesShapesFilled(3, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        java.awt.Stroke stroke28 = lineAndShapeRenderer14.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer14.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.text.TextAnchor textAnchor33 = itemLabelPosition32.getRotationAnchor();
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition32);
        java.awt.Shape shape36 = lineAndShapeRenderer0.lookupLegendShape((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        categoryPlot37.markerChanged(markerChangeEvent38);
        int int40 = categoryPlot37.getCrosshairDatasetIndex();
        float float41 = categoryPlot37.getForegroundAlpha();
        double double42 = categoryPlot37.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot37.setFixedRangeAxisSpace(axisSpace43);
        categoryPlot37.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot37.clearRangeMarkers();
        categoryPlot37.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot37.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        categoryPlot37.zoomDomainAxes((double) 1.0f, plotRenderingInfo53, point2D54);
        categoryPlot37.setDomainCrosshairColumnKey((java.lang.Comparable) (-23167), false);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = categoryPlot37.getDomainAxisEdge();
        boolean boolean60 = lineAndShapeRenderer0.equals((java.lang.Object) rectangleEdge59);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        lineAndShapeRenderer4.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition22);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer25.setSeriesFillPaint((int) '#', (java.awt.Paint) color30);
        boolean boolean32 = lineAndShapeRenderer25.getBaseSeriesVisible();
        java.awt.Color color36 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer25.setBasePaint((java.awt.Paint) color36);
        java.awt.Stroke stroke39 = lineAndShapeRenderer25.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer25.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = lineAndShapeRenderer25.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer4.setSeriesPositiveItemLabelPosition(0, itemLabelPosition43);
        java.awt.Stroke stroke45 = lineAndShapeRenderer4.getBaseOutlineStroke();
        java.awt.Stroke stroke47 = lineAndShapeRenderer4.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection48 = lineAndShapeRenderer4.getLegendItems();
        lineAndShapeRenderer4.setBaseShapesVisible(true);
        java.awt.Font font51 = lineAndShapeRenderer4.getBaseItemLabelFont();
        categoryPlot0.setRenderer(2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4, true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(stroke47);
        org.junit.Assert.assertNotNull(legendItemCollection48);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, (float) (-1), (float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        int int13 = categoryPlot9.indexOf(categoryDataset12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot9.notifyListeners(plotChangeEvent14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot9.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer17.setSeriesFillPaint((int) '#', (java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer17.getBaseSeriesVisible();
        java.awt.Font font26 = null;
        lineAndShapeRenderer17.setSeriesItemLabelFont((int) (byte) 0, font26, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer17.getItemStroke(2, 0, false);
        java.awt.Stroke stroke36 = lineAndShapeRenderer17.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot9.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke39 = categoryPlot38.getRangeZeroBaselineStroke();
        java.awt.Paint paint40 = categoryPlot38.getRangeGridlinePaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "SortOrder.ASCENDING", "GradientPaintTransformType.VERTICAL", "Category Plot", shape4, (java.awt.Paint) color8, stroke36, paint40);
        int int42 = legendItem41.getSeriesIndex();
        boolean boolean43 = legendItem41.isShapeOutlineVisible();
        java.awt.Paint paint44 = legendItem41.getOutlinePaint();
        legendItem41.setSeriesKey((java.lang.Comparable) 'a');
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.KeyedObjects2D keyedObjects2D3 = new org.jfree.data.KeyedObjects2D();
        int int4 = keyedObjects2D3.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot5.markerChanged(markerChangeEvent6);
        int int8 = categoryPlot5.getCrosshairDatasetIndex();
        float float9 = categoryPlot5.getForegroundAlpha();
        double double10 = categoryPlot5.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot5.getAxisOffset();
        boolean boolean14 = keyedObjects2D3.equals((java.lang.Object) rectangleInsets13);
        double double15 = rectangleInsets13.getTop();
        categoryPlot0.setInsets(rectangleInsets13);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            rectangleInsets13.trim(rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Paint paint13 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint14 = renderAttributes1.getDefaultOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getBaseShapesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = lineAndShapeRenderer15.getLegendItems();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        lineAndShapeRenderer15.setBaseOutlinePaint((java.awt.Paint) color32, false);
        java.awt.Font font35 = lineAndShapeRenderer15.getBaseItemLabelFont();
        renderAttributes1.setDefaultLabelFont(font35);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        float float5 = categoryPlot1.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity6 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        java.awt.Stroke stroke21 = lineAndShapeRenderer7.lookupSeriesStroke((int) (short) 10);
        boolean boolean22 = lineAndShapeRenderer7.getDrawOutlines();
        java.awt.Paint paint24 = lineAndShapeRenderer7.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer26.setUseFillPaint(true);
        int int29 = lineAndShapeRenderer26.getColumnCount();
        java.awt.Paint paint30 = lineAndShapeRenderer26.getBaseOutlinePaint();
        lineAndShapeRenderer7.setSeriesItemLabelPaint((int) '4', paint30, true);
        categoryPlot1.setOutlinePaint(paint30);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) "SortOrder.ASCENDING", obj1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        int int7 = categoryPlot4.getCrosshairDatasetIndex();
        float float8 = categoryPlot4.getForegroundAlpha();
        double double9 = categoryPlot4.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace10);
        categoryPlot4.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(1, categoryDataset16);
        categoryPlot4.setRangeZeroBaselineVisible(true);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        categoryPlot3.setDrawingSupplier(drawingSupplier9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot3.panRangeAxes(99.0d, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        categoryPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation22 = axisLocation21.getOpposite();
        categoryPlot17.setDomainAxisLocation(10, axisLocation21, true);
        categoryPlot3.setRangeAxisLocation(axisLocation21);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = categoryPlot3.removeDomainMarker(marker26, layer27);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            boolean boolean13 = categoryPlot0.removeRangeMarker(4, marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.setNoDataMessage("hi!");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendHeight((double) 'a');
        double double4 = rectangleInsets0.extendHeight((-1.0d));
        double double6 = rectangleInsets0.trimWidth((double) 192);
        double double8 = rectangleInsets0.calculateRightOutset((double) (-1L));
        double double10 = rectangleInsets0.extendWidth(18.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 190.0d + "'", double6 == 190.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 20.0d + "'", double10 == 20.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Shape shape13 = renderAttributes1.getDefaultShape();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer16.setSeriesFillPaint((int) '#', (java.awt.Paint) color21);
        boolean boolean23 = lineAndShapeRenderer16.getBaseSeriesVisible();
        java.awt.Color color27 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer16.setBasePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke30 = lineAndShapeRenderer16.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color36 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer31.setSeriesFillPaint((int) '#', (java.awt.Paint) color36);
        boolean boolean38 = lineAndShapeRenderer31.getBaseSeriesVisible();
        java.awt.Color color42 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer31.setBasePaint((java.awt.Paint) color42);
        java.awt.Stroke stroke45 = lineAndShapeRenderer31.lookupSeriesStroke((int) (short) 10);
        boolean boolean46 = lineAndShapeRenderer31.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = lineAndShapeRenderer31.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer16.setBaseNegativeItemLabelPosition(itemLabelPosition48);
        boolean boolean50 = lineAndShapeRenderer16.getAutoPopulateSeriesPaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        lineAndShapeRenderer16.setSeriesItemLabelPaint(0, paint52, false);
        renderAttributes1.setDefaultOutlinePaint(paint52);
        java.awt.Stroke stroke58 = renderAttributes1.getItemStroke((int) (byte) -1, 0);
        java.awt.Shape shape61 = renderAttributes1.getItemShape(10, 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent64 = null;
        categoryPlot63.markerChanged(markerChangeEvent64);
        java.awt.Paint paint66 = categoryPlot63.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot63.getRangeAxisEdge();
        boolean boolean68 = categoryPlot63.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        categoryPlot63.setFixedDomainAxisSpace(axisSpace69);
        categoryPlot63.clearDomainMarkers((int) 'a');
        java.awt.Stroke stroke73 = categoryPlot63.getRangeGridlineStroke();
        try {
            renderAttributes1.setSeriesStroke((int) (byte) -1, stroke73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNull(shape61);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "GradientPaintTransformType.VERTICAL");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape25 = lineAndShapeRenderer9.getBaseShape();
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape25, stroke26, (java.awt.Paint) color27);
        categoryPlot0.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke30 = categoryPlot0.getRangeGridlineStroke();
        boolean boolean31 = categoryPlot0.canSelectByPoint();
        categoryPlot0.setRangePannable(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        java.awt.Shape shape6 = lineAndShapeRenderer0.getBaseShape();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        try {
            lineAndShapeRenderer0.setSeriesPaint((-16777216), (java.awt.Paint) color8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        legendItem23.setSeriesIndex((-65536));
        java.awt.Paint paint30 = legendItem23.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup32 = defaultCategoryDataset31.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        categoryPlot33.markerChanged(markerChangeEvent34);
        java.awt.Paint paint36 = categoryPlot33.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot33.getRangeAxisEdge();
        boolean boolean38 = defaultCategoryDataset31.hasListener((java.util.EventListener) categoryPlot33);
        defaultCategoryDataset31.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int43 = defaultCategoryDataset31.getColumnCount();
        defaultCategoryDataset31.clear();
        legendItem23.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset31);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(datasetGroup32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.addChangeListener(plotChangeListener7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getInsets();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            boolean boolean12 = categoryPlot0.removeRangeMarker(marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.panDomainAxes((double) 3, plotRenderingInfo17, point2D18);
        boolean boolean20 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        try {
            int int22 = categoryPlot0.getRangeAxisIndex(valueAxis21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        java.lang.Object obj2 = keyedObjects2D0.clone();
        try {
            keyedObjects2D0.removeColumn((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        boolean boolean12 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot4);
        boolean boolean13 = categoryAxis0.isVisible();
        categoryAxis0.setFixedDimension((double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str17 = categoryAxis16.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setWeight((int) (short) -1);
        categoryPlot18.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer25.setSeriesFillPaint((int) '#', (java.awt.Paint) color30);
        boolean boolean32 = lineAndShapeRenderer25.getBaseSeriesVisible();
        java.awt.Color color36 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer25.setBasePaint((java.awt.Paint) color36);
        org.jfree.chart.LegendItem legendItem40 = lineAndShapeRenderer25.getLegendItem(2, (int) (byte) 1);
        categoryPlot18.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer25, false);
        java.awt.Color color45 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot18.setNoDataMessagePaint((java.awt.Paint) color45);
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color45);
        int int48 = categoryAxis16.getCategoryLabelPositionOffset();
        java.awt.Font font50 = categoryAxis16.getTickLabelFont((java.lang.Comparable) 8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions51 = categoryAxis16.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions51);
        categoryAxis0.setLabelAngle((double) 1);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(legendItem40);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(categoryLabelPositions51);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        boolean boolean8 = lineAndShapeRenderer3.getDrawOutlines();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        lineAndShapeRenderer3.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Shape shape12 = lineAndShapeRenderer3.lookupSeriesShape(0);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "{0}");
        java.lang.String str15 = chartEntity14.getToolTipText();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0}" + "'", str15.equals("{0}"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4, false);
        org.jfree.chart.LegendItem legendItem9 = barRenderer0.getLegendItem(3, 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Font font46 = lineAndShapeRenderer0.getSeriesItemLabelFont(255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNull(categoryURLGenerator44);
        org.junit.Assert.assertNull(font46);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge();
        java.lang.Comparable comparable6 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot0.axisChanged(axisChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer12.setUseFillPaint(true);
        boolean boolean15 = lineAndShapeRenderer12.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        boolean boolean17 = lineAndShapeRenderer12.getDrawOutlines();
        int int18 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(comparable6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        legendItem23.setLineVisible(false);
        java.lang.String str27 = legendItem23.getDescription();
        java.awt.Paint paint28 = legendItem23.getLinePaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getPassCount();
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        java.awt.Paint paint11 = categoryPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint12 = categoryPlot0.getRangeMinorGridlinePaint();
        boolean boolean13 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 100, font9);
        java.awt.Stroke stroke11 = lineAndShapeRenderer0.getBaseOutlineStroke();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (byte) 100, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        categoryPlot18.markerChanged(markerChangeEvent19);
        int int21 = categoryPlot18.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        categoryPlot22.markerChanged(markerChangeEvent23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation27 = axisLocation26.getOpposite();
        categoryPlot22.setDomainAxisLocation(10, axisLocation26, true);
        categoryPlot18.setDomainAxisLocation(axisLocation26, false);
        java.awt.Paint paint32 = categoryPlot18.getRangeCrosshairPaint();
        java.awt.Stroke stroke33 = categoryPlot18.getDomainCrosshairStroke();
        lineAndShapeRenderer0.setSeriesStroke((int) (short) 1, stroke33);
        java.awt.Paint paint36 = null;
        lineAndShapeRenderer0.setSeriesOutlinePaint(3, paint36, false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setBasePaint((java.awt.Paint) color19);
        org.jfree.chart.LegendItem legendItem23 = lineAndShapeRenderer8.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape24 = lineAndShapeRenderer8.getBaseShape();
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape24, stroke25, (java.awt.Paint) color26);
        java.lang.String str28 = legendItem27.getDescription();
        legendItem27.setToolTipText("");
        legendItem27.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint34 = lineAndShapeRenderer33.getBaseOutlinePaint();
        legendItem27.setLabelPaint(paint34);
        java.awt.Color color36 = java.awt.Color.DARK_GRAY;
        legendItem27.setLabelPaint((java.awt.Paint) color36);
        java.awt.Shape shape38 = legendItem27.getLine();
        java.awt.Paint paint39 = null;
        try {
            org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "GradientPaintTransformType.VERTICAL", "org.jfree.data.UnknownKeyException: {0}", "AxisLocation.BOTTOM_OR_RIGHT", shape38, paint39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        int int22 = lineAndShapeRenderer19.getColumnCount();
        java.awt.Paint paint23 = lineAndShapeRenderer19.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint23, true);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, false);
        int int29 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Shape shape33 = lineAndShapeRenderer0.getItemShape(8, (int) (byte) 1, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot35.markerChanged(markerChangeEvent36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation40 = axisLocation39.getOpposite();
        categoryPlot35.setDomainAxisLocation(10, axisLocation39, true);
        categoryPlot35.setAnchorValue((double) 0.0f, false);
        java.awt.Paint paint46 = categoryPlot35.getRangeCrosshairPaint();
        lineAndShapeRenderer0.setSeriesFillPaint(8, paint46);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke51 = lineAndShapeRenderer0.lookupSeriesStroke((-23167));
        lineAndShapeRenderer0.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        java.awt.Shape shape20 = lineAndShapeRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.clearSeriesPaints(false);
        boolean boolean16 = lineAndShapeRenderer0.isSeriesVisible(3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer18.setSeriesFillPaint((int) '#', (java.awt.Paint) color23);
        boolean boolean25 = lineAndShapeRenderer18.getBaseSeriesVisible();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer18.setBasePaint((java.awt.Paint) color29);
        java.awt.Stroke stroke32 = lineAndShapeRenderer18.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer18.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = lineAndShapeRenderer18.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor37 = itemLabelPosition36.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition36.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor39 = itemLabelPosition36.getItemLabelAnchor();
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition36);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(itemLabelAnchor37);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNotNull(itemLabelAnchor39);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        java.awt.Paint paint35 = lineAndShapeRenderer0.lookupSeriesPaint((int) '4');
        java.lang.Object obj36 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setWeight((int) (short) -1);
        lineAndShapeRenderer11.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        java.lang.Comparable comparable18 = categoryPlot14.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot19 = categoryPlot14.getRootPlot();
        java.awt.Paint paint20 = categoryPlot14.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot14.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier21, false);
        boolean boolean24 = categoryPlot0.isRangeGridlinesVisible();
        int int25 = categoryPlot0.getDatasetCount();
        boolean boolean26 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot27.markerChanged(markerChangeEvent28);
        int int30 = categoryPlot27.getCrosshairDatasetIndex();
        float float31 = categoryPlot27.getForegroundAlpha();
        double double32 = categoryPlot27.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace33);
        categoryPlot27.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot27.clearRangeMarkers();
        categoryPlot27.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot27.getRangeAxisEdge(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot27);
        categoryPlot0.notifyListeners(plotChangeEvent42);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        plotChangeEvent42.setType(chartChangeEventType44);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        plotChangeEvent42.setType(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = lineAndShapeRenderer9.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer9.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer9.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition27);
        java.lang.Boolean boolean30 = lineAndShapeRenderer3.getSeriesItemLabelsVisible((int) (byte) 0);
        lineAndShapeRenderer3.clearSeriesStrokes(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNull(boolean30);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        int int22 = lineAndShapeRenderer19.getColumnCount();
        java.awt.Paint paint23 = lineAndShapeRenderer19.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint23, true);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, false);
        int int29 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Shape shape33 = lineAndShapeRenderer0.getItemShape(8, (int) (byte) 1, true);
        boolean boolean36 = lineAndShapeRenderer0.getItemVisible(0, (-256));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-3,-3,3,3", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color1, false);
        barRenderer0.setItemMargin(1.0d);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        categoryPlot3.setOutlineVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace11);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke9 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis15, marker16, rectangle2D17);
        double double19 = barRenderer0.getShadowXOffset();
        double double20 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot0.markerChanged(markerChangeEvent2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        java.awt.Image image6 = null;
        categoryPlot0.setBackgroundImage(image6);
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            categoryPlot0.addRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint2 = renderAttributes1.getDefaultLabelPaint();
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (-16646144), false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        java.awt.Shape shape6 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot8.setDomainAxisLocation((int) (byte) 1, axisLocation14);
        java.lang.Comparable comparable16 = null;
        categoryPlot8.setDomainCrosshairColumnKey(comparable16, true);
        categoryPlot8.setDomainGridlinesVisible(false);
        java.awt.Stroke stroke21 = categoryPlot8.getRangeMinorGridlineStroke();
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot8, "", "{0}");
        java.lang.String str25 = plotEntity24.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PlotEntity: tooltip = " + "'", str25.equals("PlotEntity: tooltip = "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int12 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            java.lang.Comparable comparable16 = defaultCategoryDataset0.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo16, point2D17);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (-23167), false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            categoryPlot0.addDomainMarker((-16777216), categoryMarker24, layer25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis0.setUpperMargin((double) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        java.awt.Paint paint12 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot8.getRangeAxisEdge(8);
        boolean boolean15 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot8.getDatasetGroup();
        boolean boolean17 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot8);
        org.jfree.chart.plot.Plot plot18 = categoryAxis0.getPlot();
        boolean boolean19 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke22 = renderAttributes21.getDefaultOutlineStroke();
        java.awt.Paint paint25 = renderAttributes21.getItemFillPaint((int) (byte) -1, 0);
        boolean boolean26 = categoryAxis0.equals((java.lang.Object) renderAttributes21);
        java.awt.Stroke stroke27 = categoryAxis0.getTickMarkStroke();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        categoryPlot6.setDomainAxisLocation(10, axisLocation10, true);
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation10);
        int int15 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Font font3 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setSeriesFillPaint((int) '#', (java.awt.Paint) color11);
        java.awt.Shape shape16 = lineAndShapeRenderer6.getItemShape((int) '#', (int) '4', true);
        renderAttributes1.setDefaultShape(shape16);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        boolean boolean11 = categoryPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (-6.0d), (double) (byte) 100, (double) (short) 10);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateRightOutset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            rectangleInsets4.trim(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        categoryPlot3.setDrawingSupplier(drawingSupplier9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot3.setRenderers(categoryItemRendererArray13);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        abstractCategoryDataset0.removeChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15, true);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = categoryPlot0.removeDomainMarker(marker18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot0.getInsets();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, false);
        java.awt.Paint paint47 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.INSIDE4");
        categoryAxis50.setUpperMargin(2.0d);
        java.awt.Font font53 = categoryAxis50.getLabelFont();
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 10, font53, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(font53);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Paint paint25 = legendItem23.getFillPaint();
        int int26 = legendItem23.getSeriesIndex();
        org.jfree.data.general.Dataset dataset27 = legendItem23.getDataset();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(dataset27);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        categoryAxis0.setFixedDimension(2.0d);
        categoryAxis0.setTickMarkOutsideLength((float) (short) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer7.getBaseOutlineStroke();
        categoryAxis0.setAxisLineStroke(stroke8);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint2 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Shape shape3 = renderAttributes1.getDefaultShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint5 = lineAndShapeRenderer4.getBaseOutlinePaint();
        renderAttributes1.setDefaultPaint(paint5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer7.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape12 = lineAndShapeRenderer7.lookupSeriesShape(0);
        renderAttributes1.setDefaultShape(shape12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Font font5 = barRenderer0.getLegendTextFont(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(itemLabelPosition6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Paint paint13 = renderAttributes1.getDefaultOutlinePaint();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "GradientPaintTransformType.VERTICAL");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape25 = lineAndShapeRenderer9.getBaseShape();
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape25, stroke26, (java.awt.Paint) color27);
        categoryPlot0.setOutlinePaint((java.awt.Paint) color27);
        java.lang.Object obj30 = categoryPlot0.clone();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot3.removeDomainMarker((int) (byte) -1, marker11, layer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem29 = lineAndShapeRenderer14.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape30 = lineAndShapeRenderer14.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke49 = lineAndShapeRenderer35.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer35.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = lineAndShapeRenderer35.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition(0, itemLabelPosition53);
        java.awt.Stroke stroke55 = lineAndShapeRenderer14.getBaseOutlineStroke();
        java.awt.Stroke stroke57 = lineAndShapeRenderer14.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = lineAndShapeRenderer14.getLegendItems();
        boolean boolean59 = lineAndShapeRenderer14.getAutoPopulateSeriesPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14, true);
        org.jfree.chart.axis.AxisLocation axisLocation63 = null;
        try {
            categoryPlot3.setRangeAxisLocation((int) (byte) -1, axisLocation63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(stroke57);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        lineAndShapeRenderer7.setAutoPopulateSeriesShape(true);
        boolean boolean30 = lineAndShapeRenderer7.isItemLabelVisible(0, 100, false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer1.setSeriesFillPaint((int) '#', (java.awt.Paint) color6);
        boolean boolean8 = lineAndShapeRenderer1.getBaseSeriesVisible();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer1.setBasePaint((java.awt.Paint) color12);
        java.awt.Stroke stroke15 = lineAndShapeRenderer1.lookupSeriesStroke((int) (short) 10);
        boolean boolean16 = strokeList0.equals((java.lang.Object) (short) 10);
        java.lang.Object obj17 = strokeList0.clone();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.INSIDE4");
        categoryAxis1.setUpperMargin(2.0d);
        java.awt.Font font4 = categoryAxis1.getLabelFont();
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        java.awt.Stroke stroke28 = legendItem23.getLineStroke();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        categoryPlot6.setDomainAxisLocation(10, axisLocation10, true);
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation10);
        int int15 = categoryPlot0.getDatasetCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        double double19 = itemLabelPosition18.getAngle();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setSeriesFillPaint((int) '#', (java.awt.Paint) color25);
        boolean boolean27 = lineAndShapeRenderer20.getBaseSeriesVisible();
        java.awt.Color color31 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setBasePaint((java.awt.Paint) color31);
        org.jfree.chart.LegendItem legendItem35 = lineAndShapeRenderer20.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape36 = lineAndShapeRenderer20.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape36);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator38 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator39 = null;
        java.lang.String str40 = chartEntity37.getImageMapAreaTag(toolTipTagFragmentGenerator38, uRLTagFragmentGenerator39);
        java.lang.Object obj41 = chartEntity37.clone();
        boolean boolean42 = itemLabelPosition18.equals((java.lang.Object) chartEntity37);
        org.jfree.chart.text.TextAnchor textAnchor43 = itemLabelPosition18.getTextAnchor();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(legendItem35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(textAnchor43);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        double double4 = categoryAxis0.getUpperMargin();
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMinorTickMarkInsideLength((float) '4');
        categoryAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getNegativeItemLabelPositionFallback();
        barRenderer0.setMaximumBarWidth((double) 10);
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer0.getBarPainter();
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(barPainter6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        java.awt.Font font23 = lineAndShapeRenderer0.lookupLegendTextFont(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = lineAndShapeRenderer0.getToolTipGenerator((int) (short) 1, 3, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setLabel("");
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.addChangeListener(plotChangeListener7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setMinorTickMarkInsideLength(0.0f);
        categoryAxis10.setFixedDimension(2.0d);
        int int15 = categoryPlot0.getDomainAxisIndex(categoryAxis10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setShadowVisible(false);
        categoryPlot0.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        java.awt.Paint paint18 = barRenderer13.getSeriesOutlinePaint((int) (short) 1);
        org.jfree.chart.renderer.category.BarPainter barPainter19 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer13.setBarPainter(barPainter19);
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(barPainter19);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        java.lang.Comparable comparable6 = keyedObjects0.getKey(0);
        java.lang.Object obj7 = keyedObjects0.clone();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key ( ) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1.0d + "'", comparable6.equals(1.0d));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=128]");
        lineAndShapeRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator13);
        java.lang.Object obj15 = standardCategorySeriesLabelGenerator13.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 10.0f);
        double double4 = rectangleInsets0.calculateLeftOutset((double) 100);
        double double6 = rectangleInsets0.extendHeight((double) 10.0f);
        double double8 = rectangleInsets0.calculateLeftInset((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 18.0d + "'", double6 == 18.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem23.setFillPaint((java.awt.Paint) color25);
        boolean boolean27 = legendItem23.isShapeOutlineVisible();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        legendItem23.setLabelFont(font28);
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent32 = null;
        categoryPlot31.markerChanged(markerChangeEvent32);
        int int34 = categoryPlot31.getCrosshairDatasetIndex();
        float float35 = categoryPlot31.getForegroundAlpha();
        double double36 = categoryPlot31.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes38 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint39 = renderAttributes38.getDefaultOutlinePaint();
        categoryPlot31.setNoDataMessagePaint(paint39);
        int int41 = categoryPlot31.getRendererCount();
        org.jfree.chart.entity.PlotEntity plotEntity44 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) categoryPlot31, "GradientPaintTransformType.VERTICAL", "hi!");
        legendItem23.setShape(shape30);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot3.zoomDomainAxes((double) (byte) -1, plotRenderingInfo8, point2D9, true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        barRenderer0.setShadowXOffset((double) 1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer8.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer8.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        barRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition15, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator19, false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemToolTipGenerator();
        lineAndShapeRenderer0.setSeriesShapesVisible(192, true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.addChangeListener(plotChangeListener7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) (-65536), plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        lineAndShapeRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.lang.Comparable comparable32 = categoryPlot28.getDomainCrosshairRowKey();
        categoryPlot28.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) -1, marker36, layer37);
        lineAndShapeRenderer7.setPlot(categoryPlot28);
        float float40 = categoryPlot28.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.5f + "'", float40 == 0.5f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.setForegroundAlpha((float) (byte) -1);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot3.getColumnRenderingOrder();
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        lineAndShapeRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.lang.Comparable comparable32 = categoryPlot28.getDomainCrosshairRowKey();
        categoryPlot28.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) -1, marker36, layer37);
        lineAndShapeRenderer7.setPlot(categoryPlot28);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot28.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        renderAttributes2.setSeriesFillPaint(10, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer12.setUseFillPaint(true);
        boolean boolean15 = lineAndShapeRenderer12.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        int int21 = categoryPlot17.indexOf(categoryDataset20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        categoryPlot17.notifyListeners(plotChangeEvent22);
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot17.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer25.setSeriesFillPaint((int) '#', (java.awt.Paint) color30);
        boolean boolean32 = lineAndShapeRenderer25.getBaseSeriesVisible();
        java.awt.Font font34 = null;
        lineAndShapeRenderer25.setSeriesItemLabelFont((int) (byte) 0, font34, false);
        java.awt.Stroke stroke40 = lineAndShapeRenderer25.getItemStroke(2, 0, false);
        java.awt.Stroke stroke44 = lineAndShapeRenderer25.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot17.setRangeCrosshairStroke(stroke44);
        lineAndShapeRenderer12.setSeriesOutlineStroke((int) (byte) 10, stroke44, false);
        renderAttributes2.setDefaultStroke(stroke44);
        boolean boolean49 = itemLabelAnchor0.equals((java.lang.Object) renderAttributes2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint2 = renderAttributes1.getDefaultOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        categoryPlot3.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        renderAttributes1.setDefaultOutlineStroke(stroke9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        int int15 = categoryPlot12.getCrosshairDatasetIndex();
        float float16 = categoryPlot12.getForegroundAlpha();
        double double17 = categoryPlot12.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint20 = renderAttributes19.getDefaultOutlinePaint();
        categoryPlot12.setNoDataMessagePaint(paint20);
        java.awt.Paint paint22 = categoryPlot12.getDomainCrosshairPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer23.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setWeight((int) (short) -1);
        lineAndShapeRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot26);
        java.lang.Comparable comparable30 = categoryPlot26.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot31 = categoryPlot26.getRootPlot();
        java.awt.Paint paint32 = categoryPlot26.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot26.getDrawingSupplier();
        categoryPlot12.setDrawingSupplier(drawingSupplier33, false);
        boolean boolean36 = categoryPlot12.isRangeGridlinesVisible();
        int int37 = categoryPlot12.getDatasetCount();
        boolean boolean38 = categoryPlot12.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot39.notifyListeners(plotChangeEvent40);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot39.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot39.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean45 = sortOrder43.equals((java.lang.Object) axisLocation44);
        categoryPlot12.setRowRenderingOrder(sortOrder43);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color56 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer51.setSeriesFillPaint((int) '#', (java.awt.Paint) color56);
        boolean boolean58 = lineAndShapeRenderer51.getBaseSeriesVisible();
        java.awt.Color color62 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer51.setBasePaint((java.awt.Paint) color62);
        org.jfree.chart.LegendItem legendItem66 = lineAndShapeRenderer51.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape67 = lineAndShapeRenderer51.getBaseShape();
        java.awt.Stroke stroke68 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color69 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem70 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape67, stroke68, (java.awt.Paint) color69);
        java.awt.Stroke stroke71 = legendItem70.getOutlineStroke();
        java.awt.Stroke stroke72 = legendItem70.getLineStroke();
        categoryPlot12.setRangeMinorGridlineStroke(stroke72);
        try {
            renderAttributes1.setSeriesOutlineStroke((int) (short) 100, stroke72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(legendItemCollection42);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNull(legendItem66);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMinorTickMarkOutsideLength((float) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double36 = rectangleInsets35.getRight();
        double double37 = rectangleInsets35.getTop();
        categoryAxis0.setLabelInsets(rectangleInsets35);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.0d + "'", double36 == 8.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        boolean boolean45 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        lineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        boolean boolean9 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation17 = axisLocation16.getOpposite();
        categoryPlot12.setDomainAxisLocation(10, axisLocation16, true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = axisLocation16.getOpposite();
        categoryPlot0.setDomainAxisLocation(axisLocation16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        categoryPlot6.setDomainAxisLocation(10, axisLocation10, true);
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation10);
        int int15 = categoryPlot0.getDatasetCount();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            categoryPlot0.draw(graphics2D16, rectangle2D17, point2D18, plotState19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setShadowVisible(false);
        categoryPlot0.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        java.awt.Paint paint18 = barRenderer13.getSeriesOutlinePaint((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot19.markerChanged(markerChangeEvent20);
        int int22 = categoryPlot19.getCrosshairDatasetIndex();
        float float23 = categoryPlot19.getForegroundAlpha();
        double double24 = categoryPlot19.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace25);
        categoryPlot19.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean30 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot19.getRenderer();
        boolean boolean32 = barRenderer13.equals((java.lang.Object) categoryPlot19);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot19.setDomainAxis((int) (short) 10, categoryAxis34);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset37 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup38 = defaultCategoryDataset37.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        categoryPlot39.markerChanged(markerChangeEvent40);
        java.awt.Paint paint42 = categoryPlot39.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot39.getRangeAxisEdge();
        boolean boolean44 = defaultCategoryDataset37.hasListener((java.util.EventListener) categoryPlot39);
        defaultCategoryDataset37.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int49 = defaultCategoryDataset37.getColumnCount();
        defaultCategoryDataset37.clear();
        java.util.List list51 = defaultCategoryDataset37.getRowKeys();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent54 = null;
        categoryPlot53.markerChanged(markerChangeEvent54);
        int int56 = categoryPlot53.getCrosshairDatasetIndex();
        float float57 = categoryPlot53.getForegroundAlpha();
        double double58 = categoryPlot53.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot53.setFixedRangeAxisSpace(axisSpace59);
        categoryPlot53.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot53.clearRangeMarkers();
        categoryPlot53.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot53.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        java.awt.geom.Point2D point2D70 = null;
        categoryPlot53.zoomDomainAxes((double) 1.0f, plotRenderingInfo69, point2D70);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot53.getRangeAxisEdge((int) (byte) 1);
        try {
            double double74 = categoryAxis34.getCategoryMiddle((java.lang.Comparable) 8.0d, list51, rectangle2D52, rectangleEdge73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(datasetGroup38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 1.0f + "'", float57 == 1.0f);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(rectangleEdge73);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getWeight();
        java.awt.Paint paint4 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.Marker marker5 = null;
        try {
            categoryPlot0.addRangeMarker(marker5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultCategoryDataset9.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        java.awt.Paint paint14 = categoryPlot11.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getRangeAxisEdge();
        boolean boolean16 = defaultCategoryDataset9.hasListener((java.util.EventListener) categoryPlot11);
        defaultCategoryDataset9.fireSelectionEvent();
        java.util.List list18 = defaultCategoryDataset9.getColumnKeys();
        try {
            categoryPlot3.mapDatasetToDomainAxes((int) (byte) 100, list18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addRangeMarker(marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        lineAndShapeRenderer0.setSeriesShapesFilled(255, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = lineAndShapeRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot24.markerChanged(markerChangeEvent25);
        int int27 = categoryPlot24.getCrosshairDatasetIndex();
        float float28 = categoryPlot24.getForegroundAlpha();
        double double29 = categoryPlot24.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot24.setFixedRangeAxisSpace(axisSpace30);
        categoryPlot24.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        categoryPlot24.setDataset(1, categoryDataset36);
        categoryPlot24.setRangeZeroBaselineVisible(true);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.RenderingSource renderingSource43 = null;
        categoryPlot24.select((double) '4', 99.0d, rectangle2D42, renderingSource43);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (short) 100, axisLocation6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxis((-65536));
        java.awt.Color color10 = java.awt.Color.pink;
        float[] floatArray14 = new float[] { 8, (-83), 10L };
        float[] floatArray15 = color10.getColorComponents(floatArray14);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        categoryPlot1.notifyListeners(plotChangeEvent2);
        categoryPlot1.clearAnnotations();
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot1.addDomainMarker(1, categoryMarker7, layer8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        float float12 = categoryPlot8.getForegroundAlpha();
        double double13 = categoryPlot8.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace14);
        java.lang.Comparable comparable16 = categoryPlot8.getDomainCrosshairRowKey();
        java.util.List list17 = categoryPlot8.getAnnotations();
        categoryPlot8.setNoDataMessage("ChartChangeEventType.DATASET_UPDATED");
        categoryPlot3.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke22 = barRenderer21.getBaseOutlineStroke();
        categoryPlot3.setOutlineStroke(stroke22);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        objectList0.set(8, (java.lang.Object) paint6);
        java.lang.Object obj9 = objectList0.get(10);
        java.lang.Object obj11 = objectList0.get(0);
        java.lang.Object obj13 = objectList0.get(2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        java.lang.Object obj34 = lineAndShapeRenderer0.clone();
        boolean boolean35 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Font font3 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.lang.String str8 = color7.toString();
        try {
            renderAttributes1.setSeriesPaint((-83), (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=128,g=0,b=128]" + "'", str8.equals("java.awt.Color[r=128,g=0,b=128]"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        java.awt.Stroke stroke4 = barRenderer0.getBaseStroke();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultCategoryDataset5.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot7.markerChanged(markerChangeEvent8);
        java.awt.Paint paint10 = categoryPlot7.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot7.getRangeAxisEdge();
        boolean boolean12 = defaultCategoryDataset5.hasListener((java.util.EventListener) categoryPlot7);
        defaultCategoryDataset5.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.Range range18 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, false);
        int int19 = defaultCategoryDataset5.getRowCount();
        try {
            java.lang.Comparable comparable21 = defaultCategoryDataset5.getColumnKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        barRenderer0.setShadowXOffset((double) 1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer8.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer8.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        barRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition15, false);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType18 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer19 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType18);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer19);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(gradientPaintTransformType18);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str3 = chartChangeEventType2.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent4.setChart(jFreeChart5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str3.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        java.awt.Shape shape6 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot8.setDomainAxisLocation((int) (byte) 1, axisLocation14);
        java.lang.Comparable comparable16 = null;
        categoryPlot8.setDomainCrosshairColumnKey(comparable16, true);
        categoryPlot8.setDomainGridlinesVisible(false);
        java.awt.Stroke stroke21 = categoryPlot8.getRangeMinorGridlineStroke();
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot8, "", "{0}");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str26 = categoryAxis25.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double29 = rectangleInsets27.calculateTopOutset((double) 10.0f);
        categoryAxis25.setTickLabelInsets(rectangleInsets27);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis25.setLabelInsets(rectangleInsets31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryAxis25.setTickMarkStroke(stroke33);
        categoryPlot8.setDomainAxis(categoryAxis25);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation18 = axisLocation17.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation18);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(drawingSupplier20);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        java.lang.Boolean boolean12 = lineAndShapeRenderer0.getSeriesShapesFilled(100);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        categoryPlot14.setDomainAxisLocation(10, axisLocation18, true);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke24 = categoryPlot14.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesStroke(10, stroke24, true);
        java.lang.Boolean boolean28 = lineAndShapeRenderer0.getSeriesCreateEntities(4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(boolean28);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setUseFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape9 = lineAndShapeRenderer4.lookupSeriesShape(0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape9, (java.awt.Paint) color10);
        java.awt.Paint paint12 = legendItem11.getLabelPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        boolean boolean23 = lineAndShapeRenderer13.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot24.markerChanged(markerChangeEvent25);
        int int27 = categoryPlot24.getCrosshairDatasetIndex();
        float float28 = categoryPlot24.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        categoryPlot24.setDomainAxisLocation((int) (byte) 1, axisLocation30);
        java.awt.Stroke stroke32 = categoryPlot24.getOutlineStroke();
        lineAndShapeRenderer13.setBaseOutlineStroke(stroke32, false);
        java.awt.Font font36 = lineAndShapeRenderer13.lookupLegendTextFont(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot38.setWeight((int) (short) -1);
        categoryPlot38.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        boolean boolean52 = lineAndShapeRenderer45.getBaseSeriesVisible();
        java.awt.Color color56 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setBasePaint((java.awt.Paint) color56);
        org.jfree.chart.LegendItem legendItem60 = lineAndShapeRenderer45.getLegendItem(2, (int) (byte) 1);
        categoryPlot38.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45, false);
        java.awt.Font font64 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer45.setSeriesItemLabelFont((int) 'a', font64);
        lineAndShapeRenderer13.setLegendTextFont(15, font64);
        legendItem11.setLabelFont(font64);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(font36);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(legendItem60);
        org.junit.Assert.assertNotNull(font64);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        boolean boolean28 = legendItem23.isShapeVisible();
        boolean boolean29 = legendItem23.isShapeOutlineVisible();
        java.awt.Shape shape30 = legendItem23.getShape();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        categoryAxis10.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis10.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis10.setUpperMargin((double) '4');
        java.awt.Stroke stroke18 = categoryAxis10.getTickMarkStroke();
        categoryPlot3.setDomainAxis(categoryAxis10);
        categoryAxis10.configure();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint14 = lineAndShapeRenderer13.getBaseOutlinePaint();
        lineAndShapeRenderer0.setBaseOutlinePaint(paint14, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color17);
        java.awt.Stroke stroke20 = lineAndShapeRenderer0.lookupSeriesStroke(128);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        objectList0.set(8, (java.lang.Object) paint6);
        java.lang.Object obj9 = objectList0.get(10);
        org.jfree.data.KeyedObjects keyedObjects11 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj12 = keyedObjects11.clone();
        keyedObjects11.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        try {
            objectList0.set((-65536), (java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer45.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot48.setWeight((int) (short) -1);
        lineAndShapeRenderer45.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot48);
        java.lang.Comparable comparable52 = categoryPlot48.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot53 = categoryPlot48.getRootPlot();
        java.awt.Paint paint54 = categoryPlot48.getDomainGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.plot.Marker marker56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D44, categoryPlot48, valueAxis55, marker56, rectangle2D57);
        org.jfree.chart.plot.Marker marker59 = null;
        org.jfree.chart.util.Layer layer60 = null;
        try {
            categoryPlot48.addRangeMarker(marker59, layer60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNull(comparable52);
        org.junit.Assert.assertNotNull(plot53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        lineAndShapeRenderer0.setBaseLinesVisible(false);
        java.awt.Color color15 = java.awt.Color.red;
        java.awt.Color color16 = java.awt.Color.getColor("ChartEntity: tooltip = null", color15);
        java.awt.Color color17 = java.awt.Color.getColor("ChartEntity: tooltip = null", color15);
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color15, true);
        java.awt.Paint paint23 = lineAndShapeRenderer0.getItemLabelPaint((-256), (int) (short) 10, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot9.notifyListeners(plotChangeEvent10);
        categoryPlot9.clearAnnotations();
        java.awt.Paint paint13 = categoryPlot9.getNoDataMessagePaint();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot9);
        try {
            boolean boolean17 = defaultCategoryDataset0.isSelected((int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker5);
        java.util.List list7 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 10);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxisForDataset((-83));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (short) 100, axisLocation6);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean11 = categoryPlot0.removeAnnotation(categoryAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        int int19 = categoryPlot15.indexOf(categoryDataset18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        categoryPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation26 = axisLocation25.getOpposite();
        categoryPlot21.setDomainAxisLocation(10, axisLocation25, true);
        categoryPlot15.setRangeAxisLocation((int) (byte) 0, axisLocation25);
        categoryPlot15.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        int int39 = categoryPlot15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer32);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset40, plotRenderingInfo41);
        try {
            defaultCategoryDataset40.setSelected((int) (short) 0, (-83), false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState42);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, false);
        java.awt.Paint paint47 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.lang.Boolean boolean49 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49.equals(false));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        legendItem23.setToolTipText("");
        legendItem23.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint30 = lineAndShapeRenderer29.getBaseOutlinePaint();
        legendItem23.setLabelPaint(paint30);
        legendItem23.setDatasetIndex(3);
        java.lang.String str34 = legendItem23.getDescription();
        java.awt.Stroke stroke35 = legendItem23.getLineStroke();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        float float5 = categoryPlot1.getForegroundAlpha();
        double double6 = categoryPlot1.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint9 = renderAttributes8.getDefaultOutlinePaint();
        categoryPlot1.setNoDataMessagePaint(paint9);
        int int11 = categoryPlot1.getRendererCount();
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "GradientPaintTransformType.VERTICAL", "hi!");
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot1.getDomainMarkers((int) (byte) 10, layer16);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot3.getOrientation();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot3.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot3.getInsets();
        double double14 = rectangleInsets12.calculateLeftInset(4.0d);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo16, point2D17);
        boolean boolean19 = categoryPlot0.isSubplot();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        int int24 = categoryPlot20.indexOf(categoryDataset23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        categoryPlot20.notifyListeners(plotChangeEvent25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer30.setUseFillPaint(true);
        boolean boolean33 = lineAndShapeRenderer30.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot34.getDataset((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer37.setUseFillPaint(true);
        boolean boolean40 = lineAndShapeRenderer37.getAutoPopulateSeriesFillPaint();
        boolean boolean41 = lineAndShapeRenderer37.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color47 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer42.setSeriesFillPaint((int) '#', (java.awt.Paint) color47);
        boolean boolean49 = lineAndShapeRenderer42.getBaseSeriesVisible();
        java.awt.Color color53 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer42.setBasePaint((java.awt.Paint) color53);
        java.awt.Stroke stroke56 = lineAndShapeRenderer42.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer42.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = lineAndShapeRenderer42.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent63 = null;
        categoryPlot62.markerChanged(markerChangeEvent63);
        int int65 = categoryPlot62.getCrosshairDatasetIndex();
        float float66 = categoryPlot62.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation68 = null;
        categoryPlot62.setDomainAxisLocation((int) (byte) 1, axisLocation68);
        java.awt.Stroke stroke70 = categoryPlot62.getOutlineStroke();
        lineAndShapeRenderer42.setSeriesOutlineStroke(15, stroke70);
        boolean boolean72 = lineAndShapeRenderer42.getBaseShapesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray73 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer37, lineAndShapeRenderer42 };
        categoryPlot34.setRenderers(categoryItemRendererArray73);
        categoryPlot20.setRenderers(categoryItemRendererArray73);
        categoryPlot0.setRenderers(categoryItemRendererArray73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(itemLabelPosition60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 1.0f + "'", float66 == 1.0f);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray73);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemOutlineStroke(0, (int) (byte) 100, false);
        boolean boolean20 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Font font22 = lineAndShapeRenderer0.getSeriesItemLabelFont((-65536));
        boolean boolean25 = lineAndShapeRenderer0.getItemVisible(1, (-23167));
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        boolean boolean32 = lineAndShapeRenderer0.getItemShapeVisible(192, (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "GradientPaintTransformType.VERTICAL");
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        java.awt.Color color8 = java.awt.Color.red;
        java.awt.Color color9 = java.awt.Color.getColor("ChartEntity: tooltip = null", color8);
        int int10 = color8.getGreen();
        try {
            lineAndShapeRenderer0.setLegendTextPaint((int) (byte) -1, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot0.removeChangeListener(plotChangeListener9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        try {
            categoryPlot0.mapDatasetToRangeAxes((int) (short) 0, list11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = null;
        boolean boolean2 = strokeList0.equals(obj1);
        java.lang.Object obj3 = strokeList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        java.lang.Comparable comparable28 = legendItem23.getSeriesKey();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertNull(comparable28);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int12 = defaultCategoryDataset0.getColumnCount();
        try {
            defaultCategoryDataset0.removeColumn((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, (float) (-1), (float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        int int13 = categoryPlot9.indexOf(categoryDataset12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot9.notifyListeners(plotChangeEvent14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot9.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer17.setSeriesFillPaint((int) '#', (java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer17.getBaseSeriesVisible();
        java.awt.Font font26 = null;
        lineAndShapeRenderer17.setSeriesItemLabelFont((int) (byte) 0, font26, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer17.getItemStroke(2, 0, false);
        java.awt.Stroke stroke36 = lineAndShapeRenderer17.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot9.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke39 = categoryPlot38.getRangeZeroBaselineStroke();
        java.awt.Paint paint40 = categoryPlot38.getRangeGridlinePaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "SortOrder.ASCENDING", "GradientPaintTransformType.VERTICAL", "Category Plot", shape4, (java.awt.Paint) color8, stroke36, paint40);
        int int42 = legendItem41.getSeriesIndex();
        int int43 = legendItem41.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getBaseShape();
        java.awt.Font font5 = lineAndShapeRenderer0.getBaseItemLabelFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str8 = categoryAxis7.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight((int) (short) -1);
        categoryPlot9.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer16.setSeriesFillPaint((int) '#', (java.awt.Paint) color21);
        boolean boolean23 = lineAndShapeRenderer16.getBaseSeriesVisible();
        java.awt.Color color27 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer16.setBasePaint((java.awt.Paint) color27);
        org.jfree.chart.LegendItem legendItem31 = lineAndShapeRenderer16.getLegendItem(2, (int) (byte) 1);
        categoryPlot9.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16, false);
        java.awt.Color color36 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color36);
        categoryAxis7.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Color color39 = color36.darker();
        try {
            lineAndShapeRenderer0.setSeriesItemLabelPaint((-65536), (java.awt.Paint) color39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(legendItem31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean8 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem29 = lineAndShapeRenderer14.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape30 = lineAndShapeRenderer14.getBaseShape();
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color32 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape30, stroke31, (java.awt.Paint) color32);
        java.awt.Color color34 = java.awt.Color.gray;
        legendItem33.setFillPaint((java.awt.Paint) color34);
        java.text.AttributedString attributedString36 = legendItem33.getAttributedLabel();
        java.text.AttributedString attributedString37 = legendItem33.getAttributedLabel();
        java.lang.String str38 = legendItem33.getDescription();
        legendItemCollection9.add(legendItem33);
        org.jfree.data.general.Dataset dataset40 = legendItem33.getDataset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(attributedString36);
        org.junit.Assert.assertNull(attributedString37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNull(dataset40);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.lang.String str25 = legendItem24.getDescription();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem24.setFillPaint((java.awt.Paint) color26);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color26, (float) (short) 100, 3, (double) (short) 100);
        float float32 = defaultShadowGenerator31.getShadowOpacity();
        double double33 = defaultShadowGenerator31.getAngle();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 100.0f + "'", float32 == 100.0f);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        boolean boolean6 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color17 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer12.setSeriesFillPaint((int) '#', (java.awt.Paint) color17);
        boolean boolean19 = lineAndShapeRenderer12.getBaseSeriesVisible();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer12.setBasePaint((java.awt.Paint) color23);
        org.jfree.chart.LegendItem legendItem27 = lineAndShapeRenderer12.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape28 = lineAndShapeRenderer12.getBaseShape();
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color30 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape28, stroke29, (java.awt.Paint) color30);
        lineAndShapeRenderer0.setSeriesStroke(255, stroke29, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 1, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        java.lang.String str5 = chartChangeEvent3.toString();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        chartChangeEvent3.setChart(jFreeChart6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        org.jfree.chart.LegendItem legendItem25 = lineAndShapeRenderer10.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape26 = lineAndShapeRenderer10.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator28 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator29 = null;
        java.lang.String str30 = chartEntity27.getImageMapAreaTag(toolTipTagFragmentGenerator28, uRLTagFragmentGenerator29);
        java.lang.Object obj31 = chartEntity27.clone();
        boolean boolean32 = itemLabelAnchor9.equals(obj31);
        boolean boolean33 = chartChangeEventType8.equals(obj31);
        chartChangeEvent3.setType(chartChangeEventType8);
        org.junit.Assert.assertNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=1]" + "'", str5.equals("org.jfree.chart.event.ChartChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis0.setUpperMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength((float) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets10.getBottom();
        categoryAxis0.setLabelInsets(rectangleInsets10, false);
        double double15 = rectangleInsets10.extendWidth((double) 0);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator(1, categoryURLGenerator20, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer3.getLegendItemURLGenerator();
        java.awt.Paint paint10 = lineAndShapeRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint12 = lineAndShapeRenderer3.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot3.removeDomainMarker((int) (byte) -1, marker11, layer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem29 = lineAndShapeRenderer14.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape30 = lineAndShapeRenderer14.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke49 = lineAndShapeRenderer35.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer35.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = lineAndShapeRenderer35.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition(0, itemLabelPosition53);
        java.awt.Stroke stroke55 = lineAndShapeRenderer14.getBaseOutlineStroke();
        java.awt.Stroke stroke57 = lineAndShapeRenderer14.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = lineAndShapeRenderer14.getLegendItems();
        boolean boolean59 = lineAndShapeRenderer14.getAutoPopulateSeriesPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation62 = null;
        boolean boolean63 = lineAndShapeRenderer14.removeAnnotation(categoryAnnotation62);
        lineAndShapeRenderer14.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(stroke57);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setSeriesFillPaint((int) '#', (java.awt.Paint) color16);
        boolean boolean18 = lineAndShapeRenderer11.getBaseSeriesVisible();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setBasePaint((java.awt.Paint) color22);
        java.awt.Stroke stroke25 = lineAndShapeRenderer11.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color31 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer26.setSeriesFillPaint((int) '#', (java.awt.Paint) color31);
        boolean boolean33 = lineAndShapeRenderer26.getBaseSeriesVisible();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer26.setBasePaint((java.awt.Paint) color37);
        java.awt.Stroke stroke40 = lineAndShapeRenderer26.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer26.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = lineAndShapeRenderer26.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer11.setBaseNegativeItemLabelPosition(itemLabelPosition44);
        boolean boolean46 = color8.equals((java.lang.Object) lineAndShapeRenderer11);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str48 = color47.toString();
        lineAndShapeRenderer11.setBaseLegendTextPaint((java.awt.Paint) color47);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str48.equals("java.awt.Color[r=0,g=0,b=128]"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font34 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 8);
        categoryAxis0.setCategoryLabelPositionOffset(15);
        categoryAxis0.setMinorTickMarksVisible(true);
        categoryAxis0.setLabel("java.awt.Color[r=128,g=0,b=128]");
        boolean boolean41 = categoryAxis0.isMinorTickMarksVisible();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) (-16777216), (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-16777216) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        boolean boolean11 = barRenderer0.getShadowsVisible();
        java.awt.Shape shape12 = barRenderer0.getBaseLegendShape();
        double double13 = barRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot10.markerChanged(markerChangeEvent11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot10.setDomainAxisLocation(10, axisLocation14, true);
        categoryPlot10.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        categoryPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation26 = axisLocation25.getOpposite();
        categoryPlot21.setDomainAxisLocation(10, axisLocation25, true);
        categoryPlot10.setRangeAxisLocation(axisLocation25);
        categoryPlot0.setDomainAxisLocation(axisLocation25, true);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        try {
            categoryPlot0.addRangeMarker(192, marker33, layer34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = lineAndShapeRenderer3.getLegendItems();
        java.util.Iterator iterator9 = legendItemCollection8.iterator();
        int int10 = legendItemCollection8.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(iterator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        java.awt.Paint paint17 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        java.awt.Shape shape21 = lineAndShapeRenderer0.getItemShape(64, (int) (short) -1, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.lang.Comparable comparable8 = categoryPlot0.getDomainCrosshairRowKey();
        java.util.List list9 = categoryPlot0.getAnnotations();
        categoryPlot0.setNoDataMessage("ChartChangeEventType.DATASET_UPDATED");
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo7, point2D8, true);
        categoryPlot0.clearSelection();
        boolean boolean12 = categoryPlot0.canSelectByPoint();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxisForDataset((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Font font5 = barRenderer0.getLegendTextFont(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator6, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(font5);
    }
}

