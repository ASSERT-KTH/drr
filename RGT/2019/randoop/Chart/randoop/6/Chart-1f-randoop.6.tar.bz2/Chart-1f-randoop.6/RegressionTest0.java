import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            categoryPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            boolean boolean8 = categoryPlot0.removeRangeMarker((int) (short) 10, marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        try {
            lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            categoryPlot0.addRangeMarker((-1), marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) itemLabelAnchor0, jFreeChart1, chartChangeEventType2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        double double16 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D10, categoryPlot11, categoryAxis20, categoryMarker21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.util.SortOrder sortOrder8 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation1, plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "", "", categoryDataset19, (java.lang.Comparable) (-1), (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE12" + "'", str1.equals("ItemLabelAnchor.OUTSIDE12"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot19.markerChanged(markerChangeEvent20);
        int int22 = categoryPlot19.getCrosshairDatasetIndex();
        float float23 = categoryPlot19.getForegroundAlpha();
        double double24 = categoryPlot19.getAnchorValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D33 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis25, valueAxis26, categoryDataset27, 0, (int) 'a', true, categoryItemRendererState31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        try {
            lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        try {
            categoryPlot0.zoom((double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke9 = categoryPlot6.getOutlineStroke();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D5, categoryPlot6, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE4" + "'", str1.equals("ItemLabelAnchor.INSIDE4"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            java.awt.Color color1 = java.awt.Color.decode("rect");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"rect\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity11 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "rect", "ItemLabelAnchor.INSIDE4", categoryDataset8, (java.lang.Comparable) 100, (java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeRangeMarker(1, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createAdjustedRectangle(rectangle2D2, lengthAdjustmentType3, lengthAdjustmentType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.data.general.Dataset dataset3 = null;
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo4 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) lineAndShapeRenderer0, dataset3, datasetChangeInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker12 = null;
        try {
            boolean boolean13 = categoryPlot0.removeRangeMarker(marker12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.Plot plot13 = categoryPlot0.getParent();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            boolean boolean6 = categoryPlot0.removeRangeMarker((int) (short) 0, marker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        lineAndShapeRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        try {
            keyedObjects0.removeValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.util.List list9 = null;
        try {
            categoryPlot0.mapDatasetToRangeAxes((int) '#', list9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        int int10 = categoryPlot0.getRendererCount();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemOutlineStroke(0, (int) (byte) 100, false);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        try {
            lineAndShapeRenderer0.setSeriesOutlinePaint((int) (short) -1, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer1.setSeriesFillPaint((int) '#', (java.awt.Paint) color6);
        boolean boolean8 = lineAndShapeRenderer1.getBaseSeriesVisible();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer1.setBasePaint((java.awt.Paint) color12);
        java.awt.Stroke stroke15 = lineAndShapeRenderer1.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer1.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor20, textAnchor21, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) true, (java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (true) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D19, rectangle2D20, categoryAxis21, valueAxis22, layer23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator18 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator19 = null;
        java.lang.String str20 = chartEntity17.getImageMapAreaTag(toolTipTagFragmentGenerator18, uRLTagFragmentGenerator19);
        java.lang.Object obj21 = chartEntity17.clone();
        java.lang.String str22 = chartEntity17.getShapeType();
        chartEntity17.setToolTipText("hi!");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "rect" + "'", str22.equals("rect"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str1.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        boolean boolean9 = itemLabelPosition7.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        int int14 = categoryPlot10.indexOf(categoryDataset13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot10.notifyListeners(plotChangeEvent15);
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot10.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer18.setSeriesFillPaint((int) '#', (java.awt.Paint) color23);
        boolean boolean25 = lineAndShapeRenderer18.getBaseSeriesVisible();
        java.awt.Font font27 = null;
        lineAndShapeRenderer18.setSeriesItemLabelFont((int) (byte) 0, font27, false);
        java.awt.Stroke stroke33 = lineAndShapeRenderer18.getItemStroke(2, 0, false);
        java.awt.Stroke stroke37 = lineAndShapeRenderer18.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot10.setRangeCrosshairStroke(stroke37);
        lineAndShapeRenderer0.setBaseStroke(stroke37, true);
        java.awt.Paint paint41 = lineAndShapeRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        try {
            int int8 = categoryPlot0.getRangeAxisIndex(valueAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        org.junit.Assert.assertNull(comparable3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setBasePaint((java.awt.Paint) color19);
        org.jfree.chart.LegendItem legendItem23 = lineAndShapeRenderer8.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape24 = lineAndShapeRenderer8.getBaseShape();
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Color color29 = java.awt.Color.red;
        java.awt.Color color30 = java.awt.Color.getColor("ChartEntity: tooltip = null", color29);
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "", "rect", "ItemLabelAnchor.OUTSIDE12", shape24, (java.awt.Paint) color30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Comparable comparable2 = keyedObjects0.getKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        int int10 = categoryPlot0.getRendererCount();
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            categoryPlot0.addRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str1 = color0.toString();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        java.awt.color.ColorSpace colorSpace8 = null;
        float[] floatArray15 = new float[] { (-1), 0.0f, 192, 100, 192, (byte) -1 };
        try {
            float[] floatArray16 = color0.getComponents(colorSpace8, floatArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str1.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(1, categoryDataset12);
        boolean boolean14 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        int int5 = lineAndShapeRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.lang.Comparable comparable8 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        boolean boolean8 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        lineAndShapeRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.lang.Comparable comparable32 = categoryPlot28.getDomainCrosshairRowKey();
        categoryPlot28.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) -1, marker36, layer37);
        lineAndShapeRenderer7.setPlot(categoryPlot28);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        try {
            double double46 = lineAndShapeRenderer7.getItemMiddle((java.lang.Comparable) 192, (java.lang.Comparable) 10, categoryDataset42, categoryAxis43, rectangle2D44, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 10, (java.lang.Boolean) true);
        try {
            lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.Color color3 = java.awt.Color.getColor("ChartEntity: tooltip = null", color2);
        java.awt.Color color4 = java.awt.Color.getColor("ChartEntity: tooltip = null", color2);
        int int5 = color2.getRGB();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-65536) + "'", int5 == (-65536));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        int int9 = categoryPlot5.indexOf(categoryDataset8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot5.notifyListeners(plotChangeEvent10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot5.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        java.awt.Font font22 = null;
        lineAndShapeRenderer13.setSeriesItemLabelFont((int) (byte) 0, font22, false);
        java.awt.Stroke stroke28 = lineAndShapeRenderer13.getItemStroke(2, 0, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer13.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot5.setRangeCrosshairStroke(stroke32);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (byte) 10, stroke32, false);
        try {
            lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseOutlinePaint();
        boolean boolean3 = lineAndShapeRenderer0.isSeriesVisibleInLegend((int) (short) 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            boolean boolean14 = categoryPlot0.removeAnnotation(categoryAnnotation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        java.lang.Object obj2 = booleanList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        float float3 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot0.handleClick((int) (short) 0, 0, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("GradientPaintTransformType.VERTICAL");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Stroke stroke3 = null;
        try {
            lineAndShapeRenderer0.setSeriesStroke((int) (byte) -1, stroke3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = lineAndShapeRenderer9.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer24.setSeriesFillPaint((int) '#', (java.awt.Paint) color29);
        boolean boolean31 = lineAndShapeRenderer24.getBaseSeriesVisible();
        java.awt.Color color35 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer24.setBasePaint((java.awt.Paint) color35);
        java.awt.Stroke stroke38 = lineAndShapeRenderer24.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer24.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer24.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer9.setBaseNegativeItemLabelPosition(itemLabelPosition42);
        try {
            lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemToolTipGenerator();
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        try {
            lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        try {
            lineAndShapeRenderer0.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(15);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        int int11 = categoryPlot7.indexOf(categoryDataset10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        categoryPlot7.notifyListeners(plotChangeEvent12);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot7.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Font font24 = null;
        lineAndShapeRenderer15.setSeriesItemLabelFont((int) (byte) 0, font24, false);
        java.awt.Stroke stroke30 = lineAndShapeRenderer15.getItemStroke(2, 0, false);
        java.awt.Stroke stroke34 = lineAndShapeRenderer15.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot7.setRangeCrosshairStroke(stroke34);
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot7.getDataset((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        categoryPlot39.markerChanged(markerChangeEvent40);
        int int42 = categoryPlot39.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot43.markerChanged(markerChangeEvent44);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation48 = axisLocation47.getOpposite();
        categoryPlot43.setDomainAxisLocation(10, axisLocation47, true);
        categoryPlot39.setDomainAxisLocation(axisLocation47, false);
        categoryPlot7.setDomainAxisLocation((int) (byte) 100, axisLocation47, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D6, categoryPlot7, categoryAxis55, categoryMarker56, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(categoryDataset37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.util.List list3 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) '4', list3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(3, (int) ' ', (int) 'a', floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) 0, categoryMarker3, layer4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        try {
            lineAndShapeRenderer5.setBaseNegativeItemLabelPosition(itemLabelPosition11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            boolean boolean11 = categoryPlot0.removeRangeMarker((int) (byte) 0, marker8, layer9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeRow(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setUseFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer4.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape8 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Color color11 = java.awt.Color.red;
        java.awt.Color color12 = java.awt.Color.getColor("ChartEntity: tooltip = null", color11);
        java.awt.Color color13 = java.awt.Color.getColor("ChartEntity: tooltip = null", color11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        java.awt.Stroke stroke28 = lineAndShapeRenderer14.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer14.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        int int37 = categoryPlot34.getCrosshairDatasetIndex();
        float float38 = categoryPlot34.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot34.setDomainAxisLocation((int) (byte) 1, axisLocation40);
        java.awt.Stroke stroke42 = categoryPlot34.getOutlineStroke();
        lineAndShapeRenderer14.setSeriesOutlineStroke(15, stroke42);
        java.awt.Color color44 = java.awt.Color.LIGHT_GRAY;
        try {
            org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem(attributedString0, "", "ItemLabelAnchor.OUTSIDE12", "ItemLabelAnchor.INSIDE4", shape8, (java.awt.Paint) color13, stroke42, (java.awt.Paint) color44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = lineAndShapeRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        java.lang.String str29 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        try {
            lineAndShapeRenderer0.setItemMargin((double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = lineAndShapeRenderer0.getSelectedItemAttributes();
        java.awt.Paint paint2 = null;
        try {
            renderAttributes1.setDefaultFillPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot20.setDomainAxisLocation((int) (byte) 1, axisLocation26);
        java.awt.Stroke stroke28 = categoryPlot20.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(15, stroke28);
        boolean boolean30 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        java.awt.Paint paint11 = categoryPlot8.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D6, rectangle2D7, categoryPlot8, categoryAxis12, valueAxis13, categoryDataset14, 8, (int) (short) 0, false, categoryItemRendererState18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke3 = categoryPlot2.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot2.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color17 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer12.setSeriesFillPaint((int) '#', (java.awt.Paint) color17);
        boolean boolean19 = lineAndShapeRenderer12.getBaseSeriesVisible();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer12.setBasePaint((java.awt.Paint) color23);
        org.jfree.chart.LegendItem legendItem27 = lineAndShapeRenderer12.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape28 = lineAndShapeRenderer12.getBaseShape();
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color30 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape28, stroke29, (java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.gray;
        legendItem31.setFillPaint((java.awt.Paint) color32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer38.setSeriesFillPaint((int) '#', (java.awt.Paint) color43);
        boolean boolean45 = lineAndShapeRenderer38.getBaseSeriesVisible();
        java.awt.Color color49 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer38.setBasePaint((java.awt.Paint) color49);
        org.jfree.chart.LegendItem legendItem53 = lineAndShapeRenderer38.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape54 = lineAndShapeRenderer38.getBaseShape();
        java.awt.Stroke stroke55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color56 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape54, stroke55, (java.awt.Paint) color56);
        java.awt.Stroke stroke58 = legendItem57.getOutlineStroke();
        try {
            barRenderer0.drawRangeLine(graphics2D1, categoryPlot2, valueAxis5, rectangle2D6, (double) (short) 0, (java.awt.Paint) color32, stroke58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNull(legendItem53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color1 = java.awt.Color.getColor("ItemLabelAnchor.INSIDE4");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean3 = categoryPlot0.isRangePannable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            boolean boolean7 = categoryPlot0.removeRangeMarker((int) (short) 0, marker4, layer5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge(8);
        categoryPlot0.setAnchorValue((double) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxisForDataset((int) (byte) 100);
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        boolean boolean8 = lineAndShapeRenderer3.getDrawOutlines();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        lineAndShapeRenderer3.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = lineAndShapeRenderer3.getURLGenerator((int) (short) 10, 2, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryURLGenerator14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxisForDataset(1);
        org.junit.Assert.assertNull(categoryAxis2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        java.util.List list7 = null;
        try {
            categoryPlot0.mapDatasetToRangeAxes(0, list7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        lineAndShapeRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot0.setInsets(rectangleInsets3);
        boolean boolean5 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo2 = new org.jfree.chart.event.DatasetChangeInfo();
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.event.DatasetChangeEvent(obj0, dataset1, datasetChangeInfo2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation5, plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        java.awt.Color color27 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint2 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Shape shape3 = renderAttributes1.getDefaultShape();
        java.awt.Stroke stroke4 = null;
        try {
            renderAttributes1.setDefaultStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(shape3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Object obj2 = keyedObjects0.getObject((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setUseFillPaint(true);
        boolean boolean13 = lineAndShapeRenderer10.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        boolean boolean15 = sortOrder6.equals((java.lang.Object) categoryAxis8);
        java.lang.String str16 = sortOrder6.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "SortOrder.ASCENDING" + "'", str16.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.lang.String str25 = legendItem23.getToolTipText();
        int int26 = legendItem23.getDatasetIndex();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity10 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ItemLabelAnchor.OUTSIDE12", "hi!", categoryDataset7, (java.lang.Comparable) 192, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        try {
            java.lang.Comparable comparable3 = keyedObjects0.getKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        boolean boolean8 = lineAndShapeRenderer3.getDrawOutlines();
        lineAndShapeRenderer3.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, true);
        java.awt.Paint paint16 = lineAndShapeRenderer3.getItemPaint((int) '4', 100, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot3.removeDomainMarker((int) (byte) -1, marker11, layer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem29 = lineAndShapeRenderer14.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape30 = lineAndShapeRenderer14.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke49 = lineAndShapeRenderer35.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer35.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = lineAndShapeRenderer35.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition(0, itemLabelPosition53);
        java.awt.Stroke stroke55 = lineAndShapeRenderer14.getBaseOutlineStroke();
        java.awt.Stroke stroke57 = lineAndShapeRenderer14.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = lineAndShapeRenderer14.getLegendItems();
        boolean boolean59 = lineAndShapeRenderer14.getAutoPopulateSeriesPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot63.setWeight((int) (short) -1);
        categoryPlot63.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer70 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color75 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer70.setSeriesFillPaint((int) '#', (java.awt.Paint) color75);
        boolean boolean77 = lineAndShapeRenderer70.getBaseSeriesVisible();
        java.awt.Color color81 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer70.setBasePaint((java.awt.Paint) color81);
        org.jfree.chart.LegendItem legendItem85 = lineAndShapeRenderer70.getLegendItem(2, (int) (byte) 1);
        categoryPlot63.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer70, false);
        java.awt.Color color90 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot63.setNoDataMessagePaint((java.awt.Paint) color90);
        lineAndShapeRenderer14.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color90);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(stroke57);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNull(legendItem85);
        org.junit.Assert.assertNotNull(color90);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setWeight((int) (short) -1);
        categoryPlot23.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke29 = categoryPlot23.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot23.zoomDomainAxes((double) '4', plotRenderingInfo31, point2D32, false);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes38 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color45 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer40.setSeriesFillPaint((int) '#', (java.awt.Paint) color45);
        renderAttributes38.setSeriesFillPaint(10, (java.awt.Paint) color45);
        java.awt.Paint paint50 = renderAttributes38.getItemOutlinePaint(255, 2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color56 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer51.setSeriesFillPaint((int) '#', (java.awt.Paint) color56);
        boolean boolean58 = lineAndShapeRenderer51.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation59 = null;
        boolean boolean60 = lineAndShapeRenderer51.removeAnnotation(categoryAnnotation59);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot61.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        int int65 = categoryPlot61.indexOf(categoryDataset64);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent66 = null;
        categoryPlot61.notifyListeners(plotChangeEvent66);
        org.jfree.data.general.DatasetGroup datasetGroup68 = categoryPlot61.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color74 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setSeriesFillPaint((int) '#', (java.awt.Paint) color74);
        boolean boolean76 = lineAndShapeRenderer69.getBaseSeriesVisible();
        java.awt.Font font78 = null;
        lineAndShapeRenderer69.setSeriesItemLabelFont((int) (byte) 0, font78, false);
        java.awt.Stroke stroke84 = lineAndShapeRenderer69.getItemStroke(2, 0, false);
        java.awt.Stroke stroke88 = lineAndShapeRenderer69.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot61.setRangeCrosshairStroke(stroke88);
        lineAndShapeRenderer51.setBaseStroke(stroke88, true);
        try {
            lineAndShapeRenderer0.drawDomainLine(graphics2D22, categoryPlot23, rectangle2D35, 1.0d, paint50, stroke88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNull(datasetGroup68);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(stroke88);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setSeriesFillPaint((int) '#', (java.awt.Paint) color11);
        boolean boolean13 = lineAndShapeRenderer6.getBaseSeriesVisible();
        java.awt.Color color17 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setBasePaint((java.awt.Paint) color17);
        org.jfree.chart.LegendItem legendItem21 = lineAndShapeRenderer6.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape22 = lineAndShapeRenderer6.getBaseShape();
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color24 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape22, stroke23, (java.awt.Paint) color24);
        java.awt.Color color26 = java.awt.Color.gray;
        legendItem25.setFillPaint((java.awt.Paint) color26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str29 = color28.toString();
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color28.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        int int36 = color28.getTransparency();
        float[] floatArray41 = new float[] { (short) -1, (short) 1, 10.0f, 2 };
        float[] floatArray42 = color28.getComponents(floatArray41);
        float[] floatArray43 = color26.getColorComponents(floatArray41);
        try {
            float[] floatArray44 = color0.getColorComponents(colorSpace1, floatArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str29.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) 100, (java.lang.Boolean) false, false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator18 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator19 = null;
        java.lang.String str20 = chartEntity17.getImageMapAreaTag(toolTipTagFragmentGenerator18, uRLTagFragmentGenerator19);
        java.lang.String str21 = chartEntity17.toString();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color27 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer22.setSeriesFillPaint((int) '#', (java.awt.Paint) color27);
        boolean boolean29 = lineAndShapeRenderer22.getBaseSeriesVisible();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer22.setBasePaint((java.awt.Paint) color33);
        org.jfree.chart.LegendItem legendItem37 = lineAndShapeRenderer22.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape38 = lineAndShapeRenderer22.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = null;
        lineAndShapeRenderer22.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition40);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color48 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer43.setSeriesFillPaint((int) '#', (java.awt.Paint) color48);
        boolean boolean50 = lineAndShapeRenderer43.getBaseSeriesVisible();
        java.awt.Color color54 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer43.setBasePaint((java.awt.Paint) color54);
        java.awt.Stroke stroke57 = lineAndShapeRenderer43.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer43.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = lineAndShapeRenderer43.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer22.setSeriesPositiveItemLabelPosition(0, itemLabelPosition61);
        lineAndShapeRenderer22.setBaseSeriesVisible(false, false);
        java.awt.Paint paint66 = lineAndShapeRenderer22.getBaseLegendTextPaint();
        lineAndShapeRenderer22.setSeriesShapesVisible((int) '#', (java.lang.Boolean) true);
        boolean boolean70 = chartEntity17.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartEntity: tooltip = null" + "'", str21.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(legendItem37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(itemLabelPosition61);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot6.notifyListeners(plotChangeEvent7);
        categoryPlot6.clearAnnotations();
        org.jfree.data.KeyedObject keyedObject10 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) categoryPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer18.setSeriesFillPaint((int) '#', (java.awt.Paint) color23);
        boolean boolean25 = lineAndShapeRenderer18.getBaseSeriesVisible();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer18.setBasePaint((java.awt.Paint) color29);
        org.jfree.chart.LegendItem legendItem33 = lineAndShapeRenderer18.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape34 = lineAndShapeRenderer18.getBaseShape();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color36 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape34, stroke35, (java.awt.Paint) color36);
        java.lang.String str38 = legendItem37.getDescription();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem37.setFillPaint((java.awt.Paint) color39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        categoryPlot41.markerChanged(markerChangeEvent42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation46 = axisLocation45.getOpposite();
        categoryPlot41.setDomainAxisLocation(10, axisLocation45, true);
        categoryPlot41.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke51 = categoryPlot41.getOutlineStroke();
        try {
            lineAndShapeRenderer0.drawRangeLine(graphics2D4, categoryPlot6, valueAxis11, rectangle2D12, 0.0d, (java.awt.Paint) color39, stroke51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(legendItem33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers(layer15);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        try {
            categoryPlot0.setBackgroundImageAlpha((float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 10, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint18 = lineAndShapeRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setSeriesFillPaint((int) '#', (java.awt.Paint) color24);
        boolean boolean26 = lineAndShapeRenderer19.getBaseSeriesVisible();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setBasePaint((java.awt.Paint) color30);
        java.awt.Stroke stroke33 = lineAndShapeRenderer19.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer34.setSeriesFillPaint((int) '#', (java.awt.Paint) color39);
        boolean boolean41 = lineAndShapeRenderer34.getBaseSeriesVisible();
        java.awt.Color color45 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer34.setBasePaint((java.awt.Paint) color45);
        java.awt.Stroke stroke48 = lineAndShapeRenderer34.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer34.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = lineAndShapeRenderer34.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer19.setBaseNegativeItemLabelPosition(itemLabelPosition52);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition52, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator18 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator19 = null;
        java.lang.String str20 = chartEntity17.getImageMapAreaTag(toolTipTagFragmentGenerator18, uRLTagFragmentGenerator19);
        java.lang.String str21 = chartEntity17.getURLText();
        java.lang.String str22 = chartEntity17.getToolTipText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        java.awt.Color color27 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        int int33 = categoryPlot29.indexOf(categoryDataset32);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot35.markerChanged(markerChangeEvent36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation40 = axisLocation39.getOpposite();
        categoryPlot35.setDomainAxisLocation(10, axisLocation39, true);
        categoryPlot29.setRangeAxisLocation((int) (byte) 0, axisLocation39);
        categoryPlot0.setRangeAxisLocation(axisLocation39);
        boolean boolean45 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker5);
        java.util.List list7 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        try {
            int int11 = categoryPlot0.getRangeAxisIndex(valueAxis10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        legendItem23.setToolTipText("");
        legendItem23.setDatasetIndex(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint30 = lineAndShapeRenderer29.getBaseOutlinePaint();
        legendItem23.setLabelPaint(paint30);
        java.awt.Shape shape32 = legendItem23.getLine();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        float[] floatArray4 = new float[] { 100L };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB(2, (int) (byte) 10, 0, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        lineAndShapeRenderer3.setBaseLinesVisible(true);
        java.awt.Font font10 = lineAndShapeRenderer3.getBaseItemLabelFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        try {
            lineAndShapeRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) -1, (float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Paint paint25 = legendItem23.getFillPaint();
        legendItem23.setSeriesKey((java.lang.Comparable) (-6.0d));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        java.awt.Paint paint11 = categoryPlot8.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getRangeAxisEdge();
        boolean boolean13 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot8.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder14);
        boolean boolean16 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        int int18 = categoryPlot0.indexOf(categoryDataset17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-16777216), (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        java.lang.Comparable comparable12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke17 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        categoryPlot16.markerChanged(markerChangeEvent18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot16.getDomainAxisEdge();
        try {
            double double21 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) 10L, comparable12, categoryDataset13, categoryAxis14, rectangle2D15, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 1, jFreeChart1, chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 1 + "'", obj4.equals((short) 1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator18 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator19 = null;
        java.lang.String str20 = chartEntity17.getImageMapAreaTag(toolTipTagFragmentGenerator18, uRLTagFragmentGenerator19);
        chartEntity17.setToolTipText("GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            boolean boolean4 = categoryPlot0.removeRangeMarker((int) (byte) -1, marker2, layer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer41.setSeriesFillPaint((int) '#', (java.awt.Paint) color46);
        boolean boolean48 = lineAndShapeRenderer41.getBaseSeriesVisible();
        java.awt.Font font50 = null;
        lineAndShapeRenderer41.setSeriesItemLabelFont((int) (byte) 0, font50, false);
        java.awt.Stroke stroke56 = lineAndShapeRenderer41.getItemStroke(2, 0, false);
        java.awt.Stroke stroke60 = lineAndShapeRenderer41.getItemOutlineStroke(0, (int) (byte) 100, false);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke60);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color68 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer63.setSeriesFillPaint((int) '#', (java.awt.Paint) color68);
        java.awt.Shape shape73 = lineAndShapeRenderer63.getItemShape((int) '#', (int) '4', true);
        lineAndShapeRenderer0.setLegendShape(2, shape73);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(shape73);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.clearSeriesPaints(false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        double double25 = categoryPlot20.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace26);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot20.clearRangeMarkers();
        categoryPlot20.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot20.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot20.zoomDomainAxes((double) 1.0f, plotRenderingInfo36, point2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot20.getRangeAxisEdge((int) (byte) 1);
        try {
            double double41 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) (-1.0d), (java.lang.Comparable) 10, categoryDataset17, categoryAxis18, rectangle2D19, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        lineAndShapeRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.lang.Comparable comparable32 = categoryPlot28.getDomainCrosshairRowKey();
        categoryPlot28.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) -1, marker36, layer37);
        lineAndShapeRenderer7.setPlot(categoryPlot28);
        java.awt.Color color40 = java.awt.Color.CYAN;
        lineAndShapeRenderer7.setBaseItemLabelPaint((java.awt.Paint) color40, true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker(0, marker9, layer10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint18 = lineAndShapeRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 10, false);
        boolean boolean24 = lineAndShapeRenderer0.isSeriesVisible((-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        lineAndShapeRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true, true);
        lineAndShapeRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot0.addDomainMarker(3, categoryMarker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        boolean boolean22 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        int int17 = lineAndShapeRenderer0.getColumnCount();
        java.lang.Object obj18 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo16, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot0.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke21);
        java.awt.geom.GeneralPath generalPath23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        categoryPlot0.select(generalPath23, rectangle2D24, renderingSource25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 1, (float) (short) 100, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-83) + "'", int3 == (-83));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) 1, (java.lang.Comparable) (-65536));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.lang.Comparable comparable8 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable8, true);
        categoryPlot0.setDomainGridlinesVisible(false);
        java.lang.Object obj13 = categoryPlot0.clone();
        categoryPlot0.setWeight((-65536));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Paint paint4 = lineAndShapeRenderer0.getBaseOutlinePaint();
        boolean boolean5 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint7 = lineAndShapeRenderer0.getSeriesItemLabelPaint(8);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke8, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean8 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("org.jfree.data.UnknownKeyException: {0}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem23.setFillPaint((java.awt.Paint) color25);
        boolean boolean27 = legendItem23.isShapeOutlineVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setSeriesFillPaint((int) '#', (java.awt.Paint) color33);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setBasePaint((java.awt.Paint) color39);
        java.awt.Stroke stroke42 = lineAndShapeRenderer28.lookupSeriesStroke((int) (short) 10);
        boolean boolean43 = lineAndShapeRenderer28.getDrawOutlines();
        int int44 = lineAndShapeRenderer28.getRowCount();
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.data.Range range46 = lineAndShapeRenderer28.findRangeBounds(categoryDataset45);
        boolean boolean47 = legendItem23.equals((java.lang.Object) lineAndShapeRenderer28);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot52.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState61 = null;
        try {
            boolean boolean62 = lineAndShapeRenderer28.hitTest((-1.0d), (double) 'a', graphics2D50, rectangle2D51, categoryPlot52, categoryAxis55, valueAxis56, categoryDataset57, 192, 8, true, categoryItemRendererState61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer16.setSeriesFillPaint((int) '#', (java.awt.Paint) color21);
        renderAttributes14.setSeriesFillPaint(10, (java.awt.Paint) color21);
        java.awt.Paint paint25 = renderAttributes14.getSeriesOutlinePaint(100);
        java.awt.Paint paint26 = renderAttributes14.getDefaultOutlinePaint();
        try {
            barRenderer0.setSeriesPaint((-1), paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator(100, categoryToolTipGenerator2, false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo7, point2D8, true);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addDomainMarker(10, categoryMarker14, layer15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        java.awt.Stroke stroke24 = lineAndShapeRenderer10.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = lineAndShapeRenderer10.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        boolean boolean30 = itemLabelPosition28.equals((java.lang.Object) itemLabelAnchor29);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition28);
        java.awt.Paint paint33 = lineAndShapeRenderer0.getSeriesFillPaint((int) (byte) 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(paint33);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        double double5 = rectangleInsets0.trimHeight((double) 1);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        boolean boolean34 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Shape shape36 = lineAndShapeRenderer0.getSeriesShape((int) (short) 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(shape36);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        try {
            lineAndShapeRenderer0.setSeriesToolTipGenerator((-1), categoryToolTipGenerator20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint18 = lineAndShapeRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape6 = lineAndShapeRenderer2.getBaseShape();
        lineAndShapeRenderer2.setBaseSeriesVisible(false, true);
        boolean boolean10 = keyedObjects2D0.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getRed();
        float[] floatArray3 = new float[] { 2 };
        try {
            float[] floatArray4 = color0.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Color color1 = null;
        try {
            org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color1, (float) 0, 192, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'color' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        categoryPlot21.markerChanged(markerChangeEvent22);
        int int24 = categoryPlot21.getCrosshairDatasetIndex();
        float float25 = categoryPlot21.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        categoryPlot21.setDomainAxisLocation((int) (byte) 1, axisLocation27);
        java.lang.Comparable comparable29 = null;
        categoryPlot21.setDomainCrosshairColumnKey(comparable29, true);
        categoryPlot21.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot21.getRenderer();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D20, categoryPlot21, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer34);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) 190.0d, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (190.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        boolean boolean20 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setWeight((int) (short) -1);
        categoryPlot22.setAnchorValue((double) (byte) 10, false);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot22.getRendererForDataset(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D21, categoryPlot22, categoryAxis30, categoryMarker31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(categoryItemRenderer29);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        boolean boolean9 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        int int9 = categoryPlot6.getCrosshairDatasetIndex();
        float float10 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getRangeAxisLocation();
        categoryPlot6.setAnchorValue(0.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState20 = null;
        try {
            java.awt.Shape shape21 = barRenderer0.createHotSpotShape(graphics2D4, rectangle2D5, categoryPlot6, categoryAxis14, valueAxis15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset16, (-16777216), 10, true, categoryItemRendererState20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem23.setFillPaint((java.awt.Paint) color25);
        boolean boolean27 = legendItem23.isShapeOutlineVisible();
        java.awt.Paint paint28 = legendItem23.getLabelPaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint18 = lineAndShapeRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 10, false);
        boolean boolean25 = lineAndShapeRenderer0.getItemVisible((int) '4', (-83));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setBasePaint((java.awt.Paint) color19);
        java.awt.Stroke stroke22 = lineAndShapeRenderer8.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = lineAndShapeRenderer8.getSeriesNegativeItemLabelPosition((int) '4');
        try {
            lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) -1, itemLabelPosition26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.awt.Stroke stroke25 = legendItem24.getOutlineStroke();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        legendItem24.setLine(shape26);
        boolean boolean28 = paintList0.equals((java.lang.Object) legendItem24);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        paintList0.setPaint((int) (byte) 10, (java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        lineAndShapeRenderer0.setBaseShapesFilled(false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.lang.String str25 = legendItem24.getDescription();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem24.setFillPaint((java.awt.Paint) color26);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color26, (float) (short) 100, 3, (double) (short) 100);
        int int32 = defaultShadowGenerator31.getDistance();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color38 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer33.setSeriesFillPaint((int) '#', (java.awt.Paint) color38);
        boolean boolean40 = lineAndShapeRenderer33.getBaseSeriesVisible();
        java.awt.Color color44 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer33.setBasePaint((java.awt.Paint) color44);
        java.awt.Stroke stroke47 = lineAndShapeRenderer33.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer33.setAutoPopulateSeriesStroke(true);
        boolean boolean50 = defaultShadowGenerator31.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        boolean boolean34 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke49 = lineAndShapeRenderer35.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer35.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint53 = lineAndShapeRenderer35.lookupSeriesFillPaint(10);
        lineAndShapeRenderer0.setBaseFillPaint(paint53);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color60 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer55.setSeriesFillPaint((int) '#', (java.awt.Paint) color60);
        boolean boolean62 = lineAndShapeRenderer55.getBaseSeriesVisible();
        java.awt.Font font64 = null;
        lineAndShapeRenderer55.setSeriesItemLabelFont((int) (byte) 0, font64, false);
        java.awt.Stroke stroke70 = lineAndShapeRenderer55.getItemStroke(2, 0, false);
        java.awt.Stroke stroke74 = lineAndShapeRenderer55.getItemOutlineStroke(0, (int) (byte) 100, false);
        lineAndShapeRenderer0.setBaseStroke(stroke74, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator18 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator19 = null;
        java.lang.String str20 = chartEntity17.getImageMapAreaTag(toolTipTagFragmentGenerator18, uRLTagFragmentGenerator19);
        java.lang.String str21 = chartEntity17.getURLText();
        java.lang.String str22 = chartEntity17.getURLText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke19 = categoryPlot18.getRangeZeroBaselineStroke();
        lineAndShapeRenderer0.setSeriesStroke(2, stroke19, false);
        java.awt.Font font23 = lineAndShapeRenderer0.lookupLegendTextFont((int) (short) 0);
        java.awt.Shape shape25 = lineAndShapeRenderer0.getSeriesShape(8);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNull(shape25);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int3 = java.awt.Color.HSBtoRGB((float) 15, (float) 'a', 100.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-23167) + "'", int3 == (-23167));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) itemLabelAnchor1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer3.setBaseToolTipGenerator(categoryToolTipGenerator4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = lineAndShapeRenderer3.getLegendItemLabelGenerator();
        java.awt.Paint paint9 = lineAndShapeRenderer3.lookupSeriesFillPaint((int) (short) 1);
        boolean boolean10 = datasetRenderingOrder0.equals((java.lang.Object) lineAndShapeRenderer3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem23.setFillPaint((java.awt.Paint) color25);
        boolean boolean27 = legendItem23.isShapeOutlineVisible();
        java.lang.String str28 = legendItem23.getLabel();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=128]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("{0}");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str2.equals("org.jfree.data.UnknownKeyException: {0}"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 1);
        boolean boolean7 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setAnchorValue(0.0d);
        categoryPlot0.clearRangeMarkers(255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        java.lang.Comparable comparable6 = null;
        try {
            keyedObjects0.insertValue(0, comparable6, (java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str2.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        java.lang.Boolean boolean3 = booleanList0.getBoolean((int) (short) 100);
        int int4 = booleanList0.size();
        int int5 = booleanList0.size();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setShadowVisible(false);
        categoryPlot0.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        boolean boolean17 = categoryPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.awt.Stroke stroke27 = legendItem23.getLineStroke();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        boolean boolean8 = lineAndShapeRenderer3.getDrawOutlines();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        lineAndShapeRenderer3.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Shape shape12 = lineAndShapeRenderer3.lookupSeriesShape(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = lineAndShapeRenderer3.getURLGenerator(15, 100, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(categoryURLGenerator16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        try {
            defaultCategoryDataset0.setSelected((int) ' ', 1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        boolean boolean9 = categoryPlot0.isRangeZeroBaselineVisible();
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) '4', plotRenderingInfo8, point2D9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        int int15 = categoryPlot12.getCrosshairDatasetIndex();
        float float16 = categoryPlot12.getForegroundAlpha();
        double double17 = categoryPlot12.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint20 = renderAttributes19.getDefaultOutlinePaint();
        categoryPlot12.setNoDataMessagePaint(paint20);
        java.awt.Paint paint22 = categoryPlot12.getDomainCrosshairPaint();
        categoryPlot0.setDomainCrosshairPaint(paint22);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer((int) (short) 100, categoryItemRenderer9, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, false);
        java.awt.Paint paint47 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryPlot48.markerChanged(markerChangeEvent49);
        int int51 = categoryPlot48.getCrosshairDatasetIndex();
        float float52 = categoryPlot48.getForegroundAlpha();
        double double53 = categoryPlot48.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        categoryPlot48.setFixedRangeAxisSpace(axisSpace54);
        categoryPlot48.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot48.clearRangeMarkers();
        categoryPlot48.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot48.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot48.zoomDomainAxes((double) 1.0f, plotRenderingInfo64, point2D65);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot48.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot48.setRangeMinorGridlineStroke(stroke69);
        lineAndShapeRenderer0.setBaseStroke(stroke69, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 1.0f + "'", float52 == 1.0f);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(stroke69);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        try {
            categoryPlot0.setRangeAxis((-16777216), valueAxis11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            defaultCategoryDataset0.setSelected((int) (byte) 0, 2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.ShadowGenerator shadowGenerator9 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator9);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = categoryPlot0.removeRangeMarker((-1), marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        objectList0.set(8, (java.lang.Object) paint6);
        java.lang.Object obj9 = objectList0.get((int) ' ');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean8 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(1, categoryDataset12);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot0.addRangeMarker(marker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.KeyedObjects2D keyedObjects2D3 = new org.jfree.data.KeyedObjects2D();
        int int4 = keyedObjects2D3.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot5.markerChanged(markerChangeEvent6);
        int int8 = categoryPlot5.getCrosshairDatasetIndex();
        float float9 = categoryPlot5.getForegroundAlpha();
        double double10 = categoryPlot5.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot5.getAxisOffset();
        boolean boolean14 = keyedObjects2D3.equals((java.lang.Object) rectangleInsets13);
        double double15 = rectangleInsets13.getTop();
        categoryPlot0.setInsets(rectangleInsets13);
        double double18 = rectangleInsets13.extendWidth((double) 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11.0d + "'", double18 == 11.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        try {
            boolean boolean4 = defaultCategoryDataset0.isSelected((int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (short) -1, false);
        java.lang.Number number3 = selectableValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) -1 + "'", number3.equals((short) -1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setUseFillPaint(true);
        boolean boolean14 = lineAndShapeRenderer11.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        int int20 = categoryPlot16.indexOf(categoryDataset19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot16.notifyListeners(plotChangeEvent21);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot16.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer24.setSeriesFillPaint((int) '#', (java.awt.Paint) color29);
        boolean boolean31 = lineAndShapeRenderer24.getBaseSeriesVisible();
        java.awt.Font font33 = null;
        lineAndShapeRenderer24.setSeriesItemLabelFont((int) (byte) 0, font33, false);
        java.awt.Stroke stroke39 = lineAndShapeRenderer24.getItemStroke(2, 0, false);
        java.awt.Stroke stroke43 = lineAndShapeRenderer24.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot16.setRangeCrosshairStroke(stroke43);
        lineAndShapeRenderer11.setSeriesOutlineStroke((int) (byte) 10, stroke43, false);
        renderAttributes1.setDefaultStroke(stroke43);
        java.lang.Boolean boolean48 = renderAttributes1.getDefaultCreateEntity();
        try {
            java.awt.Paint paint50 = renderAttributes1.getSeriesLabelPaint((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(boolean48);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.plot.Marker marker25 = null;
        try {
            categoryPlot0.addRangeMarker(marker25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        java.awt.Shape shape14 = lineAndShapeRenderer4.getItemShape((int) '#', (int) '4', true);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = lineAndShapeRenderer16.getSelectedItemAttributes();
        java.awt.Color color21 = java.awt.Color.red;
        java.awt.Color color22 = java.awt.Color.getColor("ChartEntity: tooltip = null", color21);
        java.awt.Color color23 = java.awt.Color.getColor("ChartEntity: tooltip = null", color21);
        lineAndShapeRenderer16.setSeriesPaint((int) (short) 100, (java.awt.Paint) color21);
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "TextAnchor.BASELINE_CENTER", "ChartEntity: tooltip = null", "", shape14, stroke15, (java.awt.Paint) color21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(renderAttributes17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        boolean boolean8 = lineAndShapeRenderer3.getDrawOutlines();
        lineAndShapeRenderer3.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, true);
        lineAndShapeRenderer3.setBaseLinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Comparable comparable2 = keyedObjects0.getKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint3 = barRenderer0.getLegendTextPaint((int) (short) 1);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.lang.String str25 = legendItem24.getDescription();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem24.setFillPaint((java.awt.Paint) color26);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color26, (float) (short) 100, 3, (double) (short) 100);
        float float32 = defaultShadowGenerator31.getShadowOpacity();
        int int33 = defaultShadowGenerator31.getDistance();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 100.0f + "'", float32 == 100.0f);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo7, point2D8, true);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addRangeMarker((int) (byte) 100, marker14, layer15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15, true);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = categoryPlot0.removeDomainMarker(marker18);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        categoryPlot4.setDomainAxisLocation(10, axisLocation8, true);
        categoryPlot0.setDomainAxisLocation(axisLocation8, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot0.getDataset((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(categoryDataset15);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Shape shape15 = lineAndShapeRenderer0.getItemShape((int) (short) 10, 0, true);
        java.awt.Paint paint17 = lineAndShapeRenderer0.getSeriesItemLabelPaint(3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup21 = defaultCategoryDataset20.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        categoryPlot22.markerChanged(markerChangeEvent23);
        java.awt.Paint paint25 = categoryPlot22.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot22.getRangeAxisEdge();
        boolean boolean27 = defaultCategoryDataset20.hasListener((java.util.EventListener) categoryPlot22);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str29 = categoryAxis28.getLabelToolTip();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        try {
            double double32 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) 0L, (java.lang.Comparable) 0.0f, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset20, categoryAxis28, rectangle2D30, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(datasetGroup21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.Plot plot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = categoryAxis0.reserveSpace(graphics2D2, plot3, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setWeight((int) (short) -1);
        categoryPlot11.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke17 = categoryPlot11.getRangeGridlineStroke();
        int int18 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot11.setDomainAxis(categoryAxis19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str22 = categoryAxis21.getLabelToolTip();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup25 = defaultCategoryDataset24.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
        categoryPlot26.markerChanged(markerChangeEvent27);
        java.awt.Paint paint29 = categoryPlot26.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot26.getRangeAxisEdge();
        boolean boolean31 = defaultCategoryDataset24.hasListener((java.util.EventListener) categoryPlot26);
        defaultCategoryDataset24.fireSelectionEvent();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = null;
        try {
            boolean boolean37 = lineAndShapeRenderer0.hitTest((double) 10, 1.0d, graphics2D9, rectangle2D10, categoryPlot11, categoryAxis21, valueAxis23, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, (int) (short) 0, 10, false, categoryItemRendererState36);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(datasetGroup25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo17, point2D18);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.lang.Comparable comparable8 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable8, true);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.Marker marker13 = null;
        try {
            boolean boolean14 = categoryPlot0.removeRangeMarker(marker13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Shape shape13 = renderAttributes1.getDefaultShape();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer16.setSeriesFillPaint((int) '#', (java.awt.Paint) color21);
        boolean boolean23 = lineAndShapeRenderer16.getBaseSeriesVisible();
        java.awt.Color color27 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer16.setBasePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke30 = lineAndShapeRenderer16.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color36 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer31.setSeriesFillPaint((int) '#', (java.awt.Paint) color36);
        boolean boolean38 = lineAndShapeRenderer31.getBaseSeriesVisible();
        java.awt.Color color42 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer31.setBasePaint((java.awt.Paint) color42);
        java.awt.Stroke stroke45 = lineAndShapeRenderer31.lookupSeriesStroke((int) (short) 10);
        boolean boolean46 = lineAndShapeRenderer31.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = lineAndShapeRenderer31.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer16.setBaseNegativeItemLabelPosition(itemLabelPosition48);
        boolean boolean50 = lineAndShapeRenderer16.getAutoPopulateSeriesPaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        lineAndShapeRenderer16.setSeriesItemLabelPaint(0, paint52, false);
        renderAttributes1.setDefaultOutlinePaint(paint52);
        java.awt.Shape shape57 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent59 = null;
        categoryPlot58.markerChanged(markerChangeEvent59);
        int int61 = categoryPlot58.getCrosshairDatasetIndex();
        float float62 = categoryPlot58.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity63 = new org.jfree.chart.entity.PlotEntity(shape57, (org.jfree.chart.plot.Plot) categoryPlot58);
        java.awt.Shape shape64 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        plotEntity63.setArea(shape64);
        try {
            renderAttributes1.setSeriesShape((int) (short) -1, shape64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 1.0f + "'", float62 == 1.0f);
        org.junit.Assert.assertNotNull(shape64);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        int int17 = lineAndShapeRenderer0.getColumnCount();
        boolean boolean20 = lineAndShapeRenderer0.getItemLineVisible((int) (short) 0, (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset4.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        java.awt.Paint paint9 = categoryPlot6.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge();
        boolean boolean11 = defaultCategoryDataset4.hasListener((java.util.EventListener) categoryPlot6);
        defaultCategoryDataset4.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        categoryPlot18.markerChanged(markerChangeEvent19);
        int int21 = categoryPlot18.getCrosshairDatasetIndex();
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(8);
        try {
            double double25 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) "GradientPaintTransformType.VERTICAL", (java.lang.Comparable) (-65536), (org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, (double) 0.0f, rectangle2D17, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = lineAndShapeRenderer9.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer9.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer9.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition27);
        java.lang.Boolean boolean30 = lineAndShapeRenderer3.getSeriesItemLabelsVisible((int) (byte) 0);
        lineAndShapeRenderer3.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNull(boolean30);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        lineAndShapeRenderer7.setBaseURLGenerator(categoryURLGenerator25);
        java.lang.Boolean boolean28 = lineAndShapeRenderer7.getSeriesCreateEntities(192);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(boolean28);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = null;
        try {
            lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition44, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        try {
            keyedObjects0.removeValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 10, categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        int int22 = lineAndShapeRenderer19.getColumnCount();
        java.awt.Paint paint23 = lineAndShapeRenderer19.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint23, true);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = lineAndShapeRenderer0.getSeriesItemLabelGenerator(255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator45 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        lineAndShapeRenderer0.setUseSeriesOffset(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator45);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        int int10 = categoryPlot0.getRendererCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot0.getDrawingSupplier();
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        categoryPlot13.markerChanged(markerChangeEvent14);
        int int16 = categoryPlot13.getCrosshairDatasetIndex();
        float float17 = categoryPlot13.getForegroundAlpha();
        double double18 = categoryPlot13.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint21 = renderAttributes20.getDefaultOutlinePaint();
        categoryPlot13.setNoDataMessagePaint(paint21);
        int int23 = categoryPlot13.getRendererCount();
        org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) categoryPlot13, "GradientPaintTransformType.VERTICAL", "hi!");
        java.lang.Object obj27 = plotEntity26.clone();
        boolean boolean28 = categoryPlot0.equals(obj27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        boolean boolean34 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        boolean boolean35 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (short) 100, axisLocation6);
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            boolean boolean9 = categoryPlot0.removeRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6);
        categoryPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint18 = lineAndShapeRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 10, false);
        lineAndShapeRenderer0.setUseSeriesOffset(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        java.awt.Font font23 = lineAndShapeRenderer0.lookupLegendTextFont(0);
        lineAndShapeRenderer0.setSeriesLinesVisible(0, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 100, font9);
        java.awt.Stroke stroke11 = lineAndShapeRenderer0.getBaseOutlineStroke();
        try {
            lineAndShapeRenderer0.setItemMargin(190.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke19 = categoryPlot18.getRangeZeroBaselineStroke();
        lineAndShapeRenderer0.setSeriesStroke(2, stroke19, false);
        java.awt.Paint paint22 = null;
        try {
            lineAndShapeRenderer0.setBaseFillPaint(paint22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarPainter barPainter12 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer0.setBarPainter(barPainter12);
        double double14 = barRenderer0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(barPainter12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot0.getDataset((int) (short) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryDataset30);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        lineAndShapeRenderer0.setSeriesPaint(100, (java.awt.Paint) color2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke19 = lineAndShapeRenderer5.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setSeriesFillPaint((int) '#', (java.awt.Paint) color25);
        boolean boolean27 = lineAndShapeRenderer20.getBaseSeriesVisible();
        java.awt.Color color31 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setBasePaint((java.awt.Paint) color31);
        java.awt.Stroke stroke34 = lineAndShapeRenderer20.lookupSeriesStroke((int) (short) 10);
        boolean boolean35 = lineAndShapeRenderer20.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = lineAndShapeRenderer20.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer5.setBaseNegativeItemLabelPosition(itemLabelPosition37);
        boolean boolean39 = lineAndShapeRenderer5.getAutoPopulateSeriesPaint();
        java.awt.Font font43 = lineAndShapeRenderer5.getItemLabelFont((int) '4', 8, false);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (short) 100, font43, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        float float5 = categoryPlot1.getForegroundAlpha();
        double double6 = categoryPlot1.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint9 = renderAttributes8.getDefaultOutlinePaint();
        categoryPlot1.setNoDataMessagePaint(paint9);
        int int11 = categoryPlot1.getRendererCount();
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "GradientPaintTransformType.VERTICAL", "hi!");
        int int15 = categoryPlot1.getRangeAxisCount();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        java.awt.Paint paint11 = categoryPlot8.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getRangeAxisEdge();
        boolean boolean13 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot8.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder14);
        int int16 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        boolean boolean34 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke49 = lineAndShapeRenderer35.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer35.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint53 = lineAndShapeRenderer35.lookupSeriesFillPaint(10);
        lineAndShapeRenderer0.setBaseFillPaint(paint53);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation55 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = lineAndShapeRenderer0.getSeriesItemLabelGenerator(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        boolean boolean8 = categoryPlot0.isNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot10.markerChanged(markerChangeEvent11);
        int int13 = categoryPlot10.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        categoryPlot14.setDomainAxisLocation(10, axisLocation18, true);
        categoryPlot10.setDomainAxisLocation(axisLocation18, false);
        categoryPlot0.setRangeAxisLocation(axisLocation18, false);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot0.getDatasetGroup();
        java.awt.Font font27 = categoryPlot0.getNoDataMessageFont();
        int int28 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            boolean boolean13 = categoryPlot3.removeRangeMarker(15, marker10, layer11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0L, (double) (short) 100, (double) 0, 2.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Paint paint14 = null;
        renderAttributes1.setSeriesFillPaint((int) (short) 1, paint14);
        try {
            java.awt.Stroke stroke17 = renderAttributes1.getSeriesOutlineStroke((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        categoryPlot0.clearSelection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = lineAndShapeRenderer5.getSeriesURLGenerator(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        lineAndShapeRenderer14.setBaseToolTipGenerator(categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = lineAndShapeRenderer14.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        try {
            lineAndShapeRenderer5.setSeriesNegativeItemLabelPosition((-65536), itemLabelPosition21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        try {
            java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (hi!) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer5.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = lineAndShapeRenderer5.getLegendItemLabelGenerator();
        int int10 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        try {
            lineAndShapeRenderer5.setItemMargin(99.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        legendItem23.setSeriesIndex((-65536));
        java.text.AttributedString attributedString30 = legendItem23.getAttributedLabel();
        int int31 = legendItem23.getDatasetIndex();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertNull(attributedString30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        defaultCategoryDataset0.clear();
        java.lang.Comparable comparable13 = null;
        try {
            int int14 = defaultCategoryDataset0.getRowIndex(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addRangeMarker(marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setUseFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape9 = lineAndShapeRenderer4.lookupSeriesShape(0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape9, (java.awt.Paint) color10);
        java.awt.Shape shape12 = legendItem11.getShape();
        java.awt.Shape shape13 = legendItem11.getShape();
        java.lang.Object obj14 = legendItem11.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        lineAndShapeRenderer0.setSeriesPaint(100, (java.awt.Paint) color2);
        int int4 = color2.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        lineAndShapeRenderer0.setSeriesShapesVisible(10, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis0.setUpperMargin((double) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        java.awt.Paint paint12 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot8.getRangeAxisEdge(8);
        boolean boolean15 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot8.getDatasetGroup();
        boolean boolean17 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot8);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        categoryPlot21.markerChanged(markerChangeEvent22);
        int int24 = categoryPlot21.getCrosshairDatasetIndex();
        float float25 = categoryPlot21.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot21.getRangeAxisEdge();
        try {
            double double27 = categoryAxis0.getCategoryMiddle((int) '4', 0, rectangle2D20, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(43.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        java.lang.Comparable comparable33 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        java.awt.Paint paint6 = null;
        try {
            categoryAxis0.setLabelPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Paint paint4 = lineAndShapeRenderer0.getBaseOutlinePaint();
        boolean boolean5 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Stroke stroke6 = lineAndShapeRenderer0.getBaseStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer8.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer8.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        try {
            lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((-83), itemLabelPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent32 = null;
        categoryPlot31.markerChanged(markerChangeEvent32);
        int int34 = categoryPlot31.getCrosshairDatasetIndex();
        float float35 = categoryPlot31.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) categoryPlot31);
        boolean boolean37 = categoryAnchor29.equals((java.lang.Object) plotEntity36);
        categoryPlot0.setDomainGridlinePosition(categoryAnchor29);
        int int39 = categoryPlot0.getCrosshairDatasetIndex();
        int int40 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getColumnCount();
        double double4 = lineAndShapeRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Paint paint5 = renderAttributes1.getItemFillPaint((int) (byte) -1, 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer7.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.awt.Paint paint12 = lineAndShapeRenderer7.getBasePaint();
        java.awt.Stroke stroke16 = lineAndShapeRenderer7.getItemStroke(1, 100, false);
        try {
            renderAttributes1.setSeriesOutlineStroke(2, stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint14 = lineAndShapeRenderer13.getBaseOutlinePaint();
        lineAndShapeRenderer0.setBaseOutlinePaint(paint14, false);
        lineAndShapeRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, false);
        java.awt.Paint paint22 = lineAndShapeRenderer0.getLegendTextPaint((-23167));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRendererForDataset(categoryDataset10);
        int int12 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        java.awt.Paint paint23 = lineAndShapeRenderer0.lookupSeriesPaint(192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setBasePaint((java.awt.Paint) color19);
        org.jfree.chart.LegendItem legendItem23 = lineAndShapeRenderer8.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape24 = lineAndShapeRenderer8.getBaseShape();
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getOutlineStroke();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        legendItem27.setLine(shape29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setBasePaint((java.awt.Paint) color46);
        org.jfree.chart.LegendItem legendItem50 = lineAndShapeRenderer35.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape51 = lineAndShapeRenderer35.getBaseShape();
        java.awt.Stroke stroke52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color53 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape51, stroke52, (java.awt.Paint) color53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str56 = color55.toString();
        try {
            org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem(attributedString0, "rect", "java.awt.Color[r=0,g=0,b=128]", "ChartEntity: tooltip = null", shape29, stroke52, (java.awt.Paint) color55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(legendItem50);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str56.equals("java.awt.Color[r=0,g=0,b=128]"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setWeight((int) (short) -1);
        lineAndShapeRenderer11.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        java.lang.Comparable comparable18 = categoryPlot14.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot19 = categoryPlot14.getRootPlot();
        java.awt.Paint paint20 = categoryPlot14.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot14.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier21, false);
        categoryPlot0.setBackgroundAlpha((float) 8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot0.addChangeListener(plotChangeListener26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot20.setDomainAxisLocation((int) (byte) 1, axisLocation26);
        java.awt.Stroke stroke28 = categoryPlot20.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(15, stroke28);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        barRenderer0.setBase(18.0d);
        boolean boolean14 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Paint paint25 = legendItem23.getFillPaint();
        int int26 = legendItem23.getSeriesIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer27.setSeriesFillPaint((int) '#', (java.awt.Paint) color32);
        java.awt.Paint paint37 = lineAndShapeRenderer27.getItemFillPaint(1, 15, false);
        legendItem23.setLinePaint(paint37);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, (float) (-1), (float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        int int13 = categoryPlot9.indexOf(categoryDataset12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot9.notifyListeners(plotChangeEvent14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot9.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer17.setSeriesFillPaint((int) '#', (java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer17.getBaseSeriesVisible();
        java.awt.Font font26 = null;
        lineAndShapeRenderer17.setSeriesItemLabelFont((int) (byte) 0, font26, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer17.getItemStroke(2, 0, false);
        java.awt.Stroke stroke36 = lineAndShapeRenderer17.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot9.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke39 = categoryPlot38.getRangeZeroBaselineStroke();
        java.awt.Paint paint40 = categoryPlot38.getRangeGridlinePaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "SortOrder.ASCENDING", "GradientPaintTransformType.VERTICAL", "Category Plot", shape4, (java.awt.Paint) color8, stroke36, paint40);
        java.awt.image.ColorModel colorModel42 = null;
        java.awt.Rectangle rectangle43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color8.createContext(colorModel42, rectangle43, rectangle2D44, affineTransform45, renderingHints46);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paintContext47);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100L, (java.lang.Object) 4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition18.getRotationAnchor();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setSeriesFillPaint((int) '#', (java.awt.Paint) color25);
        boolean boolean27 = lineAndShapeRenderer20.getBaseSeriesVisible();
        java.awt.Color color31 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setBasePaint((java.awt.Paint) color31);
        lineAndShapeRenderer20.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color44 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer39.setSeriesFillPaint((int) '#', (java.awt.Paint) color44);
        boolean boolean46 = lineAndShapeRenderer39.getBaseSeriesVisible();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer39.setBasePaint((java.awt.Paint) color50);
        org.jfree.chart.LegendItem legendItem54 = lineAndShapeRenderer39.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape55 = lineAndShapeRenderer39.getBaseShape();
        java.awt.Stroke stroke56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color57 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape55, stroke56, (java.awt.Paint) color57);
        java.awt.Stroke stroke59 = legendItem58.getOutlineStroke();
        lineAndShapeRenderer20.setBaseStroke(stroke59, false);
        boolean boolean62 = textAnchor19.equals((java.lang.Object) lineAndShapeRenderer20);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(legendItem54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.ShadowGenerator shadowGenerator9 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator9);
        int int11 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        lineAndShapeRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator2, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = lineAndShapeRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint7 = lineAndShapeRenderer1.lookupSeriesFillPaint((int) (short) 1);
        java.awt.Paint paint9 = lineAndShapeRenderer1.lookupSeriesFillPaint((int) ' ');
        keyedObjects2D0.setObject((java.lang.Object) lineAndShapeRenderer1, (java.lang.Comparable) 10.0f, (java.lang.Comparable) (-1));
        boolean boolean13 = lineAndShapeRenderer1.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color25);
        java.awt.Stroke stroke28 = lineAndShapeRenderer14.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color34 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer29.setSeriesFillPaint((int) '#', (java.awt.Paint) color34);
        boolean boolean36 = lineAndShapeRenderer29.getBaseSeriesVisible();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer29.setBasePaint((java.awt.Paint) color40);
        java.awt.Stroke stroke43 = lineAndShapeRenderer29.lookupSeriesStroke((int) (short) 10);
        boolean boolean44 = lineAndShapeRenderer29.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer29.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition46);
        boolean boolean48 = lineAndShapeRenderer14.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color54 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer49.setSeriesFillPaint((int) '#', (java.awt.Paint) color54);
        boolean boolean56 = lineAndShapeRenderer49.getBaseSeriesVisible();
        java.awt.Color color60 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer49.setBasePaint((java.awt.Paint) color60);
        java.awt.Stroke stroke63 = lineAndShapeRenderer49.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer49.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint67 = lineAndShapeRenderer49.lookupSeriesFillPaint(10);
        lineAndShapeRenderer14.setBaseFillPaint(paint67);
        lineAndShapeRenderer1.setBaseItemLabelPaint(paint67, false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(paint67);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint5 = lineAndShapeRenderer0.getBasePaint();
        java.awt.Stroke stroke9 = lineAndShapeRenderer0.getItemStroke(1, 100, false);
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        int int11 = color8.getTransparency();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        java.awt.Stroke stroke24 = lineAndShapeRenderer10.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = lineAndShapeRenderer10.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        boolean boolean30 = itemLabelPosition28.equals((java.lang.Object) itemLabelAnchor29);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition28);
        java.awt.Shape shape33 = lineAndShapeRenderer0.lookupSeriesShape((int) '4');
        lineAndShapeRenderer0.setSeriesLinesVisible((int) 'a', true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setSeriesFillPaint((int) '#', (java.awt.Paint) color25);
        boolean boolean27 = lineAndShapeRenderer20.getBaseSeriesVisible();
        java.awt.Color color31 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setBasePaint((java.awt.Paint) color31);
        org.jfree.chart.LegendItem legendItem35 = lineAndShapeRenderer20.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape36 = lineAndShapeRenderer20.getBaseShape();
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color38 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape36, stroke37, (java.awt.Paint) color38);
        lineAndShapeRenderer0.setBaseShape(shape36, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(legendItem35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) 0, false);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState8 = defaultCategoryDataset0.getSelectionState();
        try {
            java.lang.Number number11 = defaultCategoryDataset0.getValue((java.lang.Comparable) (byte) -1, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setSeriesItemLabelsVisible(0, false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        double double7 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot2.getAxisOffset();
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) rectangleInsets10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets10.createInsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke10 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setSeriesFillPaint((int) '#', (java.awt.Paint) color16);
        boolean boolean18 = lineAndShapeRenderer11.getBaseSeriesVisible();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setBasePaint((java.awt.Paint) color22);
        java.awt.Stroke stroke25 = lineAndShapeRenderer11.lookupSeriesStroke((int) (short) 10);
        boolean boolean26 = lineAndShapeRenderer11.getDrawOutlines();
        java.awt.Paint paint28 = lineAndShapeRenderer11.lookupSeriesFillPaint((int) (short) 10);
        categoryPlot0.setRangeZeroBaselinePaint(paint28);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        boolean boolean9 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        int int22 = lineAndShapeRenderer19.getColumnCount();
        java.awt.Paint paint23 = lineAndShapeRenderer19.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint23, true);
        boolean boolean26 = lineAndShapeRenderer0.getBaseShapesFilled();
        try {
            lineAndShapeRenderer0.setSeriesShapesVisible((-83), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 10.0f);
        double double4 = rectangleInsets0.trimWidth((double) (short) 10);
        java.lang.String str5 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-6.0d) + "'", double4 == (-6.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str5.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double4 = rectangleInsets2.calculateTopOutset((double) 10.0f);
        categoryAxis0.setTickLabelInsets(rectangleInsets2);
        categoryAxis0.setVisible(false);
        org.jfree.data.KeyedObjects keyedObjects9 = new org.jfree.data.KeyedObjects();
        java.util.List list10 = keyedObjects9.getKeys();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        int int15 = categoryPlot12.getCrosshairDatasetIndex();
        float float16 = categoryPlot12.getForegroundAlpha();
        double double17 = categoryPlot12.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot12.setFixedRangeAxisSpace(axisSpace18);
        categoryPlot12.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot12.clearRangeMarkers();
        categoryPlot12.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot12.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot12.zoomDomainAxes((double) 1.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot12.getRangeAxisEdge((int) (byte) 1);
        try {
            double double33 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) 10.0f, list10, rectangle2D11, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        java.lang.Comparable comparable59 = categoryItemEntity58.getRowKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + (byte) 1 + "'", comparable59.equals((byte) 1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        boolean boolean5 = categoryPlot0.removeDomainMarker((int) (short) 1, marker3, layer4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        double double7 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot2.getAxisOffset();
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) rectangleInsets10);
        int int13 = keyedObjects2D0.getRowIndex((java.lang.Comparable) true);
        try {
            java.lang.Object obj16 = keyedObjects2D0.getObject((int) 'a', 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        java.lang.Boolean boolean3 = booleanList0.getBoolean((int) (short) 100);
        java.lang.Object obj4 = null;
        boolean boolean5 = booleanList0.equals(obj4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (10) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.awt.Stroke stroke25 = legendItem24.getOutlineStroke();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        legendItem24.setLine(shape26);
        boolean boolean28 = paintList0.equals((java.lang.Object) legendItem24);
        java.lang.Object obj29 = paintList0.clone();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        legendItem23.setSeriesIndex((-65536));
        java.awt.Paint paint30 = legendItem23.getLinePaint();
        int int31 = legendItem23.getSeriesIndex();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-65536) + "'", int31 == (-65536));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke10 = categoryPlot0.getOutlineStroke();
        java.lang.String str11 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) categoryPlot2);
        boolean boolean8 = categoryAnchor0.equals((java.lang.Object) plotEntity7);
        java.lang.String str9 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryAnchor.END" + "'", str9.equals("CategoryAnchor.END"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        int int6 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape23 = lineAndShapeRenderer7.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        lineAndShapeRenderer0.setBaseShape(shape23);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setMaximumBarWidth(0.0d);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        barRenderer0.notifyListeners(rendererChangeEvent8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15, true);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = categoryPlot0.removeDomainMarker(marker18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(axisSpace20);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke27 = categoryPlot26.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        categoryPlot26.drawBackgroundImage(graphics2D28, rectangle2D29);
        org.jfree.chart.plot.Marker marker31 = null;
        boolean boolean32 = categoryPlot26.removeDomainMarker(marker31);
        java.util.List list33 = categoryPlot26.getAnnotations();
        try {
            categoryPlot0.mapDatasetToDomainAxes((-65536), list33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Shape shape13 = renderAttributes1.getDefaultShape();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape13);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = null;
        try {
            legendItem23.setFillPaintTransformer(gradientPaintTransformer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        legendItem23.setSeriesIndex((-65536));
        java.text.AttributedString attributedString30 = legendItem23.getAttributedLabel();
        java.awt.Paint paint31 = legendItem23.getFillPaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertNull(attributedString30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-256) + "'", int1 == (-256));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        java.awt.Paint paint8 = categoryPlot2.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke10 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo12, point2D13);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("GradientPaintTransformType.VERTICAL", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        boolean boolean12 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot4);
        boolean boolean13 = categoryAxis0.isVisible();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        java.awt.Paint paint24 = categoryPlot20.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot20.getRangeAxisEdge(8);
        try {
            double double27 = categoryAxis0.getCategorySeriesMiddle(8, (-65536), (int) (short) 1, 100, 0.0d, rectangle2D19, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        boolean boolean8 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE2" + "'", str1.equals("ItemLabelAnchor.INSIDE2"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot20.setDomainAxisLocation((int) (byte) 1, axisLocation26);
        java.awt.Stroke stroke28 = categoryPlot20.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(15, stroke28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer38.setUseFillPaint(true);
        boolean boolean41 = lineAndShapeRenderer38.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape43 = lineAndShapeRenderer38.lookupSeriesShape(0);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape43, (java.awt.Paint) color44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot46.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        int int50 = categoryPlot46.indexOf(categoryDataset49);
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape43, (org.jfree.chart.plot.Plot) categoryPlot46, "ItemLabelAnchor.INSIDE4", "{0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent55 = null;
        categoryPlot54.markerChanged(markerChangeEvent55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation59 = axisLocation58.getOpposite();
        categoryPlot54.setDomainAxisLocation(10, axisLocation58, true);
        categoryPlot54.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke64 = categoryPlot54.getOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color74 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setSeriesFillPaint((int) '#', (java.awt.Paint) color74);
        boolean boolean76 = lineAndShapeRenderer69.getBaseSeriesVisible();
        java.awt.Color color80 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setBasePaint((java.awt.Paint) color80);
        org.jfree.chart.LegendItem legendItem84 = lineAndShapeRenderer69.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape85 = lineAndShapeRenderer69.getBaseShape();
        java.awt.Stroke stroke86 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color87 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape85, stroke86, (java.awt.Paint) color87);
        java.awt.Color color89 = java.awt.Color.gray;
        legendItem88.setFillPaint((java.awt.Paint) color89);
        org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "ChartEntity: tooltip = null", "GradientPaintTransformType.VERTICAL", "", shape43, stroke64, (java.awt.Paint) color89);
        lineAndShapeRenderer0.setBaseShape(shape43);
        boolean boolean93 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNull(legendItem84);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        java.lang.Object obj2 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        int int4 = lineAndShapeRenderer0.getColumnCount();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        lineAndShapeRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.lang.Comparable comparable32 = categoryPlot28.getDomainCrosshairRowKey();
        categoryPlot28.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) -1, marker36, layer37);
        lineAndShapeRenderer7.setPlot(categoryPlot28);
        lineAndShapeRenderer7.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        categoryItemEntity58.setColumnKey((java.lang.Comparable) 43.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 100, font9);
        java.awt.Paint paint14 = lineAndShapeRenderer0.getItemPaint((int) (short) 1, (int) (byte) 100, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer0.getSeriesToolTipGenerator((-256));
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setWeight((int) (short) -1);
        categoryPlot13.setAnchorValue((double) (byte) 10, false);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot13);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot13.getRangeMarkers(2, layer21);
        float float23 = categoryPlot13.getBackgroundAlpha();
        org.jfree.chart.util.ShadowGenerator shadowGenerator24 = categoryPlot13.getShadowGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(shadowGenerator24);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        boolean boolean45 = lineAndShapeRenderer0.getUseSeriesOffset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.panDomainAxes((double) 3, plotRenderingInfo17, point2D18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color25 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer20.setSeriesFillPaint((int) '#', (java.awt.Paint) color25);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 10.0f);
        double double4 = rectangleInsets0.trimWidth((double) (short) 10);
        double double6 = rectangleInsets0.calculateTopInset(0.0d);
        double double8 = rectangleInsets0.calculateTopOutset(99.0d);
        double double10 = rectangleInsets0.calculateBottomOutset((double) 3);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-6.0d) + "'", double4 == (-6.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        lineAndShapeRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator2, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = lineAndShapeRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint7 = lineAndShapeRenderer1.lookupSeriesFillPaint((int) (short) 1);
        java.awt.Paint paint9 = lineAndShapeRenderer1.lookupSeriesFillPaint((int) ' ');
        keyedObjects2D0.setObject((java.lang.Object) lineAndShapeRenderer1, (java.lang.Comparable) 10.0f, (java.lang.Comparable) (-1));
        boolean boolean13 = lineAndShapeRenderer1.getBaseSeriesVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup17 = defaultCategoryDataset16.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        categoryPlot18.markerChanged(markerChangeEvent19);
        java.awt.Paint paint21 = categoryPlot18.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot18.getRangeAxisEdge();
        boolean boolean23 = defaultCategoryDataset16.hasListener((java.util.EventListener) categoryPlot18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setSeriesFillPaint((int) '#', (java.awt.Paint) color33);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setBasePaint((java.awt.Paint) color39);
        org.jfree.chart.LegendItem legendItem43 = lineAndShapeRenderer28.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape44 = lineAndShapeRenderer28.getBaseShape();
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color46 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape44, stroke45, (java.awt.Paint) color46);
        java.awt.Color color48 = java.awt.Color.gray;
        legendItem47.setFillPaint((java.awt.Paint) color48);
        java.text.AttributedString attributedString50 = legendItem47.getAttributedLabel();
        java.text.AttributedString attributedString51 = legendItem47.getAttributedLabel();
        boolean boolean52 = legendItem47.isShapeVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup54 = defaultCategoryDataset53.getGroup();
        boolean boolean55 = legendItem47.equals((java.lang.Object) datasetGroup54);
        defaultCategoryDataset16.setGroup(datasetGroup54);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent60 = null;
        categoryPlot59.markerChanged(markerChangeEvent60);
        int int62 = categoryPlot59.getCrosshairDatasetIndex();
        float float63 = categoryPlot59.getForegroundAlpha();
        double double64 = categoryPlot59.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot59.setFixedRangeAxisSpace(axisSpace65);
        categoryPlot59.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot59.clearRangeMarkers();
        categoryPlot59.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot59.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        java.awt.geom.Point2D point2D76 = null;
        categoryPlot59.zoomDomainAxes((double) 1.0f, plotRenderingInfo75, point2D76);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = categoryPlot59.getRangeAxisEdge((int) (byte) 1);
        try {
            double double80 = lineAndShapeRenderer1.getItemMiddle((java.lang.Comparable) 255, (java.lang.Comparable) 'a', (org.jfree.data.category.CategoryDataset) defaultCategoryDataset16, categoryAxis57, rectangle2D58, rectangleEdge79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(datasetGroup17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(legendItem43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(attributedString50);
        org.junit.Assert.assertNull(attributedString51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(datasetGroup54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 1.0f + "'", float63 == 1.0f);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(rectangleEdge79);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setRangeZeroBaselineVisible(true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        java.lang.Boolean boolean12 = lineAndShapeRenderer0.getSeriesShapesFilled(100);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        categoryPlot14.setDomainAxisLocation(10, axisLocation18, true);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke24 = categoryPlot14.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesStroke(10, stroke24, true);
        java.awt.Paint paint28 = lineAndShapeRenderer0.lookupSeriesPaint(8);
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        try {
            java.lang.Object obj3 = keyedObjects0.getObject((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint11 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer13.setUseFillPaint(true);
        int int16 = lineAndShapeRenderer13.getColumnCount();
        java.awt.Paint paint17 = lineAndShapeRenderer13.getBaseOutlinePaint();
        barRenderer0.setSeriesPaint((int) (byte) 100, paint17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setMaximumBarWidth(0.0d);
        java.awt.Paint paint11 = barRenderer0.getItemFillPaint(0, (int) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            categoryAxis0.setTickLabelInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (short) -1, false);
        selectableValue2.setSelected(true);
        selectableValue2.setSelected(true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        categoryPlot7.setDomainAxisLocation(10, axisLocation11, true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation11.getOpposite();
        categoryPlot0.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.Marker marker18 = null;
        try {
            categoryPlot0.addRangeMarker(marker18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot0.removeDomainMarker(marker9);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.clearSeriesPaints(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryPlot15.markerChanged(markerChangeEvent16);
        java.awt.Paint paint18 = categoryPlot15.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot15.getRangeAxisEdge();
        boolean boolean20 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot15.getRowRenderingOrder();
        categoryPlot15.clearRangeMarkers();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot15.axisChanged(axisChangeEvent23);
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        boolean boolean26 = categoryPlot15.isNotify();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot11.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke19, false);
        java.awt.Font font23 = lineAndShapeRenderer0.lookupLegendTextFont(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setWeight((int) (short) -1);
        categoryPlot25.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        boolean boolean39 = lineAndShapeRenderer32.getBaseSeriesVisible();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setBasePaint((java.awt.Paint) color43);
        org.jfree.chart.LegendItem legendItem47 = lineAndShapeRenderer32.getLegendItem(2, (int) (byte) 1);
        categoryPlot25.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer32, false);
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer32.setSeriesItemLabelFont((int) 'a', font51);
        lineAndShapeRenderer0.setLegendTextFont(15, font51);
        lineAndShapeRenderer0.clearSeriesPaints(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(legendItem47);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.awt.Paint paint11 = lineAndShapeRenderer3.getItemOutlinePaint((int) '4', (-23167), false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setMaximumBarWidth(0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        int int13 = categoryPlot9.indexOf(categoryDataset12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot9.notifyListeners(plotChangeEvent14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot9.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer17.setSeriesFillPaint((int) '#', (java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer17.getBaseSeriesVisible();
        java.awt.Font font26 = null;
        lineAndShapeRenderer17.setSeriesItemLabelFont((int) (byte) 0, font26, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer17.getItemStroke(2, 0, false);
        java.awt.Stroke stroke36 = lineAndShapeRenderer17.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot9.setRangeCrosshairStroke(stroke36);
        try {
            barRenderer0.setSeriesStroke((-83), stroke36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        java.lang.Boolean boolean3 = booleanList0.getBoolean((int) (short) 100);
        java.lang.Boolean boolean5 = booleanList0.getBoolean((-65536));
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer4.setShadowVisible(false);
        barRenderer4.setShadowYOffset(1.0d);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke13 = categoryPlot10.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot10.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        barRenderer4.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis19, marker20, rectangle2D21);
        try {
            keyedObjects0.insertValue((int) 'a', (java.lang.Comparable) (-1.0f), (java.lang.Object) barRenderer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        lineAndShapeRenderer0.setSeriesShapesFilled(255, false);
        lineAndShapeRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        float float4 = categoryAxis0.getMinorTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        java.awt.Paint paint9 = categoryPlot6.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge();
        boolean boolean11 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot6.getRowRenderingOrder();
        categoryPlot6.clearRangeMarkers();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace17 = categoryAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot6, rectangle2D14, rectangleEdge15, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(sortOrder12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.getItemPaint(0, (int) ' ', true);
        java.awt.Shape shape8 = lineAndShapeRenderer0.lookupLegendShape((int) 'a');
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Shape shape17 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        java.awt.Paint paint24 = categoryPlot20.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot20.getRangeAxisEdge(8);
        boolean boolean27 = categoryPlot20.getDrawSharedDomainAxis();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup29 = defaultCategoryDataset28.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        categoryPlot30.markerChanged(markerChangeEvent31);
        java.awt.Paint paint33 = categoryPlot30.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot30.getRangeAxisEdge();
        boolean boolean35 = defaultCategoryDataset28.hasListener((java.util.EventListener) categoryPlot30);
        defaultCategoryDataset28.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int40 = defaultCategoryDataset28.getColumnCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = lineAndShapeRenderer0.initialise(graphics2D18, rectangle2D19, categoryPlot20, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, plotRenderingInfo41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot20.removeChangeListener(plotChangeListener43);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(datasetGroup29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererState42);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        int int5 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        double double16 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace17);
        categoryPlot11.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot11.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot11.zoomDomainAxes((double) 1.0f, plotRenderingInfo27, point2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot11.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot11.setRangeMinorGridlineStroke(stroke32);
        renderAttributes1.setDefaultStroke(stroke32);
        java.awt.Color color36 = java.awt.Color.GRAY;
        try {
            renderAttributes1.setSeriesLabelPaint((-65536), (java.awt.Paint) color36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        try {
            java.lang.Object obj3 = keyedObjects0.getObject(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        int int8 = defaultCategoryDataset0.getRowCount();
        java.lang.Comparable comparable10 = null;
        try {
            java.lang.Number number11 = defaultCategoryDataset0.getValue((java.lang.Comparable) 2.0d, comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis(15, valueAxis9, true);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint11 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        boolean boolean23 = lineAndShapeRenderer13.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot24.markerChanged(markerChangeEvent25);
        int int27 = categoryPlot24.getCrosshairDatasetIndex();
        float float28 = categoryPlot24.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        categoryPlot24.setDomainAxisLocation((int) (byte) 1, axisLocation30);
        java.awt.Stroke stroke32 = categoryPlot24.getOutlineStroke();
        lineAndShapeRenderer13.setBaseOutlineStroke(stroke32, false);
        java.awt.Font font36 = lineAndShapeRenderer13.lookupLegendTextFont(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot38.setWeight((int) (short) -1);
        categoryPlot38.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        boolean boolean52 = lineAndShapeRenderer45.getBaseSeriesVisible();
        java.awt.Color color56 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setBasePaint((java.awt.Paint) color56);
        org.jfree.chart.LegendItem legendItem60 = lineAndShapeRenderer45.getLegendItem(2, (int) (byte) 1);
        categoryPlot38.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45, false);
        java.awt.Font font64 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer45.setSeriesItemLabelFont((int) 'a', font64);
        lineAndShapeRenderer13.setLegendTextFont(15, font64);
        barRenderer0.setSeriesItemLabelFont(255, font64);
        double double68 = barRenderer0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(font36);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(legendItem60);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 4.0d + "'", double68 == 4.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.Plot plot2 = null;
        categoryAxis0.setPlot(plot2);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, (float) (-1), (float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        int int13 = categoryPlot9.indexOf(categoryDataset12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot9.notifyListeners(plotChangeEvent14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot9.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer17.setSeriesFillPaint((int) '#', (java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer17.getBaseSeriesVisible();
        java.awt.Font font26 = null;
        lineAndShapeRenderer17.setSeriesItemLabelFont((int) (byte) 0, font26, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer17.getItemStroke(2, 0, false);
        java.awt.Stroke stroke36 = lineAndShapeRenderer17.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot9.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke39 = categoryPlot38.getRangeZeroBaselineStroke();
        java.awt.Paint paint40 = categoryPlot38.getRangeGridlinePaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "SortOrder.ASCENDING", "GradientPaintTransformType.VERTICAL", "Category Plot", shape4, (java.awt.Paint) color8, stroke36, paint40);
        int int42 = legendItem41.getSeriesIndex();
        boolean boolean43 = legendItem41.isShapeOutlineVisible();
        java.awt.Paint paint44 = null;
        try {
            legendItem41.setOutlinePaint(paint44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        float float5 = categoryPlot1.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity6 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1);
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        plotEntity6.setArea(shape7);
        org.jfree.chart.plot.Plot plot9 = plotEntity6.getPlot();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        lineAndShapeRenderer3.setBaseLinesVisible(true);
        java.awt.Font font10 = lineAndShapeRenderer3.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineAndShapeRenderer3.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        categoryPlot3.setForegroundAlpha((float) (byte) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot3.setDomainGridlinePosition(categoryAnchor10);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(categoryAnchor10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setWeight((int) (short) -1);
        categoryPlot13.setAnchorValue((double) (byte) 10, false);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot13);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer22.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setWeight((int) (short) -1);
        lineAndShapeRenderer22.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot25);
        java.lang.Comparable comparable29 = categoryPlot25.getDomainCrosshairRowKey();
        categoryPlot25.setForegroundAlpha((float) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        int int33 = categoryPlot25.indexOf(categoryDataset32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str35 = categoryAxis34.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) 10.0f);
        categoryAxis34.setTickLabelInsets(rectangleInsets36);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis34.setLabelInsets(rectangleInsets40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset43 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultCategoryDataset43.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        categoryPlot45.markerChanged(markerChangeEvent46);
        java.awt.Paint paint48 = categoryPlot45.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot45.getRangeAxisEdge();
        boolean boolean50 = defaultCategoryDataset43.hasListener((java.util.EventListener) categoryPlot45);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState51 = defaultCategoryDataset43.getSelectionState();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color60 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer55.setSeriesFillPaint((int) '#', (java.awt.Paint) color60);
        boolean boolean62 = lineAndShapeRenderer55.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation63 = null;
        boolean boolean64 = lineAndShapeRenderer55.removeAnnotation(categoryAnnotation63);
        java.awt.Paint paint66 = lineAndShapeRenderer55.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint67 = lineAndShapeRenderer55.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot70.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        int int74 = categoryPlot70.indexOf(categoryDataset73);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent77 = null;
        categoryPlot76.markerChanged(markerChangeEvent77);
        org.jfree.chart.axis.AxisLocation axisLocation80 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation81 = axisLocation80.getOpposite();
        categoryPlot76.setDomainAxisLocation(10, axisLocation80, true);
        categoryPlot70.setRangeAxisLocation((int) (byte) 0, axisLocation80);
        categoryPlot70.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer87 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color92 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer87.setSeriesFillPaint((int) '#', (java.awt.Paint) color92);
        int int94 = categoryPlot70.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer87);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset95 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo96 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState97 = lineAndShapeRenderer55.initialise(graphics2D68, rectangle2D69, categoryPlot70, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset95, plotRenderingInfo96);
        java.awt.geom.Rectangle2D rectangle2D98 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D99 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D20, rectangle2D21, categoryPlot25, categoryAxis34, valueAxis42, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset43, 4, 2, true, categoryItemRendererState97, rectangle2D98);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState51);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(axisLocation80);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertNotNull(color92);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState97);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarPainter barPainter12 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer0.setBarPainter(barPainter12);
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(barPainter12);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation((int) (short) 1);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke19 = categoryPlot18.getRangeZeroBaselineStroke();
        lineAndShapeRenderer0.setSeriesStroke(2, stroke19, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) (-83));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke4 = renderAttributes3.getDefaultOutlineStroke();
        java.awt.Paint paint7 = renderAttributes3.getItemFillPaint((int) (byte) -1, 0);
        java.awt.Shape shape10 = renderAttributes3.getItemShape((-65536), (-1));
        java.awt.Paint paint11 = renderAttributes3.getDefaultOutlinePaint();
        paintList0.setPaint(255, paint11);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int12 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Paint paint5 = renderAttributes1.getItemFillPaint((int) (byte) -1, 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setSeriesFillPaint((int) '#', (java.awt.Paint) color16);
        boolean boolean18 = lineAndShapeRenderer11.getBaseSeriesVisible();
        java.awt.Color color22 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer11.setBasePaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem26 = lineAndShapeRenderer11.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape27 = lineAndShapeRenderer11.getBaseShape();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color29 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape27, stroke28, (java.awt.Paint) color29);
        java.lang.String str31 = legendItem30.getDescription();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem30.setFillPaint((java.awt.Paint) color32);
        renderAttributes1.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color32);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        lineAndShapeRenderer7.setAutoPopulateSeriesShape(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = lineAndShapeRenderer7.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(categoryURLGenerator27);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarPainter barPainter12 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer0.setBarPainter(barPainter12);
        barRenderer0.setMinimumBarLength((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(barPainter12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        int int8 = lineAndShapeRenderer0.getColumnCount();
        lineAndShapeRenderer0.setBaseShapesFilled(false);
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.lookupSeriesStroke(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("GradientPaintTransformType.VERTICAL", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean4 = lineAndShapeRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = lineAndShapeRenderer1.lookupSeriesShape(0);
        lineAndShapeRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        java.lang.Boolean boolean12 = lineAndShapeRenderer0.getSeriesShapesFilled((-256));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.lang.Object obj27 = legendItem23.clone();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.getItemPaint(0, (int) ' ', true);
        java.awt.Paint paint10 = lineAndShapeRenderer0.getItemOutlinePaint(255, 10, true);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) categoryPlot2);
        boolean boolean8 = categoryAnchor0.equals((java.lang.Object) plotEntity7);
        java.lang.String str9 = plotEntity7.getShapeType();
        java.lang.String str10 = plotEntity7.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "rect" + "'", str9.equals("rect"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotEntity: tooltip = null" + "'", str10.equals("PlotEntity: tooltip = null"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, true);
        boolean boolean16 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        int int42 = lineAndShapeRenderer0.getRowCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = lineAndShapeRenderer0.getNegativeItemLabelPosition(10, (int) (short) 10, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset(255);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryDataset5);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        try {
            defaultCategoryDataset53.setSelected((-23167), 255, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        java.lang.String str8 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.panRangeAxes((double) 10.0f, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 100, font9);
        int int11 = lineAndShapeRenderer0.getRowCount();
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        double double16 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace17);
        categoryPlot11.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot11.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot11.zoomDomainAxes((double) 1.0f, plotRenderingInfo27, point2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot11.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot11.setRangeMinorGridlineStroke(stroke32);
        renderAttributes1.setDefaultStroke(stroke32);
        java.awt.Font font35 = renderAttributes1.getDefaultLabelFont();
        try {
            java.awt.Stroke stroke37 = renderAttributes1.getSeriesOutlineStroke(255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(font35);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Category Plot\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        java.lang.Comparable comparable25 = legendItem23.getSeriesKey();
        java.awt.Paint paint26 = legendItem23.getFillPaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(comparable25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemOutlineStroke(0, (int) (byte) 100, false);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup28 = defaultCategoryDataset27.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryPlot29.markerChanged(markerChangeEvent30);
        java.awt.Paint paint32 = categoryPlot29.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot29.getRangeAxisEdge();
        boolean boolean34 = defaultCategoryDataset27.hasListener((java.util.EventListener) categoryPlot29);
        defaultCategoryDataset27.fireSelectionEvent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState37 = lineAndShapeRenderer0.initialise(graphics2D24, rectangle2D25, categoryPlot26, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(datasetGroup28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setShadowVisible(false);
        double double8 = barRenderer5.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        barRenderer5.setGradientPaintTransformer(gradientPaintTransformer9);
        barRenderer5.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean15 = barRenderer5.isDrawBarOutline();
        boolean boolean16 = barRenderer5.getShadowsVisible();
        java.awt.Shape shape17 = barRenderer5.getBaseLegendShape();
        lineAndShapeRenderer0.setSeriesShape(8, shape17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        categoryPlot1.notifyListeners(plotChangeEvent2);
        categoryPlot1.clearAnnotations();
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) categoryPlot1);
        java.lang.Object obj6 = keyedObject5.getObject();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.data.KeyedObjects keyedObjects11 = new org.jfree.data.KeyedObjects();
        java.util.List list12 = keyedObjects11.getKeys();
        try {
            categoryPlot0.mapDatasetToRangeAxes(255, list12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) categoryPlot2);
        boolean boolean8 = categoryAnchor0.equals((java.lang.Object) plotEntity7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str10 = categoryAxis9.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setWeight((int) (short) -1);
        categoryPlot11.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer18.setSeriesFillPaint((int) '#', (java.awt.Paint) color23);
        boolean boolean25 = lineAndShapeRenderer18.getBaseSeriesVisible();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer18.setBasePaint((java.awt.Paint) color29);
        org.jfree.chart.LegendItem legendItem33 = lineAndShapeRenderer18.getLegendItem(2, (int) (byte) 1);
        categoryPlot11.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18, false);
        java.awt.Color color38 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot11.setNoDataMessagePaint((java.awt.Paint) color38);
        categoryAxis9.setTickLabelPaint((java.awt.Paint) color38);
        int int41 = categoryAxis9.getCategoryLabelPositionOffset();
        java.awt.Font font43 = categoryAxis9.getTickLabelFont((java.lang.Comparable) 8);
        boolean boolean44 = plotEntity7.equals((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(legendItem33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        java.awt.Paint paint17 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        lineAndShapeRenderer0.setSeriesShapesVisible(2, true);
        java.lang.Boolean boolean24 = lineAndShapeRenderer0.getSeriesShapesFilled(100);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(boolean24);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("rect");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge();
        java.lang.Comparable comparable6 = categoryPlot0.getDomainCrosshairRowKey();
        double double7 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(comparable6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        int int9 = categoryPlot5.indexOf(categoryDataset8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot5.notifyListeners(plotChangeEvent10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot5.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        java.awt.Font font22 = null;
        lineAndShapeRenderer13.setSeriesItemLabelFont((int) (byte) 0, font22, false);
        java.awt.Stroke stroke28 = lineAndShapeRenderer13.getItemStroke(2, 0, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer13.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot5.setRangeCrosshairStroke(stroke32);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (byte) 10, stroke32, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 100);
        java.awt.Stroke stroke39 = null;
        lineAndShapeRenderer0.setSeriesOutlineStroke(0, stroke39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator43 = null;
        lineAndShapeRenderer42.setBaseToolTipGenerator(categoryToolTipGenerator43, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = lineAndShapeRenderer42.getPositiveItemLabelPosition(100, (int) (short) 100, false);
        java.awt.Font font51 = null;
        lineAndShapeRenderer42.setSeriesItemLabelFont((int) (byte) 100, font51);
        java.awt.Stroke stroke53 = lineAndShapeRenderer42.getBaseOutlineStroke();
        try {
            lineAndShapeRenderer0.setSeriesOutlineStroke((-1), stroke53, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        java.awt.Stroke stroke24 = lineAndShapeRenderer10.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = lineAndShapeRenderer10.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        boolean boolean30 = itemLabelPosition28.equals((java.lang.Object) itemLabelAnchor29);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition28);
        java.awt.Shape shape33 = lineAndShapeRenderer0.lookupSeriesShape((int) '4');
        double double34 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        boolean boolean35 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) ' ', categoryURLGenerator15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint3 = null;
        lineAndShapeRenderer0.setBasePaint(paint3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition6);
        lineAndShapeRenderer0.setUseFillPaint(false);
        java.awt.Stroke stroke11 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        double double33 = categoryAxis0.getCategoryMargin();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        lineAndShapeRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator2, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = lineAndShapeRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint7 = lineAndShapeRenderer1.lookupSeriesOutlinePaint(1);
        boolean boolean8 = color0.equals((java.lang.Object) paint7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str3 = color2.toString();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setBasePaint((java.awt.Paint) color19);
        org.jfree.chart.LegendItem legendItem23 = lineAndShapeRenderer8.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape24 = lineAndShapeRenderer8.getBaseShape();
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Color color28 = java.awt.Color.gray;
        legendItem27.setFillPaint((java.awt.Paint) color28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str31 = color30.toString();
        java.awt.image.ColorModel colorModel32 = null;
        java.awt.Rectangle rectangle33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.geom.AffineTransform affineTransform35 = null;
        java.awt.RenderingHints renderingHints36 = null;
        java.awt.PaintContext paintContext37 = color30.createContext(colorModel32, rectangle33, rectangle2D34, affineTransform35, renderingHints36);
        int int38 = color30.getTransparency();
        float[] floatArray43 = new float[] { (short) -1, (short) 1, 10.0f, 2 };
        float[] floatArray44 = color30.getComponents(floatArray43);
        float[] floatArray45 = color28.getColorComponents(floatArray43);
        float[] floatArray46 = color2.getColorComponents(floatArray45);
        try {
            float[] floatArray47 = color0.getComponents(colorSpace1, floatArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str3.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str31.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        boolean boolean9 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis(0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis12);
    }
}

