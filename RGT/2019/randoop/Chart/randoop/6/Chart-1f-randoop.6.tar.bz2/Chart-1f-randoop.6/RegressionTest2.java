import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge(8);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str10 = categoryAxis9.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) 10.0f);
        categoryAxis9.setTickLabelInsets(rectangleInsets11);
        categoryAxis9.setVisible(false);
        float float17 = categoryAxis9.getTickMarkOutsideLength();
        categoryPlot0.setDomainAxis(0, categoryAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis9.getLabelInsets();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-3,-3,3,3");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name -3,-3,3,3, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateTopOutset((double) (-1.0f));
        double double5 = rectangleInsets0.calculateRightInset(0.0d);
        double double7 = rectangleInsets0.calculateTopInset((double) 1);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke8 = barRenderer0.getItemStroke(2, (int) (short) 100, false);
        barRenderer0.clearSeriesStrokes(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-1.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = renderAttributes1.getDefaultOutlineStroke();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint2 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint3 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Stroke stroke4 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Paint paint7 = renderAttributes1.getItemPaint(4, (-83));
        java.lang.Boolean boolean8 = renderAttributes1.getDefaultCreateEntity();
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        org.jfree.chart.LegendItem legendItem25 = lineAndShapeRenderer10.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape26 = lineAndShapeRenderer10.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator28 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator29 = null;
        java.lang.String str30 = chartEntity27.getImageMapAreaTag(toolTipTagFragmentGenerator28, uRLTagFragmentGenerator29);
        java.lang.String str31 = chartEntity27.getURLText();
        boolean boolean32 = plotOrientation9.equals((java.lang.Object) chartEntity27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer33.setUseFillPaint(true);
        boolean boolean36 = lineAndShapeRenderer33.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape38 = lineAndShapeRenderer33.lookupSeriesShape(0);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape38);
        chartEntity27.setArea(shape38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot0.getDataset((int) (short) 1);
        boolean boolean31 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 1, 11.0d, plotRenderingInfo34, point2D35);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        legendItem23.setURLText("PlotEntity: tooltip = ");
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        categoryPlot3.markerChanged(markerChangeEvent4);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        float float7 = categoryPlot3.getForegroundAlpha();
        double double8 = categoryPlot3.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace9);
        categoryPlot3.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot3.getRangeAxisEdge(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer19.setSeriesFillPaint((int) (short) 100, (java.awt.Paint) color23, true);
        categoryPlot3.setRangeCrosshairPaint((java.awt.Paint) color23);
        boolean boolean27 = barRenderer0.equals((java.lang.Object) color23);
        barRenderer0.setIncludeBaseInRange(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis0.setUpperMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength((float) 10);
        java.lang.Object obj10 = categoryAxis0.clone();
        categoryAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font34 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 8);
        categoryAxis0.setCategoryLabelPositionOffset(15);
        categoryAxis0.setMinorTickMarksVisible(true);
        categoryAxis0.setLabel("java.awt.Color[r=128,g=0,b=128]");
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        categoryPlot41.markerChanged(markerChangeEvent42);
        int int44 = categoryPlot41.getCrosshairDatasetIndex();
        float float45 = categoryPlot41.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot41.getRangeAxisLocation();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot41);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryAxis0.getTickLabelInsets();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        objectList0.set(8, (java.lang.Object) paint6);
        java.lang.Object obj9 = objectList0.get((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        int int3 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseCreateEntities(true, false);
        lineAndShapeRenderer0.removeAnnotations();
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("GradientPaintTransformType.VERTICAL");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        categoryPlot3.markerChanged(markerChangeEvent4);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        float float7 = categoryPlot3.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity8 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot3);
        java.awt.Shape shape9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        plotEntity8.setArea(shape9);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) shape9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        java.awt.Paint paint15 = categoryPlot12.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        boolean boolean17 = categoryPlot12.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot12.getRowRenderingOrder();
        categoryPlot12.clearRangeMarkers();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        categoryPlot12.axisChanged(axisChangeEvent20);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(sortOrder18);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        barRenderer0.setBase(18.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setBasePaint((java.awt.Paint) color24);
        java.awt.Stroke stroke27 = lineAndShapeRenderer13.lookupSeriesStroke((int) (short) 10);
        boolean boolean28 = lineAndShapeRenderer13.getBaseShapesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = lineAndShapeRenderer13.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = lineAndShapeRenderer13.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator30);
        int int32 = barRenderer0.getRowCount();
        java.awt.Paint paint33 = barRenderer0.getShadowPaint();
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint36 = renderAttributes35.getDefaultOutlinePaint();
        java.awt.Paint paint37 = renderAttributes35.getDefaultOutlinePaint();
        java.awt.Stroke stroke38 = renderAttributes35.getDefaultOutlineStroke();
        java.awt.Paint paint41 = renderAttributes35.getItemPaint(4, (-83));
        barRenderer0.setShadowPaint(paint41);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(stroke38);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int2 = keyedObjects2D0.getRowCount();
        org.jfree.data.KeyedObjects keyedObjects3 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        java.awt.Paint paint7 = categoryPlot4.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getRangeAxisEdge();
        boolean boolean9 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        keyedObjects3.sortByKeys(sortOrder10);
        keyedObjects2D0.addObject((java.lang.Object) keyedObjects3, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 4.0d);
        int int16 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 43.0d);
        keyedObjects2D0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        categoryAxis0.setFixedDimension(2.0d);
        categoryAxis0.setTickMarkOutsideLength((float) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (short) -1);
        lineAndShapeRenderer7.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        java.lang.Comparable comparable14 = categoryPlot10.getDomainCrosshairRowKey();
        categoryPlot10.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot10.removeDomainMarker((int) (byte) -1, marker18, layer19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = categoryPlot10.getDatasetRenderingOrder();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        categoryAxis0.setMinorTickMarksVisible(false);
        org.junit.Assert.assertNull(comparable14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        java.awt.Font font26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer7.setSeriesItemLabelFont((int) 'a', font26);
        boolean boolean28 = lineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        java.lang.String str4 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(2, 0, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemOutlineStroke(0, (int) (byte) 100, false);
        boolean boolean20 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Font font22 = lineAndShapeRenderer0.getSeriesItemLabelFont((-65536));
        boolean boolean25 = lineAndShapeRenderer0.getItemVisible(1, (-23167));
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        boolean boolean39 = lineAndShapeRenderer32.getBaseSeriesVisible();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setBasePaint((java.awt.Paint) color43);
        org.jfree.chart.LegendItem legendItem47 = lineAndShapeRenderer32.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape48 = lineAndShapeRenderer32.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity(shape48);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator50 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator51 = null;
        java.lang.String str52 = chartEntity49.getImageMapAreaTag(toolTipTagFragmentGenerator50, uRLTagFragmentGenerator51);
        java.lang.Object obj53 = chartEntity49.clone();
        boolean boolean54 = itemLabelAnchor31.equals(obj53);
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color62 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer57.setSeriesFillPaint((int) '#', (java.awt.Paint) color62);
        boolean boolean64 = lineAndShapeRenderer57.getBaseSeriesVisible();
        java.awt.Color color68 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer57.setBasePaint((java.awt.Paint) color68);
        boolean boolean70 = textAnchor56.equals((java.lang.Object) color68);
        java.lang.String str71 = textAnchor56.toString();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition73 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor55, textAnchor56, (double) 10.0f);
        try {
            lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((-16777216), itemLabelPosition73, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(legendItem47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str71.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        java.lang.String str59 = categoryItemEntity58.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis0.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis0.setUpperMargin((double) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        java.awt.Paint paint12 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot8.getRangeAxisEdge(8);
        boolean boolean15 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot8.getDatasetGroup();
        boolean boolean17 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot8);
        org.jfree.chart.plot.Plot plot18 = categoryAxis0.getPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        boolean boolean22 = lineAndShapeRenderer19.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        int int28 = categoryPlot24.indexOf(categoryDataset27);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
        categoryPlot24.notifyListeners(plotChangeEvent29);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot24.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        boolean boolean39 = lineAndShapeRenderer32.getBaseSeriesVisible();
        java.awt.Font font41 = null;
        lineAndShapeRenderer32.setSeriesItemLabelFont((int) (byte) 0, font41, false);
        java.awt.Stroke stroke47 = lineAndShapeRenderer32.getItemStroke(2, 0, false);
        java.awt.Stroke stroke51 = lineAndShapeRenderer32.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot24.setRangeCrosshairStroke(stroke51);
        lineAndShapeRenderer19.setSeriesOutlineStroke((int) (byte) 10, stroke51, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color60 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer55.setSeriesFillPaint((int) '#', (java.awt.Paint) color60);
        boolean boolean62 = lineAndShapeRenderer55.getBaseSeriesVisible();
        java.awt.Font font64 = null;
        lineAndShapeRenderer55.setSeriesItemLabelFont((int) (byte) 0, font64, false);
        java.awt.Stroke stroke70 = lineAndShapeRenderer55.getItemStroke(2, 0, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent72 = null;
        categoryPlot71.notifyListeners(plotChangeEvent72);
        java.awt.Font font74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot71.setNoDataMessageFont(font74);
        lineAndShapeRenderer55.setBaseLegendTextFont(font74);
        lineAndShapeRenderer19.setBaseItemLabelFont(font74, true);
        categoryAxis0.setTickLabelFont(font74);
        java.awt.Stroke stroke80 = categoryAxis0.getAxisLineStroke();
        java.awt.Color color81 = java.awt.Color.gray;
        java.awt.image.ColorModel colorModel82 = null;
        java.awt.Rectangle rectangle83 = null;
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        java.awt.geom.AffineTransform affineTransform85 = null;
        java.awt.RenderingHints renderingHints86 = null;
        java.awt.PaintContext paintContext87 = color81.createContext(colorModel82, rectangle83, rectangle2D84, affineTransform85, renderingHints86);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color81);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(paintContext87);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        java.lang.Comparable comparable59 = null;
        categoryItemEntity58.setRowKey(comparable59);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color54 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer49.setSeriesFillPaint((int) '#', (java.awt.Paint) color54);
        java.awt.Shape shape59 = lineAndShapeRenderer49.getItemShape((int) '#', (int) '4', true);
        java.lang.Boolean boolean61 = lineAndShapeRenderer49.getSeriesShapesFilled(100);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent64 = null;
        categoryPlot63.markerChanged(markerChangeEvent64);
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation68 = axisLocation67.getOpposite();
        categoryPlot63.setDomainAxisLocation(10, axisLocation67, true);
        categoryPlot63.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke73 = categoryPlot63.getOutlineStroke();
        lineAndShapeRenderer49.setSeriesStroke(10, stroke73, true);
        java.awt.Paint paint77 = lineAndShapeRenderer49.lookupSeriesPaint(8);
        lineAndShapeRenderer0.setBasePaint(paint77);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNull(boolean61);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        categoryPlot0.clearSelection();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer1.setSeriesFillPaint((int) '#', (java.awt.Paint) color6);
        java.awt.Paint paint11 = lineAndShapeRenderer1.getItemFillPaint(1, 15, false);
        renderAttributes0.setDefaultLabelPaint(paint11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Font font23 = null;
        lineAndShapeRenderer14.setSeriesItemLabelFont((int) (byte) 0, font23, false);
        java.awt.Stroke stroke29 = lineAndShapeRenderer14.getItemStroke(2, 0, false);
        boolean boolean30 = lineAndShapeRenderer14.getUseSeriesOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = lineAndShapeRenderer32.getSelectedItemAttributes();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent35 = null;
        categoryPlot34.notifyListeners(plotChangeEvent35);
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot34.setNoDataMessageFont(font37);
        lineAndShapeRenderer32.setBaseLegendTextFont(font37);
        lineAndShapeRenderer14.setLegendTextFont(0, font37);
        try {
            renderAttributes0.setSeriesLabelFont((int) '#', font37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets33.getUnitType();
        double double36 = rectangleInsets33.extendHeight((double) 192);
        categoryAxis0.setLabelInsets(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = categoryAxis0.getCategorySeriesMiddle(1, (int) '4', 0, 0, (double) 0L, rectangle2D43, rectangleEdge44);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 194.0d + "'", double36 == 194.0d);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.lang.Comparable comparable8 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable8, true);
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.setCrosshairDatasetIndex(1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) 0, false);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.clearRangeMarkers(15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean12 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Shape shape16 = lineAndShapeRenderer0.getItemShape((int) (short) -1, (int) (byte) -1, true);
        java.awt.Stroke stroke18 = lineAndShapeRenderer0.lookupSeriesStroke(4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        boolean boolean9 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultCategoryDataset10.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        java.awt.Paint paint15 = categoryPlot12.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        boolean boolean17 = defaultCategoryDataset10.hasListener((java.util.EventListener) categoryPlot12);
        defaultCategoryDataset10.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int22 = defaultCategoryDataset10.getColumnCount();
        defaultCategoryDataset10.clear();
        java.util.List list24 = defaultCategoryDataset10.getRowKeys();
        int int25 = categoryPlot0.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.general.DatasetGroup datasetGroup13 = new org.jfree.data.general.DatasetGroup("DatasetRenderingOrder.REVERSE");
        defaultCategoryDataset0.setGroup(datasetGroup13);
        java.lang.String str15 = datasetGroup13.getID();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str15.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        float float3 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabelURL("TextAnchor.BASELINE_CENTER");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint5 = renderAttributes4.getDefaultOutlinePaint();
        java.awt.Paint paint6 = renderAttributes4.getDefaultOutlinePaint();
        java.awt.Stroke stroke7 = renderAttributes4.getDefaultOutlineStroke();
        java.awt.Paint paint10 = renderAttributes4.getItemPaint(4, (-83));
        java.lang.Boolean boolean11 = renderAttributes4.getDefaultCreateEntity();
        boolean boolean12 = textAnchor1.equals((java.lang.Object) renderAttributes4);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        int int6 = lineAndShapeRenderer0.getPassCount();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer0.getPositiveItemLabelPosition(0, (int) ' ', false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (-6.0d), (double) (byte) 100, (double) (short) 10);
        double double8 = rectangleInsets7.getTop();
        double double10 = rectangleInsets7.calculateRightOutset(0.0d);
        double double12 = rectangleInsets7.calculateTopOutset(1.0d);
        categoryAxis0.setLabelInsets(rectangleInsets7, true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        lineAndShapeRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.lang.Comparable comparable32 = categoryPlot28.getDomainCrosshairRowKey();
        categoryPlot28.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) -1, marker36, layer37);
        lineAndShapeRenderer7.setPlot(categoryPlot28);
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = categoryPlot28.removeDomainMarker((-65536), marker41, layer42);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color54 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer49.setSeriesFillPaint((int) '#', (java.awt.Paint) color54);
        boolean boolean56 = lineAndShapeRenderer49.getBaseSeriesVisible();
        java.awt.Color color60 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer49.setBasePaint((java.awt.Paint) color60);
        org.jfree.chart.LegendItem legendItem64 = lineAndShapeRenderer49.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape65 = lineAndShapeRenderer49.getBaseShape();
        java.awt.Stroke stroke66 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color67 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape65, stroke66, (java.awt.Paint) color67);
        java.lang.String str69 = legendItem68.getDescription();
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem68.setFillPaint((java.awt.Paint) color70);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator75 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color70, (float) (short) 100, 3, (double) (short) 100);
        categoryPlot28.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator75);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNull(legendItem64);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
        org.junit.Assert.assertNotNull(color70);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        categoryAxis0.setFixedDimension(2.0d);
        categoryAxis0.setTickMarkOutsideLength((float) (short) 10);
        double double7 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        categoryPlot3.setDrawingSupplier(drawingSupplier9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        categoryPlot3.clearRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot3.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        categoryPlot3.markerChanged(markerChangeEvent4);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        float float7 = categoryPlot3.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot3.setDomainAxisLocation((int) (byte) 1, axisLocation9);
        java.awt.Stroke stroke11 = categoryPlot3.getOutlineStroke();
        org.jfree.chart.util.ShadowGenerator shadowGenerator12 = null;
        categoryPlot3.setShadowGenerator(shadowGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        int int18 = categoryPlot14.indexOf(categoryDataset17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        categoryPlot14.notifyListeners(plotChangeEvent19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer24.setUseFillPaint(true);
        boolean boolean27 = lineAndShapeRenderer24.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot28.getDataset((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer31.setUseFillPaint(true);
        boolean boolean34 = lineAndShapeRenderer31.getAutoPopulateSeriesFillPaint();
        boolean boolean35 = lineAndShapeRenderer31.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color41 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer36.setSeriesFillPaint((int) '#', (java.awt.Paint) color41);
        boolean boolean43 = lineAndShapeRenderer36.getBaseSeriesVisible();
        java.awt.Color color47 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer36.setBasePaint((java.awt.Paint) color47);
        java.awt.Stroke stroke50 = lineAndShapeRenderer36.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer36.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = lineAndShapeRenderer36.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent57 = null;
        categoryPlot56.markerChanged(markerChangeEvent57);
        int int59 = categoryPlot56.getCrosshairDatasetIndex();
        float float60 = categoryPlot56.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation62 = null;
        categoryPlot56.setDomainAxisLocation((int) (byte) 1, axisLocation62);
        java.awt.Stroke stroke64 = categoryPlot56.getOutlineStroke();
        lineAndShapeRenderer36.setSeriesOutlineStroke(15, stroke64);
        boolean boolean66 = lineAndShapeRenderer36.getBaseShapesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray67 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer31, lineAndShapeRenderer36 };
        categoryPlot28.setRenderers(categoryItemRendererArray67);
        categoryPlot14.setRenderers(categoryItemRendererArray67);
        categoryPlot3.setRenderers(categoryItemRendererArray67);
        org.jfree.chart.util.SortOrder sortOrder71 = categoryPlot3.getColumnRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder71);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent73 = null;
        categoryPlot0.markerChanged(markerChangeEvent73);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 1.0f + "'", float60 == 1.0f);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray67);
        org.junit.Assert.assertNotNull(sortOrder71);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets33.getUnitType();
        double double36 = rectangleInsets33.extendHeight((double) 192);
        categoryAxis0.setLabelInsets(rectangleInsets33);
        categoryAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 194.0d + "'", double36 == 194.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.panDomainAxes((double) 3, plotRenderingInfo17, point2D18);
        boolean boolean20 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart21);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer23.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        lineAndShapeRenderer23.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator27);
        lineAndShapeRenderer23.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color38 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer33.setSeriesFillPaint((int) '#', (java.awt.Paint) color38);
        boolean boolean40 = lineAndShapeRenderer33.getBaseSeriesVisible();
        java.awt.Color color44 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer33.setBasePaint((java.awt.Paint) color44);
        java.awt.Stroke stroke47 = lineAndShapeRenderer33.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer33.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = lineAndShapeRenderer33.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor52 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        boolean boolean53 = itemLabelPosition51.equals((java.lang.Object) itemLabelAnchor52);
        lineAndShapeRenderer23.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition51);
        java.awt.Shape shape56 = lineAndShapeRenderer23.lookupSeriesShape((int) '4');
        double double57 = lineAndShapeRenderer23.getItemLabelAnchorOffset();
        lineAndShapeRenderer23.setSeriesItemLabelsVisible((int) (byte) 1, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color66 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer61.setSeriesFillPaint((int) '#', (java.awt.Paint) color66);
        boolean boolean68 = lineAndShapeRenderer61.getBaseSeriesVisible();
        java.awt.Color color72 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer61.setBasePaint((java.awt.Paint) color72);
        org.jfree.chart.LegendItem legendItem76 = lineAndShapeRenderer61.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape77 = lineAndShapeRenderer61.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition79 = null;
        lineAndShapeRenderer61.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition79);
        java.awt.Stroke stroke82 = lineAndShapeRenderer61.lookupSeriesOutlineStroke(0);
        lineAndShapeRenderer23.setBaseOutlineStroke(stroke82, false);
        categoryPlot0.setRangeZeroBaselineStroke(stroke82);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
        org.junit.Assert.assertNotNull(itemLabelAnchor52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNull(legendItem76);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(stroke82);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        keyedObjects2D0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        java.lang.Comparable comparable59 = categoryItemEntity58.getColumnKey();
        categoryItemEntity58.setRowKey((java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + "Category Plot" + "'", comparable59.equals("Category Plot"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        float float5 = categoryPlot1.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity6 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1);
        float float7 = categoryPlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        boolean boolean9 = categoryPlot3.isSubplot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot3.getDomainMarkers(layer10);
        categoryPlot3.setRangeGridlinesVisible(true);
        categoryPlot3.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer18.setUseFillPaint(true);
        boolean boolean21 = lineAndShapeRenderer18.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape23 = lineAndShapeRenderer18.lookupSeriesShape(0);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        lineAndShapeRenderer0.setBaseLegendShape(shape23);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup29 = defaultCategoryDataset28.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        categoryPlot30.markerChanged(markerChangeEvent31);
        java.awt.Paint paint33 = categoryPlot30.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot30.getRangeAxisEdge();
        boolean boolean35 = defaultCategoryDataset28.hasListener((java.util.EventListener) categoryPlot30);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState36 = defaultCategoryDataset28.getSelectionState();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity39 = new org.jfree.chart.entity.CategoryItemEntity(shape23, "ItemLabelAnchor.INSIDE2", "GradientPaintTransformType.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, (java.lang.Comparable) (-23167), (java.lang.Comparable) "GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(datasetGroup29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState36);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) '4', plotRenderingInfo8, point2D9, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color17 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer12.setSeriesFillPaint((int) '#', (java.awt.Paint) color17);
        boolean boolean19 = lineAndShapeRenderer12.getBaseSeriesVisible();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer12.setBasePaint((java.awt.Paint) color23);
        java.awt.Stroke stroke26 = lineAndShapeRenderer12.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer12.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke31 = categoryPlot30.getRangeZeroBaselineStroke();
        lineAndShapeRenderer12.setSeriesStroke(2, stroke31, false);
        categoryPlot0.setRangeZeroBaselineStroke(stroke31);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray35);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset38 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup39 = defaultCategoryDataset38.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        categoryPlot40.markerChanged(markerChangeEvent41);
        java.awt.Paint paint43 = categoryPlot40.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot40.getRangeAxisEdge();
        boolean boolean45 = defaultCategoryDataset38.hasListener((java.util.EventListener) categoryPlot40);
        defaultCategoryDataset38.fireSelectionEvent();
        java.util.List list47 = defaultCategoryDataset38.getColumnKeys();
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) (short) -1, list47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertNotNull(datasetGroup39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(list47);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarPainter barPainter12 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer0.setBarPainter(barPainter12);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator15);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(barPainter12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.awt.Shape shape8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot9.markerChanged(markerChangeEvent10);
        int int12 = categoryPlot9.getCrosshairDatasetIndex();
        float float13 = categoryPlot9.getForegroundAlpha();
        double double14 = categoryPlot9.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes16 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint17 = renderAttributes16.getDefaultOutlinePaint();
        categoryPlot9.setNoDataMessagePaint(paint17);
        int int19 = categoryPlot9.getRendererCount();
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "GradientPaintTransformType.VERTICAL", "hi!");
        lineAndShapeRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        java.lang.Object obj24 = lineAndShapeRenderer3.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        int int4 = color3.getGreen();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        lineAndShapeRenderer3.setUseOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        int int5 = categoryPlot2.getCrosshairDatasetIndex();
        float float6 = categoryPlot2.getForegroundAlpha();
        double double7 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot2.getAxisOffset();
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) rectangleInsets10);
        int int13 = keyedObjects2D0.getRowIndex((java.lang.Comparable) true);
        int int14 = keyedObjects2D0.getColumnCount();
        int int16 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 8.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        int int4 = lineAndShapeRenderer0.getColumnCount();
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        java.awt.Color color27 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color27);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getDomainAxisEdge(10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        java.awt.Stroke stroke4 = barRenderer0.getBaseStroke();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultCategoryDataset5.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot7.markerChanged(markerChangeEvent8);
        java.awt.Paint paint10 = categoryPlot7.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot7.getRangeAxisEdge();
        boolean boolean12 = defaultCategoryDataset5.hasListener((java.util.EventListener) categoryPlot7);
        defaultCategoryDataset5.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.Range range18 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, false);
        defaultCategoryDataset5.clear();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        java.awt.Stroke stroke45 = lineAndShapeRenderer0.lookupSeriesOutlineStroke((-23167));
        boolean boolean46 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo7, point2D8, true);
        categoryPlot0.clearSelection();
        boolean boolean12 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace13);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer3.setSeriesFillPaint((int) '#', (java.awt.Paint) color8);
        renderAttributes1.setSeriesFillPaint(10, (java.awt.Paint) color8);
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Font font13 = renderAttributes1.getDefaultLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color19 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer14.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        boolean boolean21 = lineAndShapeRenderer14.getBaseSeriesVisible();
        java.awt.Font font23 = null;
        lineAndShapeRenderer14.setSeriesItemLabelFont((int) (byte) 0, font23, false);
        java.awt.Stroke stroke29 = lineAndShapeRenderer14.getItemStroke(2, 0, false);
        boolean boolean30 = lineAndShapeRenderer14.getUseSeriesOffset();
        java.awt.Shape shape31 = lineAndShapeRenderer14.getBaseShape();
        renderAttributes1.setDefaultShape(shape31);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font34 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(128);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        categoryPlot4.setDomainAxisLocation(10, axisLocation8, true);
        categoryPlot0.setDomainAxisLocation(axisLocation8, false);
        java.awt.Paint paint14 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setNotify(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        try {
            java.lang.Comparable comparable60 = defaultCategoryDataset53.getColumnKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        int int3 = lineAndShapeRenderer2.getColumnCount();
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke4, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge(8);
        java.awt.Shape shape11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, (float) (-1), (float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        int int20 = categoryPlot16.indexOf(categoryDataset19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot16.notifyListeners(plotChangeEvent21);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot16.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer24.setSeriesFillPaint((int) '#', (java.awt.Paint) color29);
        boolean boolean31 = lineAndShapeRenderer24.getBaseSeriesVisible();
        java.awt.Font font33 = null;
        lineAndShapeRenderer24.setSeriesItemLabelFont((int) (byte) 0, font33, false);
        java.awt.Stroke stroke39 = lineAndShapeRenderer24.getItemStroke(2, 0, false);
        java.awt.Stroke stroke43 = lineAndShapeRenderer24.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot16.setRangeCrosshairStroke(stroke43);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke46 = categoryPlot45.getRangeZeroBaselineStroke();
        java.awt.Paint paint47 = categoryPlot45.getRangeGridlinePaint();
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "SortOrder.ASCENDING", "GradientPaintTransformType.VERTICAL", "Category Plot", shape11, (java.awt.Paint) color15, stroke43, paint47);
        categoryPlot0.setRangeCrosshairStroke(stroke43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        legendItem23.setLineVisible(false);
        boolean boolean27 = legendItem23.isShapeFilled();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        categoryPlot6.setDomainAxisLocation(10, axisLocation10, true);
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation10);
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        java.lang.Comparable comparable17 = categoryPlot0.getDomainCrosshairRowKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(comparable17);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        lineAndShapeRenderer0.setSeriesShapesFilled(255, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = lineAndShapeRenderer0.getLegendItemURLGenerator();
        try {
            lineAndShapeRenderer0.setItemMargin((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset(1.0d);
        barRenderer0.setShadowXOffset((double) 1);
        double double7 = barRenderer0.getShadowXOffset();
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        barRenderer0.setShadowYOffset((double) 1.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        categoryPlot6.setDomainAxisLocation(10, axisLocation10, true);
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation10);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation10.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation10, plotOrientation16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        java.awt.Font font14 = barRenderer0.getItemLabelFont((int) (byte) 0, 0, false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str19 = categoryAxis18.getLabelToolTip();
        categoryAxis18.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke23 = categoryPlot22.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        categoryPlot22.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.chart.plot.Marker marker27 = null;
        boolean boolean28 = categoryPlot22.removeDomainMarker(marker27);
        java.util.List list29 = categoryPlot22.getAnnotations();
        boolean boolean30 = categoryAxis18.hasListener((java.util.EventListener) categoryPlot22);
        boolean boolean31 = categoryAxis18.isVisible();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup34 = defaultCategoryDataset33.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot35.markerChanged(markerChangeEvent36);
        java.awt.Paint paint38 = categoryPlot35.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot35.getRangeAxisEdge();
        boolean boolean40 = defaultCategoryDataset33.hasListener((java.util.EventListener) categoryPlot35);
        defaultCategoryDataset33.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.general.DatasetGroup datasetGroup46 = new org.jfree.data.general.DatasetGroup("DatasetRenderingOrder.REVERSE");
        defaultCategoryDataset33.setGroup(datasetGroup46);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer51.setUseFillPaint(true);
        boolean boolean54 = lineAndShapeRenderer51.getBaseSeriesVisibleInLegend();
        boolean boolean55 = lineAndShapeRenderer51.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes58 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint59 = renderAttributes58.getDefaultOutlinePaint();
        java.awt.Paint paint60 = renderAttributes58.getDefaultOutlinePaint();
        java.awt.Stroke stroke63 = renderAttributes58.getItemStroke((int) (byte) 100, (-1));
        lineAndShapeRenderer51.setSeriesOutlineStroke(100, stroke63, false);
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent69 = null;
        categoryPlot68.markerChanged(markerChangeEvent69);
        int int71 = categoryPlot68.getCrosshairDatasetIndex();
        float float72 = categoryPlot68.getForegroundAlpha();
        double double73 = categoryPlot68.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes75 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint76 = renderAttributes75.getDefaultOutlinePaint();
        categoryPlot68.setNoDataMessagePaint(paint76);
        int int78 = categoryPlot68.getRendererCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier79 = categoryPlot68.getDrawingSupplier();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset80 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup81 = defaultCategoryDataset80.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent83 = null;
        categoryPlot82.markerChanged(markerChangeEvent83);
        java.awt.Paint paint85 = categoryPlot82.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = categoryPlot82.getRangeAxisEdge();
        boolean boolean87 = defaultCategoryDataset80.hasListener((java.util.EventListener) categoryPlot82);
        defaultCategoryDataset80.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int92 = defaultCategoryDataset80.getColumnCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState94 = lineAndShapeRenderer51.initialise(graphics2D66, rectangle2D67, categoryPlot68, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset80, plotRenderingInfo93);
        java.awt.geom.Rectangle2D rectangle2D95 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D96 = barRenderer0.createHotSpotBounds(graphics2D15, rectangle2D16, categoryPlot17, categoryAxis18, valueAxis32, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset33, (int) (short) 0, 1, true, categoryItemRendererState94, rectangle2D95);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(datasetGroup34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + float72 + "' != '" + 1.0f + "'", float72 == 1.0f);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier79);
        org.junit.Assert.assertNotNull(datasetGroup81);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererState94);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        int int9 = categoryPlot6.getCrosshairDatasetIndex();
        float float10 = categoryPlot6.getForegroundAlpha();
        double double11 = categoryPlot6.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot14.markerChanged(markerChangeEvent15);
        java.awt.Paint paint17 = categoryPlot14.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot14.getRangeAxisEdge();
        boolean boolean19 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot14.getRowRenderingOrder();
        categoryPlot6.setColumnRenderingOrder(sortOrder20);
        boolean boolean22 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "ItemLabelAnchor.INSIDE4", "CategoryAnchor.END");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        categoryPlot6.markerChanged(markerChangeEvent26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        java.awt.Paint paint24 = lineAndShapeRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = lineAndShapeRenderer13.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        int int32 = categoryPlot28.indexOf(categoryDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot34.markerChanged(markerChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation38.getOpposite();
        categoryPlot34.setDomainAxisLocation(10, axisLocation38, true);
        categoryPlot28.setRangeAxisLocation((int) (byte) 0, axisLocation38);
        categoryPlot28.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        int int52 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = lineAndShapeRenderer13.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, plotRenderingInfo54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset53, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        java.lang.Comparable comparable59 = categoryItemEntity58.getColumnKey();
        java.lang.Comparable comparable60 = categoryItemEntity58.getColumnKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + "Category Plot" + "'", comparable59.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + "Category Plot" + "'", comparable60.equals("Category Plot"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        int int4 = categoryPlot0.indexOf(categoryDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color13 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer8.setSeriesFillPaint((int) '#', (java.awt.Paint) color13);
        boolean boolean15 = lineAndShapeRenderer8.getBaseSeriesVisible();
        java.awt.Font font17 = null;
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (byte) 0, font17, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer8.getItemStroke(2, 0, false);
        java.awt.Stroke stroke27 = lineAndShapeRenderer8.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes30 = lineAndShapeRenderer29.getSelectedItemAttributes();
        java.awt.Color color34 = java.awt.Color.red;
        java.awt.Color color35 = java.awt.Color.getColor("ChartEntity: tooltip = null", color34);
        java.awt.Color color36 = java.awt.Color.getColor("ChartEntity: tooltip = null", color34);
        lineAndShapeRenderer29.setSeriesPaint((int) (short) 100, (java.awt.Paint) color34);
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color34);
        java.lang.String str39 = color34.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(renderAttributes30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str39.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = categoryPlot4.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker9);
        java.util.List list11 = categoryPlot4.getAnnotations();
        boolean boolean12 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot4);
        int int13 = categoryAxis0.getCategoryLabelPositionOffset();
        boolean boolean14 = categoryAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot5.markerChanged(markerChangeEvent6);
        int int8 = categoryPlot5.getCrosshairDatasetIndex();
        float float9 = categoryPlot5.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot5.setDomainAxisLocation((int) (byte) 1, axisLocation11);
        java.awt.Stroke stroke13 = categoryPlot5.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot5.getOrientation();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        org.jfree.chart.LegendItem legendItem30 = lineAndShapeRenderer15.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape31 = lineAndShapeRenderer15.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape31);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator33 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator34 = null;
        java.lang.String str35 = chartEntity32.getImageMapAreaTag(toolTipTagFragmentGenerator33, uRLTagFragmentGenerator34);
        java.lang.String str36 = chartEntity32.getURLText();
        boolean boolean37 = plotOrientation14.equals((java.lang.Object) chartEntity32);
        categoryPlot0.setOrientation(plotOrientation14);
        java.lang.String str39 = plotOrientation14.toString();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(legendItem30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PlotOrientation.VERTICAL" + "'", str39.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer0.getBarPainter();
        org.jfree.chart.LegendItem legendItem9 = barRenderer0.getLegendItem((-83), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(barPainter6);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 1);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint10 = renderAttributes8.getSeriesOutlinePaint((int) (byte) 10);
        boolean boolean11 = renderAttributes8.getAllowNull();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        renderAttributes8.setDefaultPaint((java.awt.Paint) color12);
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color12, false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.lang.Comparable comparable8 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable8, true);
        float float11 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (short) -1, false);
        boolean boolean3 = selectableValue2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        int int22 = lineAndShapeRenderer19.getColumnCount();
        java.awt.Paint paint23 = lineAndShapeRenderer19.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint23, true);
        boolean boolean26 = lineAndShapeRenderer0.getBaseShapesFilled();
        boolean boolean29 = lineAndShapeRenderer0.getItemLineVisible(0, 255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = lineAndShapeRenderer0.getBaseURLGenerator();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNull(categoryURLGenerator44);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) 1L, plotRenderingInfo5, point2D6, true);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (-6.0d), (double) (byte) 100, (double) (short) 10);
        double double21 = rectangleInsets20.getTop();
        double double23 = rectangleInsets20.calculateRightOutset(0.0d);
        double double25 = rectangleInsets20.calculateTopOutset(1.0d);
        double double26 = rectangleInsets20.getLeft();
        categoryPlot0.setInsets(rectangleInsets20);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-6.0d) + "'", double26 == (-6.0d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        categoryAxis0.setFixedDimension(2.0d);
        categoryAxis0.setMinorTickMarkOutsideLength(0.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZeroBaselineVisible();
        java.lang.Comparable comparable2 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.Plot plot4 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) (short) 1, 2.0d, 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.getItemFillPaint(255, (int) (short) 0, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        lineAndShapeRenderer9.setBaseToolTipGenerator(categoryToolTipGenerator10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = lineAndShapeRenderer9.getLegendItemLabelGenerator();
        java.awt.Paint paint15 = lineAndShapeRenderer9.lookupSeriesFillPaint((int) (short) 1);
        java.awt.Paint paint17 = lineAndShapeRenderer9.lookupSeriesFillPaint((int) ' ');
        boolean boolean18 = barRenderer0.equals((java.lang.Object) lineAndShapeRenderer9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.awt.Color color24 = java.awt.Color.gray;
        legendItem23.setFillPaint((java.awt.Paint) color24);
        java.text.AttributedString attributedString26 = legendItem23.getAttributedLabel();
        java.text.AttributedString attributedString27 = legendItem23.getAttributedLabel();
        boolean boolean28 = legendItem23.isShapeVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup30 = defaultCategoryDataset29.getGroup();
        boolean boolean31 = legendItem23.equals((java.lang.Object) datasetGroup30);
        legendItem23.setDatasetIndex((-16646144));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(attributedString26);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetGroup30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setWeight((int) (short) -1);
        lineAndShapeRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.lang.Comparable comparable32 = categoryPlot28.getDomainCrosshairRowKey();
        categoryPlot28.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) -1, marker36, layer37);
        lineAndShapeRenderer7.setPlot(categoryPlot28);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier40, true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        boolean boolean30 = lineAndShapeRenderer15.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        boolean boolean34 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint(0, paint36, false);
        boolean boolean40 = lineAndShapeRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Shape shape42 = lineAndShapeRenderer0.lookupLegendShape((int) (byte) 1);
        java.lang.Boolean boolean44 = lineAndShapeRenderer0.getSeriesLinesVisible((int) (short) 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(boolean44);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.clearRangeMarkers();
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        legendItem23.setToolTipText("");
        legendItem23.setShapeVisible(true);
        java.lang.Comparable comparable29 = legendItem23.getSeriesKey();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNull(comparable29);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setShadowVisible(false);
        categoryPlot0.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        java.awt.Paint paint17 = barRenderer13.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot3.getRangeAxis(3);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot11.markerChanged(markerChangeEvent12);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        float float15 = categoryPlot11.getForegroundAlpha();
        double double16 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace17);
        java.lang.Comparable comparable19 = categoryPlot11.getDomainCrosshairRowKey();
        java.util.List list20 = categoryPlot11.getAnnotations();
        categoryPlot11.setNoDataMessage("ChartChangeEventType.DATASET_UPDATED");
        categoryPlot3.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(comparable19);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZeroBaselineVisible();
        java.lang.Comparable comparable2 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers((int) '4', layer5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem23.setFillPaint((java.awt.Paint) color25);
        boolean boolean27 = legendItem23.isShapeOutlineVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setSeriesFillPaint((int) '#', (java.awt.Paint) color33);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer28.setBasePaint((java.awt.Paint) color39);
        java.awt.Stroke stroke42 = lineAndShapeRenderer28.lookupSeriesStroke((int) (short) 10);
        boolean boolean43 = lineAndShapeRenderer28.getDrawOutlines();
        int int44 = lineAndShapeRenderer28.getRowCount();
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.data.Range range46 = lineAndShapeRenderer28.findRangeBounds(categoryDataset45);
        boolean boolean47 = legendItem23.equals((java.lang.Object) lineAndShapeRenderer28);
        boolean boolean48 = legendItem23.isShapeFilled();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        java.awt.Paint paint4 = categoryPlot1.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot1.getRangeAxisEdge();
        boolean boolean6 = itemLabelAnchor0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot1.addDomainMarker(100, categoryMarker8, layer9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        java.lang.Comparable comparable6 = keyedObjects0.getKey(0);
        java.lang.Object obj7 = keyedObjects0.clone();
        try {
            keyedObjects0.removeValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1.0d + "'", comparable6.equals(1.0d));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape23 = lineAndShapeRenderer7.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color25 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape23, stroke24, (java.awt.Paint) color25);
        categoryPlot0.setDomainGridlineStroke(stroke24);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot0.getDataRange(valueAxis28);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(range29);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        java.awt.Stroke stroke4 = barRenderer0.getBaseStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke19 = lineAndShapeRenderer5.lookupSeriesStroke((int) (short) 10);
        boolean boolean20 = lineAndShapeRenderer5.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        java.awt.Paint paint24 = barRenderer0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            java.awt.Color color1 = java.awt.Color.decode("SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SortOrder.ASCENDING\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot20.setDomainAxisLocation((int) (byte) 1, axisLocation26);
        java.awt.Stroke stroke28 = categoryPlot20.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(15, stroke28);
        java.lang.Object obj30 = lineAndShapeRenderer0.clone();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        categoryPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation37 = axisLocation36.getOpposite();
        categoryPlot32.setDomainAxisLocation(10, axisLocation36, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        categoryPlot40.markerChanged(markerChangeEvent41);
        int int43 = categoryPlot40.getCrosshairDatasetIndex();
        float float44 = categoryPlot40.getForegroundAlpha();
        double double45 = categoryPlot40.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        categoryPlot40.setFixedRangeAxisSpace(axisSpace46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        categoryPlot40.setDataset(categoryDataset48);
        categoryPlot40.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer53.setShadowVisible(false);
        categoryPlot40.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer53);
        java.awt.Paint paint58 = barRenderer53.getSeriesOutlinePaint((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent60 = null;
        categoryPlot59.markerChanged(markerChangeEvent60);
        int int62 = categoryPlot59.getCrosshairDatasetIndex();
        float float63 = categoryPlot59.getForegroundAlpha();
        double double64 = categoryPlot59.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot59.setFixedRangeAxisSpace(axisSpace65);
        categoryPlot59.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean70 = categoryPlot59.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot59.getRenderer();
        boolean boolean72 = barRenderer53.equals((java.lang.Object) categoryPlot59);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot59.setDomainAxis((int) (short) 10, categoryAxis74);
        org.jfree.chart.plot.Plot plot76 = categoryAxis74.getPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D31, categoryPlot32, categoryAxis74, categoryMarker77, rectangle2D78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 1.0f + "'", float63 == 1.0f);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(categoryItemRenderer71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(plot76);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer41.setSeriesFillPaint((int) '#', (java.awt.Paint) color46);
        boolean boolean48 = lineAndShapeRenderer41.getBaseSeriesVisible();
        java.awt.Font font50 = null;
        lineAndShapeRenderer41.setSeriesItemLabelFont((int) (byte) 0, font50, false);
        java.awt.Stroke stroke56 = lineAndShapeRenderer41.getItemStroke(2, 0, false);
        java.awt.Stroke stroke60 = lineAndShapeRenderer41.getItemOutlineStroke(0, (int) (byte) 100, false);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke60);
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke62, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) '4', plotRenderingInfo8, point2D9, false);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation(0);
        categoryPlot0.mapDatasetToDomainAxis(0, (int) (short) 100);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot20.setDomainAxisLocation((int) (byte) 1, axisLocation26);
        java.awt.Stroke stroke28 = categoryPlot20.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(15, stroke28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer38.setUseFillPaint(true);
        boolean boolean41 = lineAndShapeRenderer38.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape43 = lineAndShapeRenderer38.lookupSeriesShape(0);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape43, (java.awt.Paint) color44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot46.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        int int50 = categoryPlot46.indexOf(categoryDataset49);
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape43, (org.jfree.chart.plot.Plot) categoryPlot46, "ItemLabelAnchor.INSIDE4", "{0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent55 = null;
        categoryPlot54.markerChanged(markerChangeEvent55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation59 = axisLocation58.getOpposite();
        categoryPlot54.setDomainAxisLocation(10, axisLocation58, true);
        categoryPlot54.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke64 = categoryPlot54.getOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color74 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setSeriesFillPaint((int) '#', (java.awt.Paint) color74);
        boolean boolean76 = lineAndShapeRenderer69.getBaseSeriesVisible();
        java.awt.Color color80 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer69.setBasePaint((java.awt.Paint) color80);
        org.jfree.chart.LegendItem legendItem84 = lineAndShapeRenderer69.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape85 = lineAndShapeRenderer69.getBaseShape();
        java.awt.Stroke stroke86 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color87 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape85, stroke86, (java.awt.Paint) color87);
        java.awt.Color color89 = java.awt.Color.gray;
        legendItem88.setFillPaint((java.awt.Paint) color89);
        org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "ChartEntity: tooltip = null", "GradientPaintTransformType.VERTICAL", "", shape43, stroke64, (java.awt.Paint) color89);
        lineAndShapeRenderer0.setBaseShape(shape43);
        org.jfree.chart.LegendItem legendItem95 = lineAndShapeRenderer0.getLegendItem(0, 64);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNull(legendItem84);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNull(legendItem95);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        lineAndShapeRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator2, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = lineAndShapeRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint7 = lineAndShapeRenderer1.lookupSeriesFillPaint((int) (short) 1);
        java.awt.Paint paint9 = lineAndShapeRenderer1.lookupSeriesFillPaint((int) ' ');
        keyedObjects2D0.setObject((java.lang.Object) lineAndShapeRenderer1, (java.lang.Comparable) 10.0f, (java.lang.Comparable) (-1));
        java.lang.Comparable comparable14 = keyedObjects2D0.getColumnKey(0);
        try {
            keyedObjects2D0.removeRow(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1) + "'", comparable14.equals((-1)));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setBase(194.0d);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getSeriesItemLabelGenerator(4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultCategoryDataset10.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        java.awt.Paint paint15 = categoryPlot12.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        boolean boolean17 = defaultCategoryDataset10.hasListener((java.util.EventListener) categoryPlot12);
        defaultCategoryDataset10.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.Range range23 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 10, 192, false);
        boolean boolean28 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = lineAndShapeRenderer3.getLegendItems();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = lineAndShapeRenderer9.lookupSeriesStroke((int) (short) 10);
        boolean boolean24 = lineAndShapeRenderer9.getDrawOutlines();
        java.awt.Shape shape26 = lineAndShapeRenderer9.lookupLegendShape(10);
        lineAndShapeRenderer3.setBaseShape(shape26, true);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent32 = null;
        categoryPlot31.markerChanged(markerChangeEvent32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation36 = axisLocation35.getOpposite();
        categoryPlot31.setDomainAxisLocation(10, axisLocation35, true);
        categoryPlot31.setAnchorValue((double) 0.0f, false);
        java.awt.Paint paint42 = categoryPlot31.getRangeCrosshairPaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset43 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState45 = lineAndShapeRenderer3.initialise(graphics2D29, rectangle2D30, categoryPlot31, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset43, plotRenderingInfo44);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(categoryItemRendererState45);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font9 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 0, font9, false);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer15.setUseFillPaint(true);
        boolean boolean18 = lineAndShapeRenderer15.getBaseSeriesVisibleInLegend();
        boolean boolean19 = lineAndShapeRenderer15.getBaseShapesFilled();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        lineAndShapeRenderer15.setBaseToolTipGenerator(categoryToolTipGenerator20, false);
        org.jfree.data.KeyedObjects2D keyedObjects2D24 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = null;
        lineAndShapeRenderer25.setBaseToolTipGenerator(categoryToolTipGenerator26, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = lineAndShapeRenderer25.getLegendItemLabelGenerator();
        java.awt.Paint paint31 = lineAndShapeRenderer25.lookupSeriesFillPaint((int) (short) 1);
        java.awt.Paint paint33 = lineAndShapeRenderer25.lookupSeriesFillPaint((int) ' ');
        keyedObjects2D24.setObject((java.lang.Object) lineAndShapeRenderer25, (java.lang.Comparable) 10.0f, (java.lang.Comparable) (-1));
        boolean boolean37 = lineAndShapeRenderer25.getBaseSeriesVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color44 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer39.setSeriesFillPaint((int) '#', (java.awt.Paint) color44);
        boolean boolean46 = lineAndShapeRenderer39.getBaseSeriesVisible();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer39.setBasePaint((java.awt.Paint) color50);
        java.awt.Stroke stroke53 = lineAndShapeRenderer39.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer39.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = lineAndShapeRenderer39.getSeriesNegativeItemLabelPosition((int) '4');
        double double58 = itemLabelPosition57.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor59 = itemLabelPosition57.getRotationAnchor();
        lineAndShapeRenderer25.setSeriesPositiveItemLabelPosition(0, itemLabelPosition57, false);
        lineAndShapeRenderer15.setSeriesPositiveItemLabelPosition(100, itemLabelPosition57);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition57, false);
        java.awt.Shape shape66 = lineAndShapeRenderer0.lookupLegendShape((int) (byte) 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor59);
        org.junit.Assert.assertNotNull(shape66);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge();
        java.lang.Comparable comparable6 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.panRangeAxes((double) 15, plotRenderingInfo8, point2D9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("{0}");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        java.lang.String str4 = unknownKeyException1.toString();
        java.lang.String str5 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str2.equals("org.jfree.data.UnknownKeyException: {0}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str3.equals("org.jfree.data.UnknownKeyException: {0}"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str4.equals("org.jfree.data.UnknownKeyException: {0}"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str5.equals("org.jfree.data.UnknownKeyException: {0}"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean12 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer0.setDrawOutlines(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.setRangePannable(true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (-16777216));
        java.awt.Stroke stroke16 = null;
        try {
            categoryPlot0.setDomainCrosshairStroke(stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        java.lang.Comparable comparable7 = categoryPlot3.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot8 = categoryPlot3.getRootPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        categoryPlot3.setDrawingSupplier(drawingSupplier9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot3.panRangeAxes(99.0d, plotRenderingInfo14, point2D15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot3.rendererChanged(rendererChangeEvent17);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        categoryPlot0.notifyListeners(plotChangeEvent1);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (short) 100, axisLocation6);
        boolean boolean8 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        boolean boolean9 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setUseFillPaint(true);
        boolean boolean14 = lineAndShapeRenderer11.getAutoPopulateSeriesFillPaint();
        java.awt.Font font18 = lineAndShapeRenderer11.getItemLabelFont((int) (byte) -1, (-1), true);
        boolean boolean19 = lineAndShapeRenderer11.getBaseItemLabelsVisible();
        lineAndShapeRenderer11.setSeriesShapesFilled((int) (short) 100, (java.lang.Boolean) true);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double4 = barRenderer0.getItemMargin();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType5 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType5);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer6);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(gradientPaintTransformType5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot0.markerChanged(markerChangeEvent2);
        java.awt.Paint paint4 = null;
        try {
            categoryPlot0.setRangeCrosshairPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot6.markerChanged(markerChangeEvent7);
        int int9 = categoryPlot6.getCrosshairDatasetIndex();
        float float10 = categoryPlot6.getForegroundAlpha();
        double double11 = categoryPlot6.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace12);
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot6.clearRangeMarkers();
        categoryPlot6.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot6.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace21, true);
        org.jfree.chart.plot.Marker marker24 = null;
        boolean boolean25 = categoryPlot6.removeDomainMarker(marker24);
        boolean boolean26 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot6.panRangeAxes((double) 100, plotRenderingInfo28, point2D29);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker12 = null;
        boolean boolean13 = categoryPlot0.removeDomainMarker(marker12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState18 = null;
        boolean boolean19 = categoryPlot0.render(graphics2D14, rectangle2D15, (int) (byte) 1, plotRenderingInfo17, categoryCrosshairState18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        categoryAxis10.setLabel("org.jfree.data.UnknownKeyException: {0}");
        categoryAxis10.setLabelURL("org.jfree.chart.event.ChartChangeEvent[source=1]");
        categoryAxis10.setUpperMargin((double) '4');
        java.awt.Stroke stroke18 = categoryAxis10.getTickMarkStroke();
        categoryPlot3.setDomainAxis(categoryAxis10);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation29 = axisLocation28.getOpposite();
        categoryPlot24.setDomainAxisLocation(10, axisLocation28, true);
        categoryPlot20.setDomainAxisLocation(axisLocation28, false);
        java.awt.Paint paint34 = categoryPlot20.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot20.getRangeAxisLocation();
        categoryPlot3.setDomainAxisLocation(axisLocation35);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        barRenderer0.setBase(194.0d);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getSeriesItemLabelGenerator(4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultCategoryDataset10.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot12.markerChanged(markerChangeEvent13);
        java.awt.Paint paint15 = categoryPlot12.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        boolean boolean17 = defaultCategoryDataset10.hasListener((java.util.EventListener) categoryPlot12);
        defaultCategoryDataset10.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        org.jfree.data.Range range23 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 10, 192, false);
        java.awt.Paint paint28 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(itemLabelPosition29);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color21);
        org.jfree.chart.LegendItem legendItem25 = lineAndShapeRenderer10.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape26 = lineAndShapeRenderer10.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator28 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator29 = null;
        java.lang.String str30 = chartEntity27.getImageMapAreaTag(toolTipTagFragmentGenerator28, uRLTagFragmentGenerator29);
        java.lang.String str31 = chartEntity27.getURLText();
        boolean boolean32 = plotOrientation9.equals((java.lang.Object) chartEntity27);
        chartEntity27.setURLText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "Category Plot");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (Category Plot) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot7.getDataset((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setUseFillPaint(true);
        boolean boolean13 = lineAndShapeRenderer10.getAutoPopulateSeriesFillPaint();
        boolean boolean14 = lineAndShapeRenderer10.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke29 = lineAndShapeRenderer15.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer15.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot35.markerChanged(markerChangeEvent36);
        int int38 = categoryPlot35.getCrosshairDatasetIndex();
        float float39 = categoryPlot35.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        categoryPlot35.setDomainAxisLocation((int) (byte) 1, axisLocation41);
        java.awt.Stroke stroke43 = categoryPlot35.getOutlineStroke();
        lineAndShapeRenderer15.setSeriesOutlineStroke(15, stroke43);
        boolean boolean45 = lineAndShapeRenderer15.getBaseShapesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray46 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer10, lineAndShapeRenderer15 };
        categoryPlot7.setRenderers(categoryItemRendererArray46);
        boolean boolean48 = categoryPlot7.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Paint paint44 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) '#', (java.lang.Boolean) true);
        lineAndShapeRenderer0.setSeriesVisible(4, (java.lang.Boolean) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent52 = null;
        categoryPlot51.markerChanged(markerChangeEvent52);
        int int54 = categoryPlot51.getCrosshairDatasetIndex();
        float float55 = categoryPlot51.getForegroundAlpha();
        double double56 = categoryPlot51.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        categoryPlot51.setFixedRangeAxisSpace(axisSpace57);
        java.lang.Comparable comparable59 = categoryPlot51.getDomainCrosshairRowKey();
        java.util.List list60 = categoryPlot51.getAnnotations();
        categoryPlot51.setNoDataMessage("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.plot.Plot plot63 = categoryPlot51.getRootPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot51);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 1.0f + "'", float55 == 1.0f);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNull(comparable59);
        org.junit.Assert.assertNotNull(list60);
        org.junit.Assert.assertNotNull(plot63);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double5 = rectangleInsets4.getRight();
        double double6 = rectangleInsets4.getTop();
        double double8 = rectangleInsets4.calculateBottomOutset(0.2d);
        categoryAxis0.setLabelInsets(rectangleInsets4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setMinorTickMarkOutsideLength((-1.0f));
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape25 = lineAndShapeRenderer9.getBaseShape();
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape25, stroke26, (java.awt.Paint) color27);
        java.awt.Stroke stroke29 = legendItem28.getOutlineStroke();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        legendItem28.setLine(shape30);
        java.awt.Stroke stroke32 = legendItem28.getOutlineStroke();
        categoryPlot0.setOutlineStroke(stroke32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot8.markerChanged(markerChangeEvent9);
        java.awt.Paint paint11 = categoryPlot8.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getRangeAxisEdge();
        boolean boolean13 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot8.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder14);
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setSeriesFillPaint((int) '#', (java.awt.Paint) color24);
        renderAttributes17.setSeriesFillPaint(10, (java.awt.Paint) color24);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot27.markerChanged(markerChangeEvent28);
        int int30 = categoryPlot27.getCrosshairDatasetIndex();
        float float31 = categoryPlot27.getForegroundAlpha();
        double double32 = categoryPlot27.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace33);
        categoryPlot27.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        categoryPlot27.clearRangeMarkers();
        categoryPlot27.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot27.getRangeAxisEdge(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot27.zoomDomainAxes((double) 1.0f, plotRenderingInfo43, point2D44);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot27.getRangeAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot27.setRangeMinorGridlineStroke(stroke48);
        renderAttributes17.setDefaultStroke(stroke48);
        categoryPlot0.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color61 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer56.setSeriesFillPaint((int) '#', (java.awt.Paint) color61);
        boolean boolean63 = lineAndShapeRenderer56.getBaseSeriesVisible();
        java.awt.Color color67 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer56.setBasePaint((java.awt.Paint) color67);
        org.jfree.chart.LegendItem legendItem71 = lineAndShapeRenderer56.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape72 = lineAndShapeRenderer56.getBaseShape();
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color74 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape72, stroke73, (java.awt.Paint) color74);
        java.lang.String str76 = legendItem75.getDescription();
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem75.setFillPaint((java.awt.Paint) color77);
        boolean boolean79 = legendItem75.isShapeOutlineVisible();
        java.awt.Font font80 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        legendItem75.setLabelFont(font80);
        categoryPlot0.setNoDataMessageFont(font80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNull(legendItem71);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(font80);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.INSIDE4");
        double double2 = categoryAxis1.getFixedDimension();
        double double3 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (-6.0d), (double) (byte) 100, (double) (short) 10);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateBottomOutset((double) 100);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.gray;
        legendItem24.setFillPaint((java.awt.Paint) color25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str28 = color27.toString();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color27.getTransparency();
        float[] floatArray40 = new float[] { (short) -1, (short) 1, 10.0f, 2 };
        float[] floatArray41 = color27.getComponents(floatArray40);
        float[] floatArray42 = color25.getColorComponents(floatArray40);
        float[] floatArray43 = color0.getComponents(floatArray40);
        int int44 = color0.getAlpha();
        java.awt.Color color45 = java.awt.Color.yellow;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color55 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer50.setSeriesFillPaint((int) '#', (java.awt.Paint) color55);
        boolean boolean57 = lineAndShapeRenderer50.getBaseSeriesVisible();
        java.awt.Color color61 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer50.setBasePaint((java.awt.Paint) color61);
        org.jfree.chart.LegendItem legendItem65 = lineAndShapeRenderer50.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape66 = lineAndShapeRenderer50.getBaseShape();
        java.awt.Stroke stroke67 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color68 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape66, stroke67, (java.awt.Paint) color68);
        java.awt.Color color70 = java.awt.Color.gray;
        legendItem69.setFillPaint((java.awt.Paint) color70);
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str73 = color72.toString();
        java.awt.image.ColorModel colorModel74 = null;
        java.awt.Rectangle rectangle75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        java.awt.geom.AffineTransform affineTransform77 = null;
        java.awt.RenderingHints renderingHints78 = null;
        java.awt.PaintContext paintContext79 = color72.createContext(colorModel74, rectangle75, rectangle2D76, affineTransform77, renderingHints78);
        int int80 = color72.getTransparency();
        float[] floatArray85 = new float[] { (short) -1, (short) 1, 10.0f, 2 };
        float[] floatArray86 = color72.getComponents(floatArray85);
        float[] floatArray87 = color70.getColorComponents(floatArray85);
        float[] floatArray88 = color45.getRGBComponents(floatArray85);
        float[] floatArray89 = null;
        float[] floatArray90 = color45.getRGBColorComponents(floatArray89);
        try {
            float[] floatArray91 = color0.getRGBComponents(floatArray90);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str28.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNull(legendItem65);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str73.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(floatArray85);
        org.junit.Assert.assertNotNull(floatArray86);
        org.junit.Assert.assertNotNull(floatArray87);
        org.junit.Assert.assertNotNull(floatArray88);
        org.junit.Assert.assertNotNull(floatArray90);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        int int19 = categoryPlot15.indexOf(categoryDataset18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        categoryPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation26 = axisLocation25.getOpposite();
        categoryPlot21.setDomainAxisLocation(10, axisLocation25, true);
        categoryPlot15.setRangeAxisLocation((int) (byte) 0, axisLocation25);
        categoryPlot15.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        int int39 = categoryPlot15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer32);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset40, plotRenderingInfo41);
        boolean boolean43 = categoryPlot15.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker4, layer5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = lineAndShapeRenderer9.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer9.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer9.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition27);
        java.awt.Stroke stroke30 = lineAndShapeRenderer3.getSeriesStroke((int) (short) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color37 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setSeriesFillPaint((int) '#', (java.awt.Paint) color37);
        boolean boolean39 = lineAndShapeRenderer32.getBaseSeriesVisible();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer32.setBasePaint((java.awt.Paint) color43);
        java.awt.Stroke stroke46 = lineAndShapeRenderer32.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer32.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = lineAndShapeRenderer32.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor51 = itemLabelPosition50.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor52 = itemLabelPosition50.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor53 = itemLabelPosition50.getItemLabelAnchor();
        try {
            lineAndShapeRenderer3.setSeriesNegativeItemLabelPosition((-256), itemLabelPosition50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNull(stroke30);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
        org.junit.Assert.assertNotNull(itemLabelAnchor51);
        org.junit.Assert.assertNotNull(itemLabelAnchor52);
        org.junit.Assert.assertNotNull(itemLabelAnchor53);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        double double4 = categoryAxis0.getUpperMargin();
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.getColor("ChartEntity: tooltip = null", color7);
        java.awt.Color color9 = java.awt.Color.getColor("ChartEntity: tooltip = null", color7);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getItemMargin();
        barRenderer0.setMaximumBarWidth((-8.0d));
        java.awt.Paint paint6 = barRenderer0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font34 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 8);
        categoryAxis0.setCategoryLabelPositionOffset(15);
        categoryAxis0.setMinorTickMarksVisible(true);
        categoryAxis0.setLabel("java.awt.Color[r=128,g=0,b=128]");
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        categoryPlot41.markerChanged(markerChangeEvent42);
        int int44 = categoryPlot41.getCrosshairDatasetIndex();
        float float45 = categoryPlot41.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot41.getRangeAxisLocation();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot41);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        categoryPlot41.setRangeAxis(15, valueAxis49, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation52 = null;
        try {
            categoryPlot41.addAnnotation(categoryAnnotation52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (short) -1);
        categoryPlot0.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer7.setBasePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer7.getLegendItem(2, (int) (byte) 1);
        categoryPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7, false);
        boolean boolean25 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        int int3 = barRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("AxisLocation.TOP_OR_LEFT");
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.getItemPaint(0, (int) ' ', true);
        lineAndShapeRenderer0.setSeriesLinesVisible(0, true);
        java.awt.Font font13 = lineAndShapeRenderer0.getItemLabelFont((int) (short) -1, (-16777216), true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setUseFillPaint(true);
        int int22 = lineAndShapeRenderer19.getColumnCount();
        java.awt.Paint paint23 = lineAndShapeRenderer19.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint23, true);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, false);
        int int29 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Shape shape33 = lineAndShapeRenderer0.getItemShape(8, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        lineAndShapeRenderer0.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        barRenderer0.setBase(18.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setBasePaint((java.awt.Paint) color24);
        java.awt.Stroke stroke27 = lineAndShapeRenderer13.lookupSeriesStroke((int) (short) 10);
        boolean boolean28 = lineAndShapeRenderer13.getBaseShapesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = lineAndShapeRenderer13.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = lineAndShapeRenderer13.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator30);
        int int32 = barRenderer0.getRowCount();
        java.awt.Paint paint33 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = barRenderer0.getPositiveItemLabelPosition((-1), (int) '4', false);
        org.jfree.chart.LegendItem legendItem40 = barRenderer0.getLegendItem(255, (int) (byte) 10);
        java.awt.Stroke stroke42 = barRenderer0.getSeriesOutlineStroke(255);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNull(legendItem40);
        org.junit.Assert.assertNull(stroke42);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        float float3 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) '#', plotRenderingInfo7, point2D8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer11, true);
        boolean boolean14 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str1.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        boolean boolean3 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        lineAndShapeRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = lineAndShapeRenderer4.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        boolean boolean12 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) lineAndShapeRenderer4);
        java.awt.Shape shape16 = lineAndShapeRenderer4.getItemShape((-256), (int) 'a', false);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ItemLabelAnchor.INSIDE4", "UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke8 = barRenderer0.getItemStroke(2, (int) (short) 100, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (short) -1);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot3);
        categoryPlot3.setCrosshairDatasetIndex(8);
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomDomainAxes((double) (-65536), plotRenderingInfo11, point2D12);
        java.awt.geom.GeneralPath generalPath14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.RenderingSource renderingSource16 = null;
        categoryPlot3.select(generalPath14, rectangle2D15, renderingSource16);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot5.markerChanged(markerChangeEvent6);
        int int8 = categoryPlot5.getCrosshairDatasetIndex();
        float float9 = categoryPlot5.getForegroundAlpha();
        double double10 = categoryPlot5.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot5.setDataset(categoryDataset13);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer18.setShadowVisible(false);
        categoryPlot5.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color27 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer22.setSeriesFillPaint((int) '#', (java.awt.Paint) color27);
        java.awt.Shape shape32 = lineAndShapeRenderer22.getItemShape((int) '#', (int) '4', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer35.setSeriesFillPaint((int) '#', (java.awt.Paint) color40);
        boolean boolean42 = lineAndShapeRenderer35.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation43 = null;
        boolean boolean44 = lineAndShapeRenderer35.removeAnnotation(categoryAnnotation43);
        java.awt.Paint paint46 = lineAndShapeRenderer35.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint47 = lineAndShapeRenderer35.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot50.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        int int54 = categoryPlot50.indexOf(categoryDataset53);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent57 = null;
        categoryPlot56.markerChanged(markerChangeEvent57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation61 = axisLocation60.getOpposite();
        categoryPlot56.setDomainAxisLocation(10, axisLocation60, true);
        categoryPlot50.setRangeAxisLocation((int) (byte) 0, axisLocation60);
        categoryPlot50.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color72 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer67.setSeriesFillPaint((int) '#', (java.awt.Paint) color72);
        int int74 = categoryPlot50.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer67);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset75 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState77 = lineAndShapeRenderer35.initialise(graphics2D48, rectangle2D49, categoryPlot50, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset75, plotRenderingInfo76);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity80 = new org.jfree.chart.entity.CategoryItemEntity(shape32, "org.jfree.data.UnknownKeyException: {0}", "rect", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset75, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "Category Plot");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState82 = lineAndShapeRenderer0.initialise(graphics2D3, rectangle2D4, categoryPlot5, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset75, plotRenderingInfo81);
        lineAndShapeRenderer0.clearSeriesStrokes(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState77);
        org.junit.Assert.assertNotNull(categoryItemRendererState82);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color9 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setSeriesFillPaint((int) '#', (java.awt.Paint) color9);
        boolean boolean11 = lineAndShapeRenderer4.getBaseSeriesVisible();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer4.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem19 = lineAndShapeRenderer4.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape20 = lineAndShapeRenderer4.getBaseShape();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke21, (java.awt.Paint) color22);
        java.lang.String str24 = legendItem23.getDescription();
        boolean boolean25 = legendItem23.isShapeVisible();
        legendItem23.setDatasetIndex((-16646144));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.panRangeAxes((double) 1.0f, plotRenderingInfo10, point2D11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean15 = color13.equals((java.lang.Object) '4');
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setWeight((int) (short) -1);
        categoryPlot17.setAnchorValue((double) (byte) 10, false);
        java.awt.Stroke stroke23 = categoryPlot17.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot17.zoomDomainAxes((double) '4', plotRenderingInfo25, point2D26, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color34 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer29.setSeriesFillPaint((int) '#', (java.awt.Paint) color34);
        boolean boolean36 = lineAndShapeRenderer29.getBaseSeriesVisible();
        java.awt.Color color40 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer29.setBasePaint((java.awt.Paint) color40);
        java.awt.Stroke stroke43 = lineAndShapeRenderer29.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer29.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke48 = categoryPlot47.getRangeZeroBaselineStroke();
        lineAndShapeRenderer29.setSeriesStroke(2, stroke48, false);
        categoryPlot17.setRangeZeroBaselineStroke(stroke48);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray52 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot17.setRangeAxes(valueAxisArray52);
        categoryPlot0.setRangeAxes(valueAxisArray52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(valueAxisArray52);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getDrawOutlines();
        int int16 = lineAndShapeRenderer0.getRowCount();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState12 = null;
        boolean boolean13 = categoryPlot0.render(graphics2D8, rectangle2D9, 10, plotRenderingInfo11, categoryCrosshairState12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot20.markerChanged(markerChangeEvent21);
        int int23 = categoryPlot20.getCrosshairDatasetIndex();
        float float24 = categoryPlot20.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot20.setDomainAxisLocation((int) (byte) 1, axisLocation26);
        java.awt.Stroke stroke28 = categoryPlot20.getOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(15, stroke28);
        java.awt.Paint paint30 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        float float5 = categoryPlot1.getForegroundAlpha();
        org.jfree.chart.entity.PlotEntity plotEntity6 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot1.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setSeriesFillPaint((int) '#', (java.awt.Paint) color20);
        boolean boolean22 = lineAndShapeRenderer15.getBaseSeriesVisible();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer15.setBasePaint((java.awt.Paint) color26);
        org.jfree.chart.LegendItem legendItem30 = lineAndShapeRenderer15.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape31 = lineAndShapeRenderer15.getBaseShape();
        java.awt.Paint paint32 = lineAndShapeRenderer15.getBaseLegendTextPaint();
        java.awt.Shape shape36 = lineAndShapeRenderer15.getItemShape((int) (byte) -1, (-23167), true);
        lineAndShapeRenderer0.setBaseLegendShape(shape36);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        lineAndShapeRenderer0.setSeriesOutlineStroke(128, stroke39);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(legendItem30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setUseFillPaint(true);
        boolean boolean6 = lineAndShapeRenderer3.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer3.getDrawingSupplier();
        boolean boolean9 = lineAndShapeRenderer3.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (short) -1, false);
        selectableValue2.setSelected(true);
        java.lang.Number number5 = selectableValue2.getValue();
        selectableValue2.setSelected(false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup17 = defaultCategoryDataset16.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        categoryPlot18.markerChanged(markerChangeEvent19);
        java.awt.Paint paint21 = categoryPlot18.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot18.getRangeAxisEdge();
        boolean boolean23 = defaultCategoryDataset16.hasListener((java.util.EventListener) categoryPlot18);
        defaultCategoryDataset16.setValue((double) 2.0f, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) 0L);
        int int28 = categoryPlot0.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(datasetGroup17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.setObject((java.lang.Comparable) 1.0d, (java.lang.Object) "{0}");
        java.lang.Comparable comparable6 = keyedObjects0.getKey(0);
        try {
            keyedObjects0.insertValue(4, (java.lang.Comparable) 10.0d, (java.lang.Object) "PlotOrientation.VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1.0d + "'", comparable6.equals(1.0d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        int int6 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = lineAndShapeRenderer0.getURLGenerator(255, (int) '#', false);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(15, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot0.markerChanged(markerChangeEvent2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker((int) '4', marker7, layer8);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "GradientPaintTransformType.VERTICAL");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape25 = lineAndShapeRenderer9.getBaseShape();
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape25, stroke26, (java.awt.Paint) color27);
        categoryPlot0.setOutlinePaint((java.awt.Paint) color27);
        java.lang.Object obj30 = categoryPlot0.clone();
        java.lang.String str31 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Category Plot" + "'", str31.equals("Category Plot"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint8 = renderAttributes7.getDefaultOutlinePaint();
        categoryPlot0.setNoDataMessagePaint(paint8);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setWeight((int) (short) -1);
        lineAndShapeRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        java.lang.Comparable comparable8 = categoryPlot4.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot4.getOrientation();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot4.getInsets();
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) (-16777216), (double) (short) 0, (double) (byte) 0, (double) (short) 1);
        boolean boolean20 = sortOrder0.equals((java.lang.Object) unitType14);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color46 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer41.setSeriesFillPaint((int) '#', (java.awt.Paint) color46);
        boolean boolean48 = lineAndShapeRenderer41.getBaseSeriesVisible();
        java.awt.Font font50 = null;
        lineAndShapeRenderer41.setSeriesItemLabelFont((int) (byte) 0, font50, false);
        java.awt.Stroke stroke56 = lineAndShapeRenderer41.getItemStroke(2, 0, false);
        java.awt.Stroke stroke60 = lineAndShapeRenderer41.getItemOutlineStroke(0, (int) (byte) 100, false);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke60);
        java.awt.Color color63 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            lineAndShapeRenderer0.setLegendTextPaint((-1), (java.awt.Paint) color63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color63);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        categoryPlot1.notifyListeners(plotChangeEvent2);
        categoryPlot1.clearAnnotations();
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) categoryPlot1);
        categoryPlot1.setRangeCrosshairValue(0.0d, false);
        categoryPlot1.setForegroundAlpha((float) 3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke23 = categoryPlot22.getRangeZeroBaselineStroke();
        java.awt.Paint paint24 = categoryPlot22.getRangeGridlinePaint();
        lineAndShapeRenderer0.setBaseOutlinePaint(paint24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot9.notifyListeners(plotChangeEvent10);
        categoryPlot9.clearAnnotations();
        java.awt.Paint paint13 = categoryPlot9.getNoDataMessagePaint();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot9);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot9.getOrientation();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor(2, 2, (int) (byte) 1);
        categoryPlot9.setRangeMinorGridlinePaint((java.awt.Paint) chartColor19);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabel("org.jfree.data.UnknownKeyException: {0}");
        double double4 = categoryAxis0.getUpperMargin();
        org.jfree.chart.plot.Plot plot5 = categoryAxis0.getPlot();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(1, categoryDataset12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot14.markerChanged(markerChangeEvent15);
        int int17 = categoryPlot14.getCrosshairDatasetIndex();
        float float18 = categoryPlot14.getForegroundAlpha();
        double double19 = categoryPlot14.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot14.setDataset(categoryDataset22);
        int int24 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot14);
        categoryPlot0.notifyListeners(plotChangeEvent25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape5 = lineAndShapeRenderer0.lookupSeriesShape(0);
        java.awt.Shape shape6 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Color color8 = java.awt.Color.green;
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        float float4 = categoryPlot0.getForegroundAlpha();
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setShadowVisible(false);
        categoryPlot0.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        java.awt.Paint paint18 = barRenderer13.getSeriesOutlinePaint((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot19.markerChanged(markerChangeEvent20);
        int int22 = categoryPlot19.getCrosshairDatasetIndex();
        float float23 = categoryPlot19.getForegroundAlpha();
        double double24 = categoryPlot19.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace25);
        categoryPlot19.mapDatasetToDomainAxis((int) (short) 10, (int) 'a');
        boolean boolean30 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot19.getRenderer();
        boolean boolean32 = barRenderer13.equals((java.lang.Object) categoryPlot19);
        double double33 = barRenderer13.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        int int9 = categoryPlot5.indexOf(categoryDataset8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot5.notifyListeners(plotChangeEvent10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot5.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        java.awt.Font font22 = null;
        lineAndShapeRenderer13.setSeriesItemLabelFont((int) (byte) 0, font22, false);
        java.awt.Stroke stroke28 = lineAndShapeRenderer13.getItemStroke(2, 0, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer13.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot5.setRangeCrosshairStroke(stroke32);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (byte) 10, stroke32, false);
        boolean boolean36 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.lang.String str25 = legendItem24.getDescription();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem24.setFillPaint((java.awt.Paint) color26);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 1, color26, (float) (short) 100, 3, (double) (short) 100);
        int int32 = defaultShadowGenerator31.getDistance();
        int int33 = defaultShadowGenerator31.getShadowSize();
        int int34 = defaultShadowGenerator31.getDistance();
        double double35 = defaultShadowGenerator31.getAngle();
        int int36 = defaultShadowGenerator31.getShadowSize();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator4);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = lineAndShapeRenderer0.getSelectedItemAttributes();
        org.junit.Assert.assertNotNull(renderAttributes9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint2 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Shape shape3 = renderAttributes1.getDefaultShape();
        java.awt.Paint paint5 = renderAttributes1.getSeriesOutlinePaint((-16777216));
        boolean boolean6 = renderAttributes1.getAllowNull();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.clearRangeMarkers();
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairRowKey();
        boolean boolean10 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryPlot1.markerChanged(markerChangeEvent2);
        java.awt.Paint paint4 = categoryPlot1.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot1.getRangeAxisEdge();
        boolean boolean6 = categoryPlot1.getDrawSharedDomainAxis();
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot1.getRowRenderingOrder();
        keyedObjects0.sortByKeys(sortOrder7);
        java.lang.String str9 = sortOrder7.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SortOrder.ASCENDING" + "'", str9.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (short) -1);
        categoryPlot2.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color14);
        boolean boolean16 = lineAndShapeRenderer9.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer9.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem24 = lineAndShapeRenderer9.getLegendItem(2, (int) (byte) 1);
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9, false);
        java.awt.Color color29 = java.awt.Color.getColor("hi!", (int) (byte) 0);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color29);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color29);
        int int32 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer33.setUseFillPaint(true);
        java.awt.Paint paint36 = null;
        lineAndShapeRenderer33.setBasePaint(paint36);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = new org.jfree.chart.labels.ItemLabelPosition();
        lineAndShapeRenderer33.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition39);
        java.awt.Font font44 = lineAndShapeRenderer33.getItemLabelFont((-16777216), (-83), true);
        categoryAxis0.setLabelFont(font44);
        categoryAxis0.setCategoryLabelPositionOffset((-83));
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = lineAndShapeRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        lineAndShapeRenderer15.setBaseToolTipGenerator(categoryToolTipGenerator16, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = lineAndShapeRenderer15.getLegendItemLabelGenerator();
        java.awt.Paint paint21 = lineAndShapeRenderer15.lookupSeriesFillPaint((int) (short) 1);
        lineAndShapeRenderer0.setLegendTextPaint(0, paint21);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color15 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color15);
        boolean boolean17 = lineAndShapeRenderer10.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        boolean boolean19 = lineAndShapeRenderer10.removeAnnotation(categoryAnnotation18);
        java.awt.Paint paint21 = lineAndShapeRenderer10.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint22 = lineAndShapeRenderer10.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint24 = lineAndShapeRenderer23.getBaseOutlinePaint();
        lineAndShapeRenderer10.setBaseOutlinePaint(paint24, false);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        lineAndShapeRenderer10.setBasePaint((java.awt.Paint) color27);
        java.awt.Shape shape32 = lineAndShapeRenderer10.getItemShape((int) (byte) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setBaseShape(shape32);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer6.setSeriesFillPaint((int) '#', (java.awt.Paint) color11);
        renderAttributes4.setSeriesFillPaint(10, (java.awt.Paint) color11);
        java.awt.Paint paint15 = renderAttributes4.getSeriesOutlinePaint(100);
        java.awt.Shape shape16 = renderAttributes4.getDefaultShape();
        renderAttributes4.setDefaultLabelVisible((java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color24 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setSeriesFillPaint((int) '#', (java.awt.Paint) color24);
        boolean boolean26 = lineAndShapeRenderer19.getBaseSeriesVisible();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer19.setBasePaint((java.awt.Paint) color30);
        java.awt.Stroke stroke33 = lineAndShapeRenderer19.lookupSeriesStroke((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color39 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer34.setSeriesFillPaint((int) '#', (java.awt.Paint) color39);
        boolean boolean41 = lineAndShapeRenderer34.getBaseSeriesVisible();
        java.awt.Color color45 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer34.setBasePaint((java.awt.Paint) color45);
        java.awt.Stroke stroke48 = lineAndShapeRenderer34.lookupSeriesStroke((int) (short) 10);
        boolean boolean49 = lineAndShapeRenderer34.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = lineAndShapeRenderer34.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        lineAndShapeRenderer19.setBaseNegativeItemLabelPosition(itemLabelPosition51);
        boolean boolean53 = lineAndShapeRenderer19.getAutoPopulateSeriesPaint();
        java.awt.Paint paint55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        lineAndShapeRenderer19.setSeriesItemLabelPaint(0, paint55, false);
        renderAttributes4.setDefaultOutlinePaint(paint55);
        java.awt.Stroke stroke61 = renderAttributes4.getItemStroke((int) (byte) -1, 0);
        strokeList0.setStroke((int) (byte) 1, stroke61);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = chartChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=a]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=a]"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer1.setSeriesFillPaint((int) '#', (java.awt.Paint) color6);
        boolean boolean8 = lineAndShapeRenderer1.getBaseSeriesVisible();
        java.awt.Font font10 = null;
        lineAndShapeRenderer1.setSeriesItemLabelFont((int) (byte) 0, font10, false);
        lineAndShapeRenderer1.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) false);
        boolean boolean16 = lineAndShapeRenderer1.getAutoPopulateSeriesPaint();
        boolean boolean17 = gradientPaintTransformType0.equals((java.lang.Object) lineAndShapeRenderer1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = lineAndShapeRenderer1.getSeriesToolTipGenerator((int) (byte) 100);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint11 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer13.removeAnnotation(categoryAnnotation21);
        boolean boolean23 = lineAndShapeRenderer13.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot24.markerChanged(markerChangeEvent25);
        int int27 = categoryPlot24.getCrosshairDatasetIndex();
        float float28 = categoryPlot24.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        categoryPlot24.setDomainAxisLocation((int) (byte) 1, axisLocation30);
        java.awt.Stroke stroke32 = categoryPlot24.getOutlineStroke();
        lineAndShapeRenderer13.setBaseOutlineStroke(stroke32, false);
        java.awt.Font font36 = lineAndShapeRenderer13.lookupLegendTextFont(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot38.setWeight((int) (short) -1);
        categoryPlot38.setAnchorValue((double) (byte) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setSeriesFillPaint((int) '#', (java.awt.Paint) color50);
        boolean boolean52 = lineAndShapeRenderer45.getBaseSeriesVisible();
        java.awt.Color color56 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer45.setBasePaint((java.awt.Paint) color56);
        org.jfree.chart.LegendItem legendItem60 = lineAndShapeRenderer45.getLegendItem(2, (int) (byte) 1);
        categoryPlot38.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45, false);
        java.awt.Font font64 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer45.setSeriesItemLabelFont((int) 'a', font64);
        lineAndShapeRenderer13.setLegendTextFont(15, font64);
        barRenderer0.setSeriesItemLabelFont(255, font64);
        barRenderer0.setDrawBarOutline(true);
        boolean boolean70 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(font36);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(legendItem60);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        boolean boolean12 = lineAndShapeRenderer5.getBaseSeriesVisible();
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer5.setBasePaint((java.awt.Paint) color16);
        org.jfree.chart.LegendItem legendItem20 = lineAndShapeRenderer5.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape21 = lineAndShapeRenderer5.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape21, stroke22, (java.awt.Paint) color23);
        java.awt.Stroke stroke25 = legendItem24.getOutlineStroke();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        legendItem24.setLine(shape26);
        boolean boolean28 = paintList0.equals((java.lang.Object) legendItem24);
        java.awt.Color color31 = java.awt.Color.red;
        java.awt.Color color32 = java.awt.Color.getColor("ChartEntity: tooltip = null", color31);
        try {
            paintList0.setPaint((-65536), (java.awt.Paint) color32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (short) 10);
        boolean boolean15 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer18.setUseFillPaint(true);
        boolean boolean21 = lineAndShapeRenderer18.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape23 = lineAndShapeRenderer18.lookupSeriesShape(0);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        lineAndShapeRenderer0.setBaseLegendShape(shape23);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, false);
        java.awt.Paint paint47 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str49 = color48.toString();
        java.awt.image.ColorModel colorModel50 = null;
        java.awt.Rectangle rectangle51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        java.awt.geom.AffineTransform affineTransform53 = null;
        java.awt.RenderingHints renderingHints54 = null;
        java.awt.PaintContext paintContext55 = color48.createContext(colorModel50, rectangle51, rectangle2D52, affineTransform53, renderingHints54);
        int int56 = color48.getTransparency();
        java.awt.image.ColorModel colorModel57 = null;
        java.awt.Rectangle rectangle58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        java.awt.geom.AffineTransform affineTransform60 = null;
        java.awt.RenderingHints renderingHints61 = null;
        java.awt.PaintContext paintContext62 = color48.createContext(colorModel57, rectangle58, rectangle2D59, affineTransform60, renderingHints61);
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color48);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str49.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(paintContext55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(paintContext62);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        categoryPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation(10, axisLocation4, true);
        categoryPlot0.setAnchorValue((double) 0.0f, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot0.zoomDomainAxes((double) 1, 43.0d, plotRenderingInfo19, point2D20);
        java.lang.String str22 = categoryPlot0.getPlotType();
        categoryPlot0.setBackgroundImageAlpha((float) (byte) 1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot2.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = categoryPlot2.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = defaultCategoryDataset0.hasListener((java.util.EventListener) categoryPlot2);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState8 = defaultCategoryDataset0.getSelectionState();
        try {
            java.lang.Number number11 = defaultCategoryDataset0.getValue(100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        int int9 = categoryPlot5.indexOf(categoryDataset8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot5.notifyListeners(plotChangeEvent10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot5.getDatasetGroup();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color18 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer13.setSeriesFillPaint((int) '#', (java.awt.Paint) color18);
        boolean boolean20 = lineAndShapeRenderer13.getBaseSeriesVisible();
        java.awt.Font font22 = null;
        lineAndShapeRenderer13.setSeriesItemLabelFont((int) (byte) 0, font22, false);
        java.awt.Stroke stroke28 = lineAndShapeRenderer13.getItemStroke(2, 0, false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer13.getItemOutlineStroke(0, (int) (byte) 100, false);
        categoryPlot5.setRangeCrosshairStroke(stroke32);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (byte) 10, stroke32, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color43 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer38.setSeriesFillPaint((int) '#', (java.awt.Paint) color43);
        boolean boolean45 = lineAndShapeRenderer38.getBaseSeriesVisible();
        java.awt.Font font47 = null;
        lineAndShapeRenderer38.setSeriesItemLabelFont((int) (byte) 0, font47, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator51 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=128]");
        lineAndShapeRenderer38.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator51);
        lineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator51);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke3 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (-1L), (double) (byte) 1, plotRenderingInfo6, point2D7);
        boolean boolean9 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        double double5 = rectangleInsets0.trimHeight((double) 1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer6.setBaseToolTipGenerator(categoryToolTipGenerator7, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer6.getLegendItemLabelGenerator();
        java.awt.Paint paint12 = lineAndShapeRenderer6.lookupSeriesFillPaint((int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        lineAndShapeRenderer6.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        java.awt.Color color16 = java.awt.Color.white;
        lineAndShapeRenderer6.setBaseFillPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets0.equals((java.lang.Object) lineAndShapeRenderer6);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        double double3 = barRenderer0.getShadowXOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true, false);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint11 = barRenderer0.getBaseFillPaint();
        double double12 = barRenderer0.getMaximumBarWidth();
        double double13 = barRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color5);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape16 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color26 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        boolean boolean28 = lineAndShapeRenderer21.getBaseSeriesVisible();
        java.awt.Color color32 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer21.setBasePaint((java.awt.Paint) color32);
        java.awt.Stroke stroke35 = lineAndShapeRenderer21.lookupSeriesStroke((int) (short) 10);
        lineAndShapeRenderer21.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = lineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) '4');
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition39);
        java.awt.Stroke stroke41 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer0.getSeriesStroke(1);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = lineAndShapeRenderer0.getLegendItems();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        java.awt.Paint paint47 = lineAndShapeRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer8.setUseFillPaint(true);
        boolean boolean11 = lineAndShapeRenderer8.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape13 = lineAndShapeRenderer8.lookupSeriesShape(0);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "java.awt.Color[r=0,g=0,b=128]", "hi!", "", shape13, (java.awt.Paint) color14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        int int20 = categoryPlot16.indexOf(categoryDataset19);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) categoryPlot16, "ItemLabelAnchor.INSIDE4", "{0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation29 = axisLocation28.getOpposite();
        categoryPlot24.setDomainAxisLocation(10, axisLocation28, true);
        categoryPlot24.setDomainCrosshairRowKey((java.lang.Comparable) 1L);
        java.awt.Stroke stroke34 = categoryPlot24.getOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color44 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer39.setSeriesFillPaint((int) '#', (java.awt.Paint) color44);
        boolean boolean46 = lineAndShapeRenderer39.getBaseSeriesVisible();
        java.awt.Color color50 = java.awt.Color.getHSBColor(0.0f, 1.0f, (float) (short) -1);
        lineAndShapeRenderer39.setBasePaint((java.awt.Paint) color50);
        org.jfree.chart.LegendItem legendItem54 = lineAndShapeRenderer39.getLegendItem(2, (int) (byte) 1);
        java.awt.Shape shape55 = lineAndShapeRenderer39.getBaseShape();
        java.awt.Stroke stroke56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color57 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("{0}", "hi!", "", "java.awt.Color[r=0,g=0,b=128]", shape55, stroke56, (java.awt.Paint) color57);
        java.awt.Color color59 = java.awt.Color.gray;
        legendItem58.setFillPaint((java.awt.Paint) color59);
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "ChartEntity: tooltip = null", "GradientPaintTransformType.VERTICAL", "", shape13, stroke34, (java.awt.Paint) color59);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent63 = null;
        categoryPlot62.markerChanged(markerChangeEvent63);
        int int65 = categoryPlot62.getCrosshairDatasetIndex();
        float float66 = categoryPlot62.getForegroundAlpha();
        double double67 = categoryPlot62.getAnchorValue();
        org.jfree.chart.renderer.RenderAttributes renderAttributes69 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Paint paint70 = renderAttributes69.getDefaultOutlinePaint();
        categoryPlot62.setNoDataMessagePaint(paint70);
        java.awt.Paint paint72 = categoryPlot62.getDomainCrosshairPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection73 = categoryPlot62.getFixedLegendItems();
        int int74 = categoryPlot62.getWeight();
        org.jfree.chart.entity.PlotEntity plotEntity77 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) categoryPlot62, "PlotEntity: tooltip = null", "ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(legendItem54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 1.0f + "'", float66 == 1.0f);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNull(legendItemCollection73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }
}

