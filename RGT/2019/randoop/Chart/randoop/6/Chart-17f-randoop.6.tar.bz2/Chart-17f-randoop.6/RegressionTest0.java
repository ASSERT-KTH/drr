import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (short) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getNearestDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439474468L + "'", long2 == 1560439474468L);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        try {
            java.lang.Number number8 = timeSeries1.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        boolean boolean3 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener6);
        java.util.List list8 = timeSeries5.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
        java.util.List list13 = timeSeries10.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, year16);
        long long18 = month17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month17, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        java.lang.String str14 = year12.toString();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 10L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        boolean boolean3 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 3);
        try {
            timeSeries1.add(timeSeriesDataItem6);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        long long4 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        boolean boolean6 = timeSeries1.equals((java.lang.Object) "February 2019");
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        try {
            java.lang.Number number3 = timeSeries1.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener13);
        java.util.List list15 = timeSeries12.getItems();
        int int16 = timeSeries12.getMaximumItemCount();
        java.lang.String str17 = timeSeries12.getDescription();
        int int18 = fixedMillisecond10.compareTo((java.lang.Object) str17);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        java.lang.String str17 = regularTimePeriod16.toString();
        java.lang.String str18 = regularTimePeriod16.toString();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "February 2019" + "'", str17.equals("February 2019"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "February 2019" + "'", str18.equals("February 2019"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year3);
//        java.lang.String str5 = year3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.next();
//        boolean boolean7 = fixedMillisecond0.equals((java.lang.Object) regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Thu Jun 13 08:24:37 PDT 2019" + "'", str1.equals("Thu Jun 13 08:24:37 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass12 = fixedMillisecond11.getClass();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100, (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        int int6 = timeSeries2.getMaximumItemCount();
        java.lang.String str7 = timeSeries2.getDescription();
        java.lang.Class class8 = timeSeries2.getTimePeriodClass();
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", class8);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, (int) (short) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        int int24 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, year17);
        long long19 = month18.getFirstMillisecond();
        boolean boolean20 = timeSeries10.equals((java.lang.Object) long19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        try {
            timeSeries10.update(regularTimePeriod22, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.lang.Object obj2 = seriesChangeEvent1.getSource();
//        java.lang.String str3 = seriesChangeEvent1.toString();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:38 PDT 2019]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:38 PDT 2019]"));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate21 = null;
        try {
            boolean boolean22 = spreadsheetDate16.isAfter(serialDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100, 31, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond2.getClass();
        java.io.InputStream inputStream4 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", (java.lang.Class) wildcardClass3);
        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(inputStream4);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        try {
            java.util.Collection collection10 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list9);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long9 = month8.getFirstMillisecond();
        boolean boolean11 = month8.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month8.previous();
        long long13 = month8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 9);
        try {
            timeSeries1.add(timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1547668799999L + "'", long13 == 1547668799999L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.util.List list7 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.util.List list12 = timeSeries9.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, year15);
        long long17 = month16.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
        try {
            int int19 = spreadsheetDate1.compareTo((java.lang.Object) timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ClassContext");
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries10.clear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, year18);
        java.lang.String str20 = year18.toString();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, number21);
        long long23 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 1.0f);
        java.lang.Object obj26 = null;
        boolean boolean27 = year18.equals(obj26);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        int int11 = month6.getYearValue();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        long long9 = month6.getSerialIndex();
        java.lang.String str10 = month6.toString();
        java.lang.String str11 = month6.toString();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24229L + "'", long9 == 24229L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 2019" + "'", str10.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January 2019" + "'", str11.equals("January 2019"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        int int15 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener20);
        java.util.List list22 = timeSeries19.getItems();
        int int23 = timeSeries19.getMaximumItemCount();
        java.lang.String str24 = timeSeries19.getDescription();
        int int25 = fixedMillisecond17.compareTo((java.lang.Object) str24);
        java.util.Calendar calendar26 = null;
        fixedMillisecond17.peg(calendar26);
        long long28 = fixedMillisecond17.getSerialIndex();
        try {
            int int29 = spreadsheetDate1.compareTo((java.lang.Object) fixedMillisecond17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone6);
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2958465, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Thu Jun 13 08:24:34 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate3.getYYYY();
        int int17 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean19 = day0.equals((java.lang.Object) spreadsheetDate3);
        java.util.Calendar calendar20 = null;
        try {
            day0.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 10.0f);
        int int5 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean8 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2147483647, (org.jfree.data.time.SerialDate) spreadsheetDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate3.getYYYY();
        int int17 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(8, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getNearestDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("13-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries1.add(regularTimePeriod9, (double) 10.0f, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries1.isEmpty();
        int int10 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int21 = spreadsheetDate16.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = spreadsheetDate23.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean32 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean35 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate23.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean41 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SerialDate serialDate43 = null;
        try {
            boolean boolean45 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, serialDate43, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        java.lang.Class class28 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass30 = year29.getClass();
        int int31 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        java.util.Calendar calendar32 = null;
        try {
            year29.peg(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        int int7 = timeSeries3.getMaximumItemCount();
        java.lang.String str8 = timeSeries3.getDescription();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) str8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond1.peg(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SerialDate serialDate6 = null;
        try {
            boolean boolean7 = spreadsheetDate1.isOnOrBefore(serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        java.lang.String str19 = month13.toString();
        int int20 = month13.getMonth();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "January 2019" + "'", str19.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("13-June-2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
        java.util.Calendar calendar5 = null;
        try {
            day4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
//        java.lang.String str3 = year1.toString();
//        long long4 = year1.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 3);
//        boolean boolean8 = year1.equals((java.lang.Object) fixedMillisecond5);
//        long long9 = fixedMillisecond5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560439485701L + "'", long9 == 1560439485701L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:38 PDT 2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getYear();
        java.util.Calendar calendar5 = null;
        try {
            day3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("February 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean7 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate4.toSerial();
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries1, (java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        int int14 = day13.getYear();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, year20);
        long long22 = month21.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) month21);
        boolean boolean24 = day13.equals((java.lang.Object) month21);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.isOnOrAfter(serialDate9);
        boolean boolean11 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate5.getClass();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate3.getYYYY();
        int int17 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean19 = day0.equals((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day20.getMiddleMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        long long9 = month6.getSerialIndex();
        java.lang.String str10 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month6.next();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24229L + "'", long9 == 24229L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 2019" + "'", str10.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate3.getYYYY();
        int int17 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean19 = day0.equals((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        long long21 = day20.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208182400001L) + "'", long21 == (-2208182400001L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Following");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate4 = serialDate2.getFollowingDayOfWeek((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        long long12 = month11.getFirstMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month11);
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month11, (double) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24229L + "'", long14 == 24229L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January 2019" + "'", str15.equals("January 2019"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year6 = month2.getYear();
        int int7 = year6.getYear();
        long long8 = year6.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass2 = year1.getClass();
        java.net.URL uRL3 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(uRL3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        long long7 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 9);
        int int11 = timeSeriesDataItem9.compareTo((java.lang.Object) 'a');
        timeSeriesDataItem9.setValue((java.lang.Number) 1560495599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1547668799999L + "'", long7 == 1547668799999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        boolean boolean9 = timeSeries1.equals((java.lang.Object) 1577865599999L);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries10.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]");
        try {
            timeSeries10.delete(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        long long10 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj11 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        timeSeries1.removeAgedItems(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries1.getTimePeriod((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(6, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = timeSeries1.equals((java.lang.Object) boolean15);
        boolean boolean17 = timeSeries1.isEmpty();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, year24);
        long long26 = month25.getFirstMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month25);
        long long28 = month25.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24229L + "'", long28 == 24229L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        int int16 = timeSeries10.getItemCount();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-460));
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) (short) 10, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day3.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        int int8 = day3.getMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day3.getSerialDate();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        int int4 = day3.getYear();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
//        long long12 = month11.getFirstMillisecond();
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month11);
//        boolean boolean14 = day3.equals((java.lang.Object) month11);
//        long long15 = day3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439491699L + "'", long4 == 1560439491699L);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        int int10 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries10.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, year19);
        int int21 = month20.getYearValue();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        timeSeries1.setDescription("January 2019");
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond2.getClass();
        java.io.InputStream inputStream4 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", (java.lang.Class) wildcardClass3);
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("Time", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(inputStream4);
        org.junit.Assert.assertNull(uRL5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) 0);
        java.util.Date date3 = fixedMillisecond0.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("January 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Thu Jun 13 08:24:34 PDT 2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.lang.String str5 = year1.toString();
        java.util.Calendar calendar6 = null;
        try {
            year1.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        long long13 = month12.getFirstMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month12);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day21, (double) 100.0f, true);
        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries27.removePropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, year31);
        long long33 = month32.getFirstMillisecond();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month32.previous();
        long long36 = month32.getSerialIndex();
        int int37 = month32.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month32.previous();
        try {
            timeSeries1.update(regularTimePeriod38, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24229L + "'", long36 == 24229L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries10.clear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, year18);
        java.lang.String str20 = year18.toString();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, number21);
        long long23 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 1.0f);
        java.lang.Class<?> wildcardClass26 = timeSeries10.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        int int29 = fixedMillisecond27.compareTo((java.lang.Object) 0);
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar3 = null;
        try {
            day2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2019, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month6.next();
        long long12 = month6.getSerialIndex();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month6.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24229L + "'", long12 == 24229L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        int int7 = timeSeries3.getMaximumItemCount();
        java.lang.String str8 = timeSeries3.getDescription();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) str8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond1.peg(calendar10);
        java.util.Date date12 = fixedMillisecond1.getTime();
        int int14 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (double) 100.0f, true);
        try {
            org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.createCopy(12, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
//        java.util.List list4 = timeSeries1.getItems();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
//        java.util.List list9 = timeSeries6.getItems();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean16 = timeSeries1.equals((java.lang.Object) boolean15);
//        boolean boolean17 = timeSeries1.isEmpty();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        long long20 = day18.getMiddleMillisecond();
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(list4);
//        org.junit.Assert.assertNotNull(list9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = timeSeries1.equals((java.lang.Object) boolean15);
        boolean boolean17 = timeSeries1.isEmpty();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setRangeDescription("ClassContext");
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date8 = spreadsheetDate6.toDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        int int7 = timeSeries3.getMaximumItemCount();
        java.lang.String str8 = timeSeries3.getDescription();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) str8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond1.peg(calendar10);
        long long12 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond1.previous();
        long long14 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-460));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ERROR : Relative To String");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-460), (int) (byte) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2958465, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getTime();
        boolean boolean6 = year2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond4.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean18 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean21 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int22 = spreadsheetDate9.getYYYY();
        int int23 = spreadsheetDate9.getDayOfWeek();
        java.util.Date date24 = spreadsheetDate9.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date24, timeZone28);
        try {
            org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date0, timeZone28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.isOnOrAfter(serialDate9);
        boolean boolean11 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate5.getFollowingDayOfWeek(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        int int15 = spreadsheetDate1.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getPreviousDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries1.isEmpty();
        java.lang.String str10 = timeSeries1.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 0L);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean11 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean14 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate2.getYYYY();
        int int16 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener20);
        java.util.List list22 = timeSeries19.getItems();
        int int23 = timeSeries19.getMaximumItemCount();
        java.lang.String str24 = timeSeries19.getDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj27 = timeSeries26.clone();
        java.lang.Comparable comparable28 = timeSeries26.getKey();
        java.util.Collection collection29 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate17, (java.lang.Object) collection29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (short) 0 + "'", comparable28.equals((short) 0));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.util.List list6 = timeSeries1.getItems();
        try {
            java.util.Collection collection7 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(list6);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439498022L + "'", long3 == 1560439498022L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month6.next();
        long long12 = month6.getSerialIndex();
        boolean boolean14 = month6.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24229L + "'", long12 == 24229L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        long long4 = year1.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 3);
        boolean boolean8 = year1.equals((java.lang.Object) fixedMillisecond5);
        long long9 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate3.getDayOfMonth();
        boolean boolean5 = fixedMillisecond0.equals((java.lang.Object) spreadsheetDate3);
        int int6 = spreadsheetDate3.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.setMaximumItemAge((long) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener19);
        java.util.List list21 = timeSeries18.getItems();
        int int22 = timeSeries18.getMaximumItemCount();
        java.lang.String str23 = timeSeries18.getDescription();
        int int24 = fixedMillisecond16.compareTo((java.lang.Object) str23);
        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        java.lang.Object obj5 = timeSeries1.clone();
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries1.getTimePeriod(14);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 14, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
        java.util.List list10 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year13);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        java.lang.String str20 = month14.toString();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, year24);
        java.lang.String str26 = year24.toString();
        java.lang.Number number27 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, number27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass30 = year29.getClass();
        boolean boolean31 = timeSeriesDataItem28.equals((java.lang.Object) wildcardClass30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str20, "org.jfree.data.general.SeriesException: ", "", (java.lang.Class) wildcardClass30);
        java.io.InputStream inputStream33 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 08:24:37 PDT 2019", (java.lang.Class) wildcardClass30);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "January 2019" + "'", str20.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(inputStream33);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (double) 100.0f, true);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day15.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        int int15 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean20 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean29 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate17.getYYYY();
        boolean boolean31 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate32 = null;
        try {
            boolean boolean33 = spreadsheetDate17.isOn(serialDate32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate26.isOnOrAfter(serialDate30);
        boolean boolean32 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate35.getYYYY();
        boolean boolean39 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate35, 12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1, timeZone5);
        int int8 = year7.getYear();
        java.util.Date date9 = year7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge(1L);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        long long9 = month6.getSerialIndex();
        java.lang.String str10 = month6.toString();
        org.jfree.data.time.Year year11 = month6.getYear();
        long long12 = month6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24229L + "'", long9 == 24229L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 2019" + "'", str10.equals("January 2019"));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1549007999999L + "'", long12 == 1549007999999L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        java.lang.Number number25 = null;
        try {
            timeSeries23.update(5, number25);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        long long12 = month11.getFirstMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean14 = day3.equals((java.lang.Object) month11);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month11.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        java.util.Calendar calendar19 = null;
        try {
            month13.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) 10.0f);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate15.isOnOrAfter(serialDate19);
        boolean boolean21 = timeSeriesDataItem13.equals((java.lang.Object) boolean20);
        try {
            timeSeries1.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        long long12 = month11.getFirstMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean14 = day3.equals((java.lang.Object) month11);
        org.jfree.data.time.Year year15 = month11.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(year15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        long long7 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 9);
        timeSeriesDataItem9.setValue((java.lang.Number) 2958465);
        java.lang.Number number12 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1547668799999L + "'", long7 == 1547668799999L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2958465 + "'", number12.equals(2958465));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, 1900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number4);
        long long6 = year1.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        timeSeries1.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        long long9 = month6.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month6.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        timeSeries1.setMaximumItemCount(100);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.setMaximumItemAge((long) 100);
        java.lang.String str15 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean7 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate4.toSerial();
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries1, (java.lang.Object) spreadsheetDate4);
        java.lang.String str10 = spreadsheetDate4.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate20.isOnOrAfter(serialDate24);
        boolean boolean27 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate20, (int) (byte) 0);
        org.jfree.data.time.SerialDate serialDate28 = null;
        try {
            boolean boolean30 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, serialDate28, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
        java.util.List list10 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year13);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries11.clear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, year19);
        java.lang.String str21 = year19.toString();
        java.lang.Number number22 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, number22);
        long long24 = year19.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1.0f);
        java.lang.Class<?> wildcardClass27 = year19.getClass();
        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:41 PDT 2019]", (java.lang.Class) wildcardClass27);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(inputStream28);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        long long9 = month6.getSerialIndex();
        java.lang.String str10 = month6.toString();
        org.jfree.data.time.Year year11 = month6.getYear();
        long long12 = month6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24229L + "'", long9 == 24229L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 2019" + "'", str10.equals("January 2019"));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1547668799999L + "'", long12 == 1547668799999L);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj6 = timeSeries5.clone();
//        timeSeries5.setMaximumItemAge((long) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries5.addChangeListener(seriesChangeListener11);
//        java.util.Collection collection13 = timeSeries5.getTimePeriods();
//        java.util.Collection collection14 = org.jfree.chart.util.ObjectUtilities.deepClone(collection13);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) collection13);
//        java.util.Collection collection16 = org.jfree.chart.util.ObjectUtilities.deepClone(collection13);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439503716L + "'", long3 == 1560439503716L);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(collection16);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        java.lang.Object obj5 = timeSeries1.clone();
        boolean boolean6 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        int int4 = day3.getMonth();
//        long long5 = day3.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        int int11 = month6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate14.isOnOrAfter(serialDate18);
        boolean boolean20 = month6.equals((java.lang.Object) boolean19);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month6.getMiddleMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        long long4 = year1.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener9);
        java.util.List list11 = timeSeries8.getItems();
        int int12 = timeSeries8.getMaximumItemCount();
        java.lang.String str13 = timeSeries8.getDescription();
        java.lang.Class class14 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, "ClassContext", "org.jfree.data.general.SeriesException: ", class14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        int int10 = timeSeries6.getMaximumItemCount();
        java.lang.String str11 = timeSeries6.getDescription();
        java.lang.Class class12 = timeSeries6.getTimePeriodClass();
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class12);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class12);
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class12);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass18 = year17.getClass();
        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Value", (java.lang.Class) wildcardClass18);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class12, (java.lang.Class) wildcardClass18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date24, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date22, timeZone26);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(13, serialDate31);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNotNull(uRL15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(inputStream19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.util.List list7 = timeSeries4.getItems();
        int int8 = timeSeries4.getMaximumItemCount();
        java.lang.String str9 = timeSeries4.getDescription();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class10);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:41 PDT 2019]", class10);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class10);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3, 2958465, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        java.lang.String str4 = year2.toString();
        java.lang.String str5 = year2.toString();
        long long6 = year2.getLastMillisecond();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(2019, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        long long5 = day3.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate7.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean16 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate7.getYYYY();
        int int21 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = spreadsheetDate23.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean32 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean35 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate23.getYYYY();
        boolean boolean37 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean38 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.lang.String str39 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.setRangeDescription("2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            int int5 = timeSeries1.getIndex(regularTimePeriod4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        int int12 = month11.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day17);
        java.util.Calendar calendar20 = null;
        try {
            month11.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 2019", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year6 = month2.getYear();
        int int7 = year6.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        java.lang.Class class28 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass30 = year29.getClass();
        int int31 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year29.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate3.getYYYY();
        int int17 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean19 = day0.equals((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        long long21 = day20.getFirstMillisecond();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day20.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208268800000L) + "'", long21 == (-2208268800000L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean8 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int9 = spreadsheetDate5.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean14 = spreadsheetDate11.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean17 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate5.getYYYY();
        int int19 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean21 = day2.equals((java.lang.Object) spreadsheetDate5);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-5542), (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(12, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean22 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate10.getYYYY();
        int int24 = spreadsheetDate10.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean30 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean36 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean39 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean40 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean47 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        int int48 = spreadsheetDate44.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean53 = spreadsheetDate50.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean56 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate52, (org.jfree.data.time.SerialDate) spreadsheetDate55);
        int int57 = spreadsheetDate44.getYYYY();
        int int58 = spreadsheetDate44.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean60 = day41.equals((java.lang.Object) spreadsheetDate44);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean62 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean63 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1900 + "'", int57 == 1900);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 3 + "'", int58 == 3);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Thu Jun 13 08:24:34 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        long long7 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 9);
        int int10 = month2.getYearValue();
        int int11 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1547668799999L + "'", long7 == 1547668799999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:41 PDT 2019]");
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.isOnOrAfter(serialDate9);
        boolean boolean11 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener14);
        java.util.List list16 = timeSeries13.getItems();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener19);
        java.util.List list21 = timeSeries18.getItems();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries18);
        boolean boolean23 = spreadsheetDate5.equals((java.lang.Object) timeSeries13);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = timeSeries1.equals((java.lang.Object) boolean15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, year18);
        int int20 = month19.getYearValue();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month19, (double) 6, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        long long13 = month12.getFirstMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month12);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day21, (double) 100.0f, true);
        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getTime();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 4, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj10 = timeSeries9.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate12.toSerial();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries9, (java.lang.Object) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears(12, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean23 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int24 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean29 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean32 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int33 = spreadsheetDate20.getYYYY();
        int int34 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean39 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int40 = spreadsheetDate36.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean45 = spreadsheetDate42.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean48 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate44, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int49 = spreadsheetDate36.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean54 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean55 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean56 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean61 = spreadsheetDate20.isOnOrBefore(serialDate60);
        boolean boolean62 = spreadsheetDate1.isOnOrAfter(serialDate60);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, year25);
        java.lang.String str27 = year25.toString();
        long long28 = year25.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 3);
        boolean boolean32 = year25.equals((java.lang.Object) fixedMillisecond29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 1, year37);
        java.lang.String str39 = year37.toString();
        java.lang.Number number40 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, number40);
        long long42 = year37.getSerialIndex();
        try {
            org.jfree.data.time.TimeSeries timeSeries43 = timeSeries1.createCopy(regularTimePeriod35, (org.jfree.data.time.RegularTimePeriod) year37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year6 = month2.getYear();
        int int7 = year6.getYear();
        long long8 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.util.Calendar calendar5 = null;
        try {
            year1.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        int int20 = timeSeries16.getMaximumItemCount();
        java.lang.String str21 = timeSeries16.getDescription();
        java.lang.Class class22 = timeSeries16.getTimePeriodClass();
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class22);
        java.io.InputStream inputStream24 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class22);
        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class22);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass28 = year27.getClass();
        java.io.InputStream inputStream29 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Value", (java.lang.Class) wildcardClass28);
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class22, (java.lang.Class) wildcardClass28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date32, timeZone36);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone39);
        try {
            timeSeries10.add(regularTimePeriod40, (java.lang.Number) 2958465, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNull(inputStream23);
        org.junit.Assert.assertNull(inputStream24);
        org.junit.Assert.assertNotNull(uRL25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(inputStream29);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1, timeZone5);
        int int8 = year7.getYear();
        java.util.Date date9 = year7.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        int int3 = day0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        long long9 = month6.getSerialIndex();
        java.lang.String str10 = month6.toString();
        org.jfree.data.time.Year year11 = month6.getYear();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24229L + "'", long9 == 24229L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 2019" + "'", str10.equals("January 2019"));
        org.junit.Assert.assertNotNull(year11);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        int int8 = day3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean9 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.toSerial();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries3, (java.lang.Object) spreadsheetDate6);
        java.lang.String str12 = spreadsheetDate6.getDescription();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(1905, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int17 = spreadsheetDate16.getDayOfMonth();
        boolean boolean18 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries10.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]");
        java.lang.String str18 = timeSeries10.getDomainDescription();
        java.util.List list19 = timeSeries10.getItems();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj22 = timeSeries21.clone();
        timeSeries21.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries21.addChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries21.getTimePeriods();
        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries10, (java.lang.Object) collection29);
        java.util.Collection collection31 = org.jfree.chart.util.ObjectUtilities.deepClone(collection29);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]" + "'", str18.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]"));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(collection31);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener30);
        java.util.List list32 = timeSeries29.getItems();
        int int33 = timeSeries29.getMaximumItemCount();
        java.lang.String str34 = timeSeries29.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener35);
        java.util.Collection collection37 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timeSeries39.removePropertyChangeListener(propertyChangeListener40);
        java.util.List list42 = timeSeries39.getItems();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries44.removePropertyChangeListener(propertyChangeListener45);
        java.util.List list47 = timeSeries44.getItems();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (byte) 1, year50);
        long long52 = month51.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) month51);
        int int54 = timeSeries48.getMaximumItemCount();
        java.util.List list55 = timeSeries48.getItems();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timeSeries48.removePropertyChangeListener(propertyChangeListener56);
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries29.addAndOrUpdate(timeSeries48);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546329600000L + "'", long52 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(timeSeries58);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean11 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean14 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate2.getYYYY();
        int int16 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean21 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int22 = spreadsheetDate18.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean27 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean30 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries35.removePropertyChangeListener(propertyChangeListener36);
        java.util.List list38 = timeSeries35.getItems();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries40.removePropertyChangeListener(propertyChangeListener41);
        java.util.List list43 = timeSeries40.getItems();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries35.addAndOrUpdate(timeSeries40);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 1, year46);
        long long48 = month47.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) month47);
        timeSeries44.clear();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (byte) 1, year52);
        java.lang.String str54 = year52.toString();
        java.lang.Number number55 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, number55);
        long long57 = year52.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, (double) 1.0f);
        java.lang.Class<?> wildcardClass60 = year52.getClass();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate18, "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:50 PDT 2019]", "hi!", (java.lang.Class) wildcardClass60);
        java.net.URL uRL62 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass60);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1546329600000L + "'", long48 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNull(uRL62);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj16 = timeSeries15.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean21 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int22 = spreadsheetDate18.toSerial();
        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries15, (java.lang.Object) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries30.removePropertyChangeListener(propertyChangeListener31);
        java.util.List list33 = timeSeries30.getItems();
        int int34 = timeSeries30.getMaximumItemCount();
        java.lang.String str35 = timeSeries30.getDescription();
        java.lang.Class class36 = timeSeries30.getTimePeriodClass();
        java.io.InputStream inputStream37 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class36);
        java.io.InputStream inputStream38 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class36);
        java.net.URL uRL39 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class36);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass42 = year41.getClass();
        java.io.InputStream inputStream43 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Value", (java.lang.Class) wildcardClass42);
        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class36, (java.lang.Class) wildcardClass42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date46 = fixedMillisecond45.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date48 = fixedMillisecond47.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date48, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date46, timeZone50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date46, timeZone53);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date46);
        boolean boolean56 = spreadsheetDate18.isOnOrBefore(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2147483647 + "'", int34 == 2147483647);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNull(inputStream37);
        org.junit.Assert.assertNull(inputStream38);
        org.junit.Assert.assertNotNull(uRL39);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNull(inputStream43);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Thu Jun 13 08:24:34 PDT 2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((int) (short) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate3.getYYYY();
        int int17 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean19 = day0.equals((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(30, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1, timeZone5);
        int int8 = year7.getYear();
        java.util.Date date9 = year7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year6 = month2.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
//        long long7 = month6.getFirstMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond9.getFirstMillisecond(calendar11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond9.next();
//        try {
//            timeSeries1.add(regularTimePeriod13, (java.lang.Number) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560439514595L + "'", long12 == 1560439514595L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.setMaximumItemAge((long) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        java.util.List list24 = timeSeries21.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, year27);
        long long29 = month28.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries35.removePropertyChangeListener(propertyChangeListener36);
        java.util.List list38 = timeSeries35.getItems();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries40.removePropertyChangeListener(propertyChangeListener41);
        java.util.List list43 = timeSeries40.getItems();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries35.addAndOrUpdate(timeSeries40);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 1, year46);
        long long48 = month47.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) month47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month47.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, 0.0d);
        boolean boolean53 = timeSeriesDataItem33.equals((java.lang.Object) month47);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) 100.0f, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1546329600000L + "'", long48 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int21 = spreadsheetDate16.getMonth();
        org.jfree.data.time.SerialDate serialDate22 = null;
        try {
            boolean boolean23 = spreadsheetDate16.isOnOrAfter(serialDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        try {
            timeSeries1.setMaximumItemCount((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        int int15 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean20 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean29 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate17.getYYYY();
        boolean boolean31 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date32 = spreadsheetDate17.toDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
//        long long3 = month2.getFirstMillisecond();
//        boolean boolean5 = month2.equals((java.lang.Object) 10L);
//        org.jfree.data.time.Year year6 = month2.getYear();
//        int int7 = year6.getYear();
//        long long8 = year6.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        boolean boolean12 = year6.equals((java.lang.Object) fixedMillisecond9);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond9.getFirstMillisecond(calendar13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560439517006L + "'", long14 == 1560439517006L);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        java.lang.String str5 = regularTimePeriod4.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12-June-2019" + "'", str5.equals("12-June-2019"));
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        java.lang.String str28 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year6 = month2.getYear();
        long long7 = year6.getSerialIndex();
        long long8 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        java.lang.Object obj5 = timeSeries1.clone();
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        java.lang.ClassLoader classLoader7 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class6);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader7);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader7);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(classLoader7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:41 PDT 2019]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:41 PDT 2019]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:41 PDT 2019]"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries10.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]");
        java.lang.String str18 = timeSeries10.getDomainDescription();
        java.util.List list19 = timeSeries10.getItems();
        long long20 = timeSeries10.getMaximumItemAge();
        timeSeries10.setMaximumItemAge((long) ' ');
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]" + "'", str18.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]"));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.List list23 = timeSeries20.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener26);
        java.util.List list28 = timeSeries25.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, year31);
        long long33 = month32.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, 0.0d);
        boolean boolean38 = timeSeriesDataItem18.equals((java.lang.Object) month32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem18.getPeriod();
        timeSeriesDataItem18.setValue((java.lang.Number) 1560439517006L);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            java.lang.Number number8 = timeSeries1.getValue(regularTimePeriod7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("13-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        int int26 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean9 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.toSerial();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries3, (java.lang.Object) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(12, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean17 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean23 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = spreadsheetDate14.getYYYY();
        int int28 = spreadsheetDate14.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean33 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int34 = spreadsheetDate30.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean39 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean42 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int43 = spreadsheetDate30.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean48 = spreadsheetDate45.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean50 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        try {
            org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9, (org.jfree.data.time.SerialDate) spreadsheetDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1900 + "'", int27 == 1900);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries10.clear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, year18);
        java.lang.String str20 = year18.toString();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, number21);
        long long23 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 1.0f);
        java.lang.Class<?> wildcardClass26 = timeSeries10.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, year32);
        long long34 = month33.getFirstMillisecond();
        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) month33);
        long long36 = month33.getSerialIndex();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24229L + "'", long36 == 24229L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        int int6 = timeSeries2.getMaximumItemCount();
        java.lang.String str7 = timeSeries2.getDescription();
        java.lang.Class class8 = timeSeries2.getTimePeriodClass();
        timeSeries2.setMaximumItemCount(2019);
        java.lang.Class class11 = timeSeries2.getTimePeriodClass();
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("12-June-2019", class11);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(inputStream12);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries10.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date14, timeZone18);
        int int21 = year20.getYear();
        java.util.Date date22 = year20.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
        java.util.Calendar calendar24 = null;
        fixedMillisecond23.peg(calendar24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, 0.0d);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean8 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int9 = spreadsheetDate5.toSerial();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj12 = timeSeries11.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean17 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate14.toSerial();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries11, (java.lang.Object) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean24 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean30 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean33 = spreadsheetDate21.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int34 = spreadsheetDate21.getYYYY();
        int int35 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean40 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int41 = spreadsheetDate37.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean46 = spreadsheetDate43.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean49 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, (org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate21.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean51 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears(13, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate54);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1900 + "'", int35 == 1900);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, year29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getTime();
        boolean boolean33 = year29.equals((java.lang.Object) fixedMillisecond31);
        java.util.Calendar calendar34 = null;
        fixedMillisecond31.peg(calendar34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-460));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond31.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod38);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.lang.String str2 = seriesChangeEvent1.toString();
//        java.lang.String str3 = seriesChangeEvent1.toString();
//        java.lang.Object obj4 = seriesChangeEvent1.getSource();
//        java.lang.String str5 = seriesChangeEvent1.toString();
//        java.lang.String str6 = seriesChangeEvent1.toString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]"));
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]"));
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.addChangeListener(seriesChangeListener8);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number4);
        timeSeriesDataItem5.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.util.List list12 = timeSeries9.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener15);
        java.util.List list17 = timeSeries14.getItems();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, year20);
        long long22 = month21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
        int int24 = timeSeries18.getMaximumItemCount();
        java.util.List list25 = timeSeries18.getItems();
        boolean boolean26 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries18);
        timeSeries18.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        java.util.Collection collection10 = org.jfree.chart.util.ObjectUtilities.deepClone(collection9);
        java.util.Collection collection11 = org.jfree.chart.util.ObjectUtilities.deepClone(collection9);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:25:19 PDT 2019]");
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        timeSeries1.setRangeDescription("");
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems((long) (-5542), false);
        boolean boolean29 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean22 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate19.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean28 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean31 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean37 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean40 = spreadsheetDate36.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int42 = spreadsheetDate19.compare(serialDate41);
        boolean boolean43 = timeSeries1.equals((java.lang.Object) serialDate41);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries45.removeChangeListener(seriesChangeListener49);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener51);
        java.util.List list53 = timeSeries45.getItems();
        timeSeries45.setNotify(false);
        boolean boolean56 = timeSeries1.equals((java.lang.Object) timeSeries45);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-5542) + "'", int42 == (-5542));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439520777L + "'", long3 == 1560439520777L);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate12.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean21 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean24 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate12.getYYYY();
        int int26 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean28 = day9.equals((java.lang.Object) spreadsheetDate12);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean31 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439520889L + "'", long2 == 1560439520889L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439520889L + "'", long4 == 1560439520889L);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        boolean boolean16 = month13.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year17 = month13.getYear();
        int int18 = year17.getYear();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.List list23 = timeSeries20.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener26);
        java.util.List list28 = timeSeries25.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, year31);
        long long33 = month32.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month32);
        int int35 = timeSeries29.getMaximumItemCount();
        timeSeries29.setNotify(false);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean44 = spreadsheetDate41.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        int int45 = spreadsheetDate41.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean50 = spreadsheetDate47.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean53 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate49, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int54 = spreadsheetDate41.getYYYY();
        int int55 = spreadsheetDate41.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean57 = day38.equals((java.lang.Object) spreadsheetDate41);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day58);
        boolean boolean60 = year17.equals((java.lang.Object) timeSeries29);
        boolean boolean61 = month6.equals((java.lang.Object) boolean60);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1900 + "'", int54 == 1900);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        long long10 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, year16);
        long long18 = month17.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.previous();
        long long21 = month17.getSerialIndex();
        boolean boolean22 = timeSeries1.equals((java.lang.Object) month17);
        timeSeries1.setNotify(false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24229L + "'", long21 == 24229L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.List list23 = timeSeries20.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener26);
        java.util.List list28 = timeSeries25.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, year31);
        long long33 = month32.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, 0.0d);
        boolean boolean38 = timeSeriesDataItem18.equals((java.lang.Object) month32);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = month32.getFirstMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24229L);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class<?> wildcardClass1 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439521356L + "'", long3 == 1560439521356L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate3.getDayOfMonth();
        boolean boolean5 = fixedMillisecond0.equals((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate7.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean16 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate7.getYYYY();
        int int21 = spreadsheetDate7.getDayOfWeek();
        boolean boolean22 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int11 = spreadsheetDate10.getDayOfMonth();
//        boolean boolean12 = fixedMillisecond7.equals((java.lang.Object) spreadsheetDate10);
//        long long13 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean14 = day4.equals((java.lang.Object) long13);
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) long13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560439521418L + "'", long13 == 1560439521418L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("9-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        int int11 = month6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.previous();
        long long13 = month6.getSerialIndex();
        long long14 = month6.getLastMillisecond();
        long long15 = month6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24229L + "'", long13 == 24229L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1549007999999L + "'", long14 == 1549007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1549007999999L + "'", long15 == 1549007999999L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Fourth" + "'", str1.equals("Fourth"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.toSerial();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries7, (java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean20 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean29 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate17.getYYYY();
        int int31 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean36 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate33.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean42 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean45 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean47 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str48 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getTime();
        boolean boolean5 = year1.equals((java.lang.Object) fixedMillisecond3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        java.util.Calendar calendar7 = null;
        try {
            year1.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(10);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj10 = timeSeries9.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate12.toSerial();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries9, (java.lang.Object) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean22 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate19.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean28 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean31 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = spreadsheetDate19.getYYYY();
        int int33 = spreadsheetDate19.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean38 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int39 = spreadsheetDate35.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean44 = spreadsheetDate41.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean47 = spreadsheetDate35.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean49 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears(13, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(1900, serialDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean56 = spreadsheetDate53.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        int int57 = spreadsheetDate53.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean62 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int63 = spreadsheetDate59.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean68 = spreadsheetDate65.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean71 = spreadsheetDate59.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate67, (org.jfree.data.time.SerialDate) spreadsheetDate70);
        int int72 = spreadsheetDate59.getYYYY();
        int int73 = spreadsheetDate59.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean78 = spreadsheetDate75.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int79 = spreadsheetDate75.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean84 = spreadsheetDate81.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate83);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean87 = spreadsheetDate75.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate83, (org.jfree.data.time.SerialDate) spreadsheetDate86);
        int int88 = spreadsheetDate75.getYYYY();
        boolean boolean89 = spreadsheetDate59.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean90 = spreadsheetDate53.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SerialDate serialDate91 = serialDate51.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1900 + "'", int72 == 1900);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1900 + "'", int73 == 1900);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 10 + "'", int79 == 10);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1900 + "'", int88 == 1900);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(serialDate91);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener30);
        java.util.List list32 = timeSeries29.getItems();
        int int33 = timeSeries29.getMaximumItemCount();
        java.lang.String str34 = timeSeries29.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener35);
        java.util.Collection collection37 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, year39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) 10.0f);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate44.isOnOrAfter(serialDate48);
        boolean boolean50 = timeSeriesDataItem42.equals((java.lang.Object) boolean49);
        try {
            timeSeries29.add(timeSeriesDataItem42);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.Class<?> wildcardClass17 = spreadsheetDate1.getClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj3 = timeSeries2.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean8 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int9 = spreadsheetDate5.toSerial();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries2, (java.lang.Object) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(12, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean16 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean22 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean25 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate13.getYYYY();
        int int27 = spreadsheetDate13.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean32 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int33 = spreadsheetDate29.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean38 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean41 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        int int42 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean47 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean49 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (byte) 1, year52);
        java.lang.String str54 = year52.toString();
        java.lang.Number number55 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, number55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass58 = year57.getClass();
        boolean boolean59 = timeSeriesDataItem56.equals((java.lang.Object) wildcardClass58);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass62 = year61.getClass();
        java.io.InputStream inputStream63 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Value", (java.lang.Class) wildcardClass62);
        java.lang.Object obj64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]", (java.lang.Class) wildcardClass58, (java.lang.Class) wildcardClass62);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13, (java.lang.Class) wildcardClass58);
        timeSeries65.setNotify(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries65.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNull(inputStream63);
        org.junit.Assert.assertNull(obj64);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        long long5 = day3.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day3.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, year29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getTime();
        boolean boolean33 = year29.equals((java.lang.Object) fixedMillisecond31);
        java.util.Calendar calendar34 = null;
        fixedMillisecond31.peg(calendar34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-460));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond31.next();
        java.util.Calendar calendar39 = null;
        fixedMillisecond31.peg(calendar39);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        int int3 = month2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond2.getClass();
        java.io.InputStream inputStream4 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", (java.lang.Class) wildcardClass3);
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:24:35 PDT 2019]", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(inputStream4);
        org.junit.Assert.assertNull(uRL5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2019, 2958465, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        int int16 = timeSeries10.getMaximumItemCount();
        timeSeries10.setNotify(false);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, year20);
        long long22 = month21.getFirstMillisecond();
        boolean boolean24 = month21.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year25 = month21.getYear();
        boolean boolean26 = timeSeries10.equals((java.lang.Object) year25);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries30.removePropertyChangeListener(propertyChangeListener31);
        java.util.List list33 = timeSeries30.getItems();
        java.lang.Object obj34 = timeSeries30.clone();
        java.lang.Class class35 = timeSeries30.getTimePeriodClass();
        java.lang.ClassLoader classLoader36 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean26, "Time", "", class35);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(classLoader36);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
        java.util.List list10 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year13);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries11.clear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, year19);
        java.lang.String str21 = year19.toString();
        java.lang.Number number22 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, number22);
        long long24 = year19.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1.0f);
        java.lang.Class<?> wildcardClass27 = timeSeries11.getClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, year29);
        java.lang.String str31 = year29.toString();
        java.lang.Number number32 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, number32);
        timeSeriesDataItem33.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.removePropertyChangeListener(propertyChangeListener38);
        java.util.List list40 = timeSeries37.getItems();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.removePropertyChangeListener(propertyChangeListener43);
        java.util.List list45 = timeSeries42.getItems();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries37.addAndOrUpdate(timeSeries42);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, year48);
        long long50 = month49.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        int int52 = timeSeries46.getMaximumItemCount();
        java.util.List list53 = timeSeries46.getItems();
        boolean boolean54 = timeSeriesDataItem33.equals((java.lang.Object) timeSeries46);
        java.lang.Class class55 = timeSeries46.getTimePeriodClass();
        java.lang.Object obj56 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass27, class55);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2147483647 + "'", int52 == 2147483647);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertNull(obj56);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        int int7 = spreadsheetDate3.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean15 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int16 = spreadsheetDate3.getYYYY();
//        int int17 = spreadsheetDate3.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        boolean boolean19 = day0.equals((java.lang.Object) spreadsheetDate3);
//        long long20 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getMonth();
        int int5 = day3.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year6 = month2.getYear();
        int int7 = year6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.util.List list12 = timeSeries9.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener15);
        java.util.List list17 = timeSeries14.getItems();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, year20);
        long long22 = month21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
        int int24 = timeSeries18.getMaximumItemCount();
        timeSeries18.setNotify(false);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean33 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int34 = spreadsheetDate30.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean39 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean42 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int43 = spreadsheetDate30.getYYYY();
        int int44 = spreadsheetDate30.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean46 = day27.equals((java.lang.Object) spreadsheetDate30);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day47);
        boolean boolean49 = year6.equals((java.lang.Object) timeSeries18);
        java.lang.Class class50 = timeSeries18.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(class50);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day3.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        int int10 = day9.getMonth();
        int int11 = day9.getYear();
        java.util.Date date12 = day9.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date12, timeZone16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date1, timeZone16);
        int int20 = year19.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1905);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.lang.String str4 = year3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean18 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate15.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean24 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean27 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate15.getYYYY();
        int int29 = spreadsheetDate15.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean34 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int35 = spreadsheetDate31.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean40 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean43 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate39, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate31.getYYYY();
        boolean boolean45 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean46 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean47 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        try {
            timeSeries1.setMaximumItemCount((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            boolean boolean12 = spreadsheetDate3.isInRange(serialDate5, (org.jfree.data.time.SerialDate) spreadsheetDate9, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        int int11 = month6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.previous();
        long long13 = month6.getSerialIndex();
        long long14 = month6.getLastMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month6.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24229L + "'", long13 == 24229L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1549007999999L + "'", long14 == 1549007999999L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        int int6 = day4.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(5, 13, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj3 = timeSeries2.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean8 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int9 = spreadsheetDate5.toSerial();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries2, (java.lang.Object) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(12, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean16 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean22 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean25 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate13.getYYYY();
        int int27 = spreadsheetDate13.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean32 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int33 = spreadsheetDate29.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean38 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean41 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        int int42 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean47 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean49 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        spreadsheetDate29.setDescription("hi!");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener6);
        java.util.List list8 = timeSeries5.getItems();
        int int9 = timeSeries5.getMaximumItemCount();
        java.lang.String str10 = timeSeries5.getDescription();
        java.lang.Class class11 = timeSeries5.getTimePeriodClass();
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class11);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class11);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class11);
        java.lang.ClassLoader classLoader15 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class11);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("9-January-1900", class11);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(inputStream12);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNotNull(uRL14);
        org.junit.Assert.assertNotNull(classLoader15);
        org.junit.Assert.assertNull(uRL16);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
        int int7 = spreadsheetDate1.getYYYY();
        java.util.Date date8 = spreadsheetDate1.toDate();
        int int9 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str3 = fixedMillisecond2.toString();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 100.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        timeSeries1.delete(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:25:26 PDT 2019" + "'", str3.equals("Thu Jun 13 08:25:26 PDT 2019"));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.toSerial();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries7, (java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean20 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean29 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate17.getYYYY();
        int int31 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean36 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate33.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean42 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean45 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean47 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int48 = spreadsheetDate10.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
        java.util.List list10 = timeSeries7.getItems();
        int int11 = timeSeries7.getMaximumItemCount();
        java.lang.String str12 = timeSeries7.getDescription();
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class13);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class13);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class13);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Value", (java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class13, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass27 = year26.getClass();
        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Value", (java.lang.Class) wildcardClass27);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560439477730L, "Following", "Thu Jun 13 08:24:49 PDT 2019", (java.lang.Class) wildcardClass27);
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 2019", class13, (java.lang.Class) wildcardClass27);
        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass27);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNotNull(uRL16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(inputStream20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(inputStream28);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertNull(uRL31);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.isOnOrAfter(serialDate13);
        boolean boolean16 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) (byte) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean21 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int22 = spreadsheetDate18.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean27 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean30 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate18.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean36 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean37 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int38 = spreadsheetDate33.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean43 = spreadsheetDate40.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate40.toSerial();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj47 = timeSeries46.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean52 = spreadsheetDate49.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int53 = spreadsheetDate49.toSerial();
        boolean boolean54 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries46, (java.lang.Object) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean59 = spreadsheetDate56.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate56.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean65 = spreadsheetDate62.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean68 = spreadsheetDate56.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int69 = spreadsheetDate56.getYYYY();
        int int70 = spreadsheetDate56.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean75 = spreadsheetDate72.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        int int76 = spreadsheetDate72.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean81 = spreadsheetDate78.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean84 = spreadsheetDate72.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate80, (org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean85 = spreadsheetDate56.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate72);
        boolean boolean86 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate49, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean87 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        java.lang.String str88 = spreadsheetDate56.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate90 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate93 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate93);
        boolean boolean95 = spreadsheetDate90.isOnOrAfter(serialDate94);
        boolean boolean96 = spreadsheetDate56.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate90);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1900 + "'", int69 == 1900);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1900 + "'", int70 == 1900);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 10 + "'", int76 == 10);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem(regularTimePeriod3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        long long12 = month11.getFirstMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month11.next();
        java.lang.Number number17 = timeSeries1.getValue(regularTimePeriod16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24229L + "'", long15 == 24229L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.isOnOrAfter(serialDate13);
        boolean boolean16 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) (byte) 0);
        java.util.Date date17 = spreadsheetDate9.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.isOnOrAfter(serialDate13);
        boolean boolean16 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) (byte) 0);
        java.lang.String str17 = spreadsheetDate2.toString();
        try {
            org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate2.getFollowingDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-January-1900" + "'", str17.equals("9-January-1900"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean15 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = timeSeries1.equals((java.lang.Object) boolean15);
        boolean boolean17 = timeSeries1.isEmpty();
        timeSeries1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, year22);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        java.lang.String str2 = year0.toString();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        int int4 = day3.getMonth();
//        int int5 = day3.getYear();
//        java.util.Date date6 = day3.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date6, timeZone10);
//        int int13 = day12.getDayOfMonth();
//        java.util.Calendar calendar14 = null;
//        try {
//            day12.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str2 = timeSeries1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Following");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getTime();
        boolean boolean5 = year1.equals((java.lang.Object) fixedMillisecond3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        long long7 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.Year year6 = month2.getYear();
        int int7 = year6.getYear();
        long long8 = year6.getMiddleMillisecond();
        java.lang.Object obj9 = null;
        int int10 = year6.compareTo(obj9);
        java.util.Calendar calendar11 = null;
        try {
            year6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        long long8 = day3.getSerialIndex();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Thu Jun 13 08:25:29 PDT 2019" + "'", str1.equals("Thu Jun 13 08:25:29 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439529792L + "'", long3 == 1560439529792L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439529792L + "'", long4 == 1560439529792L);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
//        java.lang.Object obj8 = timeSeries1.clone();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertNotNull(obj8);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.util.Date date5 = year1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        int int4 = year1.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate1.getYYYY();
        int int15 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean20 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean29 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate17.getYYYY();
        int int31 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.toSerial();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries7, (java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean20 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean29 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate17.getYYYY();
        int int31 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean36 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate33.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean42 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean45 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean47 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date48 = spreadsheetDate10.toDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(date48);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        int int11 = month6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate14.isOnOrAfter(serialDate18);
        boolean boolean20 = month6.equals((java.lang.Object) boolean19);
        long long21 = month6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24229L + "'", long21 == 24229L);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        long long5 = fixedMillisecond4.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439530182L + "'", long5 == 1560439530182L);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        int int12 = month11.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day17);
        long long20 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439530263L + "'", long3 == 1560439530263L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439530263L + "'", long5 == 1560439530263L);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year10);
        int int12 = month11.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean34 = spreadsheetDate29.isOnOrAfter(serialDate33);
        boolean boolean36 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate29, (int) (byte) 0);
        java.util.Date date37 = spreadsheetDate29.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries41.removePropertyChangeListener(propertyChangeListener42);
        java.util.List list44 = timeSeries41.getItems();
        int int45 = timeSeries41.getMaximumItemCount();
        java.lang.String str46 = timeSeries41.getDescription();
        int int47 = fixedMillisecond39.compareTo((java.lang.Object) str46);
        long long48 = fixedMillisecond39.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date50 = fixedMillisecond49.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date52 = fixedMillisecond51.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date52, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date50, timeZone54);
        int int57 = year56.getYear();
        java.util.Date date58 = year56.getEnd();
        java.lang.Class<?> wildcardClass59 = date58.getClass();
        boolean boolean60 = fixedMillisecond39.equals((java.lang.Object) date58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date62 = fixedMillisecond61.getTime();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62);
        int int65 = day64.getMonth();
        int int66 = day64.getYear();
        java.util.Date date67 = day64.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date69 = fixedMillisecond68.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(date69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date69, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date67, timeZone71);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date58, timeZone71);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date37, timeZone71);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year75, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2147483647 + "'", int45 == 2147483647);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone71);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        int int11 = month6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.previous();
        long long13 = month6.getSerialIndex();
        long long14 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month6.next();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24229L + "'", long13 == 24229L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1549007999999L + "'", long14 == 1549007999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        int int4 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.Comparable comparable10 = timeSeries6.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setDescription("Thu Jun 13 08:24:49 PDT 2019");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (short) 0 + "'", comparable3.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 0 + "'", comparable10.equals((short) 0));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate8 = null;
        try {
            int int9 = spreadsheetDate2.compare(serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        long long4 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.lang.String str6 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, 0.0d);
        java.lang.String str19 = month13.toString();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, year23);
        java.lang.String str25 = year23.toString();
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, number26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass29 = year28.getClass();
        boolean boolean30 = timeSeriesDataItem27.equals((java.lang.Object) wildcardClass29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "org.jfree.data.general.SeriesException: ", "", (java.lang.Class) wildcardClass29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean35 = timeSeries31.equals((java.lang.Object) day34);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener36);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "January 2019" + "'", str19.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        timeSeries1.setMaximumItemAge((long) 0);
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year11);
//        long long13 = month12.getFirstMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month12);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day21, (double) 100.0f, true);
//        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, year27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        boolean boolean31 = year27.equals((java.lang.Object) fixedMillisecond29);
//        java.lang.Class<?> wildcardClass32 = fixedMillisecond29.getClass();
//        long long33 = fixedMillisecond29.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj36 = timeSeries35.clone();
//        timeSeries35.setMaximumItemAge((long) 0);
//        timeSeries35.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries41.removePropertyChangeListener(propertyChangeListener42);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, year45);
//        long long47 = month46.getFirstMillisecond();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) month46);
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries41.removePropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date52 = fixedMillisecond51.getTime();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date52);
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) day55, (double) 100.0f, true);
//        int int59 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
//        int int60 = fixedMillisecond29.compareTo((java.lang.Object) timeSeries35);
//        boolean boolean61 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) day21, (java.lang.Object) timeSeries35);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560439531446L + "'", long33 == 1560439531446L);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean11 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean14 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean26 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = spreadsheetDate23.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean32 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean35 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate23.getYYYY();
        int int37 = spreadsheetDate23.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean42 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int43 = spreadsheetDate39.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean48 = spreadsheetDate45.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean51 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int53 = spreadsheetDate39.getMonth();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean55 = spreadsheetDate2.isInRange(serialDate20, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int56 = spreadsheetDate2.getMonth();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number4);
        timeSeriesDataItem5.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.util.List list12 = timeSeries9.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener15);
        java.util.List list17 = timeSeries14.getItems();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, year20);
        long long22 = month21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
        int int24 = timeSeries18.getMaximumItemCount();
        java.util.List list25 = timeSeries18.getItems();
        boolean boolean26 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries18);
        java.lang.Object obj27 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getNearestDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439532793L + "'", long3 == 1560439532793L);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        int int16 = timeSeries10.getMaximumItemCount();
        timeSeries10.setNotify(false);
        java.util.List list19 = timeSeries10.getItems();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries1.getDescription();
        timeSeries1.setNotify(false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.List list19 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.addAndOrUpdate(timeSeries16);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge((long) 100);
        java.lang.String str28 = timeSeries1.getRangeDescription();
        java.lang.Comparable comparable29 = timeSeries1.getKey();
        timeSeries1.setRangeDescription("ClassContext");
        timeSeries1.removeAgedItems(0L, true);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        boolean boolean37 = month35.equals((java.lang.Object) "Thu Jun 13 08:24:37 PDT 2019");
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 1560439499812L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (short) 0 + "'", comparable29.equals((short) 0));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean10 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj16 = timeSeries15.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean21 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int22 = spreadsheetDate18.toSerial();
        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries15, (java.lang.Object) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener27);
        java.util.List list29 = timeSeries26.getItems();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.removePropertyChangeListener(propertyChangeListener32);
        java.util.List list34 = timeSeries31.getItems();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries26.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 1, year37);
        long long39 = month38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month38, 0.0d);
        timeSeriesDataItem43.setValue((java.lang.Number) (short) 0);
        try {
            int int46 = spreadsheetDate1.compareTo((java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries1.getDescription();
        java.lang.String str8 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1, timeZone5);
        int int8 = year7.getYear();
        java.util.Date date9 = year7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11, timeZone15);
        int int18 = year17.getYear();
        java.util.Date date19 = year17.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getTime();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
        int int33 = day32.getMonth();
        int int34 = day32.getYear();
        java.util.Date date35 = day32.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date35, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date24, timeZone39);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date22, timeZone39);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date19, timeZone39);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date9, timeZone39);
        java.util.Calendar calendar46 = null;
        try {
            long long47 = year45.getFirstMillisecond(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone39);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        int int11 = month6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.previous();
        long long13 = month6.getSerialIndex();
        long long14 = month6.getLastMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            month6.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24229L + "'", long13 == 24229L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1549007999999L + "'", long14 == 1549007999999L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("9-January-1900");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, 1900, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        long long10 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        long long13 = fixedMillisecond12.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        fixedMillisecond12.peg(calendar14);
        java.util.Calendar calendar16 = null;
        fixedMillisecond12.peg(calendar16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener20);
        java.util.List list22 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.removePropertyChangeListener(propertyChangeListener25);
        java.util.List list27 = timeSeries24.getItems();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, year30);
        long long32 = month31.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        java.lang.String str34 = month31.toString();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month31);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "January 2019" + "'", str34.equals("January 2019"));
        org.junit.Assert.assertNotNull(timeSeries35);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.toSerial();
        int int6 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.util.Date date5 = year1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date8, timeZone12);
        int int15 = year14.getYear();
        java.util.Date date16 = year14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date18, timeZone22);
        int int25 = year24.getYear();
        java.util.Date date26 = year24.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getTime();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37);
        int int40 = day39.getMonth();
        int int41 = day39.getYear();
        java.util.Date date42 = day39.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date44 = fixedMillisecond43.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date42, timeZone46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date31, timeZone46);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date29, timeZone46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date26, timeZone46);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date16, timeZone46);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date5, timeZone46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(30, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.util.List list7 = timeSeries4.getItems();
        int int8 = timeSeries4.getMaximumItemCount();
        java.lang.String str9 = timeSeries4.getDescription();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemCount(2019);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries4);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, year15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, year25);
        long long27 = month26.getFirstMillisecond();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.previous();
        long long30 = month26.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month26.next();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries4.createCopy(regularTimePeriod19, regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24229L + "'", long30 == 24229L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeSeries32);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month6.next();
        java.util.Calendar calendar12 = null;
        try {
            month6.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24229L + "'", long10 == 24229L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.isOnOrAfter(serialDate13);
        boolean boolean16 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj20 = timeSeries19.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean25 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate22.toSerial();
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries19, (java.lang.Object) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears(12, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean33 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int34 = spreadsheetDate30.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean39 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean42 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int43 = spreadsheetDate30.getYYYY();
        int int44 = spreadsheetDate30.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean49 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int50 = spreadsheetDate46.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean55 = spreadsheetDate52.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean58 = spreadsheetDate46.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int59 = spreadsheetDate46.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean64 = spreadsheetDate61.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean65 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean66 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        boolean boolean71 = spreadsheetDate30.isOnOrBefore(serialDate70);
        boolean boolean72 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int73 = spreadsheetDate2.getYYYY();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1900 + "'", int59 == 1900);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1900 + "'", int73 == 1900);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        long long7 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month2.previous();
        int int11 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1547668799999L + "'", long7 == 1547668799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean11 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate8.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean17 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean20 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate8.getYYYY();
        int int22 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean24 = day5.equals((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean27 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.Object obj28 = null;
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) spreadsheetDate8, obj28);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Calendar calendar14 = null;
        fixedMillisecond10.peg(calendar14);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.Class<?> wildcardClass8 = serialDate7.getClass();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Time");
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1905);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, year5);
        long long7 = month6.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year9 = month6.getYear();
        long long10 = year9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.lang.String str12 = year9.toString();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getMonth();
        int int5 = day3.getYear();
        int int6 = day3.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long3 = month2.getFirstMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        long long7 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 9);
        int int11 = timeSeriesDataItem9.compareTo((java.lang.Object) 'a');
        java.lang.Object obj12 = timeSeriesDataItem9.clone();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Object obj14 = timeSeriesDataItem9.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1547668799999L + "'", long7 == 1547668799999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int4 = spreadsheetDate3.getDayOfMonth();
//        boolean boolean5 = fixedMillisecond0.equals((java.lang.Object) spreadsheetDate3);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getMiddleMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560439539157L + "'", long7 == 1560439539157L);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.Object obj2 = timeSeries1.clone();
//        timeSeries1.setMaximumItemAge((long) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener5);
//        timeSeries1.setNotify(false);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year12);
//        int int14 = month13.getYearValue();
//        int int15 = month13.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, year21);
//        java.lang.String str23 = year21.toString();
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, number24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        java.lang.Class<?> wildcardClass27 = year26.getClass();
//        boolean boolean28 = timeSeriesDataItem25.equals((java.lang.Object) wildcardClass27);
//        try {
//            timeSeries19.add(timeSeriesDataItem25);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560439539185L + "'", long18 == 1560439539185L);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean6 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean9 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.getYYYY();
        int int12 = spreadsheetDate8.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((-5542), (org.jfree.data.time.SerialDate) spreadsheetDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1905 + "'", int11 == 1905);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1905 + "'", int12 == 1905);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries1.isEmpty();
        long long10 = timeSeries1.getMaximumItemAge();
        long long11 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
//        java.util.List list4 = timeSeries1.getItems();
//        int int5 = timeSeries1.getMaximumItemCount();
//        java.lang.String str6 = timeSeries1.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond7);
//        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getFirstMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond7.peg(calendar12);
//        long long14 = fixedMillisecond7.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(list4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560439541818L + "'", long11 == 1560439541818L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560439541818L + "'", long14 == 1560439541818L);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, year17);
        long long19 = month18.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month18);
        boolean boolean21 = day10.equals((java.lang.Object) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month18.previous();
        java.lang.String str23 = month18.toString();
        int int24 = month18.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = spreadsheetDate33.isOnOrAfter(serialDate37);
        int int39 = spreadsheetDate33.getYYYY();
        java.util.Date date40 = spreadsheetDate33.toDate();
        boolean boolean41 = timeSeries1.equals((java.lang.Object) spreadsheetDate33);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "January 2019" + "'", str23.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener20);
        java.util.List list22 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.removePropertyChangeListener(propertyChangeListener25);
        java.util.List list27 = timeSeries24.getItems();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, year30);
        long long32 = month31.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean5 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean13 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean19 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean22 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate10.getYYYY();
        int int24 = spreadsheetDate10.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean30 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean36 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean39 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean40 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean41 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        int int49 = timeSeries45.getMaximumItemCount();
        java.lang.String str50 = timeSeries45.getDescription();
        int int51 = fixedMillisecond43.compareTo((java.lang.Object) str50);
        java.util.Calendar calendar52 = null;
        fixedMillisecond43.peg(calendar52);
        java.util.Date date54 = fixedMillisecond43.getTime();
        boolean boolean55 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) spreadsheetDate2, (java.lang.Object) fixedMillisecond43);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2147483647 + "'", int49 == 2147483647);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) 0);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        long long13 = month12.getFirstMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month12);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day21, (double) 100.0f, true);
        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day21.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }
}

