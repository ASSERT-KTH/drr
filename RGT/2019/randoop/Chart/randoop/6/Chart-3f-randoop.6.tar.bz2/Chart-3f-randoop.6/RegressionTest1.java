import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        timeSeries4.fireSeriesChanged();
        timeSeries4.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.addAndOrUpdate(timeSeries4);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month13 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year14 = month13.getYear();
        java.lang.Number number15 = null;
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year14, number15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries18.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.next();
        long long27 = fixedMillisecond23.getFirstMillisecond();
        java.lang.Number number28 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond23.next();
        boolean boolean32 = year14.equals((java.lang.Object) regularTimePeriod31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, year14);
        long long34 = year14.getSerialIndex();
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(month13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1969L + "'", long34 == 1969L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) ' ');
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries25.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection32 = timeSeries31.getTimePeriods();
        timeSeries31.fireSeriesChanged();
        timeSeries31.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries29.addAndOrUpdate(timeSeries31);
        boolean boolean37 = timeSeries25.equals((java.lang.Object) timeSeries31);
        boolean boolean38 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date46 = fixedMillisecond45.getStart();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        java.util.Date date48 = year47.getEnd();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 100);
        long long54 = fixedMillisecond51.getFirstMillisecond();
        try {
            org.jfree.data.time.TimeSeries timeSeries55 = timeSeries25.createCopy(regularTimePeriod39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 28799999L + "'", long54 == 28799999L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        long long7 = year3.getFirstMillisecond();
        int int8 = year3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) 1560182986783L);
        java.util.Calendar calendar11 = null;
        try {
            year3.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        boolean boolean13 = fixedMillisecond6.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, (java.lang.Number) 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.getNotify();
        boolean boolean11 = timeSeries1.getNotify();
        java.lang.String str12 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        int int31 = timeSeries1.getItemCount();
        timeSeries1.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=a]");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        timeSeries8.setRangeDescription("hi!");
        java.util.Collection collection14 = timeSeries8.getTimePeriods();
        boolean boolean15 = year3.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries8.addOrUpdate(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        timeSeries12.setRangeDescription("hi!");
        java.util.Collection collection18 = timeSeries12.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries12);
        java.lang.String str20 = timeSeries1.getDescription();
        boolean boolean21 = timeSeries1.getNotify();
        java.lang.Object obj22 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 'a' + "'", obj5.equals('a'));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        int int16 = day15.getYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond19.getMiddleMillisecond();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        long long25 = fixedMillisecond19.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        timeSeries12.setRangeDescription("hi!");
        java.util.Collection collection18 = timeSeries12.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries12);
        long long20 = timeSeries12.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond3.next();
        long long7 = fixedMillisecond3.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond3.getLastMillisecond(calendar8);
        boolean boolean10 = month1.equals((java.lang.Object) long9);
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int21 = year4.compareTo((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(11, year4);
        long long23 = year4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31507200000L) + "'", long23 == (-31507200000L));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        double double4 = timeSeries1.getMaxY();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date8 = fixedMillisecond7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 11);
        java.lang.Object obj12 = timeSeriesDataItem11.clone();
        timeSeriesDataItem11.setValue((java.lang.Number) (-1.0f));
        timeSeries1.add(timeSeriesDataItem11, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(28799999L);
        long long19 = fixedMillisecond18.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        seriesChangeEvent23.setSummary(seriesChangeInfo24);
        boolean boolean26 = timeSeries21.equals((java.lang.Object) seriesChangeInfo24);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
        long long34 = fixedMillisecond30.getFirstMillisecond();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond30.previous();
        boolean boolean38 = fixedMillisecond18.equals((java.lang.Object) fixedMillisecond30);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.util.List list14 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
        timeSeries7.clear();
        boolean boolean19 = timeSeries7.getNotify();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        boolean boolean16 = timeSeries8.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener17);
        timeSeries8.setRangeDescription("Time");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date23 = fixedMillisecond22.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        long long25 = day24.getSerialIndex();
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (-2649600001L));
        boolean boolean28 = timeSeries8.getNotify();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 25568L + "'", long25 == 25568L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-9999), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        timeSeries1.setNotify(true);
        boolean boolean10 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.util.List list15 = timeSeries1.getItems();
        timeSeries1.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date20 = fixedMillisecond19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, regularTimePeriod25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.util.List list15 = timeSeries1.getItems();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries17 = null;
        try {
            java.util.Collection collection18 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries1.addChangeListener(seriesChangeListener31);
        java.lang.String str33 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        timeSeriesDataItem9.setValue((java.lang.Number) 100L);
        java.lang.Number number12 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100L + "'", number12.equals(100L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.util.List list14 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date20 = year19.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183018824L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries7.removeChangeListener(seriesChangeListener23);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 11);
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        timeSeriesDataItem13.setValue((java.lang.Number) (-1.0f));
        int int17 = month7.compareTo((java.lang.Object) (-1.0f));
        java.lang.String str18 = month7.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "March 1969" + "'", str18.equals("March 1969"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) ' ');
        java.lang.Object obj24 = timeSeriesDataItem23.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("December 1969");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str12 = timePeriodFormatException10.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        timeSeries7.removeAgedItems(false);
        boolean boolean14 = timeSeries7.getNotify();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date5 = fixedMillisecond4.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        timeSeries4.setDescription("1969");
        java.lang.String str7 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("December 1969");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond24.getMiddleMillisecond(calendar27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond24.getLastMillisecond(calendar30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection34 = timeSeries33.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond38.next();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        java.lang.Number number43 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection48 = timeSeries47.getTimePeriods();
        timeSeries47.fireSeriesChanged();
        timeSeries47.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries45.addAndOrUpdate(timeSeries47);
        boolean boolean53 = fixedMillisecond38.equals((java.lang.Object) timeSeries45);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection56 = timeSeries55.getTimePeriods();
        timeSeries55.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond60.getLastMillisecond(calendar61);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond60.getMiddleMillisecond(calendar63);
        java.util.Calendar calendar65 = null;
        fixedMillisecond60.peg(calendar65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (double) (short) 100);
        timeSeries55.add(timeSeriesDataItem68);
        timeSeries45.add(timeSeriesDataItem68, true);
        int int72 = fixedMillisecond24.compareTo((java.lang.Object) timeSeries45);
        java.util.Date date73 = fixedMillisecond24.getTime();
        java.util.TimeZone timeZone74 = null;
        java.util.Locale locale75 = null;
        try {
            org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date73, timeZone74, locale75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 97L + "'", long40 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 97L + "'", long62 == 97L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 97L + "'", long64 == 97L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        timeSeries4.setDescription("1969");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date13 = fixedMillisecond12.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.Date date15 = year14.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate(regularTimePeriod20, (java.lang.Number) (-2649600000L));
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection25 = timeSeries24.getTimePeriods();
        timeSeries24.fireSeriesChanged();
        timeSeries24.setMaximumItemAge((long) ' ');
        timeSeries24.removeAgedItems(false);
        boolean boolean31 = timeSeries24.getNotify();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection34 = timeSeries33.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries33.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo42 = null;
        seriesChangeEvent41.setSummary(seriesChangeInfo42);
        boolean boolean44 = timeSeries39.equals((java.lang.Object) seriesChangeInfo42);
        java.lang.Comparable comparable45 = timeSeries39.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getLastMillisecond(calendar48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (short) 0);
        java.util.Date date52 = fixedMillisecond47.getTime();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getLastMillisecond(calendar57);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond56.getMiddleMillisecond(calendar59);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month54, (double) 1L);
        java.util.Collection collection64 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        try {
            org.jfree.data.time.TimeSeries timeSeries67 = timeSeries4.createCopy((int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + (short) -1 + "'", comparable45.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 97L + "'", long58 == 97L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 97L + "'", long60 == 97L);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(collection64);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        int int10 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemCount((int) (short) 0);
        java.lang.Object obj13 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date8, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(true);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.Date date12 = year11.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 31, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date23 = fixedMillisecond22.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = null;
        seriesChangeEvent29.setSummary(seriesChangeInfo30);
        boolean boolean32 = timeSeries27.equals((java.lang.Object) seriesChangeInfo30);
        java.lang.Comparable comparable33 = timeSeries27.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) (short) 0);
        java.util.Date date40 = fixedMillisecond35.getTime();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        int int42 = month41.getMonth();
        java.lang.String str43 = month41.toString();
        int int44 = month41.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) month41);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) -1 + "'", comparable33.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "December 1969" + "'", str43.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1969 + "'", int44 == 1969);
        org.junit.Assert.assertNotNull(timeSeries45);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        long long8 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.fireSeriesChanged();
        timeSeries16.setMaximumItemAge((long) ' ');
        timeSeries16.removeAgedItems(false);
        timeSeries16.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 11);
        timeSeries16.add(timeSeriesDataItem29);
        java.lang.Number number31 = timeSeriesDataItem29.getValue();
        timeSeries1.add(timeSeriesDataItem29);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection35 = timeSeries34.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries34.removeChangeListener(seriesChangeListener36);
        timeSeries34.removeAgedItems((long) 0, true);
        boolean boolean41 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date46 = fixedMillisecond45.getStart();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        java.util.Date date48 = year47.getEnd();
        long long49 = year47.getFirstMillisecond();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(3, year47);
        long long51 = month50.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries53.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection60 = timeSeries59.getTimePeriods();
        timeSeries59.fireSeriesChanged();
        timeSeries59.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries57.addAndOrUpdate(timeSeries59);
        boolean boolean65 = timeSeries53.equals((java.lang.Object) timeSeries59);
        int int66 = month50.compareTo((java.lang.Object) boolean65);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month50, (double) 1560183028224L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 11 + "'", number31.equals(11));
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-31507200000L) + "'", long49 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-25070400001L) + "'", long51 == (-25070400001L));
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries17.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
        long long26 = fixedMillisecond22.getFirstMillisecond();
        java.lang.Number number27 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond22.next();
        boolean boolean31 = year13.equals((java.lang.Object) regularTimePeriod30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod30, (double) 1560182986393L);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        timeSeries10.fireSeriesChanged();
        timeSeries10.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries8.addAndOrUpdate(timeSeries10);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Month month19 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year20 = month19.getYear();
        java.lang.Number number21 = null;
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year20, number21);
        boolean boolean23 = timeSeries15.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener24);
        timeSeries15.setRangeDescription("Time");
        int int28 = year3.compareTo((java.lang.Object) timeSeries15);
        timeSeries15.setNotify(true);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(month19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date7 = fixedMillisecond6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Date date9 = year8.getEnd();
        long long10 = year8.getFirstMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(3, year8);
        long long12 = month11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182976350L);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeriesDataItem14.setSelected(true);
        timeSeries1.add(timeSeriesDataItem14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date22 = fixedMillisecond21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.Date date24 = year23.getEnd();
        long long25 = year23.getFirstMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(3, year23);
        long long27 = month26.getMiddleMillisecond();
        int int28 = month26.getYearValue();
        int int29 = month26.getYearValue();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date36 = fixedMillisecond35.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        java.util.Date date38 = year37.getEnd();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date38, timeZone39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date38);
        boolean boolean42 = month26.equals((java.lang.Object) date38);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month26, (double) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period March 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-25070400001L) + "'", long12 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1560182976350L + "'", number15.equals(1560182976350L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31507200000L) + "'", long25 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-25070400001L) + "'", long27 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        timeSeries12.setRangeDescription("hi!");
        java.util.Collection collection18 = timeSeries12.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries12);
        try {
            timeSeries1.delete(0, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("December 1969");
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 'a');
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.util.List list15 = timeSeries1.getItems();
        timeSeries1.clear();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        timeSeries1.removeAgedItems(0L, false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        try {
            java.lang.Number number13 = timeSeries1.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(class11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) ' ', seriesChangeInfo6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent7.getSummary();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(seriesChangeInfo10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        java.lang.Object obj9 = timeSeries1.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries1.getMaximumItemCount();
        double double13 = timeSeries1.getMaxY();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        long long7 = day5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        timeSeries10.fireSeriesChanged();
        timeSeries10.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries8.addAndOrUpdate(timeSeries10);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Month month19 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year20 = month19.getYear();
        java.lang.Number number21 = null;
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year20, number21);
        boolean boolean23 = timeSeries15.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener24);
        timeSeries15.setRangeDescription("Time");
        int int28 = year3.compareTo((java.lang.Object) timeSeries15);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year3.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(month19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.TimeZone timeZone23 = null;
        java.util.Locale locale24 = null;
        try {
            org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21, timeZone23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod16);
        java.lang.Object obj18 = seriesChangeEvent17.getSource();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        double double10 = timeSeries7.getMaxY();
        boolean boolean11 = year3.equals((java.lang.Object) double10);
        int int12 = year3.getYear();
        java.lang.String str13 = year3.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year3, "org.jfree.data.event.SeriesChangeEvent[source=100.0]", "10");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems((long) 8, true);
        java.lang.String str6 = timeSeries1.getDescription();
        double double7 = timeSeries1.getMinY();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.lang.Object obj3 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) (byte) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        java.lang.Class<?> wildcardClass9 = timeSeries1.getClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.Date date18 = year17.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date18);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond28.getLastMillisecond(calendar33);
        int int36 = fixedMillisecond28.compareTo((java.lang.Object) 0.0f);
        java.util.Date date37 = fixedMillisecond28.getStart();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date37, timeZone38);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo19);
        boolean boolean21 = timeSeries16.equals((java.lang.Object) seriesChangeInfo19);
        java.lang.Comparable comparable22 = timeSeries16.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (short) 0);
        java.util.Date date29 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond33.getMiddleMillisecond(calendar36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month31, (double) 1L);
        java.lang.Class class41 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) -1 + "'", comparable22.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 97L + "'", long35 == 97L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(class41);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 11);
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        timeSeriesDataItem13.setValue((java.lang.Number) (-1.0f));
        int int17 = month7.compareTo((java.lang.Object) (-1.0f));
        long long18 = month7.getLastMillisecond();
        long long19 = month7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-23731200001L) + "'", long18 == (-23731200001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-26409600000L) + "'", long19 == (-26409600000L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        java.lang.Number number33 = timeSeries1.getValue(0);
        try {
            java.lang.Number number35 = timeSeries1.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.560182972264E12d + "'", number33.equals(1.560182972264E12d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        boolean boolean3 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        long long14 = month12.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28799999L + "'", long14 == 28799999L);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection8 = timeSeries7.getTimePeriods();
//        timeSeries7.fireSeriesChanged();
//        timeSeries7.setMaximumItemAge((long) ' ');
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
//        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
//        java.util.List list14 = timeSeries7.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        long long17 = fixedMillisecond15.getMiddleMillisecond();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (byte) -1, true);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection23 = timeSeries22.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries22.removeChangeListener(seriesChangeListener24);
//        boolean boolean26 = timeSeries22.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = null;
//        seriesChangeEvent30.setSummary(seriesChangeInfo31);
//        boolean boolean33 = timeSeries28.equals((java.lang.Object) seriesChangeInfo31);
//        java.lang.Comparable comparable34 = timeSeries28.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getLastMillisecond(calendar37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) (short) 0);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond45.getLastMillisecond(calendar46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getMiddleMillisecond(calendar48);
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month43, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 1560183018824L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560183039373L + "'", long16 == 1560183039373L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560183039373L + "'", long17 == 1560183039373L);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (short) -1 + "'", comparable34.equals((short) -1));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 97L + "'", long47 == 97L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.List list14 = timeSeries1.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond19.getMiddleMillisecond();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.lang.Comparable comparable25 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (short) -1 + "'", comparable25.equals((short) -1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        int int12 = timeSeries1.getIndex(regularTimePeriod11);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
//        long long12 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        timeSeries1.setDescription("March 1969");
//        timeSeries1.setDescription("June 2019");
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
//        seriesChangeEvent23.setSummary(seriesChangeInfo24);
//        boolean boolean26 = timeSeries21.equals((java.lang.Object) seriesChangeInfo24);
//        java.lang.Comparable comparable27 = timeSeries21.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getLastMillisecond(calendar30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) (short) 0);
//        java.util.Date date34 = fixedMillisecond29.getTime();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        int int36 = month35.getMonth();
//        java.lang.String str37 = month35.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getMiddleMillisecond();
//        boolean boolean40 = month35.equals((java.lang.Object) fixedMillisecond38);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection45 = timeSeries44.getTimePeriods();
//        timeSeries44.fireSeriesChanged();
//        timeSeries44.setMaximumItemAge((long) ' ');
//        timeSeries44.removeAgedItems(false);
//        timeSeries44.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date54 = fixedMillisecond53.getStart();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 11);
//        timeSeries44.add(timeSeriesDataItem57);
//        java.lang.String str59 = timeSeries44.getDomainDescription();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries60 = timeSeries1.addAndOrUpdate(timeSeries44);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (short) -1 + "'", comparable27.equals((short) -1));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "December 1969" + "'", str37.equals("December 1969"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183039721L + "'", long39 == 1560183039721L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Time" + "'", str59.equals("Time"));
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1, false);
        boolean boolean16 = year1.equals((java.lang.Object) fixedMillisecond12);
        long long17 = year1.getSerialIndex();
        long long18 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800001L) + "'", long18 == (-62104204800001L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        long long9 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getMiddleMillisecond(calendar10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        boolean boolean13 = fixedMillisecond6.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond6.next();
        long long15 = fixedMillisecond6.getFirstMillisecond();
        long long16 = fixedMillisecond6.getSerialIndex();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        long long17 = year15.getLastMillisecond();
        long long18 = year15.getFirstMillisecond();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year15.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62104204800001L) + "'", long17 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135740800000L) + "'", long18 == (-62135740800000L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        java.lang.String str35 = timeSeries15.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries15.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean7 = year4.equals((java.lang.Object) 'a');
        java.lang.String str8 = year4.toString();
        java.lang.String str9 = year4.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year4);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        java.lang.String str10 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) ' ');
        long long24 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year3.previous();
        long long26 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31507200000L) + "'", long24 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond5.getLastMillisecond(calendar10);
        int int13 = fixedMillisecond5.compareTo((java.lang.Object) 0.0f);
        java.util.Date date14 = fixedMillisecond5.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.lang.Number number16 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        long long4 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60526368000000L) + "'", long4 == (-60526368000000L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.Year year8 = month7.getYear();
        java.lang.String str9 = month7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.previous();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month7.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "March 1969" + "'", str9.equals("March 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year23.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1);
//        timeSeries2.setMaximumItemAge((long) 3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183042466L + "'", long1 == 1560183042466L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setRangeDescription("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        boolean boolean15 = timeSeries10.equals((java.lang.Object) seriesChangeInfo13);
        java.lang.Comparable comparable16 = timeSeries10.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 0);
        java.util.Date date23 = fixedMillisecond18.getTime();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date23, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date23);
        long long28 = month27.getFirstMillisecond();
        int int29 = month27.getYearValue();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) -1 + "'", comparable16.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2649600000L) + "'", long28 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) ' ');
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries25.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection32 = timeSeries31.getTimePeriods();
        timeSeries31.fireSeriesChanged();
        timeSeries31.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries29.addAndOrUpdate(timeSeries31);
        boolean boolean37 = timeSeries25.equals((java.lang.Object) timeSeries31);
        boolean boolean38 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries25);
        timeSeries25.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        java.lang.Class<?> wildcardClass9 = timeSeries1.getClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.Date date18 = year17.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date18);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone25);
        java.util.TimeZone timeZone27 = null;
        java.util.Locale locale28 = null;
        try {
            org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date18, timeZone27, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        java.lang.Number number33 = timeSeries1.getValue(0);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.560182972264E12d + "'", number33.equals(1.560182972264E12d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        boolean boolean12 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        int int6 = day5.getYear();
        long long7 = day5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400001L) + "'", long7 == (-14400001L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1, false);
        boolean boolean16 = year1.equals((java.lang.Object) fixedMillisecond12);
        java.util.Date date17 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        long long6 = day3.getFirstMillisecond();
        long long7 = day3.getLastMillisecond();
        long long8 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date8, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.next();
        long long44 = fixedMillisecond40.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 0, false);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date54 = fixedMillisecond53.getStart();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        long long56 = day55.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day55.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 0.0f, true);
        boolean boolean62 = timeSeries7.isEmpty();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 25568L + "'", long56 == 25568L);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        java.lang.String str15 = timeSeries1.getRangeDescription();
        double double16 = timeSeries1.getMinY();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        fixedMillisecond6.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 100);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.Number number16 = timeSeriesDataItem14.getValue();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0d + "'", number16.equals(100.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        boolean boolean13 = fixedMillisecond6.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond6.next();
        long long15 = fixedMillisecond6.getFirstMillisecond();
        long long16 = fixedMillisecond6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        long long18 = day17.getSerialIndex();
        int int19 = day17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.next();
        int int21 = day17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day17.previous();
        int int23 = fixedMillisecond11.compareTo((java.lang.Object) day17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day17.previous();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 25568L + "'", long18 == 25568L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.fireSeriesChanged();
        timeSeries15.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries15);
        boolean boolean21 = fixedMillisecond6.equals((java.lang.Object) timeSeries13);
        java.util.List list22 = timeSeries13.getItems();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener21);
        int int23 = timeSeries15.getItemCount();
        boolean boolean24 = timeSeries15.getNotify();
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(regularTimePeriod26, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy(0, 10);
        timeSeries21.setDescription("1969");
        boolean boolean24 = fixedMillisecond10.equals((java.lang.Object) timeSeries21);
        long long25 = fixedMillisecond10.getSerialIndex();
        java.util.Calendar calendar26 = null;
        fixedMillisecond10.peg(calendar26);
        long long28 = fixedMillisecond10.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy(0, 10);
        timeSeries21.setDescription("1969");
        boolean boolean24 = fixedMillisecond10.equals((java.lang.Object) timeSeries21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date28 = fixedMillisecond27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.Date date30 = year29.getEnd();
        long long31 = year29.getFirstMillisecond();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year29);
        long long33 = month32.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 1560182976350L);
        timeSeries21.add(timeSeriesDataItem35);
        timeSeries21.clear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-25070400001L) + "'", long33 == (-25070400001L));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        double double11 = timeSeries8.getMaxY();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 11);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        timeSeriesDataItem18.setValue((java.lang.Number) (-1.0f));
        timeSeries8.add(timeSeriesDataItem18, true);
        timeSeries1.add(timeSeriesDataItem18, false);
        java.lang.String str26 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        long long19 = day18.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        long long22 = day18.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 1560182986783L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date28 = fixedMillisecond27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.Date date30 = year29.getEnd();
        long long31 = year29.getFirstMillisecond();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year29);
        org.jfree.data.time.Year year33 = month32.getYear();
        boolean boolean34 = day18.equals((java.lang.Object) year33);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25568L + "'", long19 == 25568L);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-57600000L) + "'", long22 == (-57600000L));
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        double double11 = timeSeries8.getMaxY();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection22 = timeSeries21.getTimePeriods();
        timeSeries21.fireSeriesChanged();
        timeSeries21.setMaximumItemAge((long) ' ');
        timeSeries21.removeAgedItems(false);
        timeSeries21.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date31 = fixedMillisecond30.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 11);
        timeSeries21.add(timeSeriesDataItem34);
        timeSeries14.add(timeSeriesDataItem34, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries8.addOrUpdate(timeSeriesDataItem34);
        int int39 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo34 = null;
        seriesChangeEvent33.setSummary(seriesChangeInfo34);
        boolean boolean36 = timeSeries31.equals((java.lang.Object) seriesChangeInfo34);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries31.removePropertyChangeListener(propertyChangeListener37);
        int int39 = timeSeries31.getItemCount();
        boolean boolean40 = timeSeries31.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo45 = null;
        seriesChangeEvent44.setSummary(seriesChangeInfo45);
        boolean boolean47 = timeSeries42.equals((java.lang.Object) seriesChangeInfo45);
        java.lang.Comparable comparable48 = timeSeries42.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (double) (short) 0);
        java.util.Date date55 = fixedMillisecond50.getTime();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date55);
        int int57 = month56.getMonth();
        boolean boolean59 = month56.equals((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection62 = timeSeries61.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener63 = null;
        timeSeries61.removeChangeListener(seriesChangeListener63);
        boolean boolean65 = timeSeries61.getNotify();
        java.util.List list66 = timeSeries61.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date69 = fixedMillisecond68.getStart();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date69);
        java.util.Date date71 = year70.getEnd();
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) year70, (double) 3, false);
        int int75 = year70.getYear();
        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) month56, (org.jfree.data.time.RegularTimePeriod) year70);
        java.lang.Number number77 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year70, number77);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + (short) -1 + "'", comparable48.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 97L + "'", long52 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 12 + "'", int57 == 12);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(collection62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(list66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1969 + "'", int75 == 1969);
        org.junit.Assert.assertNotNull(timeSeries76);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        int int36 = month32.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date5 = fixedMillisecond4.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        java.lang.Comparable comparable18 = timeSeries12.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
        long long33 = fixedMillisecond30.getMiddleMillisecond();
        long long34 = fixedMillisecond30.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, 0.0d);
        long long38 = fixedMillisecond26.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (short) -1 + "'", comparable18.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        int int10 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getMiddleMillisecond(calendar15);
        java.util.Calendar calendar17 = null;
        fixedMillisecond12.peg(calendar17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560150000000L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-31507200000L), false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        int int10 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        long long17 = day16.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 0, false);
        int int23 = day19.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 25568L + "'", long17 == 25568L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        fixedMillisecond8.peg(calendar11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemAge((long) ' ');
        timeSeries14.removeAgedItems(false);
        boolean boolean21 = timeSeries14.getNotify();
        boolean boolean22 = fixedMillisecond8.equals((java.lang.Object) timeSeries14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        long long27 = day26.getSerialIndex();
        int int28 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day26.next();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Object obj31 = null;
        boolean boolean32 = fixedMillisecond8.equals(obj31);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        timeSeries34.setRangeDescription("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        boolean boolean41 = timeSeries34.equals((java.lang.Object) wildcardClass40);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo46 = null;
        seriesChangeEvent45.setSummary(seriesChangeInfo46);
        boolean boolean48 = timeSeries43.equals((java.lang.Object) seriesChangeInfo46);
        java.lang.Comparable comparable49 = timeSeries43.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond51.getLastMillisecond(calendar52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (double) (short) 0);
        java.util.Date date56 = fixedMillisecond51.getTime();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date56, timeZone58);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo60 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) wildcardClass40, seriesChangeInfo60);
        int int62 = fixedMillisecond8.compareTo((java.lang.Object) seriesChangeEvent61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = fixedMillisecond8.next();
        java.lang.Number number64 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number64);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25568L + "'", long27 == 25568L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + (short) -1 + "'", comparable49.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 97L + "'", long53 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        java.lang.String str35 = fixedMillisecond30.toString();
        java.util.Date date36 = fixedMillisecond30.getStart();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond30.getMiddleMillisecond(calendar37);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str35.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        java.util.TimeZone timeZone24 = null;
        try {
            org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date21, timeZone24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        double double4 = timeSeries1.getMaxY();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date8 = fixedMillisecond7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 11);
        java.lang.Object obj12 = timeSeriesDataItem11.clone();
        timeSeriesDataItem11.setValue((java.lang.Number) (-1.0f));
        timeSeries1.add(timeSeriesDataItem11, true);
        int int17 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection2 = timeSeries1.getTimePeriods();
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setKey((java.lang.Comparable) (short) -1);
//        timeSeries1.removeAgedItems(0L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (short) 1);
//        java.lang.Number number14 = timeSeriesDataItem13.getValue();
//        timeSeries1.add(timeSeriesDataItem13, true);
//        boolean boolean17 = timeSeries1.isEmpty();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date24 = fixedMillisecond23.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        java.util.Date date26 = year25.getEnd();
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 0L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate(timeSeriesDataItem31);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection2);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183045313L + "'", long10 == 1560183045313L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183045313L + "'", long11 == 1560183045313L);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 1 + "'", number14.equals((short) 1));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        timeSeries1.removeAgedItems(1560183039120L, false);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
//        java.lang.Comparable comparable7 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        int int16 = month15.getMonth();
//        java.lang.String str17 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        boolean boolean20 = month15.equals((java.lang.Object) fixedMillisecond18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560183045357L + "'", long19 == 1560183045357L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        double double4 = timeSeries1.getMaxY();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemAge((long) ' ');
        timeSeries14.removeAgedItems(false);
        timeSeries14.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date24 = fixedMillisecond23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 11);
        timeSeries14.add(timeSeriesDataItem27);
        timeSeries7.add(timeSeriesDataItem27, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        try {
            java.lang.Class<?> wildcardClass32 = timeSeriesDataItem31.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        seriesChangeEvent20.setSummary(seriesChangeInfo21);
        boolean boolean23 = timeSeries18.equals((java.lang.Object) seriesChangeInfo21);
        java.lang.Comparable comparable24 = timeSeries18.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) (short) 0);
        java.util.Date date31 = fixedMillisecond26.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond35.getMiddleMillisecond(calendar38);
        java.util.Calendar calendar40 = null;
        fixedMillisecond35.peg(calendar40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date44 = fixedMillisecond43.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean48 = year45.equals((java.lang.Object) 'a');
        java.lang.String str49 = year45.toString();
        java.lang.String str50 = year45.toString();
        int int51 = fixedMillisecond35.compareTo((java.lang.Object) year45);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        try {
            timeSeries1.update(1, (java.lang.Number) 1560183014860L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (short) -1 + "'", comparable24.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 97L + "'", long39 == 97L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1969" + "'", str50.equals("1969"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(timeSeries52);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries11.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        java.lang.Number number21 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        boolean boolean23 = fixedMillisecond16.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond16.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod24);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        boolean boolean15 = timeSeries10.isEmpty();
        java.lang.String str16 = timeSeries10.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond9.previous();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 0L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries1.removeChangeListener(seriesChangeListener15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date21 = fixedMillisecond20.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        int int23 = day22.getYear();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 1969L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        int int12 = day3.compareTo((java.lang.Object) regularTimePeriod11);
        java.lang.String str13 = day3.toString();
        int int14 = day3.getDayOfMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.Date date18 = year17.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date18);
        java.lang.Class<?> wildcardClass22 = fixedMillisecond21.getClass();
        java.lang.Number number23 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries36.removeChangeListener(seriesChangeListener38);
        timeSeries36.removeAgedItems((long) 0, true);
        boolean boolean43 = timeSeries36.getNotify();
        int int44 = fixedMillisecond30.compareTo((java.lang.Object) boolean43);
        int int46 = fixedMillisecond30.compareTo((java.lang.Object) (-25070400001L));
        java.lang.Object obj47 = null;
        boolean boolean48 = fixedMillisecond30.equals(obj47);
        java.util.Calendar calendar49 = null;
        fixedMillisecond30.peg(calendar49);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.next();
        long long44 = fixedMillisecond40.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 0, false);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener52);
        boolean boolean54 = timeSeries7.getNotify();
        timeSeries7.setDomainDescription("31-December-1969");
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        double double10 = timeSeries7.getMaxY();
        boolean boolean11 = year3.equals((java.lang.Object) double10);
        int int12 = year3.getYear();
        long long13 = year3.getLastMillisecond();
        java.lang.String str14 = year3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.previous();
        long long25 = month22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month22.next();
        timeSeries1.setKey((java.lang.Comparable) month22);
        java.lang.Class<?> wildcardClass28 = month22.getClass();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.util.List list14 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date20 = year19.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183018824L);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean25 = timeSeries24.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date28 = fixedMillisecond27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) day32);
        java.util.Collection collection34 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.lang.String str35 = timeSeries24.getRangeDescription();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Value" + "'", str35.equals("Value"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        long long36 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 0, false);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d, true);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo50 = null;
        seriesChangeEvent49.setSummary(seriesChangeInfo50);
        boolean boolean52 = timeSeries47.equals((java.lang.Object) seriesChangeInfo50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
        long long58 = fixedMillisecond54.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo66 = null;
        seriesChangeEvent65.setSummary(seriesChangeInfo66);
        boolean boolean68 = timeSeries63.equals((java.lang.Object) seriesChangeInfo66);
        java.lang.Comparable comparable69 = timeSeries63.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (double) (short) 0);
        java.util.Date date76 = fixedMillisecond71.getTime();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = month78.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month78, (java.lang.Number) 0);
        long long82 = month78.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date85 = fixedMillisecond84.getStart();
        java.util.Calendar calendar86 = null;
        fixedMillisecond84.peg(calendar86);
        java.util.Calendar calendar88 = null;
        long long89 = fixedMillisecond84.getFirstMillisecond(calendar88);
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month78, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond84);
        java.lang.Class class91 = timeSeries90.getTimePeriodClass();
        java.lang.Comparable comparable92 = timeSeries90.getKey();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 97L + "'", long56 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 97L + "'", long58 == 97L);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + (short) -1 + "'", comparable69.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 97L + "'", long73 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-2649600000L) + "'", long82 == (-2649600000L));
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 97L + "'", long89 == 97L);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertNotNull(class91);
        org.junit.Assert.assertTrue("'" + comparable92 + "' != '" + (short) -1 + "'", comparable92.equals((short) -1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setRangeDescription("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        boolean boolean15 = timeSeries10.equals((java.lang.Object) seriesChangeInfo13);
        java.lang.Comparable comparable16 = timeSeries10.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 0);
        java.util.Date date23 = fixedMillisecond18.getTime();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date23, timeZone25);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) wildcardClass7, seriesChangeInfo27);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = seriesChangeEvent28.getSummary();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) -1 + "'", comparable16.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(seriesChangeInfo29);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 31L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.fireSeriesChanged();
        timeSeries16.setMaximumItemAge((long) ' ');
        timeSeries16.removeAgedItems(false);
        timeSeries16.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 11);
        timeSeries16.add(timeSeriesDataItem29);
        java.lang.Number number31 = timeSeriesDataItem29.getValue();
        timeSeries1.add(timeSeriesDataItem29);
        boolean boolean33 = timeSeriesDataItem29.isSelected();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 11 + "'", number31.equals(11));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        boolean boolean13 = fixedMillisecond6.equals((java.lang.Object) 8);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond6.getFirstMillisecond(calendar14);
        java.util.Calendar calendar16 = null;
        fixedMillisecond6.peg(calendar16);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 4, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        long long14 = day13.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
        int int17 = day13.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate18 = day13.getSerialDate();
        boolean boolean19 = timeSeriesDataItem9.equals((java.lang.Object) day13);
        boolean boolean21 = day13.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.SerialDate serialDate22 = day13.getSerialDate();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 25568L + "'", long14 == 25568L);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 1, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond10.next();
        long long15 = fixedMillisecond10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond21.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (-23731200001L));
        long long31 = fixedMillisecond21.getLastMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        java.lang.Object obj5 = timeSeriesDataItem4.clone();
//        boolean boolean6 = timeSeriesDataItem4.isSelected();
//        boolean boolean8 = timeSeriesDataItem4.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date11 = fixedMillisecond10.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        java.util.Date date13 = year12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        long long15 = day14.getLastMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
//        seriesChangeEvent17.setSummary(seriesChangeInfo18);
//        int int20 = day14.compareTo((java.lang.Object) seriesChangeInfo18);
//        boolean boolean21 = timeSeriesDataItem4.equals((java.lang.Object) day14);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day14, seriesChangeInfo22);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183048049L + "'", long1 == 1560183048049L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183048049L + "'", long2 == 1560183048049L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.setKey((java.lang.Comparable) 1L);
        timeSeries18.setKey((java.lang.Comparable) ' ');
        java.lang.String str24 = timeSeries18.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries26.setNotify(false);
        timeSeries26.removeAgedItems(true);
        java.util.Collection collection31 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        int int32 = year15.compareTo((java.lang.Object) timeSeries18);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        int int16 = year13.getYear();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year13.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        long long14 = day13.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
        int int17 = day13.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate18 = day13.getSerialDate();
        boolean boolean19 = timeSeriesDataItem9.equals((java.lang.Object) day13);
        boolean boolean21 = day13.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        java.util.Calendar calendar22 = null;
        try {
            day13.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 25568L + "'", long14 == 25568L);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.Year year9 = month7.getYear();
        int int10 = month7.getYearValue();
        long long11 = month7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month7.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-26409600000L) + "'", long11 == (-26409600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        timeSeries12.setRangeDescription("hi!");
        java.util.Collection collection18 = timeSeries12.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        seriesChangeEvent23.setSummary(seriesChangeInfo24);
        boolean boolean26 = timeSeries21.equals((java.lang.Object) seriesChangeInfo24);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection31 = timeSeries30.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries30.removeChangeListener(seriesChangeListener32);
        java.util.Collection collection34 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        boolean boolean35 = timeSeries30.isEmpty();
        java.util.Collection collection36 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(collection36);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getFirstMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            month15.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2649600000L) + "'", long17 == (-2649600000L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getMiddleMillisecond(calendar10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond7.getLastMillisecond(calendar12);
        java.lang.Class<?> wildcardClass14 = fixedMillisecond7.getClass();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1, true);
        long long18 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("December 1969");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray9 = seriesException7.getSuppressed();
        java.lang.String str10 = seriesException7.toString();
        java.lang.String str11 = seriesException7.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: December 1969" + "'", str10.equals("org.jfree.data.general.SeriesException: December 1969"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: December 1969" + "'", str11.equals("org.jfree.data.general.SeriesException: December 1969"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(true);
        int int4 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date8 = fixedMillisecond7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.Date date10 = year9.getEnd();
        long long11 = year9.getFirstMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(3, year9);
        org.jfree.data.time.Year year13 = month12.getYear();
        org.jfree.data.time.Year year14 = month12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31507200000L) + "'", long11 == (-31507200000L));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date5 = fixedMillisecond4.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        java.util.Date date8 = regularTimePeriod7.getStart();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date8, timeZone11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = month7.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "Time", "31-December-1969");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-25070400001L) + "'", long8 == (-25070400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year2 = month1.getYear();
        long long3 = year2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-31507200000L) + "'", long3 == (-31507200000L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.next();
        long long44 = fixedMillisecond40.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 0, false);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener52);
        boolean boolean54 = timeSeries7.getNotify();
        timeSeries7.setMaximumItemCount((int) '#');
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener11);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.lang.Comparable comparable21 = timeSeries15.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (short) 0);
        java.util.Date date28 = fixedMillisecond23.getTime();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.next();
        int int32 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) -1 + "'", comparable21.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.previous();
        long long25 = month22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month22.next();
        timeSeries1.setKey((java.lang.Comparable) month22);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection30 = timeSeries29.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        timeSeries29.removeAgedItems(true);
        java.lang.Class class35 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date39 = fixedMillisecond38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo45 = null;
        seriesChangeEvent44.setSummary(seriesChangeInfo45);
        boolean boolean47 = timeSeries42.equals((java.lang.Object) seriesChangeInfo45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond49.getLastMillisecond(calendar50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond49.next();
        long long53 = fixedMillisecond49.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        int int57 = year40.compareTo((java.lang.Object) fixedMillisecond55);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(11, year40);
        long long59 = year40.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
        boolean boolean61 = month22.equals((java.lang.Object) year40);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNull(class35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 97L + "'", long51 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 97L + "'", long53 == 97L);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-31507200000L) + "'", long59 == (-31507200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries4, seriesChangeInfo7);
        org.junit.Assert.assertNotNull(timeSeries4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.addChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass13 = seriesChangeEvent12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.Date date19 = year18.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 100);
        timeSeries1.add(timeSeriesDataItem24);
        timeSeries1.setDescription("1969");
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        java.lang.Number number10 = timeSeriesDataItem9.getValue();
        int int12 = timeSeriesDataItem9.compareTo((java.lang.Object) 31);
        java.lang.Number number13 = timeSeriesDataItem9.getValue();
        java.lang.Object obj14 = timeSeriesDataItem9.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0d + "'", number13.equals(100.0d));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        int int15 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-31507200000L));
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeriesDataItem7.equals(obj9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.fireSeriesChanged();
        timeSeries15.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries15);
        boolean boolean21 = fixedMillisecond6.equals((java.lang.Object) timeSeries13);
        java.lang.Class<?> wildcardClass22 = fixedMillisecond6.getClass();
        long long23 = fixedMillisecond6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean14 = year11.equals((java.lang.Object) 'a');
        java.lang.String str15 = year11.toString();
        java.lang.String str16 = year11.toString();
        int int17 = fixedMillisecond1.compareTo((java.lang.Object) year11);
        long long18 = year11.getLastMillisecond();
        long long19 = year11.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1969L + "'", long19 == 1969L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean6 = year3.equals((java.lang.Object) 'a');
        long long7 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries1.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date35 = fixedMillisecond34.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        int int39 = day38.getYear();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-31507200000L));
        boolean boolean8 = timeSeriesDataItem7.isSelected();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        org.jfree.data.time.Year year18 = month16.getYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1, false);
        boolean boolean16 = year1.equals((java.lang.Object) fixedMillisecond12);
        java.util.Date date17 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Year year16 = month15.getYear();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month15.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(year16);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        java.util.Date date14 = year13.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1L));
        java.util.Calendar calendar23 = null;
        try {
            year19.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        long long10 = regularTimePeriod8.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100800001L) + "'", long10 == (-100800001L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 11);
        java.lang.Number number16 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        int int22 = day20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.next();
        java.lang.Object obj24 = null;
        int int25 = day20.compareTo(obj24);
        int int26 = day20.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 1560183030238L);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 25568L + "'", long21 == 25568L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        timeSeries1.setMaximumItemAge(1560182982730L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183051185L + "'", long1 == 1560183051185L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183051185L + "'", long2 == 1560183051185L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        long long36 = month32.getFirstMillisecond();
        int int37 = month32.getMonth();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = month32.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2649600000L) + "'", long36 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 0L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries1.addChangeListener(seriesChangeListener15);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 11);
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        timeSeriesDataItem13.setValue((java.lang.Number) (-1.0f));
        int int17 = month7.compareTo((java.lang.Object) (-1.0f));
        long long18 = month7.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        seriesChangeEvent22.setSummary(seriesChangeInfo23);
        boolean boolean25 = timeSeries20.equals((java.lang.Object) seriesChangeInfo23);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener26);
        int int28 = timeSeries20.getItemCount();
        boolean boolean29 = timeSeries20.isEmpty();
        timeSeries20.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
        seriesChangeEvent36.setSummary(seriesChangeInfo37);
        boolean boolean39 = timeSeries34.equals((java.lang.Object) seriesChangeInfo37);
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timeSeries34.removePropertyChangeListener(propertyChangeListener40);
        int int42 = timeSeries34.getItemCount();
        boolean boolean43 = timeSeries34.getNotify();
        java.util.Collection collection44 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        int int45 = month7.compareTo((java.lang.Object) collection44);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-23731200001L) + "'", long18 == (-23731200001L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 28799999L);
        long long8 = day3.getSerialIndex();
        int int9 = day3.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 11);
        timeSeries1.add(timeSeriesDataItem14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem14.getPeriod();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod16, seriesChangeInfo17);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = seriesChangeEvent18.getSummary();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(seriesChangeInfo19);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, "June 2019", "10");
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date8, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        java.lang.String str12 = day11.toString();
        int int13 = day11.getMonth();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.fireSeriesChanged();
        timeSeries17.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries15.addAndOrUpdate(timeSeries17);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Month month26 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year27 = month26.getYear();
        java.lang.Number number28 = null;
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) year27, number28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond31.getMiddleMillisecond(calendar34);
        java.util.Calendar calendar36 = null;
        fixedMillisecond31.peg(calendar36);
        java.lang.Number number38 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        boolean boolean39 = day11.equals((java.lang.Object) fixedMillisecond31);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-1969" + "'", str12.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(month26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 97L + "'", long35 == 97L);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-31507200000L));
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        int int29 = year12.compareTo((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(11, year12);
        java.lang.Class<?> wildcardClass31 = month30.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date34 = fixedMillisecond33.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        long long36 = day35.getSerialIndex();
        int int37 = day35.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day35.next();
        int int39 = day35.getYear();
        java.util.Date date40 = day35.getStart();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date40, timeZone41);
        boolean boolean43 = timeSeriesDataItem7.equals((java.lang.Object) regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 25568L + "'", long36 == 25568L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean14 = year11.equals((java.lang.Object) 'a');
        java.lang.String str15 = year11.toString();
        java.lang.String str16 = year11.toString();
        int int17 = fixedMillisecond1.compareTo((java.lang.Object) year11);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond1.getFirstMillisecond(calendar18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 97L + "'", long19 == 97L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        int int15 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year10.previous();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection2 = timeSeries1.getTimePeriods();
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setKey((java.lang.Comparable) (short) -1);
//        timeSeries1.removeAgedItems(0L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (short) 1);
//        java.lang.Number number14 = timeSeriesDataItem13.getValue();
//        timeSeries1.add(timeSeriesDataItem13, true);
//        java.lang.String str17 = timeSeries1.getDomainDescription();
//        org.junit.Assert.assertNotNull(collection2);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183053339L + "'", long10 == 1560183053339L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183053339L + "'", long11 == 1560183053339L);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 1 + "'", number14.equals((short) 1));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        timeSeries1.removeAgedItems(0L, false);
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries17.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
        long long26 = fixedMillisecond22.getFirstMillisecond();
        java.lang.Number number27 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond22.next();
        boolean boolean31 = year13.equals((java.lang.Object) regularTimePeriod30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year13.next();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        java.lang.Object obj16 = timeSeries7.clone();
        java.util.Collection collection17 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        java.lang.Comparable comparable18 = timeSeries12.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) (short) 0);
        java.util.Date date25 = fixedMillisecond20.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        int int27 = month26.getMonth();
        boolean boolean29 = month26.equals((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection32 = timeSeries31.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries31.removeChangeListener(seriesChangeListener33);
        boolean boolean35 = timeSeries31.getNotify();
        java.util.List list36 = timeSeries31.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date39 = fixedMillisecond38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.util.Date date41 = year40.getEnd();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) year40, (double) 3, false);
        int int45 = year40.getYear();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year40);
        java.util.Calendar calendar47 = null;
        try {
            long long48 = month26.getFirstMillisecond(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (short) -1 + "'", comparable18.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertNotNull(timeSeries46);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1, false);
        boolean boolean16 = year1.equals((java.lang.Object) fixedMillisecond12);
        long long17 = year1.getSerialIndex();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year1.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date8);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        java.lang.Object obj5 = timeSeriesDataItem4.clone();
//        timeSeriesDataItem4.setSelected(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183053964L + "'", long1 == 1560183053964L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183053964L + "'", long2 == 1560183053964L);
//        org.junit.Assert.assertNotNull(obj5);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.lang.String str9 = timeSeries8.getRangeDescription();
        timeSeries8.setMaximumItemCount((int) (short) 100);
        java.lang.Object obj12 = timeSeries8.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setRangeDescription("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        boolean boolean15 = timeSeries10.equals((java.lang.Object) seriesChangeInfo13);
        java.lang.Comparable comparable16 = timeSeries10.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 0);
        java.util.Date date23 = fixedMillisecond18.getTime();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date23, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date23);
        long long28 = month27.getFirstMillisecond();
        java.util.Calendar calendar29 = null;
        try {
            long long30 = month27.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) -1 + "'", comparable16.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2649600000L) + "'", long28 == (-2649600000L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        int int31 = timeSeries1.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries1.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        long long38 = fixedMillisecond35.getMiddleMillisecond();
        timeSeries1.setKey((java.lang.Comparable) long38);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries1.addChangeListener(seriesChangeListener40);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.previous();
        long long19 = month16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month16.next();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month16.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.Date date17 = year16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 100);
        long long23 = fixedMillisecond20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.addOrUpdate(regularTimePeriod24, (double) (short) 1);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28799999L + "'", long23 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.TimeZone timeZone23 = null;
        java.util.Locale locale24 = null;
        try {
            org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date21, timeZone23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str12 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        double double17 = timeSeries14.getMaxY();
        timeSeries14.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date21 = fixedMillisecond20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 11);
        java.lang.Object obj25 = timeSeriesDataItem24.clone();
        timeSeriesDataItem24.setValue((java.lang.Number) (-1.0f));
        timeSeries14.add(timeSeriesDataItem24, true);
        java.lang.Object obj30 = timeSeriesDataItem24.clone();
        boolean boolean31 = timeSeries1.equals((java.lang.Object) timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("December 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        timeSeries11.fireSeriesChanged();
        timeSeries11.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries9.addAndOrUpdate(timeSeries11);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.Month month20 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year21 = month20.getYear();
        java.lang.Number number22 = null;
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year21, number22);
        boolean boolean24 = timeSeries16.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener25);
        timeSeries16.setRangeDescription("Time");
        int int29 = year4.compareTo((java.lang.Object) timeSeries16);
        int int30 = month0.compareTo((java.lang.Object) int29);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(month20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        java.lang.Number number33 = timeSeries1.getValue(0);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 0);
        java.lang.String str35 = seriesChangeEvent34.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.560182972264E12d + "'", number33.equals(1.560182972264E12d));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=0]" + "'", str35.equals("org.jfree.data.event.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        long long17 = year15.getLastMillisecond();
        long long18 = year15.getFirstMillisecond();
        long long19 = year15.getFirstMillisecond();
        long long20 = year15.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62104204800001L) + "'", long17 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135740800000L) + "'", long18 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62135740800000L) + "'", long19 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62135740800000L) + "'", long20 == (-62135740800000L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        int int16 = month15.getMonth();
        boolean boolean18 = month15.equals((java.lang.Object) 1.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        java.lang.Class<?> wildcardClass23 = fixedMillisecond20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        int int25 = month15.compareTo((java.lang.Object) class24);
        org.jfree.data.time.Year year26 = month15.getYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(year26);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("March 1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        java.lang.Object obj9 = timeSeries1.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries1.getMaximumItemCount();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.Date date21 = year20.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date21);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year27, (double) (short) 10);
        try {
            timeSeries1.delete((int) (short) 1, 9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        timeSeries1.setDescription("March 1969");
        boolean boolean18 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.util.Date date13 = year12.getEnd();
        long long14 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.getDataItem(regularTimePeriod15);
        timeSeries1.removeAgedItems((long) 3, false);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries23.setMaximumItemCount((int) 'a');
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date30 = fixedMillisecond29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        long long32 = day31.getSerialIndex();
        int int33 = day31.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day31.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getLastMillisecond(calendar37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond36.next();
        int int40 = day31.compareTo((java.lang.Object) regularTimePeriod39);
        timeSeries23.delete(regularTimePeriod39);
        timeSeries1.add(regularTimePeriod39, (java.lang.Number) 2147483647);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31507200000L) + "'", long14 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 25568L + "'", long32 == 25568L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
        int int10 = day9.getMonth();
        java.lang.String str11 = day9.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) ' ');
        long long24 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year3.previous();
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year3.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31507200000L) + "'", long24 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getFirstMillisecond();
        java.lang.String str5 = year3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31507200000L) + "'", long4 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date8 = fixedMillisecond7.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        long long10 = day9.getSerialIndex();
        int int11 = day9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        int int18 = day9.compareTo((java.lang.Object) regularTimePeriod17);
        timeSeries1.delete(regularTimePeriod17);
        java.lang.String str20 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        int int8 = day6.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean23 = year20.equals((java.lang.Object) 'a');
        java.lang.String str24 = year20.toString();
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray27 = seriesException26.getSuppressed();
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("");
        seriesException26.addSuppressed((java.lang.Throwable) seriesException29);
        int int31 = year20.compareTo((java.lang.Object) seriesException29);
        boolean boolean32 = month15.equals((java.lang.Object) int31);
        long long33 = month15.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "December 1969" + "'", str16.equals("December 1969"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-2649600000L) + "'", long33 == (-2649600000L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond8.getLastMillisecond(calendar16);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = month7.getMiddleMillisecond();
        int int9 = month7.getYearValue();
        int int10 = month7.getYearValue();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass13 = seriesChangeEvent12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.Date date19 = year18.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date19);
        boolean boolean23 = month7.equals((java.lang.Object) date19);
        java.util.TimeZone timeZone24 = null;
        java.util.Locale locale25 = null;
        try {
            org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date19, timeZone24, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-25070400001L) + "'", long8 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        try {
            timeSeries1.update((int) ' ', (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        int int29 = year12.compareTo((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(11, year12);
        java.lang.Class<?> wildcardClass31 = month30.getClass();
        timeSeries1.setKey((java.lang.Comparable) month30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.previous();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod33, "1969", "");
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Collection collection14 = timeSeries1.getTimePeriods();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1, seriesChangeInfo15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.Year year9 = month7.getYear();
        int int10 = month7.getYearValue();
        int int11 = month7.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.fireSeriesChanged();
        timeSeries15.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries15);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.Month month24 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year25 = month24.getYear();
        java.lang.Number number26 = null;
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year25, number26);
        boolean boolean28 = timeSeries20.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener29);
        boolean boolean31 = month7.equals((java.lang.Object) propertyChangeListener29);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(month24);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date5 = fixedMillisecond4.getStart();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        try {
            java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        long long8 = day3.getLastMillisecond();
        long long9 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25568L + "'", long9 == 25568L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        java.lang.String str9 = regularTimePeriod8.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "30-December-1969" + "'", str9.equals("30-December-1969"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        timeSeries10.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.removeChangeListener(seriesChangeListener17);
        java.util.List list19 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1969, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection23 = timeSeries22.getTimePeriods();
        timeSeries22.fireSeriesChanged();
        timeSeries22.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries20.addAndOrUpdate(timeSeries22);
        boolean boolean28 = timeSeries16.equals((java.lang.Object) timeSeries22);
        java.util.List list29 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries22.createCopy(4, (int) ' ');
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date35 = year34.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (double) 1560183018824L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean40 = timeSeries39.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date43 = fixedMillisecond42.getStart();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        java.util.Date date45 = year44.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) day47);
        java.util.Collection collection49 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        int int50 = year14.compareTo((java.lang.Object) timeSeries22);
        java.lang.String str51 = year14.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1969" + "'", str51.equals("1969"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems((long) 0, true);
        boolean boolean8 = timeSeries1.getNotify();
        double double9 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries12.addAndOrUpdate(timeSeries14);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Month month23 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year24 = month23.getYear();
        java.lang.Number number25 = null;
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year24, number25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection29 = timeSeries28.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries28.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.next();
        long long37 = fixedMillisecond33.getFirstMillisecond();
        java.lang.Number number38 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        boolean boolean40 = fixedMillisecond33.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond33.next();
        boolean boolean42 = year24.equals((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (byte) 1, year24);
        int int44 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month43);
        try {
            timeSeries1.delete(10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(month23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 97L + "'", long35 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        long long7 = year3.getFirstMillisecond();
        int int8 = year3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year3.previous();
        long long10 = year3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getLastMillisecond(calendar37);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond36.getMiddleMillisecond(calendar39);
        java.util.Date date41 = fixedMillisecond36.getTime();
        long long42 = fixedMillisecond36.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo47 = null;
        seriesChangeEvent46.setSummary(seriesChangeInfo47);
        boolean boolean49 = timeSeries44.equals((java.lang.Object) seriesChangeInfo47);
        java.lang.Comparable comparable50 = timeSeries44.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) (short) 0);
        java.util.Date date57 = fixedMillisecond52.getTime();
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date57);
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = month59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month59.previous();
        long long62 = month59.getLastMillisecond();
        boolean boolean63 = fixedMillisecond36.equals((java.lang.Object) long62);
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 97L + "'", long40 == 97L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + (short) -1 + "'", comparable50.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 97L + "'", long54 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 28799999L + "'", long62 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 28799999L);
        long long8 = day3.getSerialIndex();
        int int9 = day3.getDayOfMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        timeSeries1.removeAgedItems(0L, true);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        seriesChangeEvent13.setSummary(seriesChangeInfo14);
        boolean boolean16 = timeSeries11.equals((java.lang.Object) seriesChangeInfo14);
        java.lang.Comparable comparable17 = timeSeries11.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 0);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond19.getFirstMillisecond(calendar24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = null;
        seriesChangeEvent29.setSummary(seriesChangeInfo30);
        boolean boolean32 = timeSeries27.equals((java.lang.Object) seriesChangeInfo30);
        java.lang.Comparable comparable33 = timeSeries27.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) (short) 0);
        java.util.Date date40 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod42);
        int int44 = fixedMillisecond19.compareTo((java.lang.Object) seriesChangeEvent43);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) -1);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) -1 + "'", comparable17.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) -1 + "'", comparable33.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        boolean boolean16 = timeSeries8.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener17);
        timeSeries8.setRangeDescription("Time");
        java.lang.Object obj21 = timeSeries8.clone();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        long long11 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Calendar calendar12 = null;
        fixedMillisecond8.peg(calendar12);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond8.getMiddleMillisecond(calendar14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond8.next();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setKey((java.lang.Comparable) (short) -1);
        timeSeries14.removeAgedItems(0L, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond23.getMiddleMillisecond(calendar26);
        java.util.Calendar calendar28 = null;
        fixedMillisecond23.peg(calendar28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (short) 100);
        timeSeriesDataItem31.setValue((java.lang.Number) 100L);
        boolean boolean34 = timeSeriesDataItem31.isSelected();
        java.lang.Object obj35 = timeSeriesDataItem31.clone();
        timeSeries14.add(timeSeriesDataItem31);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection41 = timeSeries40.getTimePeriods();
        timeSeries40.fireSeriesChanged();
        timeSeries40.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries38.addAndOrUpdate(timeSeries40);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener46);
        org.jfree.data.time.Month month49 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year50 = month49.getYear();
        java.lang.Number number51 = null;
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year50, number51);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection55 = timeSeries54.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries54.removeChangeListener(seriesChangeListener56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond59.getLastMillisecond(calendar60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond59.next();
        long long63 = fixedMillisecond59.getFirstMillisecond();
        java.lang.Number number64 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        boolean boolean66 = fixedMillisecond59.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond59.next();
        boolean boolean68 = year50.equals((java.lang.Object) regularTimePeriod67);
        timeSeries14.add(regularTimePeriod67, 0.0d, true);
        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries1.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date75 = fixedMillisecond74.getStart();
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
        long long77 = day76.getSerialIndex();
        int int78 = day76.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day76.next();
        java.lang.Object obj80 = null;
        int int81 = day76.compareTo(obj80);
        java.lang.String str82 = day76.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day76, (double) 1560182982730L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(month49);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNotNull(collection55);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 97L + "'", long61 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 97L + "'", long63 == 97L);
        org.junit.Assert.assertNull(number64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeSeries72);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 25568L + "'", long77 == 25568L);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1969 + "'", int78 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "31-December-1969" + "'", str82.equals("31-December-1969"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.String str7 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
        long long22 = fixedMillisecond18.getFirstMillisecond();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = null;
        seriesChangeEvent28.setSummary(seriesChangeInfo29);
        boolean boolean31 = timeSeries26.equals((java.lang.Object) seriesChangeInfo29);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection36 = timeSeries35.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries35.removeChangeListener(seriesChangeListener37);
        java.util.Collection collection39 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        boolean boolean40 = fixedMillisecond18.equals((java.lang.Object) timeSeries26);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries36.removeChangeListener(seriesChangeListener38);
        timeSeries36.removeAgedItems((long) 0, true);
        boolean boolean43 = timeSeries36.getNotify();
        int int44 = fixedMillisecond30.compareTo((java.lang.Object) boolean43);
        int int46 = fixedMillisecond30.compareTo((java.lang.Object) (-25070400001L));
        java.lang.Object obj47 = null;
        boolean boolean48 = fixedMillisecond30.equals(obj47);
        long long49 = fixedMillisecond30.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemAge((long) ' ');
        timeSeries8.removeAgedItems(false);
        boolean boolean15 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries17.removeChangeListener(seriesChangeListener19);
        boolean boolean21 = timeSeries17.getNotify();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo26 = null;
        seriesChangeEvent25.setSummary(seriesChangeInfo26);
        boolean boolean28 = timeSeries23.equals((java.lang.Object) seriesChangeInfo26);
        java.lang.Comparable comparable29 = timeSeries23.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) (short) 0);
        java.util.Date date36 = fixedMillisecond31.getTime();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond40.getMiddleMillisecond(calendar43);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month38, (double) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month38.previous();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str51 = timeSeries50.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo56 = null;
        seriesChangeEvent55.setSummary(seriesChangeInfo56);
        boolean boolean58 = timeSeries53.equals((java.lang.Object) seriesChangeInfo56);
        java.lang.Comparable comparable59 = timeSeries53.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond61.getLastMillisecond(calendar62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) (short) 0);
        java.util.Date date66 = fixedMillisecond61.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond61.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries50.addOrUpdate(regularTimePeriod67, (java.lang.Number) 1560182981229L);
        java.util.Date date70 = regularTimePeriod67.getStart();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month38, regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (short) -1 + "'", comparable29.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Value" + "'", str51.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + (short) -1 + "'", comparable59.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 97L + "'", long63 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeSeries71);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        java.lang.Comparable comparable20 = timeSeries14.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) (short) 0);
        java.util.Date date27 = fixedMillisecond22.getTime();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date27);
        boolean boolean30 = day12.equals((java.lang.Object) date27);
        long long31 = day12.getLastMillisecond();
        java.lang.String str32 = day12.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) -1 + "'", comparable20.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28799999L + "'", long31 == 28799999L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-1969" + "'", str32.equals("31-December-1969"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        seriesChangeEvent10.setSummary(seriesChangeInfo11);
        boolean boolean13 = timeSeries8.equals((java.lang.Object) seriesChangeInfo11);
        java.lang.Comparable comparable14 = timeSeries8.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) (short) 0);
        java.util.Date date21 = fixedMillisecond16.getTime();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) 1.560182972264E12d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date31 = fixedMillisecond30.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        java.util.Date date33 = year32.getEnd();
        long long34 = year32.getFirstMillisecond();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(3, year32);
        long long36 = month35.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries1.setMaximumItemAge((long) 9999);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection42 = timeSeries41.getTimePeriods();
        timeSeries41.setKey((java.lang.Comparable) 1L);
        timeSeries41.setKey((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo51 = null;
        seriesChangeEvent50.setSummary(seriesChangeInfo51);
        boolean boolean53 = timeSeries48.equals((java.lang.Object) seriesChangeInfo51);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection56 = timeSeries55.getTimePeriods();
        timeSeries55.fireSeriesChanged();
        timeSeries55.setMaximumItemAge((long) ' ');
        timeSeries55.removeAgedItems(false);
        timeSeries55.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date65 = fixedMillisecond64.getStart();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) 11);
        timeSeries55.add(timeSeriesDataItem68);
        timeSeries48.add(timeSeriesDataItem68, true);
        timeSeriesDataItem68.setSelected(false);
        timeSeries41.setKey((java.lang.Comparable) timeSeriesDataItem68);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass77 = seriesChangeEvent76.getClass();
        java.lang.Class class78 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass77);
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date81 = fixedMillisecond80.getStart();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date81);
        java.util.Date date83 = year82.getEnd();
        java.util.TimeZone timeZone84 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date83, timeZone84);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date83);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day86, (java.lang.Number) 0L);
        timeSeries41.add(timeSeriesDataItem88, true);
        try {
            org.jfree.data.time.TimeSeries timeSeries91 = timeSeries1.addAndOrUpdate(timeSeries41);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (short) -1 + "'", comparable14.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31507200000L) + "'", long34 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-25070400001L) + "'", long36 == (-25070400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(class78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNull(regularTimePeriod85);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1);
//        int int3 = timeSeries2.getItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183058050L + "'", long1 == 1560183058050L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        int int36 = month32.getMonth();
        int int37 = month32.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        int int12 = day11.getMonth();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.fireSeriesChanged();
        timeSeries16.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries14.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1, false);
        java.lang.Comparable comparable27 = timeSeries16.getKey();
        boolean boolean28 = day11.equals((java.lang.Object) comparable27);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries(comparable27);
        java.lang.Number number31 = null;
        try {
            timeSeries29.update(6, number31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (short) -1 + "'", comparable27.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) 0.0f);
        java.util.Date date10 = fixedMillisecond1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 1.560182972264E12d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        boolean boolean15 = timeSeriesDataItem12.equals((java.lang.Object) 31L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.fireSeriesChanged();
        timeSeries16.setMaximumItemAge((long) ' ');
        timeSeries16.removeAgedItems(false);
        timeSeries16.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 11);
        timeSeries16.add(timeSeriesDataItem29);
        java.lang.Number number31 = timeSeriesDataItem29.getValue();
        timeSeries1.add(timeSeriesDataItem29);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection35 = timeSeries34.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries34.removeChangeListener(seriesChangeListener36);
        timeSeries34.removeAgedItems((long) 0, true);
        boolean boolean41 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.addAndOrUpdate(timeSeries34);
        double double43 = timeSeries1.getMinY();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 11 + "'", number31.equals(11));
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 11.0d + "'", double43 == 11.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 0L);
        timeSeriesDataItem13.setSelected(false);
        timeSeriesDataItem13.setValue((java.lang.Number) 0.0f);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183058556L + "'", long1 == 1560183058556L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183058556L + "'", long2 == 1560183058556L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560183058556L + "'", long5 == 1560183058556L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        timeSeries7.removeAgedItems(false);
        boolean boolean14 = timeSeries7.getNotify();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Wed Dec 31 16:00:00 PST 1969", "");
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection22 = timeSeries21.getTimePeriods();
        timeSeries21.fireSeriesChanged();
        timeSeries21.setMaximumItemAge((long) ' ');
        timeSeries21.removeAgedItems(false);
        timeSeries21.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 0L);
        boolean boolean35 = timeSeries18.equals((java.lang.Object) 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.previous();
        long long25 = month22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month22.next();
        timeSeries1.setKey((java.lang.Comparable) month22);
        java.util.Calendar calendar28 = null;
        try {
            month22.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemAge((long) ' ');
        timeSeries8.removeAgedItems(false);
        timeSeries8.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date18 = fixedMillisecond17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 11);
        timeSeries8.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21, true);
        timeSeriesDataItem21.setSelected(false);
        java.lang.Object obj27 = timeSeriesDataItem21.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date30 = fixedMillisecond29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        long long32 = day31.getSerialIndex();
        int int33 = day31.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day31.next();
        int int35 = timeSeriesDataItem21.compareTo((java.lang.Object) regularTimePeriod34);
        timeSeriesDataItem21.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 25568L + "'", long32 == 25568L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        java.lang.String str17 = month16.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        timeSeries1.removeAgedItems(0L, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond10.peg(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (short) 100);
        timeSeriesDataItem18.setValue((java.lang.Number) 100L);
        boolean boolean21 = timeSeriesDataItem18.isSelected();
        java.lang.Object obj22 = timeSeriesDataItem18.clone();
        timeSeries1.add(timeSeriesDataItem18);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(9, (int) 'a');
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = month26.compareTo((java.lang.Object) year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
        int int30 = month26.getYearValue();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month26);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setDomainDescription("Value");
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection23 = timeSeries22.getTimePeriods();
        timeSeries22.fireSeriesChanged();
        timeSeries22.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries20.addAndOrUpdate(timeSeries22);
        boolean boolean28 = timeSeries16.equals((java.lang.Object) timeSeries22);
        java.util.List list29 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries22.createCopy(4, (int) ' ');
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date35 = year34.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (double) 1560183018824L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean40 = timeSeries39.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date43 = fixedMillisecond42.getStart();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        java.util.Date date45 = year44.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) day47);
        java.util.Collection collection49 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        int int50 = year14.compareTo((java.lang.Object) timeSeries22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year14.next();
        java.util.Calendar calendar52 = null;
        try {
            long long53 = year14.getFirstMillisecond(calendar52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 11);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        timeSeries1.clear();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries1.addChangeListener(seriesChangeListener18);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod12, "31-December-1969", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560183059478L + "'", long3 == 1560183059478L);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.lang.Object obj7 = null;
        int int8 = day3.compareTo(obj7);
        int int9 = day3.getYear();
        long long10 = day3.getSerialIndex();
        java.lang.String str11 = day3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        boolean boolean15 = timeSeries10.equals((java.lang.Object) seriesChangeInfo13);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries10.getItemCount();
        boolean boolean19 = timeSeries10.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries10.addChangeListener(seriesChangeListener23);
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        double double26 = timeSeries1.getMinY();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.lang.Comparable comparable21 = timeSeries15.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (short) 0);
        java.util.Date date28 = fixedMillisecond23.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond23.previous();
        boolean boolean31 = fixedMillisecond23.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        java.lang.Comparable comparable39 = timeSeries33.getKey();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo44 = null;
        seriesChangeEvent43.setSummary(seriesChangeInfo44);
        boolean boolean46 = timeSeries41.equals((java.lang.Object) seriesChangeInfo44);
        java.lang.Comparable comparable47 = timeSeries41.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond49.getLastMillisecond(calendar50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (double) (short) 0);
        java.util.Date date54 = fixedMillisecond49.getTime();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        int int56 = month55.getMonth();
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month55, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) month55);
        org.jfree.data.general.SeriesException seriesException61 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException63 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray64 = seriesException63.getSuppressed();
        org.jfree.data.general.SeriesException seriesException66 = new org.jfree.data.general.SeriesException("");
        seriesException63.addSuppressed((java.lang.Throwable) seriesException66);
        seriesException61.addSuppressed((java.lang.Throwable) seriesException66);
        boolean boolean69 = timeSeries1.equals((java.lang.Object) seriesException61);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) -1 + "'", comparable21.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (short) -1 + "'", comparable39.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + (short) -1 + "'", comparable47.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 97L + "'", long51 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.fireSeriesChanged();
        timeSeries15.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries15);
        boolean boolean21 = fixedMillisecond6.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection24 = timeSeries23.getTimePeriods();
        timeSeries23.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
        java.util.Calendar calendar33 = null;
        fixedMillisecond28.peg(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) (short) 100);
        timeSeries23.add(timeSeriesDataItem36);
        timeSeries13.add(timeSeriesDataItem36, true);
        timeSeriesDataItem36.setValue((java.lang.Number) 1969);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month7.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        double double7 = timeSeries1.getMinY();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        double double4 = timeSeries1.getMaxY();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemAge((long) ' ');
        timeSeries14.removeAgedItems(false);
        timeSeries14.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date24 = fixedMillisecond23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 11);
        timeSeries14.add(timeSeriesDataItem27);
        timeSeries7.add(timeSeriesDataItem27, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries1.addChangeListener(seriesChangeListener32);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        java.util.Date date10 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        fixedMillisecond6.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 100);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.String str16 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        long long7 = year3.getFirstMillisecond();
        long long8 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        timeSeries10.setKey((java.lang.Comparable) 1L);
        timeSeries10.setDomainDescription("");
        java.lang.Class<?> wildcardClass16 = timeSeries10.getClass();
        timeSeries10.removeAgedItems(0L, false);
        int int20 = year3.compareTo((java.lang.Object) false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 2147483647);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.Year year9 = month7.getYear();
        long long10 = year9.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28799999L + "'", long10 == 28799999L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.Year year9 = month7.getYear();
        int int10 = month7.getYearValue();
        long long11 = month7.getLastMillisecond();
        long long12 = month7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-23731200001L) + "'", long11 == (-23731200001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-26409600000L) + "'", long12 == (-26409600000L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.next();
        long long44 = fixedMillisecond40.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 0, false);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener52);
        boolean boolean54 = timeSeries7.isEmpty();
        java.lang.Comparable comparable55 = timeSeries7.getKey();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + (short) -1 + "'", comparable55.equals((short) -1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        int int31 = timeSeries1.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries1.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        long long38 = fixedMillisecond35.getMiddleMillisecond();
        timeSeries1.setKey((java.lang.Comparable) long38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection42 = timeSeries41.getTimePeriods();
        timeSeries41.fireSeriesChanged();
        timeSeries41.setMaximumItemAge((long) ' ');
        timeSeries41.removeAgedItems(false);
        boolean boolean48 = timeSeries41.getNotify();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection51 = timeSeries50.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries50.removeChangeListener(seriesChangeListener52);
        boolean boolean54 = timeSeries50.getNotify();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo59 = null;
        seriesChangeEvent58.setSummary(seriesChangeInfo59);
        boolean boolean61 = timeSeries56.equals((java.lang.Object) seriesChangeInfo59);
        java.lang.Comparable comparable62 = timeSeries56.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond64.getLastMillisecond(calendar65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) (short) 0);
        java.util.Date date69 = fixedMillisecond64.getTime();
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date69);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date69);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond73.getLastMillisecond(calendar74);
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond73.getMiddleMillisecond(calendar76);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) month71, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) month71, (double) 1L);
        int int81 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = month71.next();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(collection51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + (short) -1 + "'", comparable62.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 97L + "'", long66 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 97L + "'", long75 == 97L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 97L + "'", long77 == 97L);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        long long23 = month22.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28799999L + "'", long23 == 28799999L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        double double7 = timeSeries1.getMaxY();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str17 = month15.toString();
        org.jfree.data.time.Year year18 = month15.getYear();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
        org.junit.Assert.assertNotNull(year18);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        int int15 = year10.getYear();
        java.lang.String str16 = year10.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries18.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection25 = timeSeries24.getTimePeriods();
        timeSeries24.fireSeriesChanged();
        timeSeries24.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries22.addAndOrUpdate(timeSeries24);
        boolean boolean30 = timeSeries18.equals((java.lang.Object) timeSeries24);
        java.util.List list31 = timeSeries24.getItems();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries24.createCopy(4, (int) ' ');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries34.addChangeListener(seriesChangeListener35);
        boolean boolean37 = year10.equals((java.lang.Object) seriesChangeListener35);
        long long38 = year10.getSerialIndex();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1969L + "'", long38 == 1969L);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date5 = fixedMillisecond4.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day9);
//        long long11 = day9.getLastMillisecond();
//        int int12 = day9.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8);
        java.lang.String str14 = day13.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-1969" + "'", str14.equals("31-December-1969"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.next();
        long long44 = fixedMillisecond40.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 0, false);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener52);
        int int54 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems((long) (short) -1, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date60 = fixedMillisecond59.getStart();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        java.util.Date date62 = year61.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        long long64 = day63.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day63, 0.0d);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 28799999L + "'", long64 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.fireSeriesChanged();
        timeSeries15.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries15);
        boolean boolean21 = fixedMillisecond6.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection24 = timeSeries23.getTimePeriods();
        timeSeries23.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
        java.util.Calendar calendar33 = null;
        fixedMillisecond28.peg(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) (short) 100);
        timeSeries23.add(timeSeriesDataItem36);
        timeSeries13.add(timeSeriesDataItem36, true);
        boolean boolean40 = timeSeriesDataItem36.isSelected();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        int int31 = timeSeries1.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries1.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        long long38 = fixedMillisecond35.getMiddleMillisecond();
        timeSeries1.setKey((java.lang.Comparable) long38);
        java.lang.Class class40 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
        org.junit.Assert.assertNotNull(class40);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.fireSeriesChanged();
        timeSeries16.setMaximumItemAge((long) ' ');
        timeSeries16.removeAgedItems(false);
        timeSeries16.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 11);
        timeSeries16.add(timeSeriesDataItem29);
        java.lang.Number number31 = timeSeriesDataItem29.getValue();
        timeSeries1.add(timeSeriesDataItem29);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection35 = timeSeries34.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries34.removeChangeListener(seriesChangeListener36);
        timeSeries34.removeAgedItems((long) 0, true);
        boolean boolean41 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo47 = null;
        seriesChangeEvent46.setSummary(seriesChangeInfo47);
        boolean boolean49 = timeSeries44.equals((java.lang.Object) seriesChangeInfo47);
        java.lang.Comparable comparable50 = timeSeries44.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) (short) 0);
        java.util.Date date57 = fixedMillisecond52.getTime();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.previous();
        timeSeries42.add(regularTimePeriod60, (double) 9, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 11 + "'", number31.equals(11));
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + (short) -1 + "'", comparable50.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 97L + "'", long54 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        seriesChangeEvent13.setSummary(seriesChangeInfo14);
        boolean boolean16 = timeSeries11.equals((java.lang.Object) seriesChangeInfo14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
        long long22 = fixedMillisecond18.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = null;
        seriesChangeEvent29.setSummary(seriesChangeInfo30);
        boolean boolean32 = timeSeries27.equals((java.lang.Object) seriesChangeInfo30);
        java.lang.Comparable comparable33 = timeSeries27.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) (short) 0);
        java.util.Date date40 = fixedMillisecond35.getTime();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 0);
        java.util.Collection collection46 = timeSeries25.getTimePeriods();
        java.lang.String str47 = timeSeries25.getDomainDescription();
        java.lang.String str48 = timeSeries25.getRangeDescription();
        timeSeries25.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        int int52 = month51.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month51, (double) (short) -1);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) -1 + "'", comparable33.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(collection46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Time" + "'", str47.equals("Time"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Value" + "'", str48.equals("Value"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        long long7 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.next();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent4.getSummary();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        seriesChangeEvent13.setSummary(seriesChangeInfo14);
        boolean boolean16 = timeSeries11.equals((java.lang.Object) seriesChangeInfo14);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.fireSeriesChanged();
        timeSeries18.setMaximumItemAge((long) ' ');
        timeSeries18.removeAgedItems(false);
        timeSeries18.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date28 = fixedMillisecond27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 11);
        timeSeries18.add(timeSeriesDataItem31);
        timeSeries11.add(timeSeriesDataItem31, true);
        timeSeriesDataItem31.setSelected(false);
        java.lang.Object obj37 = timeSeriesDataItem31.clone();
        timeSeries1.add(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        timeSeries6.setRangeDescription("");
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems((long) 0, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate(regularTimePeriod12, (java.lang.Number) 1560182982681L);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        int int31 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete((-9999), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        seriesChangeEvent20.setSummary(seriesChangeInfo21);
        boolean boolean23 = timeSeries18.equals((java.lang.Object) seriesChangeInfo21);
        java.lang.Comparable comparable24 = timeSeries18.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) (short) 0);
        java.util.Date date31 = fixedMillisecond26.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond35.getMiddleMillisecond(calendar38);
        java.util.Calendar calendar40 = null;
        fixedMillisecond35.peg(calendar40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date44 = fixedMillisecond43.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean48 = year45.equals((java.lang.Object) 'a');
        java.lang.String str49 = year45.toString();
        java.lang.String str50 = year45.toString();
        int int51 = fixedMillisecond35.compareTo((java.lang.Object) year45);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        long long53 = day32.getLastMillisecond();
        long long54 = day32.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean57 = timeSeries56.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date60 = fixedMillisecond59.getStart();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        java.util.Date date62 = year61.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) day63, (org.jfree.data.time.RegularTimePeriod) day64);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent69 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo70 = null;
        seriesChangeEvent69.setSummary(seriesChangeInfo70);
        boolean boolean72 = timeSeries67.equals((java.lang.Object) seriesChangeInfo70);
        java.lang.Comparable comparable73 = timeSeries67.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond75.getLastMillisecond(calendar76);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries67.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar82 = null;
        long long83 = fixedMillisecond81.getLastMillisecond(calendar82);
        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar86 = null;
        long long87 = fixedMillisecond85.getLastMillisecond(calendar86);
        long long88 = fixedMillisecond85.getMiddleMillisecond();
        long long89 = fixedMillisecond85.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries67.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond85);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81, 0.0d);
        boolean boolean93 = day32.equals((java.lang.Object) fixedMillisecond81);
        java.util.Calendar calendar94 = null;
        long long95 = fixedMillisecond81.getMiddleMillisecond(calendar94);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (short) -1 + "'", comparable24.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 97L + "'", long39 == 97L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1969" + "'", str50.equals("1969"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 28799999L + "'", long53 == 28799999L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-57600000L) + "'", long54 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + comparable73 + "' != '" + (short) -1 + "'", comparable73.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 97L + "'", long77 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 97L + "'", long83 == 97L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 97L + "'", long87 == 97L);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 97L + "'", long88 == 97L);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 97L + "'", long89 == 97L);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 97L + "'", long95 == 97L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        seriesChangeEvent20.setSummary(seriesChangeInfo21);
        boolean boolean23 = timeSeries18.equals((java.lang.Object) seriesChangeInfo21);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries27.removeChangeListener(seriesChangeListener29);
        java.util.Collection collection31 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        boolean boolean32 = fixedMillisecond10.equals((java.lang.Object) timeSeries18);
        long long33 = fixedMillisecond10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        java.lang.Comparable comparable18 = timeSeries12.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) (short) 0);
        java.util.Date date25 = fixedMillisecond20.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        int int27 = month26.getMonth();
        boolean boolean29 = month26.equals((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection32 = timeSeries31.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries31.removeChangeListener(seriesChangeListener33);
        boolean boolean35 = timeSeries31.getNotify();
        java.util.List list36 = timeSeries31.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date39 = fixedMillisecond38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.util.Date date41 = year40.getEnd();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) year40, (double) 3, false);
        int int45 = year40.getYear();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year40);
        int int47 = year40.getYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (short) -1 + "'", comparable18.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1969 + "'", int47 == 1969);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        long long19 = day18.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        long long22 = day18.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 1560182986783L);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25568L + "'", long19 == 25568L);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-57600000L) + "'", long22 == (-57600000L));
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        java.lang.Object obj16 = timeSeries7.clone();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass19 = seriesChangeEvent18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date23 = fixedMillisecond22.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        java.util.Date date25 = year24.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date25);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date25);
        timeSeries7.setKey((java.lang.Comparable) date25);
        double double33 = timeSeries7.getMinY();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
//        java.lang.Comparable comparable7 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        int int16 = month15.getMonth();
//        java.lang.String str17 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        boolean boolean20 = month15.equals((java.lang.Object) fixedMillisecond18);
//        int int21 = month15.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560183066782L + "'", long19 == 1560183066782L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getSerialIndex();
        int int12 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.next();
        int int19 = day10.compareTo((java.lang.Object) regularTimePeriod18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 1560183008493L);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = seriesChangeEvent22.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        seriesChangeEvent22.setSummary(seriesChangeInfo24);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNull(seriesChangeInfo23);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.lang.Comparable comparable21 = timeSeries15.getKey();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo26 = null;
        seriesChangeEvent25.setSummary(seriesChangeInfo26);
        boolean boolean28 = timeSeries23.equals((java.lang.Object) seriesChangeInfo26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
        long long34 = fixedMillisecond30.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo42 = null;
        seriesChangeEvent41.setSummary(seriesChangeInfo42);
        boolean boolean44 = timeSeries39.equals((java.lang.Object) seriesChangeInfo42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getLastMillisecond(calendar47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond46.next();
        long long50 = fixedMillisecond46.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 0, false);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, 0.0d, true);
        java.util.Calendar calendar60 = null;
        fixedMillisecond52.peg(calendar60);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 25568L);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo68 = null;
        seriesChangeEvent67.setSummary(seriesChangeInfo68);
        boolean boolean70 = timeSeries65.equals((java.lang.Object) seriesChangeInfo68);
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timeSeries65.removePropertyChangeListener(propertyChangeListener71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar75 = null;
        long long76 = fixedMillisecond74.getLastMillisecond(calendar75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond74.next();
        long long78 = fixedMillisecond74.getFirstMillisecond();
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (java.lang.Number) 1560183036380L);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) -1 + "'", comparable21.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 97L + "'", long48 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 97L + "'", long50 == 97L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 97L + "'", long76 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 97L + "'", long78 == 97L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem82);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        long long36 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 0, false);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d, true);
        java.util.Calendar calendar46 = null;
        fixedMillisecond38.peg(calendar46);
        java.util.Date date48 = fixedMillisecond38.getTime();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
        java.util.Date date50 = month49.getEnd();
        java.util.TimeZone timeZone51 = null;
        try {
            org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date50, timeZone51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date50);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        java.util.Collection collection36 = timeSeries15.getTimePeriods();
        java.lang.String str37 = timeSeries15.getDomainDescription();
        java.lang.String str38 = timeSeries15.getRangeDescription();
        timeSeries15.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        int int42 = month41.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month41, (double) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection47 = timeSeries46.getTimePeriods();
        timeSeries46.setKey((java.lang.Comparable) 1L);
        long long50 = timeSeries46.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries46.addChangeListener(seriesChangeListener51);
        timeSeries46.setDescription("org.jfree.data.event.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries15.addAndOrUpdate(timeSeries46);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 9223372036854775807L + "'", long50 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate5);
        timeSeries8.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        long long36 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 0, false);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d, true);
        java.lang.String str46 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(str46);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        long long15 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection27 = timeSeries26.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries26.removeChangeListener(seriesChangeListener28);
        java.util.Collection collection30 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        java.lang.String str31 = timeSeries17.getRangeDescription();
        timeSeries17.setDescription("org.jfree.data.general.SeriesException: December 1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date36 = fixedMillisecond35.getStart();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        long long38 = day37.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day37, (double) 9);
        int int43 = year10.compareTo((java.lang.Object) 9);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1969L + "'", long15 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 25568L + "'", long38 == 25568L);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        long long8 = day3.getLastMillisecond();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("10");
        int int11 = day3.compareTo((java.lang.Object) seriesException10);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        int int9 = day3.getMonth();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day3.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        int int31 = timeSeries1.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries1.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        long long38 = fixedMillisecond35.getMiddleMillisecond();
        timeSeries1.setKey((java.lang.Comparable) long38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection42 = timeSeries41.getTimePeriods();
        timeSeries41.fireSeriesChanged();
        timeSeries41.setMaximumItemAge((long) ' ');
        timeSeries41.removeAgedItems(false);
        boolean boolean48 = timeSeries41.getNotify();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection51 = timeSeries50.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries50.removeChangeListener(seriesChangeListener52);
        boolean boolean54 = timeSeries50.getNotify();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo59 = null;
        seriesChangeEvent58.setSummary(seriesChangeInfo59);
        boolean boolean61 = timeSeries56.equals((java.lang.Object) seriesChangeInfo59);
        java.lang.Comparable comparable62 = timeSeries56.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond64.getLastMillisecond(calendar65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) (short) 0);
        java.util.Date date69 = fixedMillisecond64.getTime();
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date69);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date69);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond73.getLastMillisecond(calendar74);
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond73.getMiddleMillisecond(calendar76);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) month71, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) month71, (double) 1L);
        int int81 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month71);
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(collection51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + (short) -1 + "'", comparable62.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 97L + "'", long66 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 97L + "'", long75 == 97L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 97L + "'", long77 == 97L);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        double double4 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        java.lang.Comparable comparable12 = timeSeries6.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) (short) 0);
        java.util.Date date19 = fixedMillisecond14.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond14.previous();
        boolean boolean22 = fixedMillisecond14.equals((java.lang.Object) (-1));
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 1560183010642L, false);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (short) -1 + "'", comparable12.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        java.util.Calendar calendar12 = null;
        try {
            year11.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        int int36 = month32.getMonth();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = month32.getLastMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        double double11 = timeSeries8.getMaxY();
        boolean boolean12 = year4.equals((java.lang.Object) double11);
        int int13 = year4.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(7, year4);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getMiddleMillisecond(calendar10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        seriesChangeEvent15.setSummary(seriesChangeInfo16);
        boolean boolean18 = timeSeries13.equals((java.lang.Object) seriesChangeInfo16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
        long long24 = fixedMillisecond20.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        seriesChangeEvent31.setSummary(seriesChangeInfo32);
        boolean boolean34 = timeSeries29.equals((java.lang.Object) seriesChangeInfo32);
        java.lang.Comparable comparable35 = timeSeries29.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) (short) 0);
        java.util.Date date42 = fixedMillisecond37.getTime();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 0);
        java.util.Collection collection48 = timeSeries27.getTimePeriods();
        java.lang.String str49 = timeSeries27.getDomainDescription();
        timeSeries27.setRangeDescription("Time");
        boolean boolean52 = fixedMillisecond1.equals((java.lang.Object) "Time");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (short) -1 + "'", comparable35.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 97L + "'", long39 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Time" + "'", str49.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.lang.String str14 = timeSeries1.getRangeDescription();
        java.lang.Object obj15 = timeSeries1.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getMiddleMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        fixedMillisecond17.peg(calendar22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) (short) 100);
        timeSeriesDataItem25.setValue((java.lang.Number) 100L);
        boolean boolean28 = timeSeriesDataItem25.isSelected();
        java.lang.Object obj29 = timeSeriesDataItem25.clone();
        java.lang.Number number30 = timeSeriesDataItem25.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.addOrUpdate(timeSeriesDataItem25);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        java.lang.Comparable comparable39 = timeSeries33.getKey();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo44 = null;
        seriesChangeEvent43.setSummary(seriesChangeInfo44);
        boolean boolean46 = timeSeries41.equals((java.lang.Object) seriesChangeInfo44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond48.getLastMillisecond(calendar49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond48.next();
        long long52 = fixedMillisecond48.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo60 = null;
        seriesChangeEvent59.setSummary(seriesChangeInfo60);
        boolean boolean62 = timeSeries57.equals((java.lang.Object) seriesChangeInfo60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond64.getLastMillisecond(calendar65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond64.next();
        long long68 = fixedMillisecond64.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond70);
        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (double) 0, false);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, 0.0d, true);
        java.util.Calendar calendar78 = null;
        fixedMillisecond70.peg(calendar78);
        java.util.Date date80 = fixedMillisecond70.getTime();
        long long81 = fixedMillisecond70.getMiddleMillisecond();
        try {
            boolean boolean82 = timeSeriesDataItem31.equals((java.lang.Object) fixedMillisecond70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 97L + "'", long19 == 97L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 100L + "'", number30.equals(100L));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (short) -1 + "'", comparable39.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 97L + "'", long50 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 97L + "'", long52 == 97L);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 97L + "'", long66 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 97L + "'", long68 == 97L);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 97L + "'", long81 == 97L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        seriesChangeEvent10.setSummary(seriesChangeInfo11);
        boolean boolean13 = timeSeries8.equals((java.lang.Object) seriesChangeInfo11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.fireSeriesChanged();
        timeSeries15.setMaximumItemAge((long) ' ');
        timeSeries15.removeAgedItems(false);
        timeSeries15.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 11);
        timeSeries15.add(timeSeriesDataItem28);
        timeSeries8.add(timeSeriesDataItem28, true);
        timeSeriesDataItem28.setSelected(false);
        timeSeries1.setKey((java.lang.Comparable) timeSeriesDataItem28);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass37 = seriesChangeEvent36.getClass();
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date41 = fixedMillisecond40.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        java.util.Date date43 = year42.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 0L);
        timeSeries1.add(timeSeriesDataItem48, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond52.next();
        long long56 = fixedMillisecond52.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (-31507200000L));
        java.lang.Number number59 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond52.getMiddleMillisecond(calendar60);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 97L + "'", long54 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 97L + "'", long56 == 97L);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 0L + "'", number59.equals(0L));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 97L + "'", long61 == 97L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        timeSeries1.removeAgedItems(0L, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.lang.Object obj7 = null;
        int int8 = day3.compareTo(obj7);
        int int9 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
//        java.lang.Comparable comparable7 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        int int16 = month15.getMonth();
//        java.lang.String str17 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        boolean boolean20 = month15.equals((java.lang.Object) fixedMillisecond18);
//        int int21 = month15.getMonth();
//        long long22 = month15.getSerialIndex();
//        long long23 = month15.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month15.next();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560183068717L + "'", long19 == 1560183068717L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 23640L + "'", long22 == 23640L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2649600000L) + "'", long23 == (-2649600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }
//}

